var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// packages/core/src/upstream-protocol.ts
function buildOpenAiCompatibleImagesUrl(baseUrl, suffix) {
  const base = baseUrl.trim().replace(/\/+$/, "");
  if (!base) {
    throw new Error("OpenAI images base URL is empty");
  }
  const lower = base.toLowerCase();
  const standardGenerations = /\/images\/generations$/i.test(lower);
  const standardEdits = /\/images\/edits$/i.test(lower);
  const vendorGenerations = /(?:^|\/)(?:openai-)?image-generations$/i.test(lower);
  const vendorEdits = /(?:^|\/)(?:openai-)?image-edits$/i.test(lower);
  if (standardGenerations) {
    return suffix === "generations" ? base : base.replace(/\/images\/generations$/i, "/images/edits");
  }
  if (standardEdits) {
    return suffix === "edits" ? base : base.replace(/\/images\/edits$/i, "/images/generations");
  }
  if (vendorGenerations) {
    if (suffix === "generations") {
      return base;
    }
    return base.replace(
      /(openai-)?image-generations$/i,
      (_m, openaiPrefix) => `${openaiPrefix ?? ""}image-edits`
    );
  }
  if (vendorEdits) {
    if (suffix === "edits") {
      return base;
    }
    return base.replace(
      /(openai-)?image-edits$/i,
      (_m, openaiPrefix) => `${openaiPrefix ?? ""}image-generations`
    );
  }
  return `${base}/images/${suffix}`;
}
var UPSTREAM_PROTOCOLS, PROTOCOL_LIST;
var init_upstream_protocol = __esm({
  "packages/core/src/upstream-protocol.ts"() {
    "use strict";
    UPSTREAM_PROTOCOLS = [
      "openai",
      "anthropic",
      "gemini",
      "dashscope"
    ];
    PROTOCOL_LIST = UPSTREAM_PROTOCOLS.join(", ");
  }
});

// packages/core/src/gemini-upstream-url.ts
function trimTrailingSlash(baseUrl) {
  return baseUrl.replace(/\/$/, "");
}
function geminiUpstreamBaseHasPathPrefix(baseUrl) {
  try {
    const pathname = new URL(baseUrl.trim()).pathname;
    return pathname !== "" && pathname !== "/";
  } catch {
    return false;
  }
}
function assertGeminiUpstreamBaseUrl(baseUrl) {
  const trimmed = baseUrl.trim();
  if (!trimmed) {
    throw new Error(
      "Gemini upstream base URL is empty (configure providers.endpoints.gemini.base with full path prefix)"
    );
  }
  if (!geminiUpstreamBaseHasPathPrefix(trimmed)) {
    throw new Error(
      "Gemini upstream base URL must include path prefix before {model} (e.g. .../v1beta/models for Developer API, .../v1/publishers/google/models for Vertex Express)"
    );
  }
}
function buildGeminiUpstreamActionUrl(baseUrl, modelName, action) {
  assertGeminiUpstreamBaseUrl(baseUrl);
  const base = normalizeGeminiUpstreamBaseForAuthMatch(baseUrl);
  const modelSegment = `${encodeURIComponent(modelName)}:${action}`;
  return `${base}/${modelSegment}`;
}
function normalizeGeminiUpstreamBaseForAuthMatch(baseUrl) {
  const trimmed = baseUrl.trim();
  try {
    const u = new URL(trimmed);
    u.hostname = u.hostname.toLowerCase();
    const path = u.pathname.replace(/\/+/g, "/").replace(/\/$/, "") || "";
    return `${u.protocol}//${u.host}${path}`;
  } catch {
    return trimTrailingSlash(trimmed);
  }
}
var init_gemini_upstream_url = __esm({
  "packages/core/src/gemini-upstream-url.ts"() {
    "use strict";
  }
});

// packages/core/src/route-topology.ts
function canonicalizeRequestOperation(protocol2, operation) {
  const op = operation.trim();
  if (protocol2.trim().toLowerCase() !== "gemini") return op;
  if (op === GEMINI_GENERATE_OPERATION || GEMINI_LEGACY_GENERATE_OPERATIONS.includes(op)) {
    return GEMINI_GENERATE_OPERATION;
  }
  return op;
}
var GEMINI_GENERATE_OPERATION, GEMINI_LEGACY_GENERATE_OPERATIONS;
var init_route_topology = __esm({
  "packages/core/src/route-topology.ts"() {
    "use strict";
    GEMINI_GENERATE_OPERATION = "models.generate";
    GEMINI_LEGACY_GENERATE_OPERATIONS = [
      "generateContent",
      "streamGenerateContent"
    ];
  }
});

// packages/core/src/provider-endpoints.ts
function trimSlash(url) {
  return url.replace(/\/+$/, "");
}
function fillEndpointTemplate(template, vars) {
  return template.replace(/\{model\}/g, () => encodeURIComponent(vars.model ?? "")).replace(/\{action\}/g, () => encodeURIComponent(vars.action ?? "")).replace(/\{task_id\}/g, () => encodeURIComponent(vars.taskId ?? ""));
}
function resolveGeminiWireAction(capability, options) {
  const fromOptions = options.action?.trim();
  if (fromOptions === "generateContent" || fromOptions === "streamGenerateContent") {
    return fromOptions;
  }
  if (capability === "generateContent" || capability === "streamGenerateContent") {
    return capability;
  }
  throw new Error(
    "Gemini upstream endpoint requires action (generateContent or streamGenerateContent)"
  );
}
function buildDashScopeWebSocketUrl(base, endpoint) {
  const url = new URL(base);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = `/api-ws/v1/${endpoint}`;
  url.search = "";
  url.hash = "";
  return url.toString();
}
function resolveUpstreamEndpoint(protocol2, capability, providerEndpoints, options = {}) {
  const canonicalCapability = canonicalizeRequestOperation(
    protocol2,
    capability
  );
  const writable = WRITABLE_CAPABILITIES_BY_PROTOCOL[protocol2];
  if (!writable.includes(capability) && !CAPABILITIES_BY_PROTOCOL[protocol2].includes(canonicalCapability)) {
    throw new Error(
      `Capability ${JSON.stringify(capability)} is not valid for protocol "${protocol2}"`
    );
  }
  const cfg = providerEndpoints[protocol2];
  if (protocol2 === "gemini") {
    const action = resolveGeminiWireAction(capability, options);
    const model = options.model;
    const familyTemplate = cfg?.endpoints?.[GEMINI_GENERATE_OPERATION];
    if (familyTemplate) {
      if (!model) throw new Error("Gemini upstream endpoint requires model name");
      return fillEndpointTemplate(familyTemplate, { model, action });
    }
    const legacyTemplate = cfg?.endpoints?.[action];
    if (legacyTemplate) {
      if (!model) throw new Error("Gemini upstream endpoint requires model name");
      return fillEndpointTemplate(legacyTemplate, { model, action });
    }
    const base2 = cfg?.base;
    if (base2) {
      if (!model) throw new Error("Gemini upstream endpoint requires model name");
      return buildGeminiUpstreamActionUrl(trimSlash(base2), model, action);
    }
    const who2 = options.providerId != null && options.providerId !== "" ? `provider_id=${JSON.stringify(options.providerId)}` : "provider";
    throw new Error(
      `${who2}: no upstream endpoint for protocol "gemini" capability "${GEMINI_GENERATE_OPERATION}" (configure providers.endpoints.gemini)`
    );
  }
  const resolvedCapability = canonicalCapability;
  const allowed = CAPABILITIES_BY_PROTOCOL[protocol2];
  if (!allowed.includes(resolvedCapability)) {
    throw new Error(
      `Capability ${JSON.stringify(capability)} is not valid for protocol "${protocol2}"`
    );
  }
  const template = cfg?.endpoints?.[resolvedCapability];
  if (template) {
    if (resolvedCapability === "audio.transcriptions.tasks" && !options.taskId) {
      throw new Error("DashScope task endpoint requires taskId");
    }
    return fillEndpointTemplate(template, {
      model: options.model,
      action: options.action,
      taskId: options.taskId
    });
  }
  const base = cfg?.base;
  if (base) {
    const root = trimSlash(base);
    switch (resolvedCapability) {
      case "chat":
        return `${root}/chat/completions`;
      case "responses":
        return `${root}/responses`;
      case "embeddings":
        return `${root}/embeddings`;
      case "rerank":
        return `${root}/rerank`;
      case "images.generations":
        return buildOpenAiCompatibleImagesUrl(root, "generations");
      case "images.edits":
        return buildOpenAiCompatibleImagesUrl(root, "edits");
      case "audio.transcriptions":
        return protocol2 === "dashscope" ? `${root}/services/audio/asr/transcription` : `${root}/audio/transcriptions`;
      case "audio.transcriptions.multimodal":
        return `${root}/services/aigc/multimodal-generation/generation`;
      case "audio.transcriptions.tasks":
        if (!options.taskId) {
          throw new Error("DashScope task endpoint requires taskId");
        }
        return `${root}/tasks/${encodeURIComponent(options.taskId)}`;
      case "audio.speech":
        return protocol2 === "dashscope" ? `${root}/services/audio/tts/SpeechSynthesizer` : `${root}/audio/speech`;
      case "audio.speech.multimodal":
        return `${root}/services/aigc/multimodal-generation/generation`;
      case "audio.realtime.inference":
        return buildDashScopeWebSocketUrl(root, "inference");
      case "audio.realtime.session":
        return buildDashScopeWebSocketUrl(root, "realtime");
      case "audio.hotwords":
        return `${root}/services/audio/asr/customization`;
      case "audio.voices":
        return `${root}/services/audio/tts/customization`;
      case "messages":
        return `${root}/v1/messages`;
      default: {
        throw new Error(`Unhandled capability: ${JSON.stringify(resolvedCapability)}`);
      }
    }
  }
  const who = options.providerId != null && options.providerId !== "" ? `provider_id=${JSON.stringify(options.providerId)}` : "provider";
  throw new Error(
    `${who}: no upstream endpoint for protocol "${protocol2}" capability "${resolvedCapability}" (configure providers.endpoints.${protocol2})`
  );
}
var OPENAI_ENDPOINT_CAPABILITIES, ANTHROPIC_ENDPOINT_CAPABILITIES, GEMINI_ENDPOINT_CAPABILITIES, GEMINI_LEGACY_ENDPOINT_CAPABILITIES, DASHSCOPE_ENDPOINT_CAPABILITIES, CAPABILITIES_BY_PROTOCOL, ENDPOINT_CAPABILITIES_BY_OPERATION, WRITABLE_CAPABILITIES_BY_PROTOCOL, ALL_CAPABILITIES;
var init_provider_endpoints = __esm({
  "packages/core/src/provider-endpoints.ts"() {
    "use strict";
    init_gemini_upstream_url();
    init_route_topology();
    init_upstream_protocol();
    OPENAI_ENDPOINT_CAPABILITIES = [
      "chat",
      "responses",
      "embeddings",
      "rerank",
      "images.generations",
      "images.edits",
      "audio.transcriptions",
      "audio.speech"
    ];
    ANTHROPIC_ENDPOINT_CAPABILITIES = ["messages"];
    GEMINI_ENDPOINT_CAPABILITIES = [
      GEMINI_GENERATE_OPERATION
    ];
    GEMINI_LEGACY_ENDPOINT_CAPABILITIES = [
      ...GEMINI_LEGACY_GENERATE_OPERATIONS
    ];
    DASHSCOPE_ENDPOINT_CAPABILITIES = [
      "audio.transcriptions",
      "audio.transcriptions.multimodal",
      "audio.transcriptions.tasks",
      "audio.speech",
      "audio.speech.multimodal",
      "audio.realtime.inference",
      "audio.realtime.session",
      "audio.hotwords",
      "audio.voices"
    ];
    CAPABILITIES_BY_PROTOCOL = {
      openai: OPENAI_ENDPOINT_CAPABILITIES,
      anthropic: ANTHROPIC_ENDPOINT_CAPABILITIES,
      gemini: GEMINI_ENDPOINT_CAPABILITIES,
      dashscope: DASHSCOPE_ENDPOINT_CAPABILITIES
    };
    ENDPOINT_CAPABILITIES_BY_OPERATION = {
      openai: {
        chat: ["chat"],
        responses: ["responses"],
        embeddings: ["embeddings"],
        rerank: ["rerank"],
        "images.generations": ["images.generations"],
        "images.edits": ["images.edits"],
        "audio.transcriptions": ["audio.transcriptions"],
        "audio.speech": ["audio.speech"]
      },
      anthropic: {
        messages: ["messages"]
      },
      gemini: {
        [GEMINI_GENERATE_OPERATION]: [GEMINI_GENERATE_OPERATION]
      },
      dashscope: {
        "audio.transcriptions": ["audio.transcriptions"],
        "audio.transcriptions.multimodal": ["audio.transcriptions.multimodal"],
        "audio.transcriptions.async": [
          "audio.transcriptions",
          "audio.transcriptions.tasks"
        ],
        "audio.transcriptions.realtime.inference": ["audio.realtime.inference"],
        "audio.transcriptions.realtime.session": ["audio.realtime.session"],
        "audio.speech": ["audio.speech"],
        // SpeechSynthesizer streaming uses the same HTTP/SSE endpoint.
        "audio.speech.stream": ["audio.speech"],
        "audio.speech.multimodal": ["audio.speech.multimodal"],
        "audio.speech.realtime.inference": ["audio.realtime.inference"],
        "audio.speech.realtime.session": ["audio.realtime.session"]
      }
    };
    WRITABLE_CAPABILITIES_BY_PROTOCOL = {
      openai: OPENAI_ENDPOINT_CAPABILITIES,
      anthropic: ANTHROPIC_ENDPOINT_CAPABILITIES,
      gemini: [...GEMINI_ENDPOINT_CAPABILITIES, ...GEMINI_LEGACY_ENDPOINT_CAPABILITIES],
      dashscope: DASHSCOPE_ENDPOINT_CAPABILITIES
    };
    ALL_CAPABILITIES = /* @__PURE__ */ new Set([
      ...OPENAI_ENDPOINT_CAPABILITIES,
      ...ANTHROPIC_ENDPOINT_CAPABILITIES,
      ...GEMINI_ENDPOINT_CAPABILITIES,
      ...GEMINI_LEGACY_ENDPOINT_CAPABILITIES,
      ...DASHSCOPE_ENDPOINT_CAPABILITIES
    ]);
  }
});

// packages/core/src/preparation-control.ts
var init_preparation_control = __esm({
  "packages/core/src/preparation-control.ts"() {
    "use strict";
  }
});

// packages/core/src/route-data-policy.ts
var init_route_data_policy = __esm({
  "packages/core/src/route-data-policy.ts"() {
    "use strict";
    init_provider_endpoints();
  }
});

// packages/core/src/db/guardrail-budget-types.ts
var init_guardrail_budget_types = __esm({
  "packages/core/src/db/guardrail-budget-types.ts"() {
    "use strict";
  }
});

// packages/core/src/gateway-key-limits.ts
var init_gateway_key_limits = __esm({
  "packages/core/src/gateway-key-limits.ts"() {
    "use strict";
    init_guardrail_budget_types();
  }
});

// packages/core/src/workspace-budgets.ts
var init_workspace_budgets = __esm({
  "packages/core/src/workspace-budgets.ts"() {
    "use strict";
    init_guardrail_budget_types();
    init_gateway_key_limits();
  }
});

// packages/core/src/workspaces.ts
var init_workspaces = __esm({
  "packages/core/src/workspaces.ts"() {
    "use strict";
  }
});

// node_modules/drizzle-orm/entity.js
function is(value, type) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (value instanceof type) {
    return true;
  }
  if (!Object.prototype.hasOwnProperty.call(type, entityKind)) {
    throw new Error(
      `Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`
    );
  }
  let cls = Object.getPrototypeOf(value).constructor;
  if (cls) {
    while (cls) {
      if (entityKind in cls && cls[entityKind] === type[entityKind]) {
        return true;
      }
      cls = Object.getPrototypeOf(cls);
    }
  }
  return false;
}
var entityKind;
var init_entity = __esm({
  "node_modules/drizzle-orm/entity.js"() {
    entityKind = /* @__PURE__ */ Symbol.for("drizzle:entityKind");
  }
});

// node_modules/drizzle-orm/logger.js
var ConsoleLogWriter, DefaultLogger, NoopLogger;
var init_logger = __esm({
  "node_modules/drizzle-orm/logger.js"() {
    init_entity();
    ConsoleLogWriter = class {
      static [entityKind] = "ConsoleLogWriter";
      write(message) {
        console.log(message);
      }
    };
    DefaultLogger = class {
      static [entityKind] = "DefaultLogger";
      writer;
      constructor(config) {
        this.writer = config?.writer ?? new ConsoleLogWriter();
      }
      logQuery(query, params) {
        const stringifiedParams = params.map((p) => {
          try {
            return JSON.stringify(p);
          } catch {
            return String(p);
          }
        });
        const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
        this.writer.write(`Query: ${query}${paramsStr}`);
      }
    };
    NoopLogger = class {
      static [entityKind] = "NoopLogger";
      logQuery() {
      }
    };
  }
});

// node_modules/drizzle-orm/table.utils.js
var TableName;
var init_table_utils = __esm({
  "node_modules/drizzle-orm/table.utils.js"() {
    TableName = /* @__PURE__ */ Symbol.for("drizzle:Name");
  }
});

// node_modules/drizzle-orm/table.js
function getTableName(table) {
  return table[TableName];
}
function getTableUniqueName(table) {
  return `${table[Schema] ?? "public"}.${table[TableName]}`;
}
var Schema, Columns, ExtraConfigColumns, OriginalName, BaseName, IsAlias, ExtraConfigBuilder, IsDrizzleTable, Table;
var init_table = __esm({
  "node_modules/drizzle-orm/table.js"() {
    init_entity();
    init_table_utils();
    Schema = /* @__PURE__ */ Symbol.for("drizzle:Schema");
    Columns = /* @__PURE__ */ Symbol.for("drizzle:Columns");
    ExtraConfigColumns = /* @__PURE__ */ Symbol.for("drizzle:ExtraConfigColumns");
    OriginalName = /* @__PURE__ */ Symbol.for("drizzle:OriginalName");
    BaseName = /* @__PURE__ */ Symbol.for("drizzle:BaseName");
    IsAlias = /* @__PURE__ */ Symbol.for("drizzle:IsAlias");
    ExtraConfigBuilder = /* @__PURE__ */ Symbol.for("drizzle:ExtraConfigBuilder");
    IsDrizzleTable = /* @__PURE__ */ Symbol.for("drizzle:IsDrizzleTable");
    Table = class {
      static [entityKind] = "Table";
      /** @internal */
      static Symbol = {
        Name: TableName,
        Schema,
        OriginalName,
        Columns,
        ExtraConfigColumns,
        BaseName,
        IsAlias,
        ExtraConfigBuilder
      };
      /**
       * @internal
       * Can be changed if the table is aliased.
       */
      [TableName];
      /**
       * @internal
       * Used to store the original name of the table, before any aliasing.
       */
      [OriginalName];
      /** @internal */
      [Schema];
      /** @internal */
      [Columns];
      /** @internal */
      [ExtraConfigColumns];
      /**
       *  @internal
       * Used to store the table name before the transformation via the `tableCreator` functions.
       */
      [BaseName];
      /** @internal */
      [IsAlias] = false;
      /** @internal */
      [IsDrizzleTable] = true;
      /** @internal */
      [ExtraConfigBuilder] = void 0;
      constructor(name, schema, baseName) {
        this[TableName] = this[OriginalName] = name;
        this[Schema] = schema;
        this[BaseName] = baseName;
      }
    };
  }
});

// node_modules/drizzle-orm/column.js
var Column;
var init_column = __esm({
  "node_modules/drizzle-orm/column.js"() {
    init_entity();
    Column = class {
      constructor(table, config) {
        this.table = table;
        this.config = config;
        this.name = config.name;
        this.keyAsName = config.keyAsName;
        this.notNull = config.notNull;
        this.default = config.default;
        this.defaultFn = config.defaultFn;
        this.onUpdateFn = config.onUpdateFn;
        this.hasDefault = config.hasDefault;
        this.primary = config.primaryKey;
        this.isUnique = config.isUnique;
        this.uniqueName = config.uniqueName;
        this.uniqueType = config.uniqueType;
        this.dataType = config.dataType;
        this.columnType = config.columnType;
        this.generated = config.generated;
        this.generatedIdentity = config.generatedIdentity;
      }
      static [entityKind] = "Column";
      name;
      keyAsName;
      primary;
      notNull;
      default;
      defaultFn;
      onUpdateFn;
      hasDefault;
      isUnique;
      uniqueName;
      uniqueType;
      dataType;
      columnType;
      enumValues = void 0;
      generated = void 0;
      generatedIdentity = void 0;
      config;
      mapFromDriverValue(value) {
        return value;
      }
      mapToDriverValue(value) {
        return value;
      }
      // ** @internal */
      shouldDisableInsert() {
        return this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
      }
    };
  }
});

// node_modules/drizzle-orm/column-builder.js
var ColumnBuilder;
var init_column_builder = __esm({
  "node_modules/drizzle-orm/column-builder.js"() {
    init_entity();
    ColumnBuilder = class {
      static [entityKind] = "ColumnBuilder";
      config;
      constructor(name, dataType, columnType) {
        this.config = {
          name,
          keyAsName: name === "",
          notNull: false,
          default: void 0,
          hasDefault: false,
          primaryKey: false,
          isUnique: false,
          uniqueName: void 0,
          uniqueType: void 0,
          dataType,
          columnType,
          generated: void 0
        };
      }
      /**
       * Changes the data type of the column. Commonly used with `json` columns. Also, useful for branded types.
       *
       * @example
       * ```ts
       * const users = pgTable('users', {
       * 	id: integer('id').$type<UserId>().primaryKey(),
       * 	details: json('details').$type<UserDetails>().notNull(),
       * });
       * ```
       */
      $type() {
        return this;
      }
      /**
       * Adds a `not null` clause to the column definition.
       *
       * Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
       */
      notNull() {
        this.config.notNull = true;
        return this;
      }
      /**
       * Adds a `default <value>` clause to the column definition.
       *
       * Affects the `insert` model of the table - columns *with* `default` are optional on insert.
       *
       * If you need to set a dynamic default value, use {@link $defaultFn} instead.
       */
      default(value) {
        this.config.default = value;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Adds a dynamic default value to the column.
       * The function will be called when the row is inserted, and the returned value will be used as the column value.
       *
       * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
       */
      $defaultFn(fn) {
        this.config.defaultFn = fn;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Alias for {@link $defaultFn}.
       */
      $default = this.$defaultFn;
      /**
       * Adds a dynamic update value to the column.
       * The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
       * If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
       *
       * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
       */
      $onUpdateFn(fn) {
        this.config.onUpdateFn = fn;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Alias for {@link $onUpdateFn}.
       */
      $onUpdate = this.$onUpdateFn;
      /**
       * Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
       *
       * In SQLite, `integer primary key` implicitly makes the column auto-incrementing.
       */
      primaryKey() {
        this.config.primaryKey = true;
        this.config.notNull = true;
        return this;
      }
      /** @internal Sets the name of the column to the key within the table definition if a name was not given. */
      setName(name) {
        if (this.config.name !== "") return;
        this.config.name = name;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/foreign-keys.js
var ForeignKeyBuilder, ForeignKey;
var init_foreign_keys = __esm({
  "node_modules/drizzle-orm/pg-core/foreign-keys.js"() {
    init_entity();
    init_table_utils();
    ForeignKeyBuilder = class {
      static [entityKind] = "PgForeignKeyBuilder";
      /** @internal */
      reference;
      /** @internal */
      _onUpdate = "no action";
      /** @internal */
      _onDelete = "no action";
      constructor(config, actions) {
        this.reference = () => {
          const { name, columns, foreignColumns } = config();
          return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
        };
        if (actions) {
          this._onUpdate = actions.onUpdate;
          this._onDelete = actions.onDelete;
        }
      }
      onUpdate(action) {
        this._onUpdate = action === void 0 ? "no action" : action;
        return this;
      }
      onDelete(action) {
        this._onDelete = action === void 0 ? "no action" : action;
        return this;
      }
      /** @internal */
      build(table) {
        return new ForeignKey(table, this);
      }
    };
    ForeignKey = class {
      constructor(table, builder) {
        this.table = table;
        this.reference = builder.reference;
        this.onUpdate = builder._onUpdate;
        this.onDelete = builder._onDelete;
      }
      static [entityKind] = "PgForeignKey";
      reference;
      onUpdate;
      onDelete;
      getName() {
        const { name, columns, foreignColumns } = this.reference();
        const columnNames = columns.map((column) => column.name);
        const foreignColumnNames = foreignColumns.map((column) => column.name);
        const chunks = [
          this.table[TableName],
          ...columnNames,
          foreignColumns[0].table[TableName],
          ...foreignColumnNames
        ];
        return name ?? `${chunks.join("_")}_fk`;
      }
    };
  }
});

// node_modules/drizzle-orm/tracing-utils.js
function iife(fn, ...args) {
  return fn(...args);
}
var init_tracing_utils = __esm({
  "node_modules/drizzle-orm/tracing-utils.js"() {
  }
});

// node_modules/drizzle-orm/pg-core/unique-constraint.js
function uniqueKeyName(table, columns) {
  return `${table[TableName]}_${columns.join("_")}_unique`;
}
var UniqueConstraintBuilder, UniqueOnConstraintBuilder, UniqueConstraint;
var init_unique_constraint = __esm({
  "node_modules/drizzle-orm/pg-core/unique-constraint.js"() {
    init_entity();
    init_table_utils();
    UniqueConstraintBuilder = class {
      constructor(columns, name) {
        this.name = name;
        this.columns = columns;
      }
      static [entityKind] = "PgUniqueConstraintBuilder";
      /** @internal */
      columns;
      /** @internal */
      nullsNotDistinctConfig = false;
      nullsNotDistinct() {
        this.nullsNotDistinctConfig = true;
        return this;
      }
      /** @internal */
      build(table) {
        return new UniqueConstraint(table, this.columns, this.nullsNotDistinctConfig, this.name);
      }
    };
    UniqueOnConstraintBuilder = class {
      static [entityKind] = "PgUniqueOnConstraintBuilder";
      /** @internal */
      name;
      constructor(name) {
        this.name = name;
      }
      on(...columns) {
        return new UniqueConstraintBuilder(columns, this.name);
      }
    };
    UniqueConstraint = class {
      constructor(table, columns, nullsNotDistinct, name) {
        this.table = table;
        this.columns = columns;
        this.name = name ?? uniqueKeyName(this.table, this.columns.map((column) => column.name));
        this.nullsNotDistinct = nullsNotDistinct;
      }
      static [entityKind] = "PgUniqueConstraint";
      columns;
      name;
      nullsNotDistinct = false;
      getName() {
        return this.name;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/utils/array.js
function parsePgArrayValue(arrayString, startFrom, inQuotes) {
  for (let i = startFrom; i < arrayString.length; i++) {
    const char3 = arrayString[i];
    if (char3 === "\\") {
      i++;
      continue;
    }
    if (char3 === '"') {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i + 1];
    }
    if (inQuotes) {
      continue;
    }
    if (char3 === "," || char3 === "}") {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i];
    }
  }
  return [arrayString.slice(startFrom).replace(/\\/g, ""), arrayString.length];
}
function parsePgNestedArray(arrayString, startFrom = 0) {
  const result = [];
  let i = startFrom;
  let lastCharIsComma = false;
  while (i < arrayString.length) {
    const char3 = arrayString[i];
    if (char3 === ",") {
      if (lastCharIsComma || i === startFrom) {
        result.push("");
      }
      lastCharIsComma = true;
      i++;
      continue;
    }
    lastCharIsComma = false;
    if (char3 === "\\") {
      i += 2;
      continue;
    }
    if (char3 === '"') {
      const [value2, startFrom2] = parsePgArrayValue(arrayString, i + 1, true);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    if (char3 === "}") {
      return [result, i + 1];
    }
    if (char3 === "{") {
      const [value2, startFrom2] = parsePgNestedArray(arrayString, i + 1);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    const [value, newStartFrom] = parsePgArrayValue(arrayString, i, false);
    result.push(value);
    i = newStartFrom;
  }
  return [result, i];
}
function parsePgArray(arrayString) {
  const [result] = parsePgNestedArray(arrayString, 1);
  return result;
}
function makePgArray(array2) {
  return `{${array2.map((item) => {
    if (Array.isArray(item)) {
      return makePgArray(item);
    }
    if (typeof item === "string") {
      return `"${item.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
    }
    return `${item}`;
  }).join(",")}}`;
}
var init_array = __esm({
  "node_modules/drizzle-orm/pg-core/utils/array.js"() {
  }
});

// node_modules/drizzle-orm/pg-core/columns/common.js
var PgColumnBuilder, PgColumn, ExtraConfigColumn, IndexedColumn, PgArrayBuilder, PgArray;
var init_common = __esm({
  "node_modules/drizzle-orm/pg-core/columns/common.js"() {
    init_column_builder();
    init_column();
    init_entity();
    init_foreign_keys();
    init_tracing_utils();
    init_unique_constraint();
    init_array();
    PgColumnBuilder = class extends ColumnBuilder {
      foreignKeyConfigs = [];
      static [entityKind] = "PgColumnBuilder";
      array(size) {
        return new PgArrayBuilder(this.config.name, this, size);
      }
      references(ref, actions = {}) {
        this.foreignKeyConfigs.push({ ref, actions });
        return this;
      }
      unique(name, config) {
        this.config.isUnique = true;
        this.config.uniqueName = name;
        this.config.uniqueType = config?.nulls;
        return this;
      }
      generatedAlwaysAs(as) {
        this.config.generated = {
          as,
          type: "always",
          mode: "stored"
        };
        return this;
      }
      /** @internal */
      buildForeignKeys(column, table) {
        return this.foreignKeyConfigs.map(({ ref, actions }) => {
          return iife(
            (ref2, actions2) => {
              const builder = new ForeignKeyBuilder(() => {
                const foreignColumn = ref2();
                return { columns: [column], foreignColumns: [foreignColumn] };
              });
              if (actions2.onUpdate) {
                builder.onUpdate(actions2.onUpdate);
              }
              if (actions2.onDelete) {
                builder.onDelete(actions2.onDelete);
              }
              return builder.build(table);
            },
            ref,
            actions
          );
        });
      }
      /** @internal */
      buildExtraConfigColumn(table) {
        return new ExtraConfigColumn(table, this.config);
      }
    };
    PgColumn = class extends Column {
      constructor(table, config) {
        if (!config.uniqueName) {
          config.uniqueName = uniqueKeyName(table, [config.name]);
        }
        super(table, config);
        this.table = table;
      }
      static [entityKind] = "PgColumn";
    };
    ExtraConfigColumn = class extends PgColumn {
      static [entityKind] = "ExtraConfigColumn";
      getSQLType() {
        return this.getSQLType();
      }
      indexConfig = {
        order: this.config.order ?? "asc",
        nulls: this.config.nulls ?? "last",
        opClass: this.config.opClass
      };
      defaultConfig = {
        order: "asc",
        nulls: "last",
        opClass: void 0
      };
      asc() {
        this.indexConfig.order = "asc";
        return this;
      }
      desc() {
        this.indexConfig.order = "desc";
        return this;
      }
      nullsFirst() {
        this.indexConfig.nulls = "first";
        return this;
      }
      nullsLast() {
        this.indexConfig.nulls = "last";
        return this;
      }
      /**
       * ### PostgreSQL documentation quote
       *
       * > An operator class with optional parameters can be specified for each column of an index.
       * The operator class identifies the operators to be used by the index for that column.
       * For example, a B-tree index on four-byte integers would use the int4_ops class;
       * this operator class includes comparison functions for four-byte integers.
       * In practice the default operator class for the column's data type is usually sufficient.
       * The main point of having operator classes is that for some data types, there could be more than one meaningful ordering.
       * For example, we might want to sort a complex-number data type either by absolute value or by real part.
       * We could do this by defining two operator classes for the data type and then selecting the proper class when creating an index.
       * More information about operator classes check:
       *
       * ### Useful links
       * https://www.postgresql.org/docs/current/sql-createindex.html
       *
       * https://www.postgresql.org/docs/current/indexes-opclass.html
       *
       * https://www.postgresql.org/docs/current/xindex.html
       *
       * ### Additional types
       * If you have the `pg_vector` extension installed in your database, you can use the
       * `vector_l2_ops`, `vector_ip_ops`, `vector_cosine_ops`, `vector_l1_ops`, `bit_hamming_ops`, `bit_jaccard_ops`, `halfvec_l2_ops`, `sparsevec_l2_ops` options, which are predefined types.
       *
       * **You can always specify any string you want in the operator class, in case Drizzle doesn't have it natively in its types**
       *
       * @param opClass
       * @returns
       */
      op(opClass) {
        this.indexConfig.opClass = opClass;
        return this;
      }
    };
    IndexedColumn = class {
      static [entityKind] = "IndexedColumn";
      constructor(name, keyAsName, type, indexConfig) {
        this.name = name;
        this.keyAsName = keyAsName;
        this.type = type;
        this.indexConfig = indexConfig;
      }
      name;
      keyAsName;
      type;
      indexConfig;
    };
    PgArrayBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgArrayBuilder";
      constructor(name, baseBuilder, size) {
        super(name, "array", "PgArray");
        this.config.baseBuilder = baseBuilder;
        this.config.size = size;
      }
      /** @internal */
      build(table) {
        const baseColumn = this.config.baseBuilder.build(table);
        return new PgArray(
          table,
          this.config,
          baseColumn
        );
      }
    };
    PgArray = class _PgArray extends PgColumn {
      constructor(table, config, baseColumn, range) {
        super(table, config);
        this.baseColumn = baseColumn;
        this.range = range;
        this.size = config.size;
      }
      size;
      static [entityKind] = "PgArray";
      getSQLType() {
        return `${this.baseColumn.getSQLType()}[${typeof this.size === "number" ? this.size : ""}]`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          value = parsePgArray(value);
        }
        return value.map((v) => this.baseColumn.mapFromDriverValue(v));
      }
      mapToDriverValue(value, isNestedArray = false) {
        const a = value.map(
          (v) => v === null ? null : is(this.baseColumn, _PgArray) ? this.baseColumn.mapToDriverValue(v, true) : this.baseColumn.mapToDriverValue(v)
        );
        if (isNestedArray) return a;
        return makePgArray(a);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/enum.js
function isPgEnum(obj) {
  return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
}
function pgEnumWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: values,
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
function pgEnumObjectWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumObjectColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: Object.values(values),
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
var PgEnumObjectColumnBuilder, PgEnumObjectColumn, isPgEnumSym, PgEnumColumnBuilder, PgEnumColumn;
var init_enum = __esm({
  "node_modules/drizzle-orm/pg-core/columns/enum.js"() {
    init_entity();
    init_common();
    PgEnumObjectColumnBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgEnumObjectColumnBuilder";
      constructor(name, enumInstance) {
        super(name, "string", "PgEnumObjectColumn");
        this.config.enum = enumInstance;
      }
      /** @internal */
      build(table) {
        return new PgEnumObjectColumn(
          table,
          this.config
        );
      }
    };
    PgEnumObjectColumn = class extends PgColumn {
      static [entityKind] = "PgEnumObjectColumn";
      enum;
      enumValues = this.config.enum.enumValues;
      constructor(table, config) {
        super(table, config);
        this.enum = config.enum;
      }
      getSQLType() {
        return this.enum.enumName;
      }
    };
    isPgEnumSym = /* @__PURE__ */ Symbol.for("drizzle:isPgEnum");
    PgEnumColumnBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgEnumColumnBuilder";
      constructor(name, enumInstance) {
        super(name, "string", "PgEnumColumn");
        this.config.enum = enumInstance;
      }
      /** @internal */
      build(table) {
        return new PgEnumColumn(
          table,
          this.config
        );
      }
    };
    PgEnumColumn = class extends PgColumn {
      static [entityKind] = "PgEnumColumn";
      enum = this.config.enum;
      enumValues = this.config.enum.enumValues;
      constructor(table, config) {
        super(table, config);
        this.enum = config.enum;
      }
      getSQLType() {
        return this.enum.enumName;
      }
    };
  }
});

// node_modules/drizzle-orm/subquery.js
var Subquery, WithSubquery;
var init_subquery = __esm({
  "node_modules/drizzle-orm/subquery.js"() {
    init_entity();
    Subquery = class {
      static [entityKind] = "Subquery";
      constructor(sql2, fields, alias, isWith = false, usedTables = []) {
        this._ = {
          brand: "Subquery",
          sql: sql2,
          selectedFields: fields,
          alias,
          isWith,
          usedTables
        };
      }
      // getSQL(): SQL<unknown> {
      // 	return new SQL([this]);
      // }
    };
    WithSubquery = class extends Subquery {
      static [entityKind] = "WithSubquery";
    };
  }
});

// node_modules/drizzle-orm/version.js
var version;
var init_version = __esm({
  "node_modules/drizzle-orm/version.js"() {
    version = "0.45.2";
  }
});

// node_modules/drizzle-orm/tracing.js
var otel, rawTracer, tracer;
var init_tracing = __esm({
  "node_modules/drizzle-orm/tracing.js"() {
    init_tracing_utils();
    init_version();
    tracer = {
      startActiveSpan(name, fn) {
        if (!otel) {
          return fn();
        }
        if (!rawTracer) {
          rawTracer = otel.trace.getTracer("drizzle-orm", version);
        }
        return iife(
          (otel2, rawTracer2) => rawTracer2.startActiveSpan(
            name,
            (span) => {
              try {
                return fn(span);
              } catch (e) {
                span.setStatus({
                  code: otel2.SpanStatusCode.ERROR,
                  message: e instanceof Error ? e.message : "Unknown error"
                  // eslint-disable-line no-instanceof/no-instanceof
                });
                throw e;
              } finally {
                span.end();
              }
            }
          ),
          otel,
          rawTracer
        );
      }
    };
  }
});

// node_modules/drizzle-orm/view-common.js
var ViewBaseConfig;
var init_view_common = __esm({
  "node_modules/drizzle-orm/view-common.js"() {
    ViewBaseConfig = /* @__PURE__ */ Symbol.for("drizzle:ViewBaseConfig");
  }
});

// node_modules/drizzle-orm/sql/sql.js
function isSQLWrapper(value) {
  return value !== null && value !== void 0 && typeof value.getSQL === "function";
}
function mergeQueries(queries) {
  const result = { sql: "", params: [] };
  for (const query of queries) {
    result.sql += query.sql;
    result.params.push(...query.params);
    if (query.typings?.length) {
      if (!result.typings) {
        result.typings = [];
      }
      result.typings.push(...query.typings);
    }
  }
  return result;
}
function isDriverValueEncoder(value) {
  return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
}
function sql(strings, ...params) {
  const queryChunks = [];
  if (params.length > 0 || strings.length > 0 && strings[0] !== "") {
    queryChunks.push(new StringChunk(strings[0]));
  }
  for (const [paramIndex, param2] of params.entries()) {
    queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
  }
  return new SQL(queryChunks);
}
function fillPlaceholders(params, values) {
  return params.map((p) => {
    if (is(p, Placeholder)) {
      if (!(p.name in values)) {
        throw new Error(`No value for placeholder "${p.name}" was provided`);
      }
      return values[p.name];
    }
    if (is(p, Param) && is(p.value, Placeholder)) {
      if (!(p.value.name in values)) {
        throw new Error(`No value for placeholder "${p.value.name}" was provided`);
      }
      return p.encoder.mapToDriverValue(values[p.value.name]);
    }
    return p;
  });
}
var FakePrimitiveParam, StringChunk, SQL, Name, noopDecoder, noopEncoder, noopMapper, Param, Placeholder, IsDrizzleView, View;
var init_sql = __esm({
  "node_modules/drizzle-orm/sql/sql.js"() {
    init_entity();
    init_enum();
    init_subquery();
    init_tracing();
    init_view_common();
    init_column();
    init_table();
    FakePrimitiveParam = class {
      static [entityKind] = "FakePrimitiveParam";
    };
    StringChunk = class {
      static [entityKind] = "StringChunk";
      value;
      constructor(value) {
        this.value = Array.isArray(value) ? value : [value];
      }
      getSQL() {
        return new SQL([this]);
      }
    };
    SQL = class _SQL {
      constructor(queryChunks) {
        this.queryChunks = queryChunks;
        for (const chunk of queryChunks) {
          if (is(chunk, Table)) {
            const schemaName = chunk[Table.Symbol.Schema];
            this.usedTables.push(
              schemaName === void 0 ? chunk[Table.Symbol.Name] : schemaName + "." + chunk[Table.Symbol.Name]
            );
          }
        }
      }
      static [entityKind] = "SQL";
      /** @internal */
      decoder = noopDecoder;
      shouldInlineParams = false;
      /** @internal */
      usedTables = [];
      append(query) {
        this.queryChunks.push(...query.queryChunks);
        return this;
      }
      toQuery(config) {
        return tracer.startActiveSpan("drizzle.buildSQL", (span) => {
          const query = this.buildQueryFromSourceParams(this.queryChunks, config);
          span?.setAttributes({
            "drizzle.query.text": query.sql,
            "drizzle.query.params": JSON.stringify(query.params)
          });
          return query;
        });
      }
      buildQueryFromSourceParams(chunks, _config) {
        const config = Object.assign({}, _config, {
          inlineParams: _config.inlineParams || this.shouldInlineParams,
          paramStartIndex: _config.paramStartIndex || { value: 0 }
        });
        const {
          casing,
          escapeName,
          escapeParam,
          prepareTyping,
          inlineParams,
          paramStartIndex
        } = config;
        return mergeQueries(chunks.map((chunk) => {
          if (is(chunk, StringChunk)) {
            return { sql: chunk.value.join(""), params: [] };
          }
          if (is(chunk, Name)) {
            return { sql: escapeName(chunk.value), params: [] };
          }
          if (chunk === void 0) {
            return { sql: "", params: [] };
          }
          if (Array.isArray(chunk)) {
            const result = [new StringChunk("(")];
            for (const [i, p] of chunk.entries()) {
              result.push(p);
              if (i < chunk.length - 1) {
                result.push(new StringChunk(", "));
              }
            }
            result.push(new StringChunk(")"));
            return this.buildQueryFromSourceParams(result, config);
          }
          if (is(chunk, _SQL)) {
            return this.buildQueryFromSourceParams(chunk.queryChunks, {
              ...config,
              inlineParams: inlineParams || chunk.shouldInlineParams
            });
          }
          if (is(chunk, Table)) {
            const schemaName = chunk[Table.Symbol.Schema];
            const tableName = chunk[Table.Symbol.Name];
            return {
              sql: schemaName === void 0 || chunk[IsAlias] ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
              params: []
            };
          }
          if (is(chunk, Column)) {
            const columnName = casing.getColumnCasing(chunk);
            if (_config.invokeSource === "indexes") {
              return { sql: escapeName(columnName), params: [] };
            }
            const schemaName = chunk.table[Table.Symbol.Schema];
            return {
              sql: chunk.table[IsAlias] || schemaName === void 0 ? escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName) : escapeName(schemaName) + "." + escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName),
              params: []
            };
          }
          if (is(chunk, View)) {
            const schemaName = chunk[ViewBaseConfig].schema;
            const viewName = chunk[ViewBaseConfig].name;
            return {
              sql: schemaName === void 0 || chunk[ViewBaseConfig].isAlias ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
              params: []
            };
          }
          if (is(chunk, Param)) {
            if (is(chunk.value, Placeholder)) {
              return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
            }
            const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
            if (is(mappedValue, _SQL)) {
              return this.buildQueryFromSourceParams([mappedValue], config);
            }
            if (inlineParams) {
              return { sql: this.mapInlineParam(mappedValue, config), params: [] };
            }
            let typings = ["none"];
            if (prepareTyping) {
              typings = [prepareTyping(chunk.encoder)];
            }
            return { sql: escapeParam(paramStartIndex.value++, mappedValue), params: [mappedValue], typings };
          }
          if (is(chunk, Placeholder)) {
            return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
          }
          if (is(chunk, _SQL.Aliased) && chunk.fieldAlias !== void 0) {
            return { sql: escapeName(chunk.fieldAlias), params: [] };
          }
          if (is(chunk, Subquery)) {
            if (chunk._.isWith) {
              return { sql: escapeName(chunk._.alias), params: [] };
            }
            return this.buildQueryFromSourceParams([
              new StringChunk("("),
              chunk._.sql,
              new StringChunk(") "),
              new Name(chunk._.alias)
            ], config);
          }
          if (isPgEnum(chunk)) {
            if (chunk.schema) {
              return { sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName), params: [] };
            }
            return { sql: escapeName(chunk.enumName), params: [] };
          }
          if (isSQLWrapper(chunk)) {
            if (chunk.shouldOmitSQLParens?.()) {
              return this.buildQueryFromSourceParams([chunk.getSQL()], config);
            }
            return this.buildQueryFromSourceParams([
              new StringChunk("("),
              chunk.getSQL(),
              new StringChunk(")")
            ], config);
          }
          if (inlineParams) {
            return { sql: this.mapInlineParam(chunk, config), params: [] };
          }
          return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
        }));
      }
      mapInlineParam(chunk, { escapeString }) {
        if (chunk === null) {
          return "null";
        }
        if (typeof chunk === "number" || typeof chunk === "boolean") {
          return chunk.toString();
        }
        if (typeof chunk === "string") {
          return escapeString(chunk);
        }
        if (typeof chunk === "object") {
          const mappedValueAsString = chunk.toString();
          if (mappedValueAsString === "[object Object]") {
            return escapeString(JSON.stringify(chunk));
          }
          return escapeString(mappedValueAsString);
        }
        throw new Error("Unexpected param value: " + chunk);
      }
      getSQL() {
        return this;
      }
      as(alias) {
        if (alias === void 0) {
          return this;
        }
        return new _SQL.Aliased(this, alias);
      }
      mapWith(decoder) {
        this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
        return this;
      }
      inlineParams() {
        this.shouldInlineParams = true;
        return this;
      }
      /**
       * This method is used to conditionally include a part of the query.
       *
       * @param condition - Condition to check
       * @returns itself if the condition is `true`, otherwise `undefined`
       */
      if(condition) {
        return condition ? this : void 0;
      }
    };
    Name = class {
      constructor(value) {
        this.value = value;
      }
      static [entityKind] = "Name";
      brand;
      getSQL() {
        return new SQL([this]);
      }
    };
    noopDecoder = {
      mapFromDriverValue: (value) => value
    };
    noopEncoder = {
      mapToDriverValue: (value) => value
    };
    noopMapper = {
      ...noopDecoder,
      ...noopEncoder
    };
    Param = class {
      /**
       * @param value - Parameter value
       * @param encoder - Encoder to convert the value to a driver parameter
       */
      constructor(value, encoder8 = noopEncoder) {
        this.value = value;
        this.encoder = encoder8;
      }
      static [entityKind] = "Param";
      brand;
      getSQL() {
        return new SQL([this]);
      }
    };
    ((sql2) => {
      function empty() {
        return new SQL([]);
      }
      sql2.empty = empty;
      function fromList(list) {
        return new SQL(list);
      }
      sql2.fromList = fromList;
      function raw(str2) {
        return new SQL([new StringChunk(str2)]);
      }
      sql2.raw = raw;
      function join(chunks, separator) {
        const result = [];
        for (const [i, chunk] of chunks.entries()) {
          if (i > 0 && separator !== void 0) {
            result.push(separator);
          }
          result.push(chunk);
        }
        return new SQL(result);
      }
      sql2.join = join;
      function identifier(value) {
        return new Name(value);
      }
      sql2.identifier = identifier;
      function placeholder2(name2) {
        return new Placeholder(name2);
      }
      sql2.placeholder = placeholder2;
      function param2(value, encoder8) {
        return new Param(value, encoder8);
      }
      sql2.param = param2;
    })(sql || (sql = {}));
    ((SQL2) => {
      class Aliased {
        constructor(sql2, fieldAlias) {
          this.sql = sql2;
          this.fieldAlias = fieldAlias;
        }
        static [entityKind] = "SQL.Aliased";
        /** @internal */
        isSelectionField = false;
        getSQL() {
          return this.sql;
        }
        /** @internal */
        clone() {
          return new Aliased(this.sql, this.fieldAlias);
        }
      }
      SQL2.Aliased = Aliased;
    })(SQL || (SQL = {}));
    Placeholder = class {
      constructor(name2) {
        this.name = name2;
      }
      static [entityKind] = "Placeholder";
      getSQL() {
        return new SQL([this]);
      }
    };
    IsDrizzleView = /* @__PURE__ */ Symbol.for("drizzle:IsDrizzleView");
    View = class {
      static [entityKind] = "View";
      /** @internal */
      [ViewBaseConfig];
      /** @internal */
      [IsDrizzleView] = true;
      constructor({ name: name2, schema, selectedFields, query }) {
        this[ViewBaseConfig] = {
          name: name2,
          originalName: name2,
          schema,
          selectedFields,
          query,
          isExisting: !query,
          isAlias: false
        };
      }
      getSQL() {
        return new SQL([this]);
      }
    };
    Column.prototype.getSQL = function() {
      return new SQL([this]);
    };
    Table.prototype.getSQL = function() {
      return new SQL([this]);
    };
    Subquery.prototype.getSQL = function() {
      return new SQL([this]);
    };
  }
});

// node_modules/drizzle-orm/utils.js
function mapResultRow(columns, row, joinsNotNullableMap) {
  const nullifyMap = {};
  const result = columns.reduce(
    (result2, { path, field }, columnIndex) => {
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else if (is(field, Subquery)) {
        decoder = field._.sql.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      let node = result2;
      for (const [pathChunkIndex, pathChunk] of path.entries()) {
        if (pathChunkIndex < path.length - 1) {
          if (!(pathChunk in node)) {
            node[pathChunk] = {};
          }
          node = node[pathChunk];
        } else {
          const rawValue = row[columnIndex];
          const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
          if (joinsNotNullableMap && is(field, Column) && path.length === 2) {
            const objectName = path[0];
            if (!(objectName in nullifyMap)) {
              nullifyMap[objectName] = value === null ? getTableName(field.table) : false;
            } else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== getTableName(field.table)) {
              nullifyMap[objectName] = false;
            }
          }
        }
      }
      return result2;
    },
    {}
  );
  if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
    for (const [objectName, tableName] of Object.entries(nullifyMap)) {
      if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) {
        result[objectName] = null;
      }
    }
  }
  return result;
}
function orderSelectedFields(fields, pathPrefix) {
  return Object.entries(fields).reduce((result, [name, field]) => {
    if (typeof name !== "string") {
      return result;
    }
    const newPath = pathPrefix ? [...pathPrefix, name] : [name];
    if (is(field, Column) || is(field, SQL) || is(field, SQL.Aliased) || is(field, Subquery)) {
      result.push({ path: newPath, field });
    } else if (is(field, Table)) {
      result.push(...orderSelectedFields(field[Table.Symbol.Columns], newPath));
    } else {
      result.push(...orderSelectedFields(field, newPath));
    }
    return result;
  }, []);
}
function haveSameKeys(left, right) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) {
    return false;
  }
  for (const [index4, key] of leftKeys.entries()) {
    if (key !== rightKeys[index4]) {
      return false;
    }
  }
  return true;
}
function mapUpdateSet(table, values) {
  const entries = Object.entries(values).filter(([, value]) => value !== void 0).map(([key, value]) => {
    if (is(value, SQL) || is(value, Column)) {
      return [key, value];
    } else {
      return [key, new Param(value, table[Table.Symbol.Columns][key])];
    }
  });
  if (entries.length === 0) {
    throw new Error("No values to set");
  }
  return Object.fromEntries(entries);
}
function applyMixins(baseClass, extendedClasses) {
  for (const extendedClass of extendedClasses) {
    for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
      if (name === "constructor") continue;
      Object.defineProperty(
        baseClass.prototype,
        name,
        Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || /* @__PURE__ */ Object.create(null)
      );
    }
  }
}
function getTableColumns(table) {
  return table[Table.Symbol.Columns];
}
function getTableLikeName(table) {
  return is(table, Subquery) ? table._.alias : is(table, View) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : table[Table.Symbol.IsAlias] ? table[Table.Symbol.Name] : table[Table.Symbol.BaseName];
}
function getColumnNameAndConfig(a, b) {
  return {
    name: typeof a === "string" && a.length > 0 ? a : "",
    config: typeof a === "object" ? a : b
  };
}
var textDecoder;
var init_utils = __esm({
  "node_modules/drizzle-orm/utils.js"() {
    init_column();
    init_entity();
    init_sql();
    init_subquery();
    init_table();
    init_view_common();
    textDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder();
  }
});

// node_modules/drizzle-orm/pg-core/columns/int.common.js
var PgIntColumnBaseBuilder;
var init_int_common = __esm({
  "node_modules/drizzle-orm/pg-core/columns/int.common.js"() {
    init_entity();
    init_common();
    PgIntColumnBaseBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgIntColumnBaseBuilder";
      generatedAlwaysAsIdentity(sequence) {
        if (sequence) {
          const { name, ...options } = sequence;
          this.config.generatedIdentity = {
            type: "always",
            sequenceName: name,
            sequenceOptions: options
          };
        } else {
          this.config.generatedIdentity = {
            type: "always"
          };
        }
        this.config.hasDefault = true;
        this.config.notNull = true;
        return this;
      }
      generatedByDefaultAsIdentity(sequence) {
        if (sequence) {
          const { name, ...options } = sequence;
          this.config.generatedIdentity = {
            type: "byDefault",
            sequenceName: name,
            sequenceOptions: options
          };
        } else {
          this.config.generatedIdentity = {
            type: "byDefault"
          };
        }
        this.config.hasDefault = true;
        this.config.notNull = true;
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/bigint.js
function bigint(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config.mode === "number") {
    return new PgBigInt53Builder(name);
  }
  return new PgBigInt64Builder(name);
}
var PgBigInt53Builder, PgBigInt53, PgBigInt64Builder, PgBigInt64;
var init_bigint = __esm({
  "node_modules/drizzle-orm/pg-core/columns/bigint.js"() {
    init_entity();
    init_utils();
    init_common();
    init_int_common();
    PgBigInt53Builder = class extends PgIntColumnBaseBuilder {
      static [entityKind] = "PgBigInt53Builder";
      constructor(name) {
        super(name, "number", "PgBigInt53");
      }
      /** @internal */
      build(table) {
        return new PgBigInt53(table, this.config);
      }
    };
    PgBigInt53 = class extends PgColumn {
      static [entityKind] = "PgBigInt53";
      getSQLType() {
        return "bigint";
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") {
          return value;
        }
        return Number(value);
      }
    };
    PgBigInt64Builder = class extends PgIntColumnBaseBuilder {
      static [entityKind] = "PgBigInt64Builder";
      constructor(name) {
        super(name, "bigint", "PgBigInt64");
      }
      /** @internal */
      build(table) {
        return new PgBigInt64(
          table,
          this.config
        );
      }
    };
    PgBigInt64 = class extends PgColumn {
      static [entityKind] = "PgBigInt64";
      getSQLType() {
        return "bigint";
      }
      // eslint-disable-next-line unicorn/prefer-native-coercion-functions
      mapFromDriverValue(value) {
        return BigInt(value);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/bigserial.js
function bigserial(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config.mode === "number") {
    return new PgBigSerial53Builder(name);
  }
  return new PgBigSerial64Builder(name);
}
var PgBigSerial53Builder, PgBigSerial53, PgBigSerial64Builder, PgBigSerial64;
var init_bigserial = __esm({
  "node_modules/drizzle-orm/pg-core/columns/bigserial.js"() {
    init_entity();
    init_utils();
    init_common();
    PgBigSerial53Builder = class extends PgColumnBuilder {
      static [entityKind] = "PgBigSerial53Builder";
      constructor(name) {
        super(name, "number", "PgBigSerial53");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgBigSerial53(
          table,
          this.config
        );
      }
    };
    PgBigSerial53 = class extends PgColumn {
      static [entityKind] = "PgBigSerial53";
      getSQLType() {
        return "bigserial";
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") {
          return value;
        }
        return Number(value);
      }
    };
    PgBigSerial64Builder = class extends PgColumnBuilder {
      static [entityKind] = "PgBigSerial64Builder";
      constructor(name) {
        super(name, "bigint", "PgBigSerial64");
        this.config.hasDefault = true;
      }
      /** @internal */
      build(table) {
        return new PgBigSerial64(
          table,
          this.config
        );
      }
    };
    PgBigSerial64 = class extends PgColumn {
      static [entityKind] = "PgBigSerial64";
      getSQLType() {
        return "bigserial";
      }
      // eslint-disable-next-line unicorn/prefer-native-coercion-functions
      mapFromDriverValue(value) {
        return BigInt(value);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/boolean.js
function boolean(name) {
  return new PgBooleanBuilder(name ?? "");
}
var PgBooleanBuilder, PgBoolean;
var init_boolean = __esm({
  "node_modules/drizzle-orm/pg-core/columns/boolean.js"() {
    init_entity();
    init_common();
    PgBooleanBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgBooleanBuilder";
      constructor(name) {
        super(name, "boolean", "PgBoolean");
      }
      /** @internal */
      build(table) {
        return new PgBoolean(table, this.config);
      }
    };
    PgBoolean = class extends PgColumn {
      static [entityKind] = "PgBoolean";
      getSQLType() {
        return "boolean";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/char.js
function char(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgCharBuilder(name, config);
}
var PgCharBuilder, PgChar;
var init_char = __esm({
  "node_modules/drizzle-orm/pg-core/columns/char.js"() {
    init_entity();
    init_utils();
    init_common();
    PgCharBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgCharBuilder";
      constructor(name, config) {
        super(name, "string", "PgChar");
        this.config.length = config.length;
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgChar(
          table,
          this.config
        );
      }
    };
    PgChar = class extends PgColumn {
      static [entityKind] = "PgChar";
      length = this.config.length;
      enumValues = this.config.enumValues;
      getSQLType() {
        return this.length === void 0 ? `char` : `char(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/cidr.js
function cidr(name) {
  return new PgCidrBuilder(name ?? "");
}
var PgCidrBuilder, PgCidr;
var init_cidr = __esm({
  "node_modules/drizzle-orm/pg-core/columns/cidr.js"() {
    init_entity();
    init_common();
    PgCidrBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgCidrBuilder";
      constructor(name) {
        super(name, "string", "PgCidr");
      }
      /** @internal */
      build(table) {
        return new PgCidr(table, this.config);
      }
    };
    PgCidr = class extends PgColumn {
      static [entityKind] = "PgCidr";
      getSQLType() {
        return "cidr";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/custom.js
function customType(customTypeParams) {
  return (a, b) => {
    const { name, config } = getColumnNameAndConfig(a, b);
    return new PgCustomColumnBuilder(name, config, customTypeParams);
  };
}
var PgCustomColumnBuilder, PgCustomColumn;
var init_custom = __esm({
  "node_modules/drizzle-orm/pg-core/columns/custom.js"() {
    init_entity();
    init_utils();
    init_common();
    PgCustomColumnBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgCustomColumnBuilder";
      constructor(name, fieldConfig, customTypeParams) {
        super(name, "custom", "PgCustomColumn");
        this.config.fieldConfig = fieldConfig;
        this.config.customTypeParams = customTypeParams;
      }
      /** @internal */
      build(table) {
        return new PgCustomColumn(
          table,
          this.config
        );
      }
    };
    PgCustomColumn = class extends PgColumn {
      static [entityKind] = "PgCustomColumn";
      sqlName;
      mapTo;
      mapFrom;
      constructor(table, config) {
        super(table, config);
        this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
        this.mapTo = config.customTypeParams.toDriver;
        this.mapFrom = config.customTypeParams.fromDriver;
      }
      getSQLType() {
        return this.sqlName;
      }
      mapFromDriverValue(value) {
        return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
      }
      mapToDriverValue(value) {
        return typeof this.mapTo === "function" ? this.mapTo(value) : value;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/date.common.js
var PgDateColumnBaseBuilder;
var init_date_common = __esm({
  "node_modules/drizzle-orm/pg-core/columns/date.common.js"() {
    init_entity();
    init_sql();
    init_common();
    PgDateColumnBaseBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgDateColumnBaseBuilder";
      defaultNow() {
        return this.default(sql`now()`);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/date.js
function date(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "date") {
    return new PgDateBuilder(name);
  }
  return new PgDateStringBuilder(name);
}
var PgDateBuilder, PgDate, PgDateStringBuilder, PgDateString;
var init_date = __esm({
  "node_modules/drizzle-orm/pg-core/columns/date.js"() {
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgDateBuilder = class extends PgDateColumnBaseBuilder {
      static [entityKind] = "PgDateBuilder";
      constructor(name) {
        super(name, "date", "PgDate");
      }
      /** @internal */
      build(table) {
        return new PgDate(table, this.config);
      }
    };
    PgDate = class extends PgColumn {
      static [entityKind] = "PgDate";
      getSQLType() {
        return "date";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") return new Date(value);
        return value;
      }
      mapToDriverValue(value) {
        return value.toISOString();
      }
    };
    PgDateStringBuilder = class extends PgDateColumnBaseBuilder {
      static [entityKind] = "PgDateStringBuilder";
      constructor(name) {
        super(name, "string", "PgDateString");
      }
      /** @internal */
      build(table) {
        return new PgDateString(
          table,
          this.config
        );
      }
    };
    PgDateString = class extends PgColumn {
      static [entityKind] = "PgDateString";
      getSQLType() {
        return "date";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        return value.toISOString().slice(0, -14);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/double-precision.js
function doublePrecision(name) {
  return new PgDoublePrecisionBuilder(name ?? "");
}
var PgDoublePrecisionBuilder, PgDoublePrecision;
var init_double_precision = __esm({
  "node_modules/drizzle-orm/pg-core/columns/double-precision.js"() {
    init_entity();
    init_common();
    PgDoublePrecisionBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgDoublePrecisionBuilder";
      constructor(name) {
        super(name, "number", "PgDoublePrecision");
      }
      /** @internal */
      build(table) {
        return new PgDoublePrecision(
          table,
          this.config
        );
      }
    };
    PgDoublePrecision = class extends PgColumn {
      static [entityKind] = "PgDoublePrecision";
      getSQLType() {
        return "double precision";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number.parseFloat(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/inet.js
function inet(name) {
  return new PgInetBuilder(name ?? "");
}
var PgInetBuilder, PgInet;
var init_inet = __esm({
  "node_modules/drizzle-orm/pg-core/columns/inet.js"() {
    init_entity();
    init_common();
    PgInetBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgInetBuilder";
      constructor(name) {
        super(name, "string", "PgInet");
      }
      /** @internal */
      build(table) {
        return new PgInet(table, this.config);
      }
    };
    PgInet = class extends PgColumn {
      static [entityKind] = "PgInet";
      getSQLType() {
        return "inet";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/integer.js
function integer(name) {
  return new PgIntegerBuilder(name ?? "");
}
var PgIntegerBuilder, PgInteger;
var init_integer = __esm({
  "node_modules/drizzle-orm/pg-core/columns/integer.js"() {
    init_entity();
    init_common();
    init_int_common();
    PgIntegerBuilder = class extends PgIntColumnBaseBuilder {
      static [entityKind] = "PgIntegerBuilder";
      constructor(name) {
        super(name, "number", "PgInteger");
      }
      /** @internal */
      build(table) {
        return new PgInteger(table, this.config);
      }
    };
    PgInteger = class extends PgColumn {
      static [entityKind] = "PgInteger";
      getSQLType() {
        return "integer";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number.parseInt(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/interval.js
function interval(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgIntervalBuilder(name, config);
}
var PgIntervalBuilder, PgInterval;
var init_interval = __esm({
  "node_modules/drizzle-orm/pg-core/columns/interval.js"() {
    init_entity();
    init_utils();
    init_common();
    PgIntervalBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgIntervalBuilder";
      constructor(name, intervalConfig) {
        super(name, "string", "PgInterval");
        this.config.intervalConfig = intervalConfig;
      }
      /** @internal */
      build(table) {
        return new PgInterval(table, this.config);
      }
    };
    PgInterval = class extends PgColumn {
      static [entityKind] = "PgInterval";
      fields = this.config.intervalConfig.fields;
      precision = this.config.intervalConfig.precision;
      getSQLType() {
        const fields = this.fields ? ` ${this.fields}` : "";
        const precision = this.precision ? `(${this.precision})` : "";
        return `interval${fields}${precision}`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/json.js
function json(name) {
  return new PgJsonBuilder(name ?? "");
}
var PgJsonBuilder, PgJson;
var init_json = __esm({
  "node_modules/drizzle-orm/pg-core/columns/json.js"() {
    init_entity();
    init_common();
    PgJsonBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgJsonBuilder";
      constructor(name) {
        super(name, "json", "PgJson");
      }
      /** @internal */
      build(table) {
        return new PgJson(table, this.config);
      }
    };
    PgJson = class extends PgColumn {
      static [entityKind] = "PgJson";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "json";
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          try {
            return JSON.parse(value);
          } catch {
            return value;
          }
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/jsonb.js
function jsonb(name) {
  return new PgJsonbBuilder(name ?? "");
}
var PgJsonbBuilder, PgJsonb;
var init_jsonb = __esm({
  "node_modules/drizzle-orm/pg-core/columns/jsonb.js"() {
    init_entity();
    init_common();
    PgJsonbBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgJsonbBuilder";
      constructor(name) {
        super(name, "json", "PgJsonb");
      }
      /** @internal */
      build(table) {
        return new PgJsonb(table, this.config);
      }
    };
    PgJsonb = class extends PgColumn {
      static [entityKind] = "PgJsonb";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "jsonb";
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          try {
            return JSON.parse(value);
          } catch {
            return value;
          }
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/line.js
function line(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgLineBuilder(name);
  }
  return new PgLineABCBuilder(name);
}
var PgLineBuilder, PgLineTuple, PgLineABCBuilder, PgLineABC;
var init_line = __esm({
  "node_modules/drizzle-orm/pg-core/columns/line.js"() {
    init_entity();
    init_utils();
    init_common();
    PgLineBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgLineBuilder";
      constructor(name) {
        super(name, "array", "PgLine");
      }
      /** @internal */
      build(table) {
        return new PgLineTuple(
          table,
          this.config
        );
      }
    };
    PgLineTuple = class extends PgColumn {
      static [entityKind] = "PgLine";
      getSQLType() {
        return "line";
      }
      mapFromDriverValue(value) {
        const [a, b, c] = value.slice(1, -1).split(",");
        return [Number.parseFloat(a), Number.parseFloat(b), Number.parseFloat(c)];
      }
      mapToDriverValue(value) {
        return `{${value[0]},${value[1]},${value[2]}}`;
      }
    };
    PgLineABCBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgLineABCBuilder";
      constructor(name) {
        super(name, "json", "PgLineABC");
      }
      /** @internal */
      build(table) {
        return new PgLineABC(
          table,
          this.config
        );
      }
    };
    PgLineABC = class extends PgColumn {
      static [entityKind] = "PgLineABC";
      getSQLType() {
        return "line";
      }
      mapFromDriverValue(value) {
        const [a, b, c] = value.slice(1, -1).split(",");
        return { a: Number.parseFloat(a), b: Number.parseFloat(b), c: Number.parseFloat(c) };
      }
      mapToDriverValue(value) {
        return `{${value.a},${value.b},${value.c}}`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/macaddr.js
function macaddr(name) {
  return new PgMacaddrBuilder(name ?? "");
}
var PgMacaddrBuilder, PgMacaddr;
var init_macaddr = __esm({
  "node_modules/drizzle-orm/pg-core/columns/macaddr.js"() {
    init_entity();
    init_common();
    PgMacaddrBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgMacaddrBuilder";
      constructor(name) {
        super(name, "string", "PgMacaddr");
      }
      /** @internal */
      build(table) {
        return new PgMacaddr(table, this.config);
      }
    };
    PgMacaddr = class extends PgColumn {
      static [entityKind] = "PgMacaddr";
      getSQLType() {
        return "macaddr";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/macaddr8.js
function macaddr8(name) {
  return new PgMacaddr8Builder(name ?? "");
}
var PgMacaddr8Builder, PgMacaddr8;
var init_macaddr8 = __esm({
  "node_modules/drizzle-orm/pg-core/columns/macaddr8.js"() {
    init_entity();
    init_common();
    PgMacaddr8Builder = class extends PgColumnBuilder {
      static [entityKind] = "PgMacaddr8Builder";
      constructor(name) {
        super(name, "string", "PgMacaddr8");
      }
      /** @internal */
      build(table) {
        return new PgMacaddr8(table, this.config);
      }
    };
    PgMacaddr8 = class extends PgColumn {
      static [entityKind] = "PgMacaddr8";
      getSQLType() {
        return "macaddr8";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/numeric.js
function numeric(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  const mode = config?.mode;
  return mode === "number" ? new PgNumericNumberBuilder(name, config?.precision, config?.scale) : mode === "bigint" ? new PgNumericBigIntBuilder(name, config?.precision, config?.scale) : new PgNumericBuilder(name, config?.precision, config?.scale);
}
var PgNumericBuilder, PgNumeric, PgNumericNumberBuilder, PgNumericNumber, PgNumericBigIntBuilder, PgNumericBigInt;
var init_numeric = __esm({
  "node_modules/drizzle-orm/pg-core/columns/numeric.js"() {
    init_entity();
    init_utils();
    init_common();
    PgNumericBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgNumericBuilder";
      constructor(name, precision, scale) {
        super(name, "string", "PgNumeric");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumeric(table, this.config);
      }
    };
    PgNumeric = class extends PgColumn {
      static [entityKind] = "PgNumeric";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        return String(value);
      }
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
    PgNumericNumberBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgNumericNumberBuilder";
      constructor(name, precision, scale) {
        super(name, "number", "PgNumericNumber");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumericNumber(
          table,
          this.config
        );
      }
    };
    PgNumericNumber = class extends PgColumn {
      static [entityKind] = "PgNumericNumber";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") return value;
        return Number(value);
      }
      mapToDriverValue = String;
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
    PgNumericBigIntBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgNumericBigIntBuilder";
      constructor(name, precision, scale) {
        super(name, "bigint", "PgNumericBigInt");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumericBigInt(
          table,
          this.config
        );
      }
    };
    PgNumericBigInt = class extends PgColumn {
      static [entityKind] = "PgNumericBigInt";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue = BigInt;
      mapToDriverValue = String;
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/point.js
function point(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgPointTupleBuilder(name);
  }
  return new PgPointObjectBuilder(name);
}
var PgPointTupleBuilder, PgPointTuple, PgPointObjectBuilder, PgPointObject;
var init_point = __esm({
  "node_modules/drizzle-orm/pg-core/columns/point.js"() {
    init_entity();
    init_utils();
    init_common();
    PgPointTupleBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgPointTupleBuilder";
      constructor(name) {
        super(name, "array", "PgPointTuple");
      }
      /** @internal */
      build(table) {
        return new PgPointTuple(
          table,
          this.config
        );
      }
    };
    PgPointTuple = class extends PgColumn {
      static [entityKind] = "PgPointTuple";
      getSQLType() {
        return "point";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          const [x, y] = value.slice(1, -1).split(",");
          return [Number.parseFloat(x), Number.parseFloat(y)];
        }
        return [value.x, value.y];
      }
      mapToDriverValue(value) {
        return `(${value[0]},${value[1]})`;
      }
    };
    PgPointObjectBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgPointObjectBuilder";
      constructor(name) {
        super(name, "json", "PgPointObject");
      }
      /** @internal */
      build(table) {
        return new PgPointObject(
          table,
          this.config
        );
      }
    };
    PgPointObject = class extends PgColumn {
      static [entityKind] = "PgPointObject";
      getSQLType() {
        return "point";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          const [x, y] = value.slice(1, -1).split(",");
          return { x: Number.parseFloat(x), y: Number.parseFloat(y) };
        }
        return value;
      }
      mapToDriverValue(value) {
        return `(${value.x},${value.y})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/postgis_extension/utils.js
function hexToBytes(hex) {
  const bytes = [];
  for (let c = 0; c < hex.length; c += 2) {
    bytes.push(Number.parseInt(hex.slice(c, c + 2), 16));
  }
  return new Uint8Array(bytes);
}
function bytesToFloat64(bytes, offset) {
  const buffer = new ArrayBuffer(8);
  const view = new DataView(buffer);
  for (let i = 0; i < 8; i++) {
    view.setUint8(i, bytes[offset + i]);
  }
  return view.getFloat64(0, true);
}
function parseEWKB(hex) {
  const bytes = hexToBytes(hex);
  let offset = 0;
  const byteOrder = bytes[offset];
  offset += 1;
  const view = new DataView(bytes.buffer);
  const geomType = view.getUint32(offset, byteOrder === 1);
  offset += 4;
  let _srid;
  if (geomType & 536870912) {
    _srid = view.getUint32(offset, byteOrder === 1);
    offset += 4;
  }
  if ((geomType & 65535) === 1) {
    const x = bytesToFloat64(bytes, offset);
    offset += 8;
    const y = bytesToFloat64(bytes, offset);
    offset += 8;
    return [x, y];
  }
  throw new Error("Unsupported geometry type");
}
var init_utils2 = __esm({
  "node_modules/drizzle-orm/pg-core/columns/postgis_extension/utils.js"() {
  }
});

// node_modules/drizzle-orm/pg-core/columns/postgis_extension/geometry.js
function geometry(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgGeometryBuilder(name);
  }
  return new PgGeometryObjectBuilder(name);
}
var PgGeometryBuilder, PgGeometry, PgGeometryObjectBuilder, PgGeometryObject;
var init_geometry = __esm({
  "node_modules/drizzle-orm/pg-core/columns/postgis_extension/geometry.js"() {
    init_entity();
    init_utils();
    init_common();
    init_utils2();
    PgGeometryBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgGeometryBuilder";
      constructor(name) {
        super(name, "array", "PgGeometry");
      }
      /** @internal */
      build(table) {
        return new PgGeometry(
          table,
          this.config
        );
      }
    };
    PgGeometry = class extends PgColumn {
      static [entityKind] = "PgGeometry";
      getSQLType() {
        return "geometry(point)";
      }
      mapFromDriverValue(value) {
        return parseEWKB(value);
      }
      mapToDriverValue(value) {
        return `point(${value[0]} ${value[1]})`;
      }
    };
    PgGeometryObjectBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgGeometryObjectBuilder";
      constructor(name) {
        super(name, "json", "PgGeometryObject");
      }
      /** @internal */
      build(table) {
        return new PgGeometryObject(
          table,
          this.config
        );
      }
    };
    PgGeometryObject = class extends PgColumn {
      static [entityKind] = "PgGeometryObject";
      getSQLType() {
        return "geometry(point)";
      }
      mapFromDriverValue(value) {
        const parsed = parseEWKB(value);
        return { x: parsed[0], y: parsed[1] };
      }
      mapToDriverValue(value) {
        return `point(${value.x} ${value.y})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/real.js
function real(name) {
  return new PgRealBuilder(name ?? "");
}
var PgRealBuilder, PgReal;
var init_real = __esm({
  "node_modules/drizzle-orm/pg-core/columns/real.js"() {
    init_entity();
    init_common();
    PgRealBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgRealBuilder";
      constructor(name, length) {
        super(name, "number", "PgReal");
        this.config.length = length;
      }
      /** @internal */
      build(table) {
        return new PgReal(table, this.config);
      }
    };
    PgReal = class extends PgColumn {
      static [entityKind] = "PgReal";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "real";
      }
      mapFromDriverValue = (value) => {
        if (typeof value === "string") {
          return Number.parseFloat(value);
        }
        return value;
      };
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/serial.js
function serial(name) {
  return new PgSerialBuilder(name ?? "");
}
var PgSerialBuilder, PgSerial;
var init_serial = __esm({
  "node_modules/drizzle-orm/pg-core/columns/serial.js"() {
    init_entity();
    init_common();
    PgSerialBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgSerialBuilder";
      constructor(name) {
        super(name, "number", "PgSerial");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgSerial(table, this.config);
      }
    };
    PgSerial = class extends PgColumn {
      static [entityKind] = "PgSerial";
      getSQLType() {
        return "serial";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/smallint.js
function smallint(name) {
  return new PgSmallIntBuilder(name ?? "");
}
var PgSmallIntBuilder, PgSmallInt;
var init_smallint = __esm({
  "node_modules/drizzle-orm/pg-core/columns/smallint.js"() {
    init_entity();
    init_common();
    init_int_common();
    PgSmallIntBuilder = class extends PgIntColumnBaseBuilder {
      static [entityKind] = "PgSmallIntBuilder";
      constructor(name) {
        super(name, "number", "PgSmallInt");
      }
      /** @internal */
      build(table) {
        return new PgSmallInt(table, this.config);
      }
    };
    PgSmallInt = class extends PgColumn {
      static [entityKind] = "PgSmallInt";
      getSQLType() {
        return "smallint";
      }
      mapFromDriverValue = (value) => {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      };
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/smallserial.js
function smallserial(name) {
  return new PgSmallSerialBuilder(name ?? "");
}
var PgSmallSerialBuilder, PgSmallSerial;
var init_smallserial = __esm({
  "node_modules/drizzle-orm/pg-core/columns/smallserial.js"() {
    init_entity();
    init_common();
    PgSmallSerialBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgSmallSerialBuilder";
      constructor(name) {
        super(name, "number", "PgSmallSerial");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgSmallSerial(
          table,
          this.config
        );
      }
    };
    PgSmallSerial = class extends PgColumn {
      static [entityKind] = "PgSmallSerial";
      getSQLType() {
        return "smallserial";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/text.js
function text(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgTextBuilder(name, config);
}
var PgTextBuilder, PgText;
var init_text = __esm({
  "node_modules/drizzle-orm/pg-core/columns/text.js"() {
    init_entity();
    init_utils();
    init_common();
    PgTextBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgTextBuilder";
      constructor(name, config) {
        super(name, "string", "PgText");
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgText(table, this.config);
      }
    };
    PgText = class extends PgColumn {
      static [entityKind] = "PgText";
      enumValues = this.config.enumValues;
      getSQLType() {
        return "text";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/time.js
function time(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgTimeBuilder(name, config.withTimezone ?? false, config.precision);
}
var PgTimeBuilder, PgTime;
var init_time = __esm({
  "node_modules/drizzle-orm/pg-core/columns/time.js"() {
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgTimeBuilder = class extends PgDateColumnBaseBuilder {
      constructor(name, withTimezone, precision) {
        super(name, "string", "PgTime");
        this.withTimezone = withTimezone;
        this.precision = precision;
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      static [entityKind] = "PgTimeBuilder";
      /** @internal */
      build(table) {
        return new PgTime(table, this.config);
      }
    };
    PgTime = class extends PgColumn {
      static [entityKind] = "PgTime";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : `(${this.precision})`;
        return `time${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/timestamp.js
function timestamp(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "string") {
    return new PgTimestampStringBuilder(name, config.withTimezone ?? false, config.precision);
  }
  return new PgTimestampBuilder(name, config?.withTimezone ?? false, config?.precision);
}
var PgTimestampBuilder, PgTimestamp, PgTimestampStringBuilder, PgTimestampString;
var init_timestamp = __esm({
  "node_modules/drizzle-orm/pg-core/columns/timestamp.js"() {
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgTimestampBuilder = class extends PgDateColumnBaseBuilder {
      static [entityKind] = "PgTimestampBuilder";
      constructor(name, withTimezone, precision) {
        super(name, "date", "PgTimestamp");
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      /** @internal */
      build(table) {
        return new PgTimestamp(table, this.config);
      }
    };
    PgTimestamp = class extends PgColumn {
      static [entityKind] = "PgTimestamp";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : ` (${this.precision})`;
        return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") return new Date(this.withTimezone ? value : value + "+0000");
        return value;
      }
      mapToDriverValue = (value) => {
        return value.toISOString();
      };
    };
    PgTimestampStringBuilder = class extends PgDateColumnBaseBuilder {
      static [entityKind] = "PgTimestampStringBuilder";
      constructor(name, withTimezone, precision) {
        super(name, "string", "PgTimestampString");
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      /** @internal */
      build(table) {
        return new PgTimestampString(
          table,
          this.config
        );
      }
    };
    PgTimestampString = class extends PgColumn {
      static [entityKind] = "PgTimestampString";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : `(${this.precision})`;
        return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        const shortened = value.toISOString().slice(0, -1).replace("T", " ");
        if (this.withTimezone) {
          const offset = value.getTimezoneOffset();
          const sign = offset <= 0 ? "+" : "-";
          return `${shortened}${sign}${Math.floor(Math.abs(offset) / 60).toString().padStart(2, "0")}`;
        }
        return shortened;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/uuid.js
function uuid(name) {
  return new PgUUIDBuilder(name ?? "");
}
var PgUUIDBuilder, PgUUID;
var init_uuid = __esm({
  "node_modules/drizzle-orm/pg-core/columns/uuid.js"() {
    init_entity();
    init_sql();
    init_common();
    PgUUIDBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgUUIDBuilder";
      constructor(name) {
        super(name, "string", "PgUUID");
      }
      /**
       * Adds `default gen_random_uuid()` to the column definition.
       */
      defaultRandom() {
        return this.default(sql`gen_random_uuid()`);
      }
      /** @internal */
      build(table) {
        return new PgUUID(table, this.config);
      }
    };
    PgUUID = class extends PgColumn {
      static [entityKind] = "PgUUID";
      getSQLType() {
        return "uuid";
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/varchar.js
function varchar(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgVarcharBuilder(name, config);
}
var PgVarcharBuilder, PgVarchar;
var init_varchar = __esm({
  "node_modules/drizzle-orm/pg-core/columns/varchar.js"() {
    init_entity();
    init_utils();
    init_common();
    PgVarcharBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgVarcharBuilder";
      constructor(name, config) {
        super(name, "string", "PgVarchar");
        this.config.length = config.length;
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgVarchar(
          table,
          this.config
        );
      }
    };
    PgVarchar = class extends PgColumn {
      static [entityKind] = "PgVarchar";
      length = this.config.length;
      enumValues = this.config.enumValues;
      getSQLType() {
        return this.length === void 0 ? `varchar` : `varchar(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/vector_extension/bit.js
function bit(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgBinaryVectorBuilder(name, config);
}
var PgBinaryVectorBuilder, PgBinaryVector;
var init_bit = __esm({
  "node_modules/drizzle-orm/pg-core/columns/vector_extension/bit.js"() {
    init_entity();
    init_utils();
    init_common();
    PgBinaryVectorBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgBinaryVectorBuilder";
      constructor(name, config) {
        super(name, "string", "PgBinaryVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgBinaryVector(
          table,
          this.config
        );
      }
    };
    PgBinaryVector = class extends PgColumn {
      static [entityKind] = "PgBinaryVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `bit(${this.dimensions})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/vector_extension/halfvec.js
function halfvec(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgHalfVectorBuilder(name, config);
}
var PgHalfVectorBuilder, PgHalfVector;
var init_halfvec = __esm({
  "node_modules/drizzle-orm/pg-core/columns/vector_extension/halfvec.js"() {
    init_entity();
    init_utils();
    init_common();
    PgHalfVectorBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgHalfVectorBuilder";
      constructor(name, config) {
        super(name, "array", "PgHalfVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgHalfVector(
          table,
          this.config
        );
      }
    };
    PgHalfVector = class extends PgColumn {
      static [entityKind] = "PgHalfVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `halfvec(${this.dimensions})`;
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/vector_extension/sparsevec.js
function sparsevec(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgSparseVectorBuilder(name, config);
}
var PgSparseVectorBuilder, PgSparseVector;
var init_sparsevec = __esm({
  "node_modules/drizzle-orm/pg-core/columns/vector_extension/sparsevec.js"() {
    init_entity();
    init_utils();
    init_common();
    PgSparseVectorBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgSparseVectorBuilder";
      constructor(name, config) {
        super(name, "string", "PgSparseVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgSparseVector(
          table,
          this.config
        );
      }
    };
    PgSparseVector = class extends PgColumn {
      static [entityKind] = "PgSparseVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `sparsevec(${this.dimensions})`;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/vector_extension/vector.js
function vector(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new PgVectorBuilder(name, config);
}
var PgVectorBuilder, PgVector;
var init_vector = __esm({
  "node_modules/drizzle-orm/pg-core/columns/vector_extension/vector.js"() {
    init_entity();
    init_utils();
    init_common();
    PgVectorBuilder = class extends PgColumnBuilder {
      static [entityKind] = "PgVectorBuilder";
      constructor(name, config) {
        super(name, "array", "PgVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgVector(
          table,
          this.config
        );
      }
    };
    PgVector = class extends PgColumn {
      static [entityKind] = "PgVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `vector(${this.dimensions})`;
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/all.js
function getPgColumnBuilders() {
  return {
    bigint,
    bigserial,
    boolean,
    char,
    cidr,
    customType,
    date,
    doublePrecision,
    inet,
    integer,
    interval,
    json,
    jsonb,
    line,
    macaddr,
    macaddr8,
    numeric,
    point,
    geometry,
    real,
    serial,
    smallint,
    smallserial,
    text,
    time,
    timestamp,
    uuid,
    varchar,
    bit,
    halfvec,
    sparsevec,
    vector
  };
}
var init_all = __esm({
  "node_modules/drizzle-orm/pg-core/columns/all.js"() {
    init_bigint();
    init_bigserial();
    init_boolean();
    init_char();
    init_cidr();
    init_custom();
    init_date();
    init_double_precision();
    init_inet();
    init_integer();
    init_interval();
    init_json();
    init_jsonb();
    init_line();
    init_macaddr();
    init_macaddr8();
    init_numeric();
    init_point();
    init_geometry();
    init_real();
    init_serial();
    init_smallint();
    init_smallserial();
    init_text();
    init_time();
    init_timestamp();
    init_uuid();
    init_varchar();
    init_bit();
    init_halfvec();
    init_sparsevec();
    init_vector();
  }
});

// node_modules/drizzle-orm/pg-core/table.js
function pgTableWithSchema(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new PgTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns(getPgColumnBuilders()) : columns;
  const builtColumns = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.build(rawTable);
      rawTable[InlineForeignKeys].push(...colBuilder.buildForeignKeys(column, rawTable));
      return [name2, column];
    })
  );
  const builtColumnsForExtraConfig = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.buildExtraConfigColumn(rawTable);
      return [name2, column];
    })
  );
  const table = Object.assign(rawTable, builtColumns);
  table[Table.Symbol.Columns] = builtColumns;
  table[Table.Symbol.ExtraConfigColumns] = builtColumnsForExtraConfig;
  if (extraConfig) {
    table[PgTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return Object.assign(table, {
    enableRLS: () => {
      table[PgTable.Symbol.EnableRLS] = true;
      return table;
    }
  });
}
var InlineForeignKeys, EnableRLS, PgTable, pgTable;
var init_table2 = __esm({
  "node_modules/drizzle-orm/pg-core/table.js"() {
    init_entity();
    init_table();
    init_all();
    InlineForeignKeys = /* @__PURE__ */ Symbol.for("drizzle:PgInlineForeignKeys");
    EnableRLS = /* @__PURE__ */ Symbol.for("drizzle:EnableRLS");
    PgTable = class extends Table {
      static [entityKind] = "PgTable";
      /** @internal */
      static Symbol = Object.assign({}, Table.Symbol, {
        InlineForeignKeys,
        EnableRLS
      });
      /**@internal */
      [InlineForeignKeys] = [];
      /** @internal */
      [EnableRLS] = false;
      /** @internal */
      [Table.Symbol.ExtraConfigBuilder] = void 0;
      /** @internal */
      [Table.Symbol.ExtraConfigColumns] = {};
    };
    pgTable = (name, columns, extraConfig) => {
      return pgTableWithSchema(name, columns, extraConfig, void 0);
    };
  }
});

// node_modules/drizzle-orm/pg-core/primary-keys.js
function primaryKey(...config) {
  if (config[0].columns) {
    return new PrimaryKeyBuilder(config[0].columns, config[0].name);
  }
  return new PrimaryKeyBuilder(config);
}
var PrimaryKeyBuilder, PrimaryKey;
var init_primary_keys = __esm({
  "node_modules/drizzle-orm/pg-core/primary-keys.js"() {
    init_entity();
    init_table2();
    PrimaryKeyBuilder = class {
      static [entityKind] = "PgPrimaryKeyBuilder";
      /** @internal */
      columns;
      /** @internal */
      name;
      constructor(columns, name) {
        this.columns = columns;
        this.name = name;
      }
      /** @internal */
      build(table) {
        return new PrimaryKey(table, this.columns, this.name);
      }
    };
    PrimaryKey = class {
      constructor(table, columns, name) {
        this.table = table;
        this.columns = columns;
        this.name = name;
      }
      static [entityKind] = "PgPrimaryKey";
      columns;
      name;
      getName() {
        return this.name ?? `${this.table[PgTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
      }
    };
  }
});

// node_modules/drizzle-orm/sql/expressions/conditions.js
function bindIfParam(value, column) {
  if (isDriverValueEncoder(column) && !isSQLWrapper(value) && !is(value, Param) && !is(value, Placeholder) && !is(value, Column) && !is(value, Table) && !is(value, View)) {
    return new Param(value, column);
  }
  return value;
}
function and(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" and ")),
    new StringChunk(")")
  ]);
}
function or(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" or ")),
    new StringChunk(")")
  ]);
}
function not(condition) {
  return sql`not ${condition}`;
}
function inArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`false`;
    }
    return sql`${column} in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return sql`${column} in ${bindIfParam(values, column)}`;
}
function notInArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`true`;
    }
    return sql`${column} not in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return sql`${column} not in ${bindIfParam(values, column)}`;
}
function isNull(value) {
  return sql`${value} is null`;
}
function isNotNull(value) {
  return sql`${value} is not null`;
}
function exists(subquery) {
  return sql`exists ${subquery}`;
}
function notExists(subquery) {
  return sql`not exists ${subquery}`;
}
function between(column, min, max) {
  return sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(
    max,
    column
  )}`;
}
function notBetween(column, min, max) {
  return sql`${column} not between ${bindIfParam(
    min,
    column
  )} and ${bindIfParam(max, column)}`;
}
function like(column, value) {
  return sql`${column} like ${value}`;
}
function notLike(column, value) {
  return sql`${column} not like ${value}`;
}
function ilike(column, value) {
  return sql`${column} ilike ${value}`;
}
function notIlike(column, value) {
  return sql`${column} not ilike ${value}`;
}
var eq, ne, gt, gte, lt, lte;
var init_conditions = __esm({
  "node_modules/drizzle-orm/sql/expressions/conditions.js"() {
    init_column();
    init_entity();
    init_table();
    init_sql();
    eq = (left, right) => {
      return sql`${left} = ${bindIfParam(right, left)}`;
    };
    ne = (left, right) => {
      return sql`${left} <> ${bindIfParam(right, left)}`;
    };
    gt = (left, right) => {
      return sql`${left} > ${bindIfParam(right, left)}`;
    };
    gte = (left, right) => {
      return sql`${left} >= ${bindIfParam(right, left)}`;
    };
    lt = (left, right) => {
      return sql`${left} < ${bindIfParam(right, left)}`;
    };
    lte = (left, right) => {
      return sql`${left} <= ${bindIfParam(right, left)}`;
    };
  }
});

// node_modules/drizzle-orm/sql/expressions/select.js
function asc(column) {
  return sql`${column} asc`;
}
function desc(column) {
  return sql`${column} desc`;
}
var init_select = __esm({
  "node_modules/drizzle-orm/sql/expressions/select.js"() {
    init_sql();
  }
});

// node_modules/drizzle-orm/sql/expressions/index.js
var init_expressions = __esm({
  "node_modules/drizzle-orm/sql/expressions/index.js"() {
    init_conditions();
    init_select();
  }
});

// node_modules/drizzle-orm/relations.js
function getOperators() {
  return {
    and,
    between,
    eq,
    exists,
    gt,
    gte,
    ilike,
    inArray,
    isNull,
    isNotNull,
    like,
    lt,
    lte,
    ne,
    not,
    notBetween,
    notExists,
    notLike,
    notIlike,
    notInArray,
    or,
    sql
  };
}
function getOrderByOperators() {
  return {
    sql,
    asc,
    desc
  };
}
function normalizeRelation(schema, tableNamesMap, relation) {
  if (is(relation, One) && relation.config) {
    return {
      fields: relation.config.fields,
      references: relation.config.references
    };
  }
  const referencedTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
  if (!referencedTableTsName) {
    throw new Error(
      `Table "${relation.referencedTable[Table.Symbol.Name]}" not found in schema`
    );
  }
  const referencedTableConfig = schema[referencedTableTsName];
  if (!referencedTableConfig) {
    throw new Error(`Table "${referencedTableTsName}" not found in schema`);
  }
  const sourceTable = relation.sourceTable;
  const sourceTableTsName = tableNamesMap[getTableUniqueName(sourceTable)];
  if (!sourceTableTsName) {
    throw new Error(
      `Table "${sourceTable[Table.Symbol.Name]}" not found in schema`
    );
  }
  const reverseRelations = [];
  for (const referencedTableRelation of Object.values(
    referencedTableConfig.relations
  )) {
    if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) {
      reverseRelations.push(referencedTableRelation);
    }
  }
  if (reverseRelations.length > 1) {
    throw relation.relationName ? new Error(
      `There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`
    ) : new Error(
      `There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[Table.Symbol.Name]}". Please specify relation name`
    );
  }
  if (reverseRelations[0] && is(reverseRelations[0], One) && reverseRelations[0].config) {
    return {
      fields: reverseRelations[0].config.references,
      references: reverseRelations[0].config.fields
    };
  }
  throw new Error(
    `There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`
  );
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
  const result = {};
  for (const [
    selectionItemIndex,
    selectionItem
  ] of buildQueryResultSelection.entries()) {
    if (selectionItem.isJson) {
      const relation = tableConfig.relations[selectionItem.tsKey];
      const rawSubRows = row[selectionItemIndex];
      const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
      result[selectionItem.tsKey] = is(relation, One) ? subRows && mapRelationalRow(
        tablesConfig,
        tablesConfig[selectionItem.relationTableTsKey],
        subRows,
        selectionItem.selection,
        mapColumnValue
      ) : subRows.map(
        (subRow) => mapRelationalRow(
          tablesConfig,
          tablesConfig[selectionItem.relationTableTsKey],
          subRow,
          selectionItem.selection,
          mapColumnValue
        )
      );
    } else {
      const value = mapColumnValue(row[selectionItemIndex]);
      const field = selectionItem.field;
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
    }
  }
  return result;
}
var Relation, Relations, One, Many;
var init_relations = __esm({
  "node_modules/drizzle-orm/relations.js"() {
    init_table();
    init_column();
    init_entity();
    init_primary_keys();
    init_expressions();
    init_sql();
    Relation = class {
      constructor(sourceTable, referencedTable, relationName) {
        this.sourceTable = sourceTable;
        this.referencedTable = referencedTable;
        this.relationName = relationName;
        this.referencedTableName = referencedTable[Table.Symbol.Name];
      }
      static [entityKind] = "Relation";
      referencedTableName;
      fieldName;
    };
    Relations = class {
      constructor(table, config) {
        this.table = table;
        this.config = config;
      }
      static [entityKind] = "Relations";
    };
    One = class _One extends Relation {
      constructor(sourceTable, referencedTable, config, isNullable) {
        super(sourceTable, referencedTable, config?.relationName);
        this.config = config;
        this.isNullable = isNullable;
      }
      static [entityKind] = "One";
      withFieldName(fieldName2) {
        const relation = new _One(
          this.sourceTable,
          this.referencedTable,
          this.config,
          this.isNullable
        );
        relation.fieldName = fieldName2;
        return relation;
      }
    };
    Many = class _Many extends Relation {
      constructor(sourceTable, referencedTable, config) {
        super(sourceTable, referencedTable, config?.relationName);
        this.config = config;
      }
      static [entityKind] = "Many";
      withFieldName(fieldName2) {
        const relation = new _Many(
          this.sourceTable,
          this.referencedTable,
          this.config
        );
        relation.fieldName = fieldName2;
        return relation;
      }
    };
  }
});

// node_modules/drizzle-orm/alias.js
function aliasedTable(table, tableAlias) {
  return new Proxy(table, new TableAliasProxyHandler(tableAlias, false));
}
function aliasedTableColumn(column, tableAlias) {
  return new Proxy(
    column,
    new ColumnAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false)))
  );
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
  return new SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
  return sql.join(query.queryChunks.map((c) => {
    if (is(c, Column)) {
      return aliasedTableColumn(c, alias);
    }
    if (is(c, SQL)) {
      return mapColumnsInSQLToAlias(c, alias);
    }
    if (is(c, SQL.Aliased)) {
      return mapColumnsInAliasedSQLToAlias(c, alias);
    }
    return c;
  }));
}
var ColumnAliasProxyHandler, TableAliasProxyHandler, RelationTableAliasProxyHandler;
var init_alias = __esm({
  "node_modules/drizzle-orm/alias.js"() {
    init_column();
    init_entity();
    init_sql();
    init_table();
    init_view_common();
    ColumnAliasProxyHandler = class {
      constructor(table) {
        this.table = table;
      }
      static [entityKind] = "ColumnAliasProxyHandler";
      get(columnObj, prop) {
        if (prop === "table") {
          return this.table;
        }
        return columnObj[prop];
      }
    };
    TableAliasProxyHandler = class {
      constructor(alias, replaceOriginalName) {
        this.alias = alias;
        this.replaceOriginalName = replaceOriginalName;
      }
      static [entityKind] = "TableAliasProxyHandler";
      get(target, prop) {
        if (prop === Table.Symbol.IsAlias) {
          return true;
        }
        if (prop === Table.Symbol.Name) {
          return this.alias;
        }
        if (this.replaceOriginalName && prop === Table.Symbol.OriginalName) {
          return this.alias;
        }
        if (prop === ViewBaseConfig) {
          return {
            ...target[ViewBaseConfig],
            name: this.alias,
            isAlias: true
          };
        }
        if (prop === Table.Symbol.Columns) {
          const columns = target[Table.Symbol.Columns];
          if (!columns) {
            return columns;
          }
          const proxiedColumns = {};
          Object.keys(columns).map((key) => {
            proxiedColumns[key] = new Proxy(
              columns[key],
              new ColumnAliasProxyHandler(new Proxy(target, this))
            );
          });
          return proxiedColumns;
        }
        const value = target[prop];
        if (is(value, Column)) {
          return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
        }
        return value;
      }
    };
    RelationTableAliasProxyHandler = class {
      constructor(alias) {
        this.alias = alias;
      }
      static [entityKind] = "RelationTableAliasProxyHandler";
      get(target, prop) {
        if (prop === "sourceTable") {
          return aliasedTable(target.sourceTable, this.alias);
        }
        return target[prop];
      }
    };
  }
});

// node_modules/drizzle-orm/selection-proxy.js
var SelectionProxyHandler;
var init_selection_proxy = __esm({
  "node_modules/drizzle-orm/selection-proxy.js"() {
    init_alias();
    init_column();
    init_entity();
    init_sql();
    init_subquery();
    init_view_common();
    SelectionProxyHandler = class _SelectionProxyHandler {
      static [entityKind] = "SelectionProxyHandler";
      config;
      constructor(config) {
        this.config = { ...config };
      }
      get(subquery, prop) {
        if (prop === "_") {
          return {
            ...subquery["_"],
            selectedFields: new Proxy(
              subquery._.selectedFields,
              this
            )
          };
        }
        if (prop === ViewBaseConfig) {
          return {
            ...subquery[ViewBaseConfig],
            selectedFields: new Proxy(
              subquery[ViewBaseConfig].selectedFields,
              this
            )
          };
        }
        if (typeof prop === "symbol") {
          return subquery[prop];
        }
        const columns = is(subquery, Subquery) ? subquery._.selectedFields : is(subquery, View) ? subquery[ViewBaseConfig].selectedFields : subquery;
        const value = columns[prop];
        if (is(value, SQL.Aliased)) {
          if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) {
            return value.sql;
          }
          const newValue = value.clone();
          newValue.isSelectionField = true;
          return newValue;
        }
        if (is(value, SQL)) {
          if (this.config.sqlBehavior === "sql") {
            return value;
          }
          throw new Error(
            `You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`
          );
        }
        if (is(value, Column)) {
          if (this.config.alias) {
            return new Proxy(
              value,
              new ColumnAliasProxyHandler(
                new Proxy(
                  value.table,
                  new TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false)
                )
              )
            );
          }
          return value;
        }
        if (typeof value !== "object" || value === null) {
          return value;
        }
        return new Proxy(value, new _SelectionProxyHandler(this.config));
      }
    };
  }
});

// node_modules/drizzle-orm/query-promise.js
var QueryPromise;
var init_query_promise = __esm({
  "node_modules/drizzle-orm/query-promise.js"() {
    init_entity();
    QueryPromise = class {
      static [entityKind] = "QueryPromise";
      [Symbol.toStringTag] = "QueryPromise";
      catch(onRejected) {
        return this.then(void 0, onRejected);
      }
      finally(onFinally) {
        return this.then(
          (value) => {
            onFinally?.();
            return value;
          },
          (reason) => {
            onFinally?.();
            throw reason;
          }
        );
      }
      then(onFulfilled, onRejected) {
        return this.execute().then(onFulfilled, onRejected);
      }
    };
  }
});

// node_modules/drizzle-orm/casing.js
function toSnakeCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.reduce((acc, word, i) => {
    const formattedWord = i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`;
    return acc + formattedWord;
  }, "");
}
function noopCase(input) {
  return input;
}
var CasingCache;
var init_casing = __esm({
  "node_modules/drizzle-orm/casing.js"() {
    init_entity();
    init_table();
    CasingCache = class {
      static [entityKind] = "CasingCache";
      /** @internal */
      cache = {};
      cachedTables = {};
      convert;
      constructor(casing) {
        this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
      }
      getColumnCasing(column) {
        if (!column.keyAsName) return column.name;
        const schema = column.table[Table.Symbol.Schema] ?? "public";
        const tableName = column.table[Table.Symbol.OriginalName];
        const key = `${schema}.${tableName}.${column.name}`;
        if (!this.cache[key]) {
          this.cacheTable(column.table);
        }
        return this.cache[key];
      }
      cacheTable(table) {
        const schema = table[Table.Symbol.Schema] ?? "public";
        const tableName = table[Table.Symbol.OriginalName];
        const tableKey = `${schema}.${tableName}`;
        if (!this.cachedTables[tableKey]) {
          for (const column of Object.values(table[Table.Symbol.Columns])) {
            const columnKey = `${tableKey}.${column.name}`;
            this.cache[columnKey] = this.convert(column.name);
          }
          this.cachedTables[tableKey] = true;
        }
      }
      clearCache() {
        this.cache = {};
        this.cachedTables = {};
      }
    };
  }
});

// node_modules/drizzle-orm/errors.js
var DrizzleError, DrizzleQueryError, TransactionRollbackError;
var init_errors = __esm({
  "node_modules/drizzle-orm/errors.js"() {
    init_entity();
    DrizzleError = class extends Error {
      static [entityKind] = "DrizzleError";
      constructor({ message, cause }) {
        super(message);
        this.name = "DrizzleError";
        this.cause = cause;
      }
    };
    DrizzleQueryError = class _DrizzleQueryError extends Error {
      constructor(query, params, cause) {
        super(`Failed query: ${query}
params: ${params}`);
        this.query = query;
        this.params = params;
        this.cause = cause;
        Error.captureStackTrace(this, _DrizzleQueryError);
        if (cause) this.cause = cause;
      }
    };
    TransactionRollbackError = class extends DrizzleError {
      static [entityKind] = "TransactionRollbackError";
      constructor() {
        super({ message: "Rollback" });
      }
    };
  }
});

// node_modules/drizzle-orm/sql/functions/aggregate.js
var init_aggregate = __esm({
  "node_modules/drizzle-orm/sql/functions/aggregate.js"() {
    init_column();
    init_entity();
    init_sql();
  }
});

// node_modules/drizzle-orm/sql/functions/vector.js
var init_vector2 = __esm({
  "node_modules/drizzle-orm/sql/functions/vector.js"() {
    init_sql();
  }
});

// node_modules/drizzle-orm/sql/functions/index.js
var init_functions = __esm({
  "node_modules/drizzle-orm/sql/functions/index.js"() {
    init_aggregate();
    init_vector2();
  }
});

// node_modules/drizzle-orm/sql/index.js
var init_sql2 = __esm({
  "node_modules/drizzle-orm/sql/index.js"() {
    init_expressions();
    init_functions();
    init_sql();
  }
});

// node_modules/drizzle-orm/query-builders/query-builder.js
var TypedQueryBuilder;
var init_query_builder = __esm({
  "node_modules/drizzle-orm/query-builders/query-builder.js"() {
    init_entity();
    TypedQueryBuilder = class {
      static [entityKind] = "TypedQueryBuilder";
      /** @internal */
      getSelectedFields() {
        return this._.selectedFields;
      }
    };
  }
});

// node_modules/drizzle-orm/cache/core/cache.js
async function hashQuery(sql2, params) {
  const dataToHash = `${sql2}-${JSON.stringify(params)}`;
  const encoder8 = new TextEncoder();
  const data = encoder8.encode(dataToHash);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = [...new Uint8Array(hashBuffer)];
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}
var Cache, NoopCache;
var init_cache = __esm({
  "node_modules/drizzle-orm/cache/core/cache.js"() {
    init_entity();
    Cache = class {
      static [entityKind] = "Cache";
    };
    NoopCache = class extends Cache {
      strategy() {
        return "all";
      }
      static [entityKind] = "NoopCache";
      async get(_key) {
        return void 0;
      }
      async put(_hashedQuery, _response, _tables, _config) {
      }
      async onMutate(_params) {
      }
    };
  }
});

// node_modules/drizzle-orm/cache/core/index.js
var init_core = __esm({
  "node_modules/drizzle-orm/cache/core/index.js"() {
    init_cache();
  }
});

// node_modules/drizzle-orm/operations.js
var init_operations = __esm({
  "node_modules/drizzle-orm/operations.js"() {
  }
});

// node_modules/drizzle-orm/index.js
var init_drizzle_orm = __esm({
  "node_modules/drizzle-orm/index.js"() {
    init_alias();
    init_column_builder();
    init_column();
    init_entity();
    init_errors();
    init_logger();
    init_operations();
    init_query_promise();
    init_relations();
    init_sql2();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
  }
});

// packages/core/src/lib/analytics-ttft-sql.ts
var init_analytics_ttft_sql = __esm({
  "packages/core/src/lib/analytics-ttft-sql.ts"() {
    "use strict";
  }
});

// packages/core/src/lib/money-precision.ts
var GATEWAY_MONEY_DECIMAL_PLACES, SCALE;
var init_money_precision = __esm({
  "packages/core/src/lib/money-precision.ts"() {
    "use strict";
    GATEWAY_MONEY_DECIMAL_PLACES = 6;
    SCALE = 10 ** GATEWAY_MONEY_DECIMAL_PLACES;
  }
});

// packages/core/src/db/d1/admin-analytics.impl.ts
var init_admin_analytics_impl = __esm({
  "packages/core/src/db/d1/admin-analytics.impl.ts"() {
    "use strict";
    init_analytics_ttft_sql();
    init_money_precision();
  }
});

// packages/core/src/db/batch-types.ts
var MAX_BATCH_INPUT_BYTES, MAX_BATCH_ITEM_RANGE_BYTES, MAX_BATCH_LEASE_MILLISECONDS;
var init_batch_types = __esm({
  "packages/core/src/db/batch-types.ts"() {
    "use strict";
    MAX_BATCH_INPUT_BYTES = 50 * 1024 * 1024;
    MAX_BATCH_ITEM_RANGE_BYTES = 1024 * 1024 + 2;
    MAX_BATCH_LEASE_MILLISECONDS = 5 * 60 * 1e3;
  }
});

// packages/core/src/db/batch-repository-utils.ts
var init_batch_repository_utils = __esm({
  "packages/core/src/db/batch-repository-utils.ts"() {
    "use strict";
    init_batch_types();
  }
});

// packages/core/src/db/d1/batches.impl.ts
var init_batches_impl = __esm({
  "packages/core/src/db/d1/batches.impl.ts"() {
    "use strict";
    init_batch_types();
    init_batch_repository_utils();
  }
});

// packages/core/src/lib/key-hash.ts
var encoder;
var init_key_hash = __esm({
  "packages/core/src/lib/key-hash.ts"() {
    "use strict";
    encoder = new TextEncoder();
  }
});

// packages/core/src/db/user-audit-catalog.ts
var USER_AUDIT_EVENT_TYPES, USER_AUDIT_SOURCE_CHANNELS, USER_AUDIT_ACTOR_TYPES, USER_AUDIT_ACTOR_KINDS, ACTOR_KIND_SET, EVENT_SET, SOURCE_SET, ACTOR_TYPE_SET;
var init_user_audit_catalog = __esm({
  "packages/core/src/db/user-audit-catalog.ts"() {
    "use strict";
    USER_AUDIT_EVENT_TYPES = [
      "usage_charge",
      "period_reset",
      "admin_adjust",
      "key_created",
      "key_revoked",
      "key_deleted",
      "user_created",
      "user_deleted",
      "byok_key_created",
      "byok_key_updated",
      "byok_key_deleted",
      "workspace_created",
      "workspace_updated",
      "workspace_deleted",
      "guardrail_created",
      "guardrail_updated",
      "guardrail_deleted",
      "guardrail_key_assignments_updated",
      "guardrail_member_assignments_updated",
      "workspace_members_added",
      "workspace_members_removed",
      "guardrail_blocked",
      "guardrail_redacted",
      "guardrail_flagged"
    ];
    USER_AUDIT_SOURCE_CHANNELS = [
      "gateway_usage",
      "gateway_auth",
      "gateway_user_service",
      "gateway_key_service",
      "gateway_guardrails",
      "key_provision",
      "gateway_user_provision",
      "admin_users",
      /** Admin `POST /users/:id/budget/transition`（结转/换档预算迁移） */
      "admin_budget_transition",
      "admin_keys",
      "admin_user_key",
      "portal_management_keys",
      "gateway_management_workspaces",
      "gateway_management_guardrails",
      "gateway_management_byok",
      /** 历史兼容：仅归一化读入，新写入不应再产生 */
      "usage_charge",
      "period_reset"
    ];
    USER_AUDIT_ACTOR_TYPES = [
      "system",
      "admin",
      "service",
      "user"
    ];
    USER_AUDIT_ACTOR_KINDS = [
      "console",
      "admin_key",
      "admin",
      "system",
      "service",
      "portal"
    ];
    ACTOR_KIND_SET = new Set(USER_AUDIT_ACTOR_KINDS);
    EVENT_SET = new Set(USER_AUDIT_EVENT_TYPES);
    SOURCE_SET = new Set(USER_AUDIT_SOURCE_CHANNELS);
    ACTOR_TYPE_SET = new Set(USER_AUDIT_ACTOR_TYPES);
  }
});

// packages/core/src/db/user-audit-snapshot.ts
var init_user_audit_snapshot = __esm({
  "packages/core/src/db/user-audit-snapshot.ts"() {
    "use strict";
    init_money_precision();
  }
});

// packages/core/src/db/admin-key-mutation.ts
var init_admin_key_mutation = __esm({
  "packages/core/src/db/admin-key-mutation.ts"() {
    "use strict";
    init_user_audit_catalog();
    init_user_audit_snapshot();
  }
});

// packages/core/src/db/api-keys-types.ts
var init_api_keys_types = __esm({
  "packages/core/src/db/api-keys-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/api-keys-list-sort.ts
var init_api_keys_list_sort = __esm({
  "packages/core/src/db/api-keys-list-sort.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/api-keys.impl.ts
var init_api_keys_impl = __esm({
  "packages/core/src/db/d1/api-keys.impl.ts"() {
    "use strict";
    init_money_precision();
    init_key_hash();
    init_admin_key_mutation();
    init_api_keys_types();
    init_api_keys_list_sort();
  }
});

// packages/core/src/db/patch-allowlists.ts
var init_patch_allowlists = __esm({
  "packages/core/src/db/patch-allowlists.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/model-routes.impl.ts
var init_model_routes_impl = __esm({
  "packages/core/src/db/d1/model-routes.impl.ts"() {
    "use strict";
    init_patch_allowlists();
  }
});

// packages/core/src/db/pricing-profile.ts
var init_pricing_profile = __esm({
  "packages/core/src/db/pricing-profile.ts"() {
    "use strict";
  }
});

// packages/core/src/db/model-modalities.ts
var MODEL_INPUT_MODALITIES, MODEL_OUTPUT_MODALITIES, MAX_CALLABLE_EMBEDDING_MODELS, MAX_CALLABLE_EMBEDDING_MODEL_QUERY_RESULTS, INPUT_SET, OUTPUT_SET;
var init_model_modalities = __esm({
  "packages/core/src/db/model-modalities.ts"() {
    "use strict";
    init_pricing_profile();
    MODEL_INPUT_MODALITIES = ["text", "image", "audio", "video", "file"];
    MODEL_OUTPUT_MODALITIES = [
      "text",
      "image",
      "embeddings",
      "audio",
      "video",
      "rerank",
      "speech",
      "transcription"
    ];
    MAX_CALLABLE_EMBEDDING_MODELS = 1e3;
    MAX_CALLABLE_EMBEDDING_MODEL_QUERY_RESULTS = MAX_CALLABLE_EMBEDDING_MODELS + 1;
    INPUT_SET = new Set(MODEL_INPUT_MODALITIES);
    OUTPUT_SET = new Set(MODEL_OUTPUT_MODALITIES);
  }
});

// packages/core/src/db/d1/model-routing.impl.ts
var init_model_routing_impl = __esm({
  "packages/core/src/db/d1/model-routing.impl.ts"() {
    "use strict";
    init_model_modalities();
  }
});

// packages/core/src/db/model-policy-conditional-write.ts
var init_model_policy_conditional_write = __esm({
  "packages/core/src/db/model-policy-conditional-write.ts"() {
    "use strict";
    init_patch_allowlists();
  }
});

// packages/core/src/db/d1/models.impl.ts
var init_models_impl = __esm({
  "packages/core/src/db/d1/models.impl.ts"() {
    "use strict";
    init_patch_allowlists();
    init_model_policy_conditional_write();
  }
});

// packages/core/src/db/providers-types.ts
var init_providers_types = __esm({
  "packages/core/src/db/providers-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/providers.impl.ts
var init_providers_impl = __esm({
  "packages/core/src/db/d1/providers.impl.ts"() {
    "use strict";
    init_providers_types();
    init_patch_allowlists();
  }
});

// packages/core/src/lib/dashboard-request-stats.ts
var init_dashboard_request_stats = __esm({
  "packages/core/src/lib/dashboard-request-stats.ts"() {
    "use strict";
  }
});

// packages/core/src/db/admin-request-log-detail.ts
var init_admin_request_log_detail = __esm({
  "packages/core/src/db/admin-request-log-detail.ts"() {
    "use strict";
  }
});

// packages/core/src/db/request-logs-types.ts
var MAX_GENERATION_PROVIDER_RESPONSES_JSON_BYTES;
var init_request_logs_types = __esm({
  "packages/core/src/db/request-logs-types.ts"() {
    "use strict";
    MAX_GENERATION_PROVIDER_RESPONSES_JSON_BYTES = 32 * 1024;
  }
});

// packages/core/src/db/request-log-status-filter.ts
var init_request_log_status_filter = __esm({
  "packages/core/src/db/request-log-status-filter.ts"() {
    "use strict";
  }
});

// packages/core/src/db/route-performance-sampling.ts
var init_route_performance_sampling = __esm({
  "packages/core/src/db/route-performance-sampling.ts"() {
    "use strict";
  }
});

// packages/core/src/db/management-api-keys-types.ts
var init_management_api_keys_types = __esm({
  "packages/core/src/db/management-api-keys-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/generation-feedback-types.ts
var GENERATION_FEEDBACK_CATEGORIES, CATEGORY_SET;
var init_generation_feedback_types = __esm({
  "packages/core/src/db/generation-feedback-types.ts"() {
    "use strict";
    init_management_api_keys_types();
    GENERATION_FEEDBACK_CATEGORIES = [
      "latency",
      "incoherence",
      "incorrect_response",
      "formatting",
      "billing",
      "api_error",
      "other"
    ];
    CATEGORY_SET = new Set(GENERATION_FEEDBACK_CATEGORIES);
  }
});

// packages/core/src/db/provider-attempt-availability.ts
var init_provider_attempt_availability = __esm({
  "packages/core/src/db/provider-attempt-availability.ts"() {
    "use strict";
  }
});

// packages/core/src/db/analytics-query.ts
var ANALYTICS_METRICS, ANALYTICS_DIMENSIONS, ANALYTICS_GRANULARITIES, ANALYTICS_FILTER_OPERATORS, METRIC_SET, DIMENSION_SET, GRANULARITY_SET, FILTER_OPERATOR_SET;
var init_analytics_query = __esm({
  "packages/core/src/db/analytics-query.ts"() {
    "use strict";
    init_management_api_keys_types();
    ANALYTICS_METRICS = [
      "request_count",
      "total_usage",
      "credits_usage",
      "openrouter_usage",
      "byok_usage",
      "byok_fees",
      "usage_upstream",
      "tokens_total",
      "tokens_prompt",
      "tokens_completion",
      "reasoning_tokens",
      "cached_tokens",
      "byok_request_count",
      "avg_latency",
      "cache_hit_rate"
    ];
    ANALYTICS_DIMENSIONS = [
      "model",
      "provider",
      "api_key_id",
      "user",
      "workspace",
      "app",
      "generation_id",
      "session_id",
      "finish_reason",
      "service_tier",
      "is_byok"
    ];
    ANALYTICS_GRANULARITIES = [
      "minute",
      "hour",
      "day",
      "week",
      "month"
    ];
    ANALYTICS_FILTER_OPERATORS = [
      "eq",
      "neq",
      "gt",
      "gte",
      "lt",
      "lte",
      "in",
      "not_in"
    ];
    METRIC_SET = new Set(ANALYTICS_METRICS);
    DIMENSION_SET = new Set(ANALYTICS_DIMENSIONS);
    GRANULARITY_SET = new Set(ANALYTICS_GRANULARITIES);
    FILTER_OPERATOR_SET = new Set(ANALYTICS_FILTER_OPERATORS);
  }
});

// packages/core/src/db/d1/request-logs.impl.ts
var init_request_logs_impl = __esm({
  "packages/core/src/db/d1/request-logs.impl.ts"() {
    "use strict";
    init_money_precision();
    init_dashboard_request_stats();
    init_admin_request_log_detail();
    init_request_logs_types();
    init_request_log_status_filter();
    init_route_performance_sampling();
    init_generation_feedback_types();
    init_provider_attempt_availability();
    init_analytics_query();
  }
});

// packages/core/src/lib/alert-webhook-system-config.ts
var init_alert_webhook_system_config = __esm({
  "packages/core/src/lib/alert-webhook-system-config.ts"() {
    "use strict";
  }
});

// packages/core/src/db/system-config-audit.ts
var init_system_config_audit = __esm({
  "packages/core/src/db/system-config-audit.ts"() {
    "use strict";
    init_alert_webhook_system_config();
  }
});

// packages/core/src/db/system-config-group.ts
var init_system_config_group = __esm({
  "packages/core/src/db/system-config-group.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/system-config.impl.ts
var init_system_config_impl = __esm({
  "packages/core/src/db/d1/system-config.impl.ts"() {
    "use strict";
    init_system_config_audit();
    init_system_config_group();
  }
});

// packages/core/src/db/d1/route-pool-sticky-bindings.impl.ts
var init_route_pool_sticky_bindings_impl = __esm({
  "packages/core/src/db/d1/route-pool-sticky-bindings.impl.ts"() {
    "use strict";
  }
});

// packages/core/src/db/user-audit-log-derived.ts
var init_user_audit_log_derived = __esm({
  "packages/core/src/db/user-audit-log-derived.ts"() {
    "use strict";
    init_money_precision();
  }
});

// packages/core/src/db/user-audit-export-limits.ts
var USER_AUDIT_EXPORT_TEXT_LIMITS;
var init_user_audit_export_limits = __esm({
  "packages/core/src/db/user-audit-export-limits.ts"() {
    "use strict";
    USER_AUDIT_EXPORT_TEXT_LIMITS = {
      id: 512,
      userId: 512,
      apiKeyId: 512,
      requestLogId: 512,
      correlationId: 512,
      actorId: 512,
      userEmail: 320,
      eventType: 256,
      source: 256,
      reasonCode: 256,
      actorType: 256,
      reasonText: 2048,
      userSnapshot: 8192,
      createdAt: 64
    };
  }
});

// packages/core/src/db/d1/user-audit-logs.impl.ts
var exportTextColumns, exportProjection, exportOversized;
var init_user_audit_logs_impl = __esm({
  "packages/core/src/db/d1/user-audit-logs.impl.ts"() {
    "use strict";
    init_user_audit_catalog();
    init_user_audit_log_derived();
    init_user_audit_export_limits();
    exportTextColumns = [
      ["a.id", "id", USER_AUDIT_EXPORT_TEXT_LIMITS.id],
      ["a.created_at", "created_at", USER_AUDIT_EXPORT_TEXT_LIMITS.createdAt],
      ["a.request_log_id", "request_log_id", USER_AUDIT_EXPORT_TEXT_LIMITS.requestLogId],
      ["a.correlation_id", "correlation_id", USER_AUDIT_EXPORT_TEXT_LIMITS.correlationId],
      ["a.event_type", "event_type", USER_AUDIT_EXPORT_TEXT_LIMITS.eventType],
      ["a.source", "source", USER_AUDIT_EXPORT_TEXT_LIMITS.source],
      ["a.reason_code", "reason_code", USER_AUDIT_EXPORT_TEXT_LIMITS.reasonCode],
      ["a.reason_text", "reason_text", USER_AUDIT_EXPORT_TEXT_LIMITS.reasonText],
      ["a.actor_type", "actor_type", USER_AUDIT_EXPORT_TEXT_LIMITS.actorType],
      ["a.actor_id", "actor_id", USER_AUDIT_EXPORT_TEXT_LIMITS.actorId],
      ["a.user_id", "user_id", USER_AUDIT_EXPORT_TEXT_LIMITS.userId],
      ["u.email", "user_email", USER_AUDIT_EXPORT_TEXT_LIMITS.userEmail],
      ["a.api_key_id", "api_key_id", USER_AUDIT_EXPORT_TEXT_LIMITS.apiKeyId],
      ["a.before_user_snapshot", "before_user_snapshot", USER_AUDIT_EXPORT_TEXT_LIMITS.userSnapshot],
      ["a.after_user_snapshot", "after_user_snapshot", USER_AUDIT_EXPORT_TEXT_LIMITS.userSnapshot]
    ];
    exportProjection = exportTextColumns.map(
      ([column, alias, max]) => `CASE WHEN length(CAST(${column} AS BLOB)) > ${max} THEN NULL ELSE ${column} END AS ${alias}`
    ).join(",\n");
    exportOversized = `CASE WHEN ${exportTextColumns.map(
      ([column, , max]) => `length(CAST(${column} AS BLOB)) > ${max}`
    ).join(" OR ")} THEN 1 ELSE 0 END`;
  }
});

// packages/core/src/db/user-budget-reservation-types.ts
var USER_BUDGET_MAX_SAFE_MICROS;
var init_user_budget_reservation_types = __esm({
  "packages/core/src/db/user-budget-reservation-types.ts"() {
    "use strict";
    USER_BUDGET_MAX_SAFE_MICROS = Number.MAX_SAFE_INTEGER;
  }
});

// packages/core/src/db/users-list-sort.ts
var init_users_list_sort = __esm({
  "packages/core/src/db/users-list-sort.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/users.impl.ts
var init_users_impl = __esm({
  "packages/core/src/db/d1/users.impl.ts"() {
    "use strict";
    init_money_precision();
    init_user_budget_reservation_types();
    init_user_audit_catalog();
    init_workspaces();
    init_users_list_sort();
  }
});

// packages/core/src/db/admin-access-audit.ts
var init_admin_access_audit = __esm({
  "packages/core/src/db/admin-access-audit.ts"() {
    "use strict";
  }
});

// packages/core/src/db/admin-access-sql.ts
var init_admin_access_sql = __esm({
  "packages/core/src/db/admin-access-sql.ts"() {
    "use strict";
    init_admin_access_audit();
  }
});

// packages/core/src/db/d1/admin-access.impl.ts
var AUDIT_PERMISSION_VALUES, SAFE_PERMISSIONS_SQL;
var init_admin_access_impl = __esm({
  "packages/core/src/db/d1/admin-access.impl.ts"() {
    "use strict";
    init_key_hash();
    init_admin_access_audit();
    init_admin_access_sql();
    AUDIT_PERMISSION_VALUES = `'*', 'users.read', 'users.write', 'user_keys.read', 'user_keys.write',
  'providers.read', 'providers.write', 'providers.secrets.read', 'models.read', 'models.write',
  'presets.read', 'presets.write', 'guardrails.read', 'guardrails.write', 'routes.read', 'routes.write',
  'config.read', 'config.write', 'config.secrets.read', 'analytics.read', 'logs.read', 'playground.execute'`;
    SAFE_PERMISSIONS_SQL = `CASE WHEN length(permissions_json) <= 4096 AND json_valid(permissions_json) THEN
  CASE WHEN json_type(permissions_json) = 'array' AND NOT EXISTS (
    SELECT 1 FROM json_each(permissions_json)
    WHERE type <> 'text' OR value NOT IN (${AUDIT_PERMISSION_VALUES})
  ) THEN CASE WHEN EXISTS (SELECT 1 FROM json_each(permissions_json) WHERE value = '*') THEN '["*"]'
    ELSE (SELECT json_group_array(value) FROM (SELECT DISTINCT value FROM json_each(permissions_json) ORDER BY value))
    END ELSE NULL END ELSE NULL END`;
  }
});

// packages/core/src/db/d1/request-presets.impl.ts
var init_request_presets_impl = __esm({
  "packages/core/src/db/d1/request-presets.impl.ts"() {
    "use strict";
  }
});

// packages/core/src/db/guardrails-types.ts
var init_guardrails_types = __esm({
  "packages/core/src/db/guardrails-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/guardrails.impl.ts
var init_guardrails_impl = __esm({
  "packages/core/src/db/d1/guardrails.impl.ts"() {
    "use strict";
    init_guardrails_types();
  }
});

// packages/core/src/db/guardrail-budget-repository-utils.ts
var init_guardrail_budget_repository_utils = __esm({
  "packages/core/src/db/guardrail-budget-repository-utils.ts"() {
    "use strict";
    init_guardrail_budget_types();
    init_gateway_key_limits();
    init_workspace_budgets();
  }
});

// packages/core/src/db/d1/guardrail-budgets.impl.ts
var init_guardrail_budgets_impl = __esm({
  "packages/core/src/db/d1/guardrail-budgets.impl.ts"() {
    "use strict";
    init_guardrail_budget_repository_utils();
  }
});

// packages/core/src/db/user-budget-reservation-utils.ts
var init_user_budget_reservation_utils = __esm({
  "packages/core/src/db/user-budget-reservation-utils.ts"() {
    "use strict";
    init_user_budget_reservation_types();
  }
});

// packages/core/src/db/d1/user-budget-reservations.impl.ts
var init_user_budget_reservations_impl = __esm({
  "packages/core/src/db/d1/user-budget-reservations.impl.ts"() {
    "use strict";
    init_user_budget_reservation_types();
    init_user_budget_reservation_utils();
  }
});

// packages/core/src/db/route-data-policy-types.ts
var init_route_data_policy_types = __esm({
  "packages/core/src/db/route-data-policy-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/route-data-policy-conditional-write.ts
var init_route_data_policy_conditional_write = __esm({
  "packages/core/src/db/route-data-policy-conditional-write.ts"() {
    "use strict";
    init_route_data_policy();
    init_route_data_policy_types();
  }
});

// packages/core/src/db/d1/route-data-policies.impl.ts
var init_route_data_policies_impl = __esm({
  "packages/core/src/db/d1/route-data-policies.impl.ts"() {
    "use strict";
    init_route_data_policy_types();
    init_route_data_policy_conditional_write();
  }
});

// packages/core/src/db/model-endpoints-types.ts
var init_model_endpoints_types = __esm({
  "packages/core/src/db/model-endpoints-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/d1/model-endpoints.impl.ts
var init_model_endpoints_impl = __esm({
  "packages/core/src/db/d1/model-endpoints.impl.ts"() {
    "use strict";
    init_model_endpoints_types();
    init_patch_allowlists();
  }
});

// packages/core/src/db/mysql/mysql2-compat.ts
var init_mysql2_compat = __esm({
  "packages/core/src/db/mysql/mysql2-compat.ts"() {
    "use strict";
  }
});

// packages/core/src/storage/management-api-keys.ts
var init_management_api_keys = __esm({
  "packages/core/src/storage/management-api-keys.ts"() {
    "use strict";
    init_management_api_keys_types();
    init_key_hash();
    init_mysql2_compat();
  }
});

// packages/core/src/db/byok-keys-types.ts
var BYOK_MAX_CREDENTIAL_BYTES;
var init_byok_keys_types = __esm({
  "packages/core/src/db/byok-keys-types.ts"() {
    "use strict";
    BYOK_MAX_CREDENTIAL_BYTES = 64 * 1024;
  }
});

// packages/core/src/db/shared-keys-types.ts
var init_shared_keys_types = __esm({
  "packages/core/src/db/shared-keys-types.ts"() {
    "use strict";
  }
});

// packages/core/src/db/shared-key-state.ts
var init_shared_key_state = __esm({
  "packages/core/src/db/shared-key-state.ts"() {
    "use strict";
  }
});

// packages/core/src/db/admin-shared-key-governance.ts
var init_admin_shared_key_governance = __esm({
  "packages/core/src/db/admin-shared-key-governance.ts"() {
    "use strict";
    init_key_hash();
    init_shared_keys_types();
    init_shared_key_state();
  }
});

// packages/core/src/lib/shared-key-encryption.ts
var init_shared_key_encryption = __esm({
  "packages/core/src/lib/shared-key-encryption.ts"() {
    "use strict";
    init_preparation_control();
    init_admin_shared_key_governance();
  }
});

// packages/core/src/storage/byok-keys.ts
var METADATA_COLUMNS, RUNTIME_COLUMNS;
var init_byok_keys = __esm({
  "packages/core/src/storage/byok-keys.ts"() {
    "use strict";
    init_byok_keys_types();
    init_management_api_keys_types();
    init_mysql2_compat();
    init_shared_key_encryption();
    METADATA_COLUMNS = `byok.id, byok.workspace_id, byok.provider, byok.name,
	byok.label, byok.disabled, byok.is_fallback, byok.always_use_for_provider,
	byok.always_use_for_matching_models, byok.sort_order,
	byok.allowed_models_json, byok.allowed_user_ids_json,
	byok.allowed_api_key_hashes_json, byok.created_by_management_key_id,
	byok.created_at, byok.updated_at`;
    RUNTIME_COLUMNS = `${METADATA_COLUMNS}, byok.api_key_encrypted AS api_key`;
  }
});

// packages/core/src/db/admin-shared-key-repository.ts
var init_admin_shared_key_repository = __esm({
  "packages/core/src/db/admin-shared-key-repository.ts"() {
    "use strict";
    init_mysql2_compat();
    init_shared_key_state();
    init_shared_keys_types();
    init_admin_shared_key_governance();
  }
});

// packages/core/src/db/d1/portal-marketplace.impl.ts
var init_portal_marketplace_impl = __esm({
  "packages/core/src/db/d1/portal-marketplace.impl.ts"() {
    "use strict";
    init_admin_shared_key_repository();
    init_shared_key_state();
  }
});

// packages/core/src/storage/repositories-d1.ts
var init_repositories_d1 = __esm({
  "packages/core/src/storage/repositories-d1.ts"() {
    "use strict";
    init_admin_analytics_impl();
    init_batches_impl();
    init_api_keys_impl();
    init_model_routes_impl();
    init_model_routing_impl();
    init_models_impl();
    init_providers_impl();
    init_request_logs_impl();
    init_system_config_impl();
    init_route_pool_sticky_bindings_impl();
    init_user_audit_logs_impl();
    init_users_impl();
    init_admin_access_impl();
    init_request_presets_impl();
    init_guardrails_impl();
    init_guardrail_budgets_impl();
    init_user_budget_reservations_impl();
    init_route_data_policies_impl();
    init_model_endpoints_impl();
    init_management_api_keys();
    init_byok_keys();
    init_portal_marketplace_impl();
  }
});

// packages/core/src/storage/postgres-connection-error.ts
var init_postgres_connection_error = __esm({
  "packages/core/src/storage/postgres-connection-error.ts"() {
    "use strict";
  }
});

// packages/core/src/storage/postgres-initialization.ts
var init_postgres_initialization = __esm({
  "packages/core/src/storage/postgres-initialization.ts"() {
    "use strict";
    init_postgres_connection_error();
  }
});

// packages/core/src/storage/critical-write-paths-utils.ts
var init_critical_write_paths_utils = __esm({
  "packages/core/src/storage/critical-write-paths-utils.ts"() {
    "use strict";
    init_money_precision();
  }
});

// packages/core/src/db/user-audit-drizzle-insert.ts
var init_user_audit_drizzle_insert = __esm({
  "packages/core/src/db/user-audit-drizzle-insert.ts"() {
    "use strict";
    init_user_audit_catalog();
  }
});

// node_modules/drizzle-orm/mysql-core/alias.js
var init_alias2 = __esm({
  "node_modules/drizzle-orm/mysql-core/alias.js"() {
    init_alias();
  }
});

// node_modules/drizzle-orm/mysql-core/checks.js
function check2(name, value) {
  return new CheckBuilder2(name, value);
}
var CheckBuilder2, Check2;
var init_checks = __esm({
  "node_modules/drizzle-orm/mysql-core/checks.js"() {
    init_entity();
    CheckBuilder2 = class {
      constructor(name, value) {
        this.name = name;
        this.value = value;
      }
      static [entityKind] = "MySqlCheckBuilder";
      brand;
      /** @internal */
      build(table) {
        return new Check2(table, this);
      }
    };
    Check2 = class {
      constructor(table, builder) {
        this.table = table;
        this.name = builder.name;
        this.value = builder.value;
      }
      static [entityKind] = "MySqlCheck";
      name;
      value;
    };
  }
});

// node_modules/drizzle-orm/mysql-core/foreign-keys.js
var ForeignKeyBuilder3, ForeignKey3;
var init_foreign_keys2 = __esm({
  "node_modules/drizzle-orm/mysql-core/foreign-keys.js"() {
    init_entity();
    init_table_utils();
    ForeignKeyBuilder3 = class {
      static [entityKind] = "MySqlForeignKeyBuilder";
      /** @internal */
      reference;
      /** @internal */
      _onUpdate;
      /** @internal */
      _onDelete;
      constructor(config, actions) {
        this.reference = () => {
          const { name, columns, foreignColumns } = config();
          return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
        };
        if (actions) {
          this._onUpdate = actions.onUpdate;
          this._onDelete = actions.onDelete;
        }
      }
      onUpdate(action) {
        this._onUpdate = action;
        return this;
      }
      onDelete(action) {
        this._onDelete = action;
        return this;
      }
      /** @internal */
      build(table) {
        return new ForeignKey3(table, this);
      }
    };
    ForeignKey3 = class {
      constructor(table, builder) {
        this.table = table;
        this.reference = builder.reference;
        this.onUpdate = builder._onUpdate;
        this.onDelete = builder._onDelete;
      }
      static [entityKind] = "MySqlForeignKey";
      reference;
      onUpdate;
      onDelete;
      getName() {
        const { name, columns, foreignColumns } = this.reference();
        const columnNames = columns.map((column) => column.name);
        const foreignColumnNames = foreignColumns.map((column) => column.name);
        const chunks = [
          this.table[TableName],
          ...columnNames,
          foreignColumns[0].table[TableName],
          ...foreignColumnNames
        ];
        return name ?? `${chunks.join("_")}_fk`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/unique-constraint.js
function uniqueKeyName3(table, columns) {
  return `${table[TableName]}_${columns.join("_")}_unique`;
}
var UniqueConstraintBuilder3, UniqueOnConstraintBuilder3, UniqueConstraint3;
var init_unique_constraint2 = __esm({
  "node_modules/drizzle-orm/mysql-core/unique-constraint.js"() {
    init_entity();
    init_table_utils();
    UniqueConstraintBuilder3 = class {
      constructor(columns, name) {
        this.name = name;
        this.columns = columns;
      }
      static [entityKind] = "MySqlUniqueConstraintBuilder";
      /** @internal */
      columns;
      /** @internal */
      build(table) {
        return new UniqueConstraint3(table, this.columns, this.name);
      }
    };
    UniqueOnConstraintBuilder3 = class {
      static [entityKind] = "MySqlUniqueOnConstraintBuilder";
      /** @internal */
      name;
      constructor(name) {
        this.name = name;
      }
      on(...columns) {
        return new UniqueConstraintBuilder3(columns, this.name);
      }
    };
    UniqueConstraint3 = class {
      constructor(table, columns, name) {
        this.table = table;
        this.columns = columns;
        this.name = name ?? uniqueKeyName3(this.table, this.columns.map((column) => column.name));
      }
      static [entityKind] = "MySqlUniqueConstraint";
      columns;
      name;
      nullsNotDistinct = false;
      getName() {
        return this.name;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/common.js
var MySqlColumnBuilder, MySqlColumn, MySqlColumnBuilderWithAutoIncrement, MySqlColumnWithAutoIncrement;
var init_common2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/common.js"() {
    init_column_builder();
    init_column();
    init_entity();
    init_foreign_keys2();
    init_unique_constraint2();
    MySqlColumnBuilder = class extends ColumnBuilder {
      static [entityKind] = "MySqlColumnBuilder";
      foreignKeyConfigs = [];
      references(ref, actions = {}) {
        this.foreignKeyConfigs.push({ ref, actions });
        return this;
      }
      unique(name) {
        this.config.isUnique = true;
        this.config.uniqueName = name;
        return this;
      }
      generatedAlwaysAs(as, config) {
        this.config.generated = {
          as,
          type: "always",
          mode: config?.mode ?? "virtual"
        };
        return this;
      }
      /** @internal */
      buildForeignKeys(column, table) {
        return this.foreignKeyConfigs.map(({ ref, actions }) => {
          return ((ref2, actions2) => {
            const builder = new ForeignKeyBuilder3(() => {
              const foreignColumn = ref2();
              return { columns: [column], foreignColumns: [foreignColumn] };
            });
            if (actions2.onUpdate) {
              builder.onUpdate(actions2.onUpdate);
            }
            if (actions2.onDelete) {
              builder.onDelete(actions2.onDelete);
            }
            return builder.build(table);
          })(ref, actions);
        });
      }
    };
    MySqlColumn = class extends Column {
      constructor(table, config) {
        if (!config.uniqueName) {
          config.uniqueName = uniqueKeyName3(table, [config.name]);
        }
        super(table, config);
        this.table = table;
      }
      static [entityKind] = "MySqlColumn";
    };
    MySqlColumnBuilderWithAutoIncrement = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlColumnBuilderWithAutoIncrement";
      constructor(name, dataType, columnType) {
        super(name, dataType, columnType);
        this.config.autoIncrement = false;
      }
      autoincrement() {
        this.config.autoIncrement = true;
        this.config.hasDefault = true;
        return this;
      }
    };
    MySqlColumnWithAutoIncrement = class extends MySqlColumn {
      static [entityKind] = "MySqlColumnWithAutoIncrement";
      autoIncrement = this.config.autoIncrement;
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/bigint.js
function bigint2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config.mode === "number") {
    return new MySqlBigInt53Builder(name, config.unsigned);
  }
  return new MySqlBigInt64Builder(name, config.unsigned);
}
var MySqlBigInt53Builder, MySqlBigInt53, MySqlBigInt64Builder, MySqlBigInt64;
var init_bigint2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/bigint.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlBigInt53Builder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlBigInt53Builder";
      constructor(name, unsigned = false) {
        super(name, "number", "MySqlBigInt53");
        this.config.unsigned = unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlBigInt53(
          table,
          this.config
        );
      }
    };
    MySqlBigInt53 = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlBigInt53";
      getSQLType() {
        return `bigint${this.config.unsigned ? " unsigned" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") {
          return value;
        }
        return Number(value);
      }
    };
    MySqlBigInt64Builder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlBigInt64Builder";
      constructor(name, unsigned = false) {
        super(name, "bigint", "MySqlBigInt64");
        this.config.unsigned = unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlBigInt64(
          table,
          this.config
        );
      }
    };
    MySqlBigInt64 = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlBigInt64";
      getSQLType() {
        return `bigint${this.config.unsigned ? " unsigned" : ""}`;
      }
      // eslint-disable-next-line unicorn/prefer-native-coercion-functions
      mapFromDriverValue(value) {
        return BigInt(value);
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/binary.js
function binary(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlBinaryBuilder(name, config.length);
}
var MySqlBinaryBuilder, MySqlBinary;
var init_binary = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/binary.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlBinaryBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlBinaryBuilder";
      constructor(name, length) {
        super(name, "string", "MySqlBinary");
        this.config.length = length;
      }
      /** @internal */
      build(table) {
        return new MySqlBinary(table, this.config);
      }
    };
    MySqlBinary = class extends MySqlColumn {
      static [entityKind] = "MySqlBinary";
      length = this.config.length;
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        if (Buffer.isBuffer(value)) return value.toString();
        const str2 = [];
        for (const v of value) {
          str2.push(v === 49 ? "1" : "0");
        }
        return str2.join("");
      }
      getSQLType() {
        return this.length === void 0 ? `binary` : `binary(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/boolean.js
function boolean2(name) {
  return new MySqlBooleanBuilder(name ?? "");
}
var MySqlBooleanBuilder, MySqlBoolean;
var init_boolean2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/boolean.js"() {
    init_entity();
    init_common2();
    MySqlBooleanBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlBooleanBuilder";
      constructor(name) {
        super(name, "boolean", "MySqlBoolean");
      }
      /** @internal */
      build(table) {
        return new MySqlBoolean(
          table,
          this.config
        );
      }
    };
    MySqlBoolean = class extends MySqlColumn {
      static [entityKind] = "MySqlBoolean";
      getSQLType() {
        return "boolean";
      }
      mapFromDriverValue(value) {
        if (typeof value === "boolean") {
          return value;
        }
        return value === 1;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/char.js
function char2(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlCharBuilder(name, config);
}
var MySqlCharBuilder, MySqlChar;
var init_char2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/char.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlCharBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlCharBuilder";
      constructor(name, config) {
        super(name, "string", "MySqlChar");
        this.config.length = config.length;
        this.config.enum = config.enum;
      }
      /** @internal */
      build(table) {
        return new MySqlChar(
          table,
          this.config
        );
      }
    };
    MySqlChar = class extends MySqlColumn {
      static [entityKind] = "MySqlChar";
      length = this.config.length;
      enumValues = this.config.enum;
      getSQLType() {
        return this.length === void 0 ? `char` : `char(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/custom.js
function customType3(customTypeParams) {
  return (a, b) => {
    const { name, config } = getColumnNameAndConfig(a, b);
    return new MySqlCustomColumnBuilder(name, config, customTypeParams);
  };
}
var MySqlCustomColumnBuilder, MySqlCustomColumn;
var init_custom2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/custom.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlCustomColumnBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlCustomColumnBuilder";
      constructor(name, fieldConfig, customTypeParams) {
        super(name, "custom", "MySqlCustomColumn");
        this.config.fieldConfig = fieldConfig;
        this.config.customTypeParams = customTypeParams;
      }
      /** @internal */
      build(table) {
        return new MySqlCustomColumn(
          table,
          this.config
        );
      }
    };
    MySqlCustomColumn = class extends MySqlColumn {
      static [entityKind] = "MySqlCustomColumn";
      sqlName;
      mapTo;
      mapFrom;
      constructor(table, config) {
        super(table, config);
        this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
        this.mapTo = config.customTypeParams.toDriver;
        this.mapFrom = config.customTypeParams.fromDriver;
      }
      getSQLType() {
        return this.sqlName;
      }
      mapFromDriverValue(value) {
        return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
      }
      mapToDriverValue(value) {
        return typeof this.mapTo === "function" ? this.mapTo(value) : value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/date.js
function date2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "string") {
    return new MySqlDateStringBuilder(name);
  }
  return new MySqlDateBuilder(name);
}
var MySqlDateBuilder, MySqlDate, MySqlDateStringBuilder, MySqlDateString;
var init_date2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/date.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlDateBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlDateBuilder";
      constructor(name) {
        super(name, "date", "MySqlDate");
      }
      /** @internal */
      build(table) {
        return new MySqlDate(table, this.config);
      }
    };
    MySqlDate = class extends MySqlColumn {
      static [entityKind] = "MySqlDate";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return `date`;
      }
      mapFromDriverValue(value) {
        return new Date(value);
      }
    };
    MySqlDateStringBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlDateStringBuilder";
      constructor(name) {
        super(name, "string", "MySqlDateString");
      }
      /** @internal */
      build(table) {
        return new MySqlDateString(
          table,
          this.config
        );
      }
    };
    MySqlDateString = class extends MySqlColumn {
      static [entityKind] = "MySqlDateString";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return `date`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/datetime.js
function datetime(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "string") {
    return new MySqlDateTimeStringBuilder(name, config);
  }
  return new MySqlDateTimeBuilder(name, config);
}
var MySqlDateTimeBuilder, MySqlDateTime, MySqlDateTimeStringBuilder, MySqlDateTimeString;
var init_datetime = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/datetime.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlDateTimeBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlDateTimeBuilder";
      constructor(name, config) {
        super(name, "date", "MySqlDateTime");
        this.config.fsp = config?.fsp;
      }
      /** @internal */
      build(table) {
        return new MySqlDateTime(
          table,
          this.config
        );
      }
    };
    MySqlDateTime = class extends MySqlColumn {
      static [entityKind] = "MySqlDateTime";
      fsp;
      constructor(table, config) {
        super(table, config);
        this.fsp = config.fsp;
      }
      getSQLType() {
        const precision = this.fsp === void 0 ? "" : `(${this.fsp})`;
        return `datetime${precision}`;
      }
      mapToDriverValue(value) {
        return value.toISOString().replace("T", " ").replace("Z", "");
      }
      mapFromDriverValue(value) {
        return /* @__PURE__ */ new Date(value.replace(" ", "T") + "Z");
      }
    };
    MySqlDateTimeStringBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlDateTimeStringBuilder";
      constructor(name, config) {
        super(name, "string", "MySqlDateTimeString");
        this.config.fsp = config?.fsp;
      }
      /** @internal */
      build(table) {
        return new MySqlDateTimeString(
          table,
          this.config
        );
      }
    };
    MySqlDateTimeString = class extends MySqlColumn {
      static [entityKind] = "MySqlDateTimeString";
      fsp;
      constructor(table, config) {
        super(table, config);
        this.fsp = config.fsp;
      }
      getSQLType() {
        const precision = this.fsp === void 0 ? "" : `(${this.fsp})`;
        return `datetime${precision}`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/decimal.js
function decimal(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  const mode = config?.mode;
  return mode === "number" ? new MySqlDecimalNumberBuilder(name, config) : mode === "bigint" ? new MySqlDecimalBigIntBuilder(name, config) : new MySqlDecimalBuilder(name, config);
}
var MySqlDecimalBuilder, MySqlDecimal, MySqlDecimalNumberBuilder, MySqlDecimalNumber, MySqlDecimalBigIntBuilder, MySqlDecimalBigInt;
var init_decimal = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/decimal.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlDecimalBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlDecimalBuilder";
      constructor(name, config) {
        super(name, "string", "MySqlDecimal");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
        this.config.unsigned = config?.unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlDecimal(
          table,
          this.config
        );
      }
    };
    MySqlDecimal = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlDecimal";
      precision = this.config.precision;
      scale = this.config.scale;
      unsigned = this.config.unsigned;
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        return String(value);
      }
      getSQLType() {
        let type = "";
        if (this.precision !== void 0 && this.scale !== void 0) {
          type += `decimal(${this.precision},${this.scale})`;
        } else if (this.precision === void 0) {
          type += "decimal";
        } else {
          type += `decimal(${this.precision})`;
        }
        type = type === "decimal(10,0)" || type === "decimal(10)" ? "decimal" : type;
        return this.unsigned ? `${type} unsigned` : type;
      }
    };
    MySqlDecimalNumberBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlDecimalNumberBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlDecimalNumber");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
        this.config.unsigned = config?.unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlDecimalNumber(
          table,
          this.config
        );
      }
    };
    MySqlDecimalNumber = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlDecimalNumber";
      precision = this.config.precision;
      scale = this.config.scale;
      unsigned = this.config.unsigned;
      mapFromDriverValue(value) {
        if (typeof value === "number") return value;
        return Number(value);
      }
      mapToDriverValue = String;
      getSQLType() {
        let type = "";
        if (this.precision !== void 0 && this.scale !== void 0) {
          type += `decimal(${this.precision},${this.scale})`;
        } else if (this.precision === void 0) {
          type += "decimal";
        } else {
          type += `decimal(${this.precision})`;
        }
        type = type === "decimal(10,0)" || type === "decimal(10)" ? "decimal" : type;
        return this.unsigned ? `${type} unsigned` : type;
      }
    };
    MySqlDecimalBigIntBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlDecimalBigIntBuilder";
      constructor(name, config) {
        super(name, "bigint", "MySqlDecimalBigInt");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
        this.config.unsigned = config?.unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlDecimalBigInt(
          table,
          this.config
        );
      }
    };
    MySqlDecimalBigInt = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlDecimalBigInt";
      precision = this.config.precision;
      scale = this.config.scale;
      unsigned = this.config.unsigned;
      mapFromDriverValue = BigInt;
      mapToDriverValue = String;
      getSQLType() {
        let type = "";
        if (this.precision !== void 0 && this.scale !== void 0) {
          type += `decimal(${this.precision},${this.scale})`;
        } else if (this.precision === void 0) {
          type += "decimal";
        } else {
          type += `decimal(${this.precision})`;
        }
        type = type === "decimal(10,0)" || type === "decimal(10)" ? "decimal" : type;
        return this.unsigned ? `${type} unsigned` : type;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/double.js
function double(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlDoubleBuilder(name, config);
}
var MySqlDoubleBuilder, MySqlDouble;
var init_double = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/double.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlDoubleBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlDoubleBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlDouble");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
        this.config.unsigned = config?.unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlDouble(table, this.config);
      }
    };
    MySqlDouble = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlDouble";
      precision = this.config.precision;
      scale = this.config.scale;
      unsigned = this.config.unsigned;
      getSQLType() {
        let type = "";
        if (this.precision !== void 0 && this.scale !== void 0) {
          type += `double(${this.precision},${this.scale})`;
        } else if (this.precision === void 0) {
          type += "double";
        } else {
          type += `double(${this.precision})`;
        }
        return this.unsigned ? `${type} unsigned` : type;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/enum.js
function mysqlEnum(a, b) {
  if (typeof a === "string" && Array.isArray(b) || Array.isArray(a)) {
    const name = typeof a === "string" && a.length > 0 ? a : "";
    const values = (typeof a === "string" ? b : a) ?? [];
    if (values.length === 0) {
      throw new Error(`You have an empty array for "${name}" enum values`);
    }
    return new MySqlEnumColumnBuilder(name, values);
  }
  if (typeof a === "string" && typeof b === "object" || typeof a === "object") {
    const name = typeof a === "object" ? "" : a;
    const values = typeof a === "object" ? Object.values(a) : typeof b === "object" ? Object.values(b) : [];
    if (values.length === 0) {
      throw new Error(`You have an empty array for "${name}" enum values`);
    }
    return new MySqlEnumObjectColumnBuilder(name, values);
  }
}
var MySqlEnumColumnBuilder, MySqlEnumColumn, MySqlEnumObjectColumnBuilder, MySqlEnumObjectColumn;
var init_enum2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/enum.js"() {
    init_entity();
    init_common2();
    MySqlEnumColumnBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlEnumColumnBuilder";
      constructor(name, values) {
        super(name, "string", "MySqlEnumColumn");
        this.config.enumValues = values;
      }
      /** @internal */
      build(table) {
        return new MySqlEnumColumn(
          table,
          this.config
        );
      }
    };
    MySqlEnumColumn = class extends MySqlColumn {
      static [entityKind] = "MySqlEnumColumn";
      enumValues = this.config.enumValues;
      getSQLType() {
        return `enum(${this.enumValues.map((value) => `'${value}'`).join(",")})`;
      }
    };
    MySqlEnumObjectColumnBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlEnumObjectColumnBuilder";
      constructor(name, values) {
        super(name, "string", "MySqlEnumObjectColumn");
        this.config.enumValues = values;
      }
      /** @internal */
      build(table) {
        return new MySqlEnumObjectColumn(
          table,
          this.config
        );
      }
    };
    MySqlEnumObjectColumn = class extends MySqlColumn {
      static [entityKind] = "MySqlEnumObjectColumn";
      enumValues = this.config.enumValues;
      getSQLType() {
        return `enum(${this.enumValues.map((value) => `'${value}'`).join(",")})`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/float.js
function float(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlFloatBuilder(name, config);
}
var MySqlFloatBuilder, MySqlFloat;
var init_float = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/float.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlFloatBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlFloatBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlFloat");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
        this.config.unsigned = config?.unsigned;
      }
      /** @internal */
      build(table) {
        return new MySqlFloat(table, this.config);
      }
    };
    MySqlFloat = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlFloat";
      precision = this.config.precision;
      scale = this.config.scale;
      unsigned = this.config.unsigned;
      getSQLType() {
        let type = "";
        if (this.precision !== void 0 && this.scale !== void 0) {
          type += `float(${this.precision},${this.scale})`;
        } else if (this.precision === void 0) {
          type += "float";
        } else {
          type += `float(${this.precision})`;
        }
        return this.unsigned ? `${type} unsigned` : type;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/int.js
function int(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlIntBuilder(name, config);
}
var MySqlIntBuilder, MySqlInt;
var init_int = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/int.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlIntBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlIntBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlInt");
        this.config.unsigned = config ? config.unsigned : false;
      }
      /** @internal */
      build(table) {
        return new MySqlInt(table, this.config);
      }
    };
    MySqlInt = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlInt";
      getSQLType() {
        return `int${this.config.unsigned ? " unsigned" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/json.js
function json2(name) {
  return new MySqlJsonBuilder(name ?? "");
}
var MySqlJsonBuilder, MySqlJson;
var init_json2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/json.js"() {
    init_entity();
    init_common2();
    MySqlJsonBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlJsonBuilder";
      constructor(name) {
        super(name, "json", "MySqlJson");
      }
      /** @internal */
      build(table) {
        return new MySqlJson(table, this.config);
      }
    };
    MySqlJson = class extends MySqlColumn {
      static [entityKind] = "MySqlJson";
      getSQLType() {
        return "json";
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/mediumint.js
function mediumint(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlMediumIntBuilder(name, config);
}
var MySqlMediumIntBuilder, MySqlMediumInt;
var init_mediumint = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/mediumint.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlMediumIntBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlMediumIntBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlMediumInt");
        this.config.unsigned = config ? config.unsigned : false;
      }
      /** @internal */
      build(table) {
        return new MySqlMediumInt(
          table,
          this.config
        );
      }
    };
    MySqlMediumInt = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlMediumInt";
      getSQLType() {
        return `mediumint${this.config.unsigned ? " unsigned" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/real.js
function real3(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlRealBuilder(name, config);
}
var MySqlRealBuilder, MySqlReal;
var init_real2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/real.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlRealBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlRealBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlReal");
        this.config.precision = config?.precision;
        this.config.scale = config?.scale;
      }
      /** @internal */
      build(table) {
        return new MySqlReal(table, this.config);
      }
    };
    MySqlReal = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlReal";
      precision = this.config.precision;
      scale = this.config.scale;
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `real(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "real";
        } else {
          return `real(${this.precision})`;
        }
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/serial.js
function serial2(name) {
  return new MySqlSerialBuilder(name ?? "");
}
var MySqlSerialBuilder, MySqlSerial;
var init_serial2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/serial.js"() {
    init_entity();
    init_common2();
    MySqlSerialBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlSerialBuilder";
      constructor(name) {
        super(name, "number", "MySqlSerial");
        this.config.hasDefault = true;
        this.config.autoIncrement = true;
      }
      /** @internal */
      build(table) {
        return new MySqlSerial(table, this.config);
      }
    };
    MySqlSerial = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlSerial";
      getSQLType() {
        return "serial";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/smallint.js
function smallint2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlSmallIntBuilder(name, config);
}
var MySqlSmallIntBuilder, MySqlSmallInt;
var init_smallint2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/smallint.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlSmallIntBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlSmallIntBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlSmallInt");
        this.config.unsigned = config ? config.unsigned : false;
      }
      /** @internal */
      build(table) {
        return new MySqlSmallInt(
          table,
          this.config
        );
      }
    };
    MySqlSmallInt = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlSmallInt";
      getSQLType() {
        return `smallint${this.config.unsigned ? " unsigned" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/text.js
function text3(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTextBuilder(name, "text", config);
}
function tinytext(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTextBuilder(name, "tinytext", config);
}
function mediumtext(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTextBuilder(name, "mediumtext", config);
}
function longtext(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTextBuilder(name, "longtext", config);
}
var MySqlTextBuilder, MySqlText;
var init_text2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/text.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlTextBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlTextBuilder";
      constructor(name, textType, config) {
        super(name, "string", "MySqlText");
        this.config.textType = textType;
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new MySqlText(table, this.config);
      }
    };
    MySqlText = class extends MySqlColumn {
      static [entityKind] = "MySqlText";
      textType = this.config.textType;
      enumValues = this.config.enumValues;
      getSQLType() {
        return this.textType;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/time.js
function time2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTimeBuilder(name, config);
}
var MySqlTimeBuilder, MySqlTime;
var init_time2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/time.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlTimeBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlTimeBuilder";
      constructor(name, config) {
        super(name, "string", "MySqlTime");
        this.config.fsp = config?.fsp;
      }
      /** @internal */
      build(table) {
        return new MySqlTime(table, this.config);
      }
    };
    MySqlTime = class extends MySqlColumn {
      static [entityKind] = "MySqlTime";
      fsp = this.config.fsp;
      getSQLType() {
        const precision = this.fsp === void 0 ? "" : `(${this.fsp})`;
        return `time${precision}`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/date.common.js
var MySqlDateColumnBaseBuilder, MySqlDateBaseColumn;
var init_date_common2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/date.common.js"() {
    init_entity();
    init_sql();
    init_common2();
    MySqlDateColumnBaseBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlDateColumnBuilder";
      defaultNow() {
        return this.default(sql`(now())`);
      }
      // "on update now" also adds an implicit default value to the column - https://dev.mysql.com/doc/refman/8.0/en/timestamp-initialization.html
      onUpdateNow() {
        this.config.hasOnUpdateNow = true;
        this.config.hasDefault = true;
        return this;
      }
    };
    MySqlDateBaseColumn = class extends MySqlColumn {
      static [entityKind] = "MySqlDateColumn";
      hasOnUpdateNow = this.config.hasOnUpdateNow;
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/timestamp.js
function timestamp2(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "string") {
    return new MySqlTimestampStringBuilder(name, config);
  }
  return new MySqlTimestampBuilder(name, config);
}
var MySqlTimestampBuilder, MySqlTimestamp, MySqlTimestampStringBuilder, MySqlTimestampString;
var init_timestamp2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/timestamp.js"() {
    init_entity();
    init_utils();
    init_date_common2();
    MySqlTimestampBuilder = class extends MySqlDateColumnBaseBuilder {
      static [entityKind] = "MySqlTimestampBuilder";
      constructor(name, config) {
        super(name, "date", "MySqlTimestamp");
        this.config.fsp = config?.fsp;
      }
      /** @internal */
      build(table) {
        return new MySqlTimestamp(
          table,
          this.config
        );
      }
    };
    MySqlTimestamp = class extends MySqlDateBaseColumn {
      static [entityKind] = "MySqlTimestamp";
      fsp = this.config.fsp;
      getSQLType() {
        const precision = this.fsp === void 0 ? "" : `(${this.fsp})`;
        return `timestamp${precision}`;
      }
      mapFromDriverValue(value) {
        return /* @__PURE__ */ new Date(value + "+0000");
      }
      mapToDriverValue(value) {
        return value.toISOString().slice(0, -1).replace("T", " ");
      }
    };
    MySqlTimestampStringBuilder = class extends MySqlDateColumnBaseBuilder {
      static [entityKind] = "MySqlTimestampStringBuilder";
      constructor(name, config) {
        super(name, "string", "MySqlTimestampString");
        this.config.fsp = config?.fsp;
      }
      /** @internal */
      build(table) {
        return new MySqlTimestampString(
          table,
          this.config
        );
      }
    };
    MySqlTimestampString = class extends MySqlDateBaseColumn {
      static [entityKind] = "MySqlTimestampString";
      fsp = this.config.fsp;
      getSQLType() {
        const precision = this.fsp === void 0 ? "" : `(${this.fsp})`;
        return `timestamp${precision}`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/tinyint.js
function tinyint(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlTinyIntBuilder(name, config);
}
var MySqlTinyIntBuilder, MySqlTinyInt;
var init_tinyint = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/tinyint.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlTinyIntBuilder = class extends MySqlColumnBuilderWithAutoIncrement {
      static [entityKind] = "MySqlTinyIntBuilder";
      constructor(name, config) {
        super(name, "number", "MySqlTinyInt");
        this.config.unsigned = config ? config.unsigned : false;
      }
      /** @internal */
      build(table) {
        return new MySqlTinyInt(
          table,
          this.config
        );
      }
    };
    MySqlTinyInt = class extends MySqlColumnWithAutoIncrement {
      static [entityKind] = "MySqlTinyInt";
      getSQLType() {
        return `tinyint${this.config.unsigned ? " unsigned" : ""}`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/varbinary.js
function varbinary(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlVarBinaryBuilder(name, config);
}
var MySqlVarBinaryBuilder, MySqlVarBinary;
var init_varbinary = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/varbinary.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlVarBinaryBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlVarBinaryBuilder";
      /** @internal */
      constructor(name, config) {
        super(name, "string", "MySqlVarBinary");
        this.config.length = config?.length;
      }
      /** @internal */
      build(table) {
        return new MySqlVarBinary(
          table,
          this.config
        );
      }
    };
    MySqlVarBinary = class extends MySqlColumn {
      static [entityKind] = "MySqlVarBinary";
      length = this.config.length;
      mapFromDriverValue(value) {
        if (typeof value === "string") return value;
        if (Buffer.isBuffer(value)) return value.toString();
        const str2 = [];
        for (const v of value) {
          str2.push(v === 49 ? "1" : "0");
        }
        return str2.join("");
      }
      getSQLType() {
        return this.length === void 0 ? `varbinary` : `varbinary(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/varchar.js
function varchar2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  return new MySqlVarCharBuilder(name, config);
}
var MySqlVarCharBuilder, MySqlVarChar;
var init_varchar2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/varchar.js"() {
    init_entity();
    init_utils();
    init_common2();
    MySqlVarCharBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlVarCharBuilder";
      /** @internal */
      constructor(name, config) {
        super(name, "string", "MySqlVarChar");
        this.config.length = config.length;
        this.config.enum = config.enum;
      }
      /** @internal */
      build(table) {
        return new MySqlVarChar(
          table,
          this.config
        );
      }
    };
    MySqlVarChar = class extends MySqlColumn {
      static [entityKind] = "MySqlVarChar";
      length = this.config.length;
      enumValues = this.config.enum;
      getSQLType() {
        return this.length === void 0 ? `varchar` : `varchar(${this.length})`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/year.js
function year(name) {
  return new MySqlYearBuilder(name ?? "");
}
var MySqlYearBuilder, MySqlYear;
var init_year = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/year.js"() {
    init_entity();
    init_common2();
    MySqlYearBuilder = class extends MySqlColumnBuilder {
      static [entityKind] = "MySqlYearBuilder";
      constructor(name) {
        super(name, "number", "MySqlYear");
      }
      /** @internal */
      build(table) {
        return new MySqlYear(table, this.config);
      }
    };
    MySqlYear = class extends MySqlColumn {
      static [entityKind] = "MySqlYear";
      getSQLType() {
        return `year`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/index.js
var init_columns = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/index.js"() {
    init_bigint2();
    init_binary();
    init_boolean2();
    init_char2();
    init_common2();
    init_custom2();
    init_date2();
    init_datetime();
    init_decimal();
    init_double();
    init_enum2();
    init_float();
    init_int();
    init_json2();
    init_mediumint();
    init_real2();
    init_serial2();
    init_smallint2();
    init_text2();
    init_time2();
    init_timestamp2();
    init_tinyint();
    init_varbinary();
    init_varchar2();
    init_year();
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/count.js
var MySqlCountBuilder;
var init_count = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/count.js"() {
    init_entity();
    init_sql();
    MySqlCountBuilder = class _MySqlCountBuilder extends SQL {
      constructor(params) {
        super(_MySqlCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
        this.params = params;
        this.mapWith(Number);
        this.session = params.session;
        this.sql = _MySqlCountBuilder.buildCount(
          params.source,
          params.filters
        );
      }
      sql;
      static [entityKind] = "MySqlCountBuilder";
      [Symbol.toStringTag] = "MySqlCountBuilder";
      session;
      static buildEmbeddedCount(source, filters) {
        return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
      }
      static buildCount(source, filters) {
        return sql`select count(*) as count from ${source}${sql.raw(" where ").if(filters)}${filters}`;
      }
      then(onfulfilled, onrejected) {
        return Promise.resolve(this.session.count(this.sql)).then(
          onfulfilled,
          onrejected
        );
      }
      catch(onRejected) {
        return this.then(void 0, onRejected);
      }
      finally(onFinally) {
        return this.then(
          (value) => {
            onFinally?.();
            return value;
          },
          (reason) => {
            onFinally?.();
            throw reason;
          }
        );
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/indexes.js
function index2(name) {
  return new IndexBuilderOn2(name, false);
}
function uniqueIndex2(name) {
  return new IndexBuilderOn2(name, true);
}
var IndexBuilderOn2, IndexBuilder2, Index2;
var init_indexes = __esm({
  "node_modules/drizzle-orm/mysql-core/indexes.js"() {
    init_entity();
    IndexBuilderOn2 = class {
      constructor(name, unique) {
        this.name = name;
        this.unique = unique;
      }
      static [entityKind] = "MySqlIndexBuilderOn";
      on(...columns) {
        return new IndexBuilder2(this.name, columns, this.unique);
      }
    };
    IndexBuilder2 = class {
      static [entityKind] = "MySqlIndexBuilder";
      /** @internal */
      config;
      constructor(name, columns, unique) {
        this.config = {
          name,
          columns,
          unique
        };
      }
      using(using) {
        this.config.using = using;
        return this;
      }
      algorithm(algorithm) {
        this.config.algorithm = algorithm;
        return this;
      }
      lock(lock) {
        this.config.lock = lock;
        return this;
      }
      /** @internal */
      build(table) {
        return new Index2(this.config, table);
      }
    };
    Index2 = class {
      static [entityKind] = "MySqlIndex";
      config;
      constructor(config, table) {
        this.config = { ...config, table };
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/columns/all.js
function getMySqlColumnBuilders() {
  return {
    bigint: bigint2,
    binary,
    boolean: boolean2,
    char: char2,
    customType: customType3,
    date: date2,
    datetime,
    decimal,
    double,
    mysqlEnum,
    float,
    int,
    json: json2,
    mediumint,
    real: real3,
    serial: serial2,
    smallint: smallint2,
    text: text3,
    time: time2,
    timestamp: timestamp2,
    tinyint,
    varbinary,
    varchar: varchar2,
    year,
    longtext,
    mediumtext,
    tinytext
  };
}
var init_all2 = __esm({
  "node_modules/drizzle-orm/mysql-core/columns/all.js"() {
    init_bigint2();
    init_binary();
    init_boolean2();
    init_char2();
    init_custom2();
    init_date2();
    init_datetime();
    init_decimal();
    init_double();
    init_enum2();
    init_float();
    init_int();
    init_json2();
    init_mediumint();
    init_real2();
    init_serial2();
    init_smallint2();
    init_text2();
    init_time2();
    init_timestamp2();
    init_tinyint();
    init_varbinary();
    init_varchar2();
    init_year();
  }
});

// node_modules/drizzle-orm/mysql-core/table.js
function mysqlTableWithSchema(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new MySqlTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns(getMySqlColumnBuilders()) : columns;
  const builtColumns = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.build(rawTable);
      rawTable[InlineForeignKeys3].push(...colBuilder.buildForeignKeys(column, rawTable));
      return [name2, column];
    })
  );
  const table = Object.assign(rawTable, builtColumns);
  table[Table.Symbol.Columns] = builtColumns;
  table[Table.Symbol.ExtraConfigColumns] = builtColumns;
  if (extraConfig) {
    table[MySqlTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return table;
}
var InlineForeignKeys3, MySqlTable, mysqlTable;
var init_table3 = __esm({
  "node_modules/drizzle-orm/mysql-core/table.js"() {
    init_entity();
    init_table();
    init_all2();
    InlineForeignKeys3 = /* @__PURE__ */ Symbol.for("drizzle:MySqlInlineForeignKeys");
    MySqlTable = class extends Table {
      static [entityKind] = "MySqlTable";
      /** @internal */
      static Symbol = Object.assign({}, Table.Symbol, {
        InlineForeignKeys: InlineForeignKeys3
      });
      /** @internal */
      [Table.Symbol.Columns];
      /** @internal */
      [InlineForeignKeys3] = [];
      /** @internal */
      [Table.Symbol.ExtraConfigBuilder] = void 0;
    };
    mysqlTable = (name, columns, extraConfig) => {
      return mysqlTableWithSchema(name, columns, extraConfig, void 0, name);
    };
  }
});

// node_modules/drizzle-orm/mysql-core/primary-keys.js
function primaryKey3(...config) {
  if (config[0].columns) {
    return new PrimaryKeyBuilder3(config[0].columns, config[0].name);
  }
  return new PrimaryKeyBuilder3(config);
}
var PrimaryKeyBuilder3, PrimaryKey3;
var init_primary_keys2 = __esm({
  "node_modules/drizzle-orm/mysql-core/primary-keys.js"() {
    init_entity();
    init_table3();
    PrimaryKeyBuilder3 = class {
      static [entityKind] = "MySqlPrimaryKeyBuilder";
      /** @internal */
      columns;
      /** @internal */
      name;
      constructor(columns, name) {
        this.columns = columns;
        this.name = name;
      }
      /** @internal */
      build(table) {
        return new PrimaryKey3(table, this.columns, this.name);
      }
    };
    PrimaryKey3 = class {
      constructor(table, columns, name) {
        this.table = table;
        this.columns = columns;
        this.name = name;
      }
      static [entityKind] = "MySqlPrimaryKey";
      columns;
      name;
      getName() {
        return this.name ?? `${this.table[MySqlTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/view-common.js
var MySqlViewConfig;
var init_view_common2 = __esm({
  "node_modules/drizzle-orm/mysql-core/view-common.js"() {
    MySqlViewConfig = /* @__PURE__ */ Symbol.for("drizzle:MySqlViewConfig");
  }
});

// node_modules/drizzle-orm/mysql-core/utils.js
function extractUsedTable2(table) {
  if (is(table, MySqlTable)) {
    return [`${table[Table.Symbol.BaseName]}`];
  }
  if (is(table, Subquery)) {
    return table._.usedTables ?? [];
  }
  if (is(table, SQL)) {
    return table.usedTables ?? [];
  }
  return [];
}
function convertIndexToString(indexes) {
  return indexes.map((idx) => {
    return typeof idx === "object" ? idx.config.name : idx;
  });
}
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}
var init_utils3 = __esm({
  "node_modules/drizzle-orm/mysql-core/utils.js"() {
    init_entity();
    init_drizzle_orm();
    init_subquery();
    init_table();
    init_view_common();
    init_checks();
    init_foreign_keys2();
    init_indexes();
    init_primary_keys2();
    init_table3();
    init_unique_constraint2();
    init_view_common2();
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/delete.js
var MySqlDeleteBase;
var init_delete = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/delete.js"() {
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_table();
    init_utils3();
    MySqlDeleteBase = class extends QueryPromise {
      constructor(table, session, dialect, withList) {
        super();
        this.table = table;
        this.session = session;
        this.dialect = dialect;
        this.config = { table, withList };
      }
      static [entityKind] = "MySqlDelete";
      config;
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will delete only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be deleted.
       *
       * ```ts
       * // Delete all cars with green color
       * db.delete(cars).where(eq(cars.color, 'green'));
       * // or
       * db.delete(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Delete all BMW cars with a green color
       * db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Delete all cars with the green or blue color
       * db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      orderBy(...columns) {
        if (typeof columns[0] === "function") {
          const orderBy = columns[0](
            new Proxy(
              this.config.table[Table.Symbol.Columns],
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
          this.config.orderBy = orderByArray;
        } else {
          const orderByArray = columns;
          this.config.orderBy = orderByArray;
        }
        return this;
      }
      limit(limit) {
        this.config.limit = limit;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildDeleteQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      prepare() {
        return this.session.prepareQuery(
          this.dialect.sqlToQuery(this.getSQL()),
          this.config.returning,
          void 0,
          void 0,
          void 0,
          {
            type: "delete",
            tables: extractUsedTable2(this.config.table)
          }
        );
      }
      execute = (placeholderValues) => {
        return this.prepare().execute(placeholderValues);
      };
      createIterator = () => {
        const self = this;
        return async function* (placeholderValues) {
          yield* self.prepare().iterator(placeholderValues);
        };
      };
      iterator = this.createIterator();
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/view-base.js
var MySqlViewBase;
var init_view_base = __esm({
  "node_modules/drizzle-orm/mysql-core/view-base.js"() {
    init_entity();
    init_sql();
    MySqlViewBase = class extends View {
      static [entityKind] = "MySqlViewBase";
    };
  }
});

// node_modules/drizzle-orm/mysql-core/dialect.js
var MySqlDialect;
var init_dialect = __esm({
  "node_modules/drizzle-orm/mysql-core/dialect.js"() {
    init_alias();
    init_casing();
    init_column();
    init_entity();
    init_errors();
    init_relations();
    init_expressions();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    init_common2();
    init_table3();
    init_view_base();
    MySqlDialect = class {
      static [entityKind] = "MySqlDialect";
      /** @internal */
      casing;
      constructor(config) {
        this.casing = new CasingCache(config?.casing);
      }
      async migrate(migrations, session, config) {
        const migrationsTable = config.migrationsTable ?? "__drizzle_migrations";
        const migrationTableCreate = sql`
			create table if not exists ${sql.identifier(migrationsTable)} (
				id serial primary key,
				hash text not null,
				created_at bigint
			)
		`;
        await session.execute(migrationTableCreate);
        const dbMigrations = await session.all(
          sql`select id, hash, created_at from ${sql.identifier(migrationsTable)} order by created_at desc limit 1`
        );
        const lastDbMigration = dbMigrations[0];
        await session.transaction(async (tx) => {
          for (const migration of migrations) {
            if (!lastDbMigration || Number(lastDbMigration.created_at) < migration.folderMillis) {
              for (const stmt of migration.sql) {
                await tx.execute(sql.raw(stmt));
              }
              await tx.execute(
                sql`insert into ${sql.identifier(
                  migrationsTable
                )} (\`hash\`, \`created_at\`) values(${migration.hash}, ${migration.folderMillis})`
              );
            }
          }
        });
      }
      escapeName(name) {
        return `\`${name.replace(/`/g, "``")}\``;
      }
      escapeParam(_num) {
        return `?`;
      }
      escapeString(str2) {
        return `'${str2.replace(/'/g, "''")}'`;
      }
      buildWithCTE(queries) {
        if (!queries?.length) return void 0;
        const withSqlChunks = [sql`with `];
        for (const [i, w] of queries.entries()) {
          withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
          if (i < queries.length - 1) {
            withSqlChunks.push(sql`, `);
          }
        }
        withSqlChunks.push(sql` `);
        return sql.join(withSqlChunks);
      }
      buildDeleteQuery({
        table,
        where,
        returning,
        withList,
        limit,
        orderBy
      }) {
        const withSql = this.buildWithCTE(withList);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        const orderBySql = this.buildOrderBy(orderBy);
        const limitSql = this.buildLimit(limit);
        return sql`${withSql}delete from ${table}${whereSql}${orderBySql}${limitSql}${returningSql}`;
      }
      buildUpdateSet(table, set) {
        const tableColumns = table[Table.Symbol.Columns];
        const columnNames = Object.keys(tableColumns).filter(
          (colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0
        );
        const setSize = columnNames.length;
        return sql.join(
          columnNames.flatMap((colName, i) => {
            const col = tableColumns[colName];
            const onUpdateFnResult = col.onUpdateFn?.();
            const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
            const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
            if (i < setSize - 1) {
              return [res, sql.raw(", ")];
            }
            return [res];
          })
        );
      }
      buildUpdateQuery({
        table,
        set,
        where,
        returning,
        withList,
        limit,
        orderBy
      }) {
        const withSql = this.buildWithCTE(withList);
        const setSql = this.buildUpdateSet(table, set);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        const orderBySql = this.buildOrderBy(orderBy);
        const limitSql = this.buildLimit(limit);
        return sql`${withSql}update ${table} set ${setSql}${whereSql}${orderBySql}${limitSql}${returningSql}`;
      }
      /**
       * Builds selection SQL with provided fields/expressions
       *
       * Examples:
       *
       * `select <selection> from`
       *
       * `insert ... returning <selection>`
       *
       * If `isSingleTable` is true, then columns won't be prefixed with table name
       */
      buildSelection(fields, { isSingleTable = false } = {}) {
        const columnsLen = fields.length;
        const chunks = fields.flatMap(({ field }, i) => {
          const chunk = [];
          if (is(field, SQL.Aliased) && field.isSelectionField) {
            chunk.push(sql.identifier(field.fieldAlias));
          } else if (is(field, SQL.Aliased) || is(field, SQL)) {
            const query = is(field, SQL.Aliased) ? field.sql : field;
            if (isSingleTable) {
              chunk.push(
                new SQL(
                  query.queryChunks.map((c) => {
                    if (is(c, MySqlColumn)) {
                      return sql.identifier(this.casing.getColumnCasing(c));
                    }
                    return c;
                  })
                )
              );
            } else {
              chunk.push(query);
            }
            if (is(field, SQL.Aliased)) {
              chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
            }
          } else if (is(field, Column)) {
            if (isSingleTable) {
              chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
            } else {
              chunk.push(field);
            }
          } else if (is(field, Subquery)) {
            const entries = Object.entries(field._.selectedFields);
            if (entries.length === 1) {
              const entry = entries[0][1];
              const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
              if (fieldDecoder) {
                field._.sql.decoder = fieldDecoder;
              }
            }
            chunk.push(field);
          }
          if (i < columnsLen - 1) {
            chunk.push(sql`, `);
          }
          return chunk;
        });
        return sql.join(chunks);
      }
      buildLimit(limit) {
        return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
      }
      buildOrderBy(orderBy) {
        return orderBy && orderBy.length > 0 ? sql` order by ${sql.join(orderBy, sql`, `)}` : void 0;
      }
      buildIndex({
        indexes,
        indexFor
      }) {
        return indexes && indexes.length > 0 ? sql` ${sql.raw(indexFor)} INDEX (${sql.raw(indexes.join(`, `))})` : void 0;
      }
      buildSelectQuery({
        withList,
        fields,
        fieldsFlat,
        where,
        having,
        table,
        joins,
        orderBy,
        groupBy,
        limit,
        offset,
        lockingClause,
        distinct,
        setOperators,
        useIndex,
        forceIndex,
        ignoreIndex
      }) {
        const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
        for (const f of fieldsList) {
          if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, MySqlViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(
            ({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])
          ))(f.field.table)) {
            const tableName = getTableName(f.field.table);
            throw new Error(
              `Your "${f.path.join(
                "->"
              )}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`
            );
          }
        }
        const isSingleTable = !joins || joins.length === 0;
        const withSql = this.buildWithCTE(withList);
        const distinctSql = distinct ? sql` distinct` : void 0;
        const selection = this.buildSelection(fieldsList, { isSingleTable });
        const tableSql = (() => {
          if (is(table, Table) && table[Table.Symbol.IsAlias]) {
            return sql`${sql`${sql.identifier(table[Table.Symbol.Schema] ?? "")}.`.if(table[Table.Symbol.Schema])}${sql.identifier(
              table[Table.Symbol.OriginalName]
            )} ${sql.identifier(table[Table.Symbol.Name])}`;
          }
          return table;
        })();
        const joinsArray = [];
        if (joins) {
          for (const [index4, joinMeta] of joins.entries()) {
            if (index4 === 0) {
              joinsArray.push(sql` `);
            }
            const table2 = joinMeta.table;
            const lateralSql = joinMeta.lateral ? sql` lateral` : void 0;
            const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
            if (is(table2, MySqlTable)) {
              const tableName = table2[MySqlTable.Symbol.Name];
              const tableSchema = table2[MySqlTable.Symbol.Schema];
              const origTableName = table2[MySqlTable.Symbol.OriginalName];
              const alias = tableName === origTableName ? void 0 : joinMeta.alias;
              const useIndexSql2 = this.buildIndex({
                indexes: joinMeta.useIndex,
                indexFor: "USE"
              });
              const forceIndexSql2 = this.buildIndex({
                indexes: joinMeta.forceIndex,
                indexFor: "FORCE"
              });
              const ignoreIndexSql2 = this.buildIndex({
                indexes: joinMeta.ignoreIndex,
                indexFor: "IGNORE"
              });
              joinsArray.push(
                sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${useIndexSql2}${forceIndexSql2}${ignoreIndexSql2}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
              );
            } else if (is(table2, View)) {
              const viewName = table2[ViewBaseConfig].name;
              const viewSchema = table2[ViewBaseConfig].schema;
              const origViewName = table2[ViewBaseConfig].originalName;
              const alias = viewName === origViewName ? void 0 : joinMeta.alias;
              joinsArray.push(
                sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? sql`${sql.identifier(viewSchema)}.` : void 0}${sql.identifier(origViewName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
              );
            } else {
              joinsArray.push(
                sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${table2}${onSql}`
              );
            }
            if (index4 < joins.length - 1) {
              joinsArray.push(sql` `);
            }
          }
        }
        const joinsSql = sql.join(joinsArray);
        const whereSql = where ? sql` where ${where}` : void 0;
        const havingSql = having ? sql` having ${having}` : void 0;
        const orderBySql = this.buildOrderBy(orderBy);
        const groupBySql = groupBy && groupBy.length > 0 ? sql` group by ${sql.join(groupBy, sql`, `)}` : void 0;
        const limitSql = this.buildLimit(limit);
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        const useIndexSql = this.buildIndex({ indexes: useIndex, indexFor: "USE" });
        const forceIndexSql = this.buildIndex({
          indexes: forceIndex,
          indexFor: "FORCE"
        });
        const ignoreIndexSql = this.buildIndex({
          indexes: ignoreIndex,
          indexFor: "IGNORE"
        });
        let lockingClausesSql;
        if (lockingClause) {
          const { config, strength } = lockingClause;
          lockingClausesSql = sql` for ${sql.raw(strength)}`;
          if (config.noWait) {
            lockingClausesSql.append(sql` nowait`);
          } else if (config.skipLocked) {
            lockingClausesSql.append(sql` skip locked`);
          }
        }
        const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${useIndexSql}${forceIndexSql}${ignoreIndexSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClausesSql}`;
        if (setOperators.length > 0) {
          return this.buildSetOperations(finalQuery, setOperators);
        }
        return finalQuery;
      }
      buildSetOperations(leftSelect, setOperators) {
        const [setOperator, ...rest] = setOperators;
        if (!setOperator) {
          throw new Error("Cannot pass undefined values to any set operator");
        }
        if (rest.length === 0) {
          return this.buildSetOperationQuery({ leftSelect, setOperator });
        }
        return this.buildSetOperations(
          this.buildSetOperationQuery({ leftSelect, setOperator }),
          rest
        );
      }
      buildSetOperationQuery({
        leftSelect,
        setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
      }) {
        const leftChunk = sql`(${leftSelect.getSQL()}) `;
        const rightChunk = sql`(${rightSelect.getSQL()})`;
        let orderBySql;
        if (orderBy && orderBy.length > 0) {
          const orderByValues = [];
          for (const orderByUnit of orderBy) {
            if (is(orderByUnit, MySqlColumn)) {
              orderByValues.push(
                sql.identifier(this.casing.getColumnCasing(orderByUnit))
              );
            } else if (is(orderByUnit, SQL)) {
              for (let i = 0; i < orderByUnit.queryChunks.length; i++) {
                const chunk = orderByUnit.queryChunks[i];
                if (is(chunk, MySqlColumn)) {
                  orderByUnit.queryChunks[i] = sql.identifier(
                    this.casing.getColumnCasing(chunk)
                  );
                }
              }
              orderByValues.push(sql`${orderByUnit}`);
            } else {
              orderByValues.push(sql`${orderByUnit}`);
            }
          }
          orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)} `;
        }
        const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
        const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
      }
      buildInsertQuery({
        table,
        values: valuesOrSelect,
        ignore,
        onConflict,
        select
      }) {
        const valuesSqlList = [];
        const columns = table[Table.Symbol.Columns];
        const colEntries = Object.entries(columns).filter(
          ([_, col]) => !col.shouldDisableInsert()
        );
        const insertOrder = colEntries.map(([, column]) => sql.identifier(this.casing.getColumnCasing(column)));
        const generatedIdsResponse = [];
        if (select) {
          const select2 = valuesOrSelect;
          if (is(select2, SQL)) {
            valuesSqlList.push(select2);
          } else {
            valuesSqlList.push(select2.getSQL());
          }
        } else {
          const values = valuesOrSelect;
          valuesSqlList.push(sql.raw("values "));
          for (const [valueIndex, value] of values.entries()) {
            const generatedIds = {};
            const valueList = [];
            for (const [fieldName2, col] of colEntries) {
              const colValue = value[fieldName2];
              if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
                if (col.defaultFn !== void 0) {
                  const defaultFnResult = col.defaultFn();
                  generatedIds[fieldName2] = defaultFnResult;
                  const defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
                  valueList.push(defaultValue);
                } else if (!col.default && col.onUpdateFn !== void 0) {
                  const onUpdateFnResult = col.onUpdateFn();
                  const newValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
                  valueList.push(newValue);
                } else {
                  valueList.push(sql`default`);
                }
              } else {
                if (col.defaultFn && is(colValue, Param)) {
                  generatedIds[fieldName2] = colValue.value;
                }
                valueList.push(colValue);
              }
            }
            generatedIdsResponse.push(generatedIds);
            valuesSqlList.push(valueList);
            if (valueIndex < values.length - 1) {
              valuesSqlList.push(sql`, `);
            }
          }
        }
        const valuesSql = sql.join(valuesSqlList);
        const ignoreSql = ignore ? sql` ignore` : void 0;
        const onConflictSql = onConflict ? sql` on duplicate key ${onConflict}` : void 0;
        return {
          sql: sql`insert${ignoreSql} into ${table} ${insertOrder} ${valuesSql}${onConflictSql}`,
          generatedIds: generatedIdsResponse
        };
      }
      sqlToQuery(sql2, invokeSource) {
        return sql2.toQuery({
          casing: this.casing,
          escapeName: this.escapeName,
          escapeParam: this.escapeParam,
          escapeString: this.escapeString,
          invokeSource
        });
      }
      buildRelationalQuery({
        fullSchema,
        schema,
        tableNamesMap,
        table,
        tableConfig,
        queryConfig: config,
        tableAlias,
        nestedQueryRelation,
        joinOn
      }) {
        let selection = [];
        let limit, offset, orderBy, where;
        const joins = [];
        if (config === true) {
          const selectionEntries = Object.entries(tableConfig.columns);
          selection = selectionEntries.map(([key, value]) => ({
            dbKey: value.name,
            tsKey: key,
            field: aliasedTableColumn(value, tableAlias),
            relationTableTsKey: void 0,
            isJson: false,
            selection: []
          }));
        } else {
          const aliasedColumns = Object.fromEntries(
            Object.entries(tableConfig.columns).map(([key, value]) => [
              key,
              aliasedTableColumn(value, tableAlias)
            ])
          );
          if (config.where) {
            const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
            where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
          }
          const fieldsSelection = [];
          let selectedColumns = [];
          if (config.columns) {
            let isIncludeMode = false;
            for (const [field, value] of Object.entries(config.columns)) {
              if (value === void 0) {
                continue;
              }
              if (field in tableConfig.columns) {
                if (!isIncludeMode && value === true) {
                  isIncludeMode = true;
                }
                selectedColumns.push(field);
              }
            }
            if (selectedColumns.length > 0) {
              selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter(
                (key) => !selectedColumns.includes(key)
              );
            }
          } else {
            selectedColumns = Object.keys(tableConfig.columns);
          }
          for (const field of selectedColumns) {
            const column = tableConfig.columns[field];
            fieldsSelection.push({ tsKey: field, value: column });
          }
          let selectedRelations = [];
          if (config.with) {
            selectedRelations = Object.entries(config.with).filter(
              (entry) => !!entry[1]
            ).map(([tsKey, queryConfig]) => ({
              tsKey,
              queryConfig,
              relation: tableConfig.relations[tsKey]
            }));
          }
          let extras;
          if (config.extras) {
            extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
            for (const [tsKey, value] of Object.entries(extras)) {
              fieldsSelection.push({
                tsKey,
                value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
              });
            }
          }
          for (const { tsKey, value } of fieldsSelection) {
            selection.push({
              dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
              tsKey,
              field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
              relationTableTsKey: void 0,
              isJson: false,
              selection: []
            });
          }
          let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
          if (!Array.isArray(orderByOrig)) {
            orderByOrig = [orderByOrig];
          }
          orderBy = orderByOrig.map((orderByValue) => {
            if (is(orderByValue, Column)) {
              return aliasedTableColumn(orderByValue, tableAlias);
            }
            return mapColumnsInSQLToAlias(orderByValue, tableAlias);
          });
          limit = config.limit;
          offset = config.offset;
          for (const {
            tsKey: selectedRelationTsKey,
            queryConfig: selectedRelationConfigValue,
            relation
          } of selectedRelations) {
            const normalizedRelation = normalizeRelation(
              schema,
              tableNamesMap,
              relation
            );
            const relationTableName = getTableUniqueName(relation.referencedTable);
            const relationTableTsName = tableNamesMap[relationTableName];
            const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
            const joinOn2 = and(
              ...normalizedRelation.fields.map(
                (field2, i) => eq(
                  aliasedTableColumn(
                    normalizedRelation.references[i],
                    relationTableAlias
                  ),
                  aliasedTableColumn(field2, tableAlias)
                )
              )
            );
            const builtRelation = this.buildRelationalQuery({
              fullSchema,
              schema,
              tableNamesMap,
              table: fullSchema[relationTableTsName],
              tableConfig: schema[relationTableTsName],
              queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
              tableAlias: relationTableAlias,
              joinOn: joinOn2,
              nestedQueryRelation: relation
            });
            const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier("data")}`.as(
              selectedRelationTsKey
            );
            joins.push({
              on: sql`true`,
              table: new Subquery(builtRelation.sql, {}, relationTableAlias),
              alias: relationTableAlias,
              joinType: "left",
              lateral: true
            });
            selection.push({
              dbKey: selectedRelationTsKey,
              tsKey: selectedRelationTsKey,
              field,
              relationTableTsKey: relationTableTsName,
              isJson: true,
              selection: builtRelation.selection
            });
          }
        }
        if (selection.length === 0) {
          throw new DrizzleError({
            message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")`
          });
        }
        let result;
        where = and(joinOn, where);
        if (nestedQueryRelation) {
          let field = sql`json_array(${sql.join(
            selection.map(
              ({ field: field2, tsKey, isJson }) => isJson ? sql`${sql.identifier(`${tableAlias}_${tsKey}`)}.${sql.identifier("data")}` : is(field2, SQL.Aliased) ? field2.sql : field2
            ),
            sql`, `
          )})`;
          if (is(nestedQueryRelation, Many)) {
            field = sql`coalesce(json_arrayagg(${field}), json_array())`;
          }
          const nestedSelection = [
            {
              dbKey: "data",
              tsKey: "data",
              field: field.as("data"),
              isJson: true,
              relationTableTsKey: tableConfig.tsName,
              selection
            }
          ];
          const needsSubquery = limit !== void 0 || offset !== void 0 || (orderBy?.length ?? 0) > 0;
          if (needsSubquery) {
            result = this.buildSelectQuery({
              table: aliasedTable(table, tableAlias),
              fields: {},
              fieldsFlat: [
                {
                  path: [],
                  field: sql.raw("*")
                },
                ...(orderBy?.length ?? 0) > 0 ? [
                  {
                    path: [],
                    field: sql`row_number() over (order by ${sql.join(orderBy, sql`, `)})`
                  }
                ] : []
              ],
              where,
              limit,
              offset,
              setOperators: []
            });
            where = void 0;
            limit = void 0;
            offset = void 0;
            orderBy = void 0;
          } else {
            result = aliasedTable(table, tableAlias);
          }
          result = this.buildSelectQuery({
            table: is(result, MySqlTable) ? result : new Subquery(result, {}, tableAlias),
            fields: {},
            fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
              path: [],
              field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        } else {
          result = this.buildSelectQuery({
            table: aliasedTable(table, tableAlias),
            fields: {},
            fieldsFlat: selection.map(({ field }) => ({
              path: [],
              field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        }
        return {
          tableTsKey: tableConfig.tsName,
          sql: result,
          selection
        };
      }
      buildRelationalQueryWithoutLateralSubqueries({
        fullSchema,
        schema,
        tableNamesMap,
        table,
        tableConfig,
        queryConfig: config,
        tableAlias,
        nestedQueryRelation,
        joinOn
      }) {
        let selection = [];
        let limit, offset, orderBy = [], where;
        if (config === true) {
          const selectionEntries = Object.entries(tableConfig.columns);
          selection = selectionEntries.map(([key, value]) => ({
            dbKey: value.name,
            tsKey: key,
            field: aliasedTableColumn(value, tableAlias),
            relationTableTsKey: void 0,
            isJson: false,
            selection: []
          }));
        } else {
          const aliasedColumns = Object.fromEntries(
            Object.entries(tableConfig.columns).map(([key, value]) => [
              key,
              aliasedTableColumn(value, tableAlias)
            ])
          );
          if (config.where) {
            const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
            where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
          }
          const fieldsSelection = [];
          let selectedColumns = [];
          if (config.columns) {
            let isIncludeMode = false;
            for (const [field, value] of Object.entries(config.columns)) {
              if (value === void 0) {
                continue;
              }
              if (field in tableConfig.columns) {
                if (!isIncludeMode && value === true) {
                  isIncludeMode = true;
                }
                selectedColumns.push(field);
              }
            }
            if (selectedColumns.length > 0) {
              selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter(
                (key) => !selectedColumns.includes(key)
              );
            }
          } else {
            selectedColumns = Object.keys(tableConfig.columns);
          }
          for (const field of selectedColumns) {
            const column = tableConfig.columns[field];
            fieldsSelection.push({ tsKey: field, value: column });
          }
          let selectedRelations = [];
          if (config.with) {
            selectedRelations = Object.entries(config.with).filter(
              (entry) => !!entry[1]
            ).map(([tsKey, queryConfig]) => ({
              tsKey,
              queryConfig,
              relation: tableConfig.relations[tsKey]
            }));
          }
          let extras;
          if (config.extras) {
            extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
            for (const [tsKey, value] of Object.entries(extras)) {
              fieldsSelection.push({
                tsKey,
                value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
              });
            }
          }
          for (const { tsKey, value } of fieldsSelection) {
            selection.push({
              dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
              tsKey,
              field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
              relationTableTsKey: void 0,
              isJson: false,
              selection: []
            });
          }
          let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
          if (!Array.isArray(orderByOrig)) {
            orderByOrig = [orderByOrig];
          }
          orderBy = orderByOrig.map((orderByValue) => {
            if (is(orderByValue, Column)) {
              return aliasedTableColumn(orderByValue, tableAlias);
            }
            return mapColumnsInSQLToAlias(orderByValue, tableAlias);
          });
          limit = config.limit;
          offset = config.offset;
          for (const {
            tsKey: selectedRelationTsKey,
            queryConfig: selectedRelationConfigValue,
            relation
          } of selectedRelations) {
            const normalizedRelation = normalizeRelation(
              schema,
              tableNamesMap,
              relation
            );
            const relationTableName = getTableUniqueName(relation.referencedTable);
            const relationTableTsName = tableNamesMap[relationTableName];
            const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
            const joinOn2 = and(
              ...normalizedRelation.fields.map(
                (field2, i) => eq(
                  aliasedTableColumn(
                    normalizedRelation.references[i],
                    relationTableAlias
                  ),
                  aliasedTableColumn(field2, tableAlias)
                )
              )
            );
            const builtRelation = this.buildRelationalQueryWithoutLateralSubqueries(
              {
                fullSchema,
                schema,
                tableNamesMap,
                table: fullSchema[relationTableTsName],
                tableConfig: schema[relationTableTsName],
                queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
                tableAlias: relationTableAlias,
                joinOn: joinOn2,
                nestedQueryRelation: relation
              }
            );
            let fieldSql = sql`(${builtRelation.sql})`;
            if (is(relation, Many)) {
              fieldSql = sql`coalesce(${fieldSql}, json_array())`;
            }
            const field = fieldSql.as(selectedRelationTsKey);
            selection.push({
              dbKey: selectedRelationTsKey,
              tsKey: selectedRelationTsKey,
              field,
              relationTableTsKey: relationTableTsName,
              isJson: true,
              selection: builtRelation.selection
            });
          }
        }
        if (selection.length === 0) {
          throw new DrizzleError({
            message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.`
          });
        }
        let result;
        where = and(joinOn, where);
        if (nestedQueryRelation) {
          let field = sql`json_array(${sql.join(
            selection.map(
              ({ field: field2 }) => is(field2, MySqlColumn) ? sql.identifier(this.casing.getColumnCasing(field2)) : is(field2, SQL.Aliased) ? field2.sql : field2
            ),
            sql`, `
          )})`;
          if (is(nestedQueryRelation, Many)) {
            field = sql`json_arrayagg(${field})`;
          }
          const nestedSelection = [
            {
              dbKey: "data",
              tsKey: "data",
              field,
              isJson: true,
              relationTableTsKey: tableConfig.tsName,
              selection
            }
          ];
          const needsSubquery = limit !== void 0 || offset !== void 0 || orderBy.length > 0;
          if (needsSubquery) {
            result = this.buildSelectQuery({
              table: aliasedTable(table, tableAlias),
              fields: {},
              fieldsFlat: [
                {
                  path: [],
                  field: sql.raw("*")
                },
                ...orderBy.length > 0 ? [
                  {
                    path: [],
                    field: sql`row_number() over (order by ${sql.join(orderBy, sql`, `)})`
                  }
                ] : []
              ],
              where,
              limit,
              offset,
              setOperators: []
            });
            where = void 0;
            limit = void 0;
            offset = void 0;
            orderBy = void 0;
          } else {
            result = aliasedTable(table, tableAlias);
          }
          result = this.buildSelectQuery({
            table: is(result, MySqlTable) ? result : new Subquery(result, {}, tableAlias),
            fields: {},
            fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
              path: [],
              field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
            })),
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        } else {
          result = this.buildSelectQuery({
            table: aliasedTable(table, tableAlias),
            fields: {},
            fieldsFlat: selection.map(({ field }) => ({
              path: [],
              field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
            })),
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        }
        return {
          tableTsKey: tableConfig.tsName,
          sql: result,
          selection
        };
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/select.js
function createSetOperator2(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
var MySqlSelectBuilder, MySqlSelectQueryBuilderBase, MySqlSelectBase, getMySqlSetOperators, union2, unionAll2, intersect2, intersectAll, except2, exceptAll;
var init_select2 = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/select.js"() {
    init_entity();
    init_table3();
    init_query_builder();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    init_utils3();
    init_view_base();
    MySqlSelectBuilder = class {
      static [entityKind] = "MySqlSelectBuilder";
      fields;
      session;
      dialect;
      withList = [];
      distinct;
      constructor(config) {
        this.fields = config.fields;
        this.session = config.session;
        this.dialect = config.dialect;
        if (config.withList) {
          this.withList = config.withList;
        }
        this.distinct = config.distinct;
      }
      from(source, onIndex) {
        const isPartialSelect = !!this.fields;
        let fields;
        if (this.fields) {
          fields = this.fields;
        } else if (is(source, Subquery)) {
          fields = Object.fromEntries(
            Object.keys(source._.selectedFields).map((key) => [key, source[key]])
          );
        } else if (is(source, MySqlViewBase)) {
          fields = source[ViewBaseConfig].selectedFields;
        } else if (is(source, SQL)) {
          fields = {};
        } else {
          fields = getTableColumns(source);
        }
        let useIndex = [];
        let forceIndex = [];
        let ignoreIndex = [];
        if (is(source, MySqlTable) && onIndex && typeof onIndex !== "string") {
          if (onIndex.useIndex) {
            useIndex = convertIndexToString(toArray(onIndex.useIndex));
          }
          if (onIndex.forceIndex) {
            forceIndex = convertIndexToString(toArray(onIndex.forceIndex));
          }
          if (onIndex.ignoreIndex) {
            ignoreIndex = convertIndexToString(toArray(onIndex.ignoreIndex));
          }
        }
        return new MySqlSelectBase(
          {
            table: source,
            fields,
            isPartialSelect,
            session: this.session,
            dialect: this.dialect,
            withList: this.withList,
            distinct: this.distinct,
            useIndex,
            forceIndex,
            ignoreIndex
          }
        );
      }
    };
    MySqlSelectQueryBuilderBase = class extends TypedQueryBuilder {
      static [entityKind] = "MySqlSelectQueryBuilder";
      _;
      config;
      joinsNotNullableMap;
      tableName;
      isPartialSelect;
      /** @internal */
      session;
      dialect;
      cacheConfig = void 0;
      usedTables = /* @__PURE__ */ new Set();
      constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct, useIndex, forceIndex, ignoreIndex }) {
        super();
        this.config = {
          withList,
          table,
          fields: { ...fields },
          distinct,
          setOperators: [],
          useIndex,
          forceIndex,
          ignoreIndex
        };
        this.isPartialSelect = isPartialSelect;
        this.session = session;
        this.dialect = dialect;
        this._ = {
          selectedFields: fields,
          config: this.config
        };
        this.tableName = getTableLikeName(table);
        this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
        for (const item of extractUsedTable2(table)) this.usedTables.add(item);
      }
      /** @internal */
      getUsedTables() {
        return [...this.usedTables];
      }
      createJoin(joinType, lateral) {
        return (table, a, b) => {
          const isCrossJoin = joinType === "cross";
          let on = isCrossJoin ? void 0 : a;
          const onIndex = isCrossJoin ? a : b;
          const baseTableName = this.tableName;
          const tableName = getTableLikeName(table);
          for (const item of extractUsedTable2(table)) this.usedTables.add(item);
          if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
            throw new Error(`Alias "${tableName}" is already used in this query`);
          }
          if (!this.isPartialSelect) {
            if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
              this.config.fields = {
                [baseTableName]: this.config.fields
              };
            }
            if (typeof tableName === "string" && !is(table, SQL)) {
              const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
              this.config.fields[tableName] = selection;
            }
          }
          if (typeof on === "function") {
            on = on(
              new Proxy(
                this.config.fields,
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              )
            );
          }
          if (!this.config.joins) {
            this.config.joins = [];
          }
          let useIndex = [];
          let forceIndex = [];
          let ignoreIndex = [];
          if (is(table, MySqlTable) && onIndex && typeof onIndex !== "string") {
            if (onIndex.useIndex) {
              useIndex = convertIndexToString(toArray(onIndex.useIndex));
            }
            if (onIndex.forceIndex) {
              forceIndex = convertIndexToString(toArray(onIndex.forceIndex));
            }
            if (onIndex.ignoreIndex) {
              ignoreIndex = convertIndexToString(toArray(onIndex.ignoreIndex));
            }
          }
          this.config.joins.push({ on, table, joinType, alias: tableName, useIndex, forceIndex, ignoreIndex, lateral });
          if (typeof tableName === "string") {
            switch (joinType) {
              case "left": {
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
              case "right": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "cross":
              case "inner": {
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
            }
          }
          return this;
        };
      }
      /**
       * Executes a `left join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       * @param onIndex index hint.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId with use index hint
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId), {
       *     useIndex: ['pets_owner_id_index']
       * })
       * ```
       */
      leftJoin = this.createJoin("left", false);
      /**
       * Executes a `left join lateral` operation by adding subquery to the current query.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      leftJoinLateral = this.createJoin("left", true);
      /**
       * Executes a `right join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       * @param onIndex index hint.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId with use index hint
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId), {
       *     useIndex: ['pets_owner_id_index']
       * })
       * ```
       */
      rightJoin = this.createJoin("right", false);
      /**
       * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       * @param onIndex index hint.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId with use index hint
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId), {
       *     useIndex: ['pets_owner_id_index']
       * })
       * ```
       */
      innerJoin = this.createJoin("inner", false);
      /**
       * Executes an `inner join lateral` operation, creating a new table by combining rows from two queries that have matching values.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      innerJoinLateral = this.createJoin("inner", true);
      /**
       * Executes a `cross join` operation by combining rows from two tables into a new table.
       *
       * Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
       *
       * @param table the table to join.
       * @param onIndex index hint.
       *
       * @example
       *
       * ```ts
       * // Select all users, each user with every pet
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .crossJoin(pets)
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .crossJoin(pets)
       *
       * // Select userId and petId with use index hint
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .crossJoin(pets, {
       *     useIndex: ['pets_owner_id_index']
       * })
       * ```
       */
      crossJoin = this.createJoin("cross", false);
      /**
       * Executes a `cross join lateral` operation by combining rows from two queries into a new table.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves all rows from both main and joined queries, merging all rows from each query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join-lateral}
       *
       * @param table the query to join.
       */
      crossJoinLateral = this.createJoin("cross", true);
      createSetOperator(type, isAll) {
        return (rightSelection) => {
          const rightSelect = typeof rightSelection === "function" ? rightSelection(getMySqlSetOperators()) : rightSelection;
          if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
            throw new Error(
              "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
            );
          }
          this.config.setOperators.push({ type, isAll, rightSelect });
          return this;
        };
      }
      /**
       * Adds `union` set operator to the query.
       *
       * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
       *
       * @example
       *
       * ```ts
       * // Select all unique names from customers and users tables
       * await db.select({ name: users.name })
       *   .from(users)
       *   .union(
       *     db.select({ name: customers.name }).from(customers)
       *   );
       * // or
       * import { union } from 'drizzle-orm/mysql-core'
       *
       * await union(
       *   db.select({ name: users.name }).from(users),
       *   db.select({ name: customers.name }).from(customers)
       * );
       * ```
       */
      union = this.createSetOperator("union", false);
      /**
       * Adds `union all` set operator to the query.
       *
       * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
       *
       * @example
       *
       * ```ts
       * // Select all transaction ids from both online and in-store sales
       * await db.select({ transaction: onlineSales.transactionId })
       *   .from(onlineSales)
       *   .unionAll(
       *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       *   );
       * // or
       * import { unionAll } from 'drizzle-orm/mysql-core'
       *
       * await unionAll(
       *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
       *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       * );
       * ```
       */
      unionAll = this.createSetOperator("union", true);
      /**
       * Adds `intersect` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
       *
       * @example
       *
       * ```ts
       * // Select course names that are offered in both departments A and B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .intersect(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { intersect } from 'drizzle-orm/mysql-core'
       *
       * await intersect(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      intersect = this.createSetOperator("intersect", false);
      /**
       * Adds `intersect all` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets including all duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect-all}
       *
       * @example
       *
       * ```ts
       * // Select all products and quantities that are ordered by both regular and VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered
       * })
       * .from(regularCustomerOrders)
       * .intersectAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { intersectAll } from 'drizzle-orm/mysql-core'
       *
       * await intersectAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      intersectAll = this.createSetOperator("intersect", true);
      /**
       * Adds `except` set operator to the query.
       *
       * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
       *
       * @example
       *
       * ```ts
       * // Select all courses offered in department A but not in department B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .except(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { except } from 'drizzle-orm/mysql-core'
       *
       * await except(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      except = this.createSetOperator("except", false);
      /**
       * Adds `except all` set operator to the query.
       *
       * Calling this method will retrieve all rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except-all}
       *
       * @example
       *
       * ```ts
       * // Select all products that are ordered by regular customers but not by VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered,
       * })
       * .from(regularCustomerOrders)
       * .exceptAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered,
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { exceptAll } from 'drizzle-orm/mysql-core'
       *
       * await exceptAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      exceptAll = this.createSetOperator("except", true);
      /** @internal */
      addSetOperators(setOperators) {
        this.config.setOperators.push(...setOperators);
        return this;
      }
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be selected.
       *
       * ```ts
       * // Select all cars with green color
       * await db.select().from(cars).where(eq(cars.color, 'green'));
       * // or
       * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Select all BMW cars with a green color
       * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Select all cars with the green or blue color
       * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        if (typeof where === "function") {
          where = where(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.where = where;
        return this;
      }
      /**
       * Adds a `having` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
       *
       * @param having the `having` clause.
       *
       * @example
       *
       * ```ts
       * // Select all brands with more than one car
       * await db.select({
       * 	brand: cars.brand,
       * 	count: sql<number>`cast(count(${cars.id}) as int)`,
       * })
       *   .from(cars)
       *   .groupBy(cars.brand)
       *   .having(({ count }) => gt(count, 1));
       * ```
       */
      having(having) {
        if (typeof having === "function") {
          having = having(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.having = having;
        return this;
      }
      groupBy(...columns) {
        if (typeof columns[0] === "function") {
          const groupBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
        } else {
          this.config.groupBy = columns;
        }
        return this;
      }
      orderBy(...columns) {
        if (typeof columns[0] === "function") {
          const orderBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        } else {
          const orderByArray = columns;
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        }
        return this;
      }
      /**
       * Adds a `limit` clause to the query.
       *
       * Calling this method will set the maximum number of rows that will be returned by this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param limit the `limit` clause.
       *
       * @example
       *
       * ```ts
       * // Get the first 10 people from this query.
       * await db.select().from(people).limit(10);
       * ```
       */
      limit(limit) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).limit = limit;
        } else {
          this.config.limit = limit;
        }
        return this;
      }
      /**
       * Adds an `offset` clause to the query.
       *
       * Calling this method will skip a number of rows when returning results from this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param offset the `offset` clause.
       *
       * @example
       *
       * ```ts
       * // Get the 10th-20th people from this query.
       * await db.select().from(people).offset(10).limit(10);
       * ```
       */
      offset(offset) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).offset = offset;
        } else {
          this.config.offset = offset;
        }
        return this;
      }
      /**
       * Adds a `for` clause to the query.
       *
       * Calling this method will specify a lock strength for this query that controls how strictly it acquires exclusive access to the rows being queried.
       *
       * See docs: {@link https://dev.mysql.com/doc/refman/8.0/en/innodb-locking-reads.html}
       *
       * @param strength the lock strength.
       * @param config the lock configuration.
       */
      for(strength, config = {}) {
        this.config.lockingClause = { strength, config };
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildSelectQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      as(alias) {
        const usedTables = [];
        usedTables.push(...extractUsedTable2(this.config.table));
        if (this.config.joins) {
          for (const it of this.config.joins) usedTables.push(...extractUsedTable2(it.table));
        }
        return new Proxy(
          new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]),
          new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      /** @internal */
      getSelectedFields() {
        return new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      $dynamic() {
        return this;
      }
      $withCache(config) {
        this.cacheConfig = config === void 0 ? { config: {}, enable: true, autoInvalidate: true } : config === false ? { enable: false } : { enable: true, autoInvalidate: true, ...config };
        return this;
      }
    };
    MySqlSelectBase = class extends MySqlSelectQueryBuilderBase {
      static [entityKind] = "MySqlSelect";
      prepare() {
        if (!this.session) {
          throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
        }
        const fieldsList = orderSelectedFields(this.config.fields);
        const query = this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), fieldsList, void 0, void 0, void 0, {
          type: "select",
          tables: [...this.usedTables]
        }, this.cacheConfig);
        query.joinsNotNullableMap = this.joinsNotNullableMap;
        return query;
      }
      execute = (placeholderValues) => {
        return this.prepare().execute(placeholderValues);
      };
      createIterator = () => {
        const self = this;
        return async function* (placeholderValues) {
          yield* self.prepare().iterator(placeholderValues);
        };
      };
      iterator = this.createIterator();
    };
    applyMixins(MySqlSelectBase, [QueryPromise]);
    getMySqlSetOperators = () => ({
      union: union2,
      unionAll: unionAll2,
      intersect: intersect2,
      intersectAll,
      except: except2,
      exceptAll
    });
    union2 = createSetOperator2("union", false);
    unionAll2 = createSetOperator2("union", true);
    intersect2 = createSetOperator2("intersect", false);
    intersectAll = createSetOperator2("intersect", true);
    except2 = createSetOperator2("except", false);
    exceptAll = createSetOperator2("except", true);
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/query-builder.js
var QueryBuilder2;
var init_query_builder2 = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/query-builder.js"() {
    init_entity();
    init_dialect();
    init_selection_proxy();
    init_subquery();
    init_select2();
    QueryBuilder2 = class {
      static [entityKind] = "MySqlQueryBuilder";
      dialect;
      dialectConfig;
      constructor(dialect) {
        this.dialect = is(dialect, MySqlDialect) ? dialect : void 0;
        this.dialectConfig = is(dialect, MySqlDialect) ? void 0 : dialect;
      }
      $with = (alias, selection) => {
        const queryBuilder = this;
        const as = (qb) => {
          if (typeof qb === "function") {
            qb = qb(queryBuilder);
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        };
        return { as };
      };
      with(...queries) {
        const self = this;
        function select(fields) {
          return new MySqlSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            withList: queries
          });
        }
        function selectDistinct(fields) {
          return new MySqlSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            withList: queries,
            distinct: true
          });
        }
        return { select, selectDistinct };
      }
      select(fields) {
        return new MySqlSelectBuilder({ fields: fields ?? void 0, session: void 0, dialect: this.getDialect() });
      }
      selectDistinct(fields) {
        return new MySqlSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect(),
          distinct: true
        });
      }
      // Lazy load dialect to avoid circular dependency
      getDialect() {
        if (!this.dialect) {
          this.dialect = new MySqlDialect(this.dialectConfig);
        }
        return this.dialect;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/insert.js
var MySqlInsertBuilder, MySqlInsertBase;
var init_insert = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/insert.js"() {
    init_entity();
    init_query_promise();
    init_sql();
    init_table();
    init_utils();
    init_utils3();
    init_query_builder2();
    MySqlInsertBuilder = class {
      constructor(table, session, dialect) {
        this.table = table;
        this.session = session;
        this.dialect = dialect;
      }
      static [entityKind] = "MySqlInsertBuilder";
      shouldIgnore = false;
      ignore() {
        this.shouldIgnore = true;
        return this;
      }
      values(values) {
        values = Array.isArray(values) ? values : [values];
        if (values.length === 0) {
          throw new Error("values() must be called with at least one value");
        }
        const mappedValues = values.map((entry) => {
          const result = {};
          const cols = this.table[Table.Symbol.Columns];
          for (const colKey of Object.keys(entry)) {
            const colValue = entry[colKey];
            result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
          }
          return result;
        });
        return new MySqlInsertBase(this.table, mappedValues, this.shouldIgnore, this.session, this.dialect);
      }
      select(selectQuery) {
        const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder2()) : selectQuery;
        if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) {
          throw new Error(
            "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
          );
        }
        return new MySqlInsertBase(this.table, select, this.shouldIgnore, this.session, this.dialect, true);
      }
    };
    MySqlInsertBase = class extends QueryPromise {
      constructor(table, values, ignore, session, dialect, select) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { table, values, select, ignore };
      }
      static [entityKind] = "MySqlInsert";
      config;
      cacheConfig;
      /**
       * Adds an `on duplicate key update` clause to the query.
       *
       * Calling this method will update the row if any unique index conflicts. MySQL will automatically determine the conflict target based on the primary key and unique indexes.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert#on-duplicate-key-update}
       *
       * @param config The `set` clause
       *
       * @example
       * ```ts
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW'})
       *   .onDuplicateKeyUpdate({ set: { brand: 'Porsche' }});
       * ```
       *
       * While MySQL does not directly support doing nothing on conflict, you can perform a no-op by setting any column's value to itself and achieve the same effect:
       *
       * ```ts
       * import { sql } from 'drizzle-orm';
       *
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onDuplicateKeyUpdate({ set: { id: sql`id` } });
       * ```
       */
      onDuplicateKeyUpdate(config) {
        const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
        this.config.onConflict = sql`update ${setSql}`;
        return this;
      }
      $returningId() {
        const returning = [];
        for (const [key, value] of Object.entries(this.config.table[Table.Symbol.Columns])) {
          if (value.primary) {
            returning.push({ field: value, path: [key] });
          }
        }
        this.config.returning = returning;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildInsertQuery(this.config).sql;
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      prepare() {
        const { sql: sql2, generatedIds } = this.dialect.buildInsertQuery(this.config);
        return this.session.prepareQuery(
          this.dialect.sqlToQuery(sql2),
          void 0,
          void 0,
          generatedIds,
          this.config.returning,
          {
            type: "insert",
            tables: extractUsedTable2(this.config.table)
          },
          this.cacheConfig
        );
      }
      execute = (placeholderValues) => {
        return this.prepare().execute(placeholderValues);
      };
      createIterator = () => {
        const self = this;
        return async function* (placeholderValues) {
          yield* self.prepare().iterator(placeholderValues);
        };
      };
      iterator = this.createIterator();
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/select.types.js
var init_select_types = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/select.types.js"() {
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/update.js
var MySqlUpdateBuilder, MySqlUpdateBase;
var init_update = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/update.js"() {
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_table();
    init_utils();
    init_utils3();
    MySqlUpdateBuilder = class {
      constructor(table, session, dialect, withList) {
        this.table = table;
        this.session = session;
        this.dialect = dialect;
        this.withList = withList;
      }
      static [entityKind] = "MySqlUpdateBuilder";
      set(values) {
        return new MySqlUpdateBase(this.table, mapUpdateSet(this.table, values), this.session, this.dialect, this.withList);
      }
    };
    MySqlUpdateBase = class extends QueryPromise {
      constructor(table, set, session, dialect, withList) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { set, table, withList };
      }
      static [entityKind] = "MySqlUpdate";
      config;
      cacheConfig;
      /**
       * Adds a 'where' clause to the query.
       *
       * Calling this method will update only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param where the 'where' clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be updated.
       *
       * ```ts
       * // Update all cars with green color
       * db.update(cars).set({ color: 'red' })
       *   .where(eq(cars.color, 'green'));
       * // or
       * db.update(cars).set({ color: 'red' })
       *   .where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Update all BMW cars with a green color
       * db.update(cars).set({ color: 'red' })
       *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Update all cars with the green or blue color
       * db.update(cars).set({ color: 'red' })
       *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      orderBy(...columns) {
        if (typeof columns[0] === "function") {
          const orderBy = columns[0](
            new Proxy(
              this.config.table[Table.Symbol.Columns],
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
          this.config.orderBy = orderByArray;
        } else {
          const orderByArray = columns;
          this.config.orderBy = orderByArray;
        }
        return this;
      }
      limit(limit) {
        this.config.limit = limit;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildUpdateQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      prepare() {
        return this.session.prepareQuery(
          this.dialect.sqlToQuery(this.getSQL()),
          void 0,
          void 0,
          void 0,
          this.config.returning,
          {
            type: "insert",
            tables: extractUsedTable2(this.config.table)
          },
          this.cacheConfig
        );
      }
      execute = (placeholderValues) => {
        return this.prepare().execute(placeholderValues);
      };
      createIterator = () => {
        const self = this;
        return async function* (placeholderValues) {
          yield* self.prepare().iterator(placeholderValues);
        };
      };
      iterator = this.createIterator();
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/index.js
var init_query_builders = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/index.js"() {
    init_delete();
    init_insert();
    init_query_builder2();
    init_select2();
    init_select_types();
    init_update();
  }
});

// node_modules/drizzle-orm/mysql-core/query-builders/query.js
var RelationalQueryBuilder2, MySqlRelationalQuery;
var init_query = __esm({
  "node_modules/drizzle-orm/mysql-core/query-builders/query.js"() {
    init_entity();
    init_query_promise();
    init_relations();
    RelationalQueryBuilder2 = class {
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, mode) {
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect;
        this.session = session;
        this.mode = mode;
      }
      static [entityKind] = "MySqlRelationalQueryBuilder";
      findMany(config) {
        return new MySqlRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? config : {},
          "many",
          this.mode
        );
      }
      findFirst(config) {
        return new MySqlRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? { ...config, limit: 1 } : { limit: 1 },
          "first",
          this.mode
        );
      }
    };
    MySqlRelationalQuery = class extends QueryPromise {
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, queryMode, mode) {
        super();
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect;
        this.session = session;
        this.config = config;
        this.queryMode = queryMode;
        this.mode = mode;
      }
      static [entityKind] = "MySqlRelationalQuery";
      prepare() {
        const { query, builtQuery } = this._toSQL();
        return this.session.prepareQuery(
          builtQuery,
          void 0,
          (rawRows) => {
            const rows = rawRows.map((row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection));
            if (this.queryMode === "first") {
              return rows[0];
            }
            return rows;
          }
        );
      }
      _getQuery() {
        const query = this.mode === "planetscale" ? this.dialect.buildRelationalQueryWithoutLateralSubqueries({
          fullSchema: this.fullSchema,
          schema: this.schema,
          tableNamesMap: this.tableNamesMap,
          table: this.table,
          tableConfig: this.tableConfig,
          queryConfig: this.config,
          tableAlias: this.tableConfig.tsName
        }) : this.dialect.buildRelationalQuery({
          fullSchema: this.fullSchema,
          schema: this.schema,
          tableNamesMap: this.tableNamesMap,
          table: this.table,
          tableConfig: this.tableConfig,
          queryConfig: this.config,
          tableAlias: this.tableConfig.tsName
        });
        return query;
      }
      _toSQL() {
        const query = this._getQuery();
        const builtQuery = this.dialect.sqlToQuery(query.sql);
        return { builtQuery, query };
      }
      /** @internal */
      getSQL() {
        return this._getQuery().sql;
      }
      toSQL() {
        return this._toSQL().builtQuery;
      }
      execute() {
        return this.prepare().execute();
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/db.js
var MySqlDatabase;
var init_db = __esm({
  "node_modules/drizzle-orm/mysql-core/db.js"() {
    init_entity();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_count();
    init_query_builders();
    init_query();
    MySqlDatabase = class {
      constructor(dialect, session, schema, mode) {
        this.dialect = dialect;
        this.session = session;
        this.mode = mode;
        this._ = schema ? {
          schema: schema.schema,
          fullSchema: schema.fullSchema,
          tableNamesMap: schema.tableNamesMap
        } : {
          schema: void 0,
          fullSchema: {},
          tableNamesMap: {}
        };
        this.query = {};
        if (this._.schema) {
          for (const [tableName, columns] of Object.entries(this._.schema)) {
            this.query[tableName] = new RelationalQueryBuilder2(
              schema.fullSchema,
              this._.schema,
              this._.tableNamesMap,
              schema.fullSchema[tableName],
              columns,
              dialect,
              session,
              this.mode
            );
          }
        }
        this.$cache = { invalidate: async (_params) => {
        } };
      }
      static [entityKind] = "MySqlDatabase";
      query;
      /**
       * Creates a subquery that defines a temporary named result set as a CTE.
       *
       * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param alias The alias for the subquery.
       *
       * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
       *
       * @example
       *
       * ```ts
       * // Create a subquery with alias 'sq' and use it in the select query
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * const result = await db.with(sq).select().from(sq);
       * ```
       *
       * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
       *
       * ```ts
       * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
       * const sq = db.$with('sq').as(db.select({
       *   name: sql<string>`upper(${users.name})`.as('name'),
       * })
       * .from(users));
       *
       * const result = await db.with(sq).select({ name: sq.name }).from(sq);
       * ```
       */
      $with = (alias, selection) => {
        const self = this;
        const as = (qb) => {
          if (typeof qb === "function") {
            qb = qb(new QueryBuilder2(self.dialect));
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        };
        return { as };
      };
      $count(source, filters) {
        return new MySqlCountBuilder({ source, filters, session: this.session });
      }
      $cache;
      /**
       * Incorporates a previously defined CTE (using `$with`) into the main query.
       *
       * This method allows the main query to reference a temporary named result set.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param queries The CTEs to incorporate into the main query.
       *
       * @example
       *
       * ```ts
       * // Define a subquery 'sq' as a CTE using $with
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * // Incorporate the CTE 'sq' into the main query and select from it
       * const result = await db.with(sq).select().from(sq);
       * ```
       */
      with(...queries) {
        const self = this;
        function select(fields) {
          return new MySqlSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries
          });
        }
        function selectDistinct(fields) {
          return new MySqlSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries,
            distinct: true
          });
        }
        function update(table) {
          return new MySqlUpdateBuilder(table, self.session, self.dialect, queries);
        }
        function delete_(table) {
          return new MySqlDeleteBase(table, self.session, self.dialect, queries);
        }
        return { select, selectDistinct, update, delete: delete_ };
      }
      select(fields) {
        return new MySqlSelectBuilder({ fields: fields ?? void 0, session: this.session, dialect: this.dialect });
      }
      selectDistinct(fields) {
        return new MySqlSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect,
          distinct: true
        });
      }
      /**
       * Creates an update query.
       *
       * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
       *
       * Use `.set()` method to specify which values to update.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param table The table to update.
       *
       * @example
       *
       * ```ts
       * // Update all rows in the 'cars' table
       * await db.update(cars).set({ color: 'red' });
       *
       * // Update rows with filters and conditions
       * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
       * ```
       */
      update(table) {
        return new MySqlUpdateBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates an insert query.
       *
       * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert}
       *
       * @param table The table to insert into.
       *
       * @example
       *
       * ```ts
       * // Insert one row
       * await db.insert(cars).values({ brand: 'BMW' });
       *
       * // Insert multiple rows
       * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
       * ```
       */
      insert(table) {
        return new MySqlInsertBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates a delete query.
       *
       * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param table The table to delete from.
       *
       * @example
       *
       * ```ts
       * // Delete all rows in the 'cars' table
       * await db.delete(cars);
       *
       * // Delete rows with filters and conditions
       * await db.delete(cars).where(eq(cars.color, 'green'));
       * ```
       */
      delete(table) {
        return new MySqlDeleteBase(table, this.session, this.dialect);
      }
      execute(query) {
        return this.session.execute(typeof query === "string" ? sql.raw(query) : query.getSQL());
      }
      transaction(transaction, config) {
        return this.session.transaction(transaction, config);
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/view.js
function mysqlViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualViewBuilder2(name, selection, schema);
  }
  return new ViewBuilder2(name, schema);
}
var ViewBuilderCore2, ViewBuilder2, ManualViewBuilder2, MySqlView;
var init_view = __esm({
  "node_modules/drizzle-orm/mysql-core/view.js"() {
    init_entity();
    init_selection_proxy();
    init_utils();
    init_query_builder2();
    init_table3();
    init_view_base();
    init_view_common2();
    ViewBuilderCore2 = class {
      constructor(name, schema) {
        this.name = name;
        this.schema = schema;
      }
      static [entityKind] = "MySqlViewBuilder";
      config = {};
      algorithm(algorithm) {
        this.config.algorithm = algorithm;
        return this;
      }
      sqlSecurity(sqlSecurity) {
        this.config.sqlSecurity = sqlSecurity;
        return this;
      }
      withCheckOption(withCheckOption) {
        this.config.withCheckOption = withCheckOption ?? "cascaded";
        return this;
      }
    };
    ViewBuilder2 = class extends ViewBuilderCore2 {
      static [entityKind] = "MySqlViewBuilder";
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder2());
        }
        const selectionProxy = new SelectionProxyHandler({
          alias: this.name,
          sqlBehavior: "error",
          sqlAliasedBehavior: "alias",
          replaceOriginalName: true
        });
        const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
        return new Proxy(
          new MySqlView({
            mysqlConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: aliasedSelection,
              query: qb.getSQL().inlineParams()
            }
          }),
          selectionProxy
        );
      }
    };
    ManualViewBuilder2 = class extends ViewBuilderCore2 {
      static [entityKind] = "MySqlManualViewBuilder";
      columns;
      constructor(name, columns, schema) {
        super(name, schema);
        this.columns = getTableColumns(mysqlTable(name, columns));
      }
      existing() {
        return new Proxy(
          new MySqlView({
            mysqlConfig: void 0,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: void 0
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
      as(query) {
        return new Proxy(
          new MySqlView({
            mysqlConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: query.inlineParams()
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
    };
    MySqlView = class extends MySqlViewBase {
      static [entityKind] = "MySqlView";
      [MySqlViewConfig];
      constructor({ mysqlConfig, config }) {
        super(config);
        this[MySqlViewConfig] = mysqlConfig;
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/schema.js
var MySqlSchema;
var init_schema = __esm({
  "node_modules/drizzle-orm/mysql-core/schema.js"() {
    init_entity();
    init_table3();
    init_view();
    MySqlSchema = class {
      constructor(schemaName) {
        this.schemaName = schemaName;
      }
      static [entityKind] = "MySqlSchema";
      table = (name, columns, extraConfig) => {
        return mysqlTableWithSchema(name, columns, extraConfig, this.schemaName);
      };
      view = (name, columns) => {
        return mysqlViewWithSchema(name, columns, this.schemaName);
      };
    };
  }
});

// node_modules/drizzle-orm/mysql-core/session.js
var MySqlPreparedQuery, MySqlSession, MySqlTransaction;
var init_session = __esm({
  "node_modules/drizzle-orm/mysql-core/session.js"() {
    init_cache();
    init_entity();
    init_errors();
    init_sql();
    init_db();
    MySqlPreparedQuery = class {
      constructor(cache, queryMetadata, cacheConfig) {
        this.cache = cache;
        this.queryMetadata = queryMetadata;
        this.cacheConfig = cacheConfig;
        if (cache && cache.strategy() === "all" && cacheConfig === void 0) {
          this.cacheConfig = { enable: true, autoInvalidate: true };
        }
        if (!this.cacheConfig?.enable) {
          this.cacheConfig = void 0;
        }
      }
      static [entityKind] = "MySqlPreparedQuery";
      /** @internal */
      async queryWithCache(queryString, params, query) {
        if (this.cache === void 0 || is(this.cache, NoopCache) || this.queryMetadata === void 0) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (this.cacheConfig && !this.cacheConfig.enable) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) {
          try {
            const [res] = await Promise.all([
              query(),
              this.cache.onMutate({ tables: this.queryMetadata.tables })
            ]);
            return res;
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (!this.cacheConfig) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (this.queryMetadata.type === "select") {
          const fromCache = await this.cache.get(
            this.cacheConfig.tag ?? await hashQuery(queryString, params),
            this.queryMetadata.tables,
            this.cacheConfig.tag !== void 0,
            this.cacheConfig.autoInvalidate
          );
          if (fromCache === void 0) {
            let result;
            try {
              result = await query();
            } catch (e) {
              throw new DrizzleQueryError(queryString, params, e);
            }
            await this.cache.put(
              this.cacheConfig.tag ?? await hashQuery(queryString, params),
              result,
              // make sure we send tables that were used in a query only if user wants to invalidate it on each write
              this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [],
              this.cacheConfig.tag !== void 0,
              this.cacheConfig.config
            );
            return result;
          }
          return fromCache;
        }
        try {
          return await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
      /** @internal */
      joinsNotNullableMap;
    };
    MySqlSession = class {
      constructor(dialect) {
        this.dialect = dialect;
      }
      static [entityKind] = "MySqlSession";
      execute(query) {
        return this.prepareQuery(
          this.dialect.sqlToQuery(query),
          void 0
        ).execute();
      }
      async count(sql2) {
        const res = await this.execute(sql2);
        return Number(
          res[0][0]["count"]
        );
      }
      getSetTransactionSQL(config) {
        const parts = [];
        if (config.isolationLevel) {
          parts.push(`isolation level ${config.isolationLevel}`);
        }
        return parts.length ? sql`set transaction ${sql.raw(parts.join(" "))}` : void 0;
      }
      getStartTransactionSQL(config) {
        const parts = [];
        if (config.withConsistentSnapshot) {
          parts.push("with consistent snapshot");
        }
        if (config.accessMode) {
          parts.push(config.accessMode);
        }
        return parts.length ? sql`start transaction ${sql.raw(parts.join(" "))}` : void 0;
      }
    };
    MySqlTransaction = class extends MySqlDatabase {
      constructor(dialect, session, schema, nestedIndex, mode) {
        super(dialect, session, schema, mode);
        this.schema = schema;
        this.nestedIndex = nestedIndex;
      }
      static [entityKind] = "MySqlTransaction";
      rollback() {
        throw new TransactionRollbackError();
      }
    };
  }
});

// node_modules/drizzle-orm/mysql-core/subquery.js
var init_subquery2 = __esm({
  "node_modules/drizzle-orm/mysql-core/subquery.js"() {
  }
});

// node_modules/drizzle-orm/mysql-core/index.js
var init_mysql_core = __esm({
  "node_modules/drizzle-orm/mysql-core/index.js"() {
    init_alias2();
    init_checks();
    init_columns();
    init_db();
    init_dialect();
    init_foreign_keys2();
    init_indexes();
    init_primary_keys2();
    init_query_builders();
    init_schema();
    init_session();
    init_subquery2();
    init_table3();
    init_unique_constraint2();
    init_utils3();
    init_view_common2();
    init_view();
  }
});

// packages/core/src/storage/drizzle/schema.mysql.ts
var COL, asciiBinarySha256, usersTable2, organizationsTable2, organizationMembershipsTable2, identityEventInboxTable2, workspacesTable2, workspaceBudgetsTable2, workspaceMembershipsTable2, apiKeysTable2, managementApiKeysTable2, byokKeysTable2, providersTable2, modelsTable2, modelEndpointsTable2, routePoolsTable2, routePoolStickyBindingsTable2, modelSurfacesTable2, modelRoutesTable2, modelEndpointRoutesTable2, apiKeyRequestLogsTable2, providerAttemptAvailabilityTable2, generationFeedbackTable2, publicModelDailyStatsTable2, systemConfigTable2, configGroupAuditTable2, systemConfigWriteMutexTable, requestPresetsTable2, requestPresetVersionsTable2, guardrailsTable2, guardrailVersionsTable2, guardrailAssignmentsTable2, guardrailBudgetWindowsTable2, guardrailBudgetReservationsTable2, userBudgetReservationsTable2, routeDataPoliciesTable2, routeDataPolicyAuditTable2, userAuditLogsTable2, adminApiKeysTable2, adminAccessKeyAuditTable2, adminSharedKeyAuditTable2, adminSessionsTable2, portalSessionsTable2, sharedKeysTable2, sharedKeyEarningsTable2, userEarningsTable2, withdrawalsTable2, nftMintsTable2, signedChainTransaction, chainJobTransactionsTable, batchesTable2, batchItemsTable2;
var init_schema_mysql = __esm({
  "packages/core/src/storage/drizzle/schema.mysql.ts"() {
    "use strict";
    init_drizzle_orm();
    init_mysql_core();
    COL = {
      ID: 512,
      KEY: 767,
      USER_ID: 512,
      EMAIL: 512,
      EXTERNAL_USER_ID: 512,
      EXTERNAL_SYSTEM: 128,
      STATUS: 32,
      PERIOD: 64,
      PROVIDER_NAME: 512,
      MODEL_ID: 512,
      PROVIDER_ID: 512,
      ROUTE_GROUP: 64,
      VENDOR: 64,
      EVENT_TYPE: 64,
      ACTOR_TYPE: 32,
      SYSCONFIG_KEY: 255,
      TAG: 255,
      NAME: 512,
      WORKSPACE_ID: 600,
      WORKSPACE_SLUG: 128,
      ENDPOINT_ID: 191
    };
    asciiBinarySha256 = customType3({
      dataType: () => "char(64) character set ascii collate ascii_bin"
    });
    usersTable2 = mysqlTable(
      "users",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        /**
         * 在 `external_system` 命名空间内唯一（含 internal 用户，即 `external_system IS NULL`）；
         * 因 InnoDB 不支持 partial index，靠生成列 `external_system_norm` + `uk_users_external_system_email` 实现。
         */
        email: varchar2("email", { length: COL.EMAIL }).notNull(),
        budgetMax: decimal("budget_max", { precision: 18, scale: 6 }),
        budgetBase: decimal("budget_base", { precision: 18, scale: 6 }).notNull().default("0"),
        budgetSpent: decimal("budget_spent", { precision: 18, scale: 6 }).notNull().default("0"),
        budgetPeriod: varchar2("budget_period", { length: COL.PERIOD }).notNull().default("none"),
        budgetResetAt: timestamp2("budget_reset_at", { fsp: 6, mode: "string" }),
        budgetEpoch: bigint2("budget_epoch", { mode: "number" }).notNull().default(0),
        budgetReservedMicros: bigint2("budget_reserved_micros", { mode: "number" }).notNull().default(0),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        metadata: text3("metadata"),
        /** `{ "<models.id>": factor }` JSON；NULL 表示无用户级 Charged 折扣 */
        chargedCostFactors: text3("charged_cost_factors"),
        /** 上游命名空间（产品/租户），与 external_user_id 成对做幂等；纯网关用户二者皆空。 */
        externalSystem: varchar2("external_system", { length: COL.EXTERNAL_SYSTEM }),
        externalUserId: varchar2("external_user_id", {
          length: COL.EXTERNAL_USER_ID
        }),
        /**
         * MySQL-only generated column: `COALESCE(external_system, '')`. 与 `email` 组成
         * `uk_users_external_system_email` 唯一约束，让 internal 用户共享一个 namespace。
         * `users_external_system_nonempty_chk` 保证 `''` 哨兵不会与真实值碰撞。
         */
        externalSystemNorm: varchar2("external_system_norm", {
          length: COL.EXTERNAL_SYSTEM
        }).generatedAlwaysAs(sql`COALESCE(external_system, '')`, {
          mode: "stored"
        }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_users_external_system_user_id").on(
          t.externalSystem,
          t.externalUserId
        ),
        uniqueIndex2("uk_users_external_system_email").on(
          t.externalSystemNorm,
          t.email
        ),
        check2(
          "users_external_pair_chk",
          sql`(external_system IS NULL AND external_user_id IS NULL) OR (external_system IS NOT NULL AND external_user_id IS NOT NULL)`
        ),
        check2(
          "users_external_system_nonempty_chk",
          sql`external_system IS NULL OR CHAR_LENGTH(external_system) > 0`
        ),
        check2(
          "users_budget_epoch_chk",
          sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
        ),
        check2(
          "users_budget_reserved_micros_chk",
          sql`${t.budgetReservedMicros} >= 0 AND ${t.budgetReservedMicros} <= 9007199254740991`
        )
      ]
    );
    organizationsTable2 = mysqlTable(
      "organizations",
      {
        id: varchar2("id", { length: 255 }).primaryKey(),
        source: varchar2("source", { length: COL.EXTERNAL_SYSTEM }).notNull(),
        name: varchar2("name", { length: COL.NAME }).notNull(),
        slug: varchar2("slug", { length: 255 }),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        metadataJson: text3("metadata_json"),
        sourceUpdatedAt: timestamp2("source_updated_at", {
          fsp: 6,
          mode: "string"
        }).notNull(),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        check2(
          "organizations_status_chk",
          sql`${t.status} IN ('pending', 'active', 'suspended', 'deleted')`
        ),
        check2(
          "organizations_source_nonempty_chk",
          sql`CHAR_LENGTH(${t.source}) > 0`
        )
      ]
    );
    organizationMembershipsTable2 = mysqlTable(
      "organization_memberships",
      {
        organizationId: varchar2("organization_id", { length: 255 }).notNull().references(() => organizationsTable2.id, { onDelete: "cascade" }),
        subject: varchar2("subject", { length: 255 }).notNull(),
        userId: varchar2("user_id", { length: COL.USER_ID }).references(
          () => usersTable2.id,
          { onDelete: "set null" }
        ),
        email: varchar2("email", { length: COL.EMAIL }),
        rolesJson: text3("roles_json").notNull(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        sourceUpdatedAt: timestamp2("source_updated_at", {
          fsp: 6,
          mode: "string"
        }).notNull(),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey3({ columns: [t.organizationId, t.subject] }),
        check2(
          "organization_memberships_status_chk",
          sql`${t.status} IN ('active', 'suspended', 'removed')`
        ),
        check2(
          "organization_memberships_subject_nonempty_chk",
          sql`CHAR_LENGTH(${t.subject}) > 0`
        )
      ]
    );
    identityEventInboxTable2 = mysqlTable(
      "identity_event_inbox",
      {
        source: varchar2("source", { length: COL.EXTERNAL_SYSTEM }).notNull(),
        eventId: varchar2("event_id", { length: 200 }).notNull(),
        eventType: varchar2("event_type", { length: 128 }).notNull(),
        aggregateType: varchar2("aggregate_type", { length: 64 }).notNull(),
        aggregateId: varchar2("aggregate_id", { length: 512 }).notNull(),
        payloadSha256: varchar2("payload_sha256", { length: 64 }).notNull(),
        processorToken: varchar2("processor_token", { length: 64 }).notNull().unique(),
        occurredAt: timestamp2("occurred_at", { fsp: 6, mode: "string" }).notNull(),
        processedAt: timestamp2("processed_at", {
          fsp: 6,
          mode: "string"
        }).notNull()
      },
      (t) => [primaryKey3({ columns: [t.source, t.eventId] })]
    );
    workspacesTable2 = mysqlTable(
      "workspaces",
      {
        id: varchar2("id", { length: COL.WORKSPACE_ID }).primaryKey(),
        scopeType: varchar2("scope_type", { length: COL.STATUS }).notNull(),
        organizationId: varchar2("organization_id", { length: 255 }).references(
          () => organizationsTable2.id,
          { onDelete: "cascade" }
        ),
        personalOwnerUserId: varchar2("personal_owner_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "cascade" }),
        name: varchar2("name", { length: 255 }).notNull(),
        slug: varchar2("slug", { length: COL.WORKSPACE_SLUG }).notNull(),
        description: text3("description"),
        isDefault: int("is_default").notNull().default(0),
        defaultScopeKey: varchar2("default_scope_key", {
          length: COL.WORKSPACE_ID
        }).unique(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        settingsJson: text3("settings_json"),
        createdByUserId: varchar2("created_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_workspaces_personal_slug").on(
          t.personalOwnerUserId,
          t.slug
        ),
        uniqueIndex2("uk_workspaces_organization_slug").on(t.organizationId, t.slug),
        check2(
          "workspaces_scope_type_chk",
          sql`${t.scopeType} IN ('personal', 'organization')`
        ),
        check2("workspaces_status_chk", sql`${t.status} IN ('active', 'archived')`),
        check2("workspaces_default_flag_chk", sql`${t.isDefault} IN (0, 1)`),
        check2(
          "workspaces_scope_owner_chk",
          sql`(
			(${t.scopeType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.scopeType} = 'organization' AND ${t.organizationId} IS NOT NULL AND ${t.personalOwnerUserId} IS NULL)
		)`
        ),
        check2(
          "workspaces_default_key_chk",
          sql`(
			(${t.isDefault} = 1 AND ${t.defaultScopeKey} IS NOT NULL)
			OR (${t.isDefault} = 0 AND ${t.defaultScopeKey} IS NULL)
		)`
        )
      ]
    );
    workspaceBudgetsTable2 = mysqlTable(
      "workspace_budgets",
      {
        id: varchar2("id", { length: 64 }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        resetInterval: varchar2("reset_interval", { length: 16 }).notNull(),
        limitMicros: bigint2("limit_micros", { mode: "number", unsigned: true }).notNull(),
        configEpoch: int("config_epoch", { unsigned: true }).notNull().default(0),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_workspace_budgets_interval").on(t.workspaceId, t.resetInterval),
        index2("idx_workspace_budgets_workspace").on(t.workspaceId),
        check2("workspace_budgets_interval_chk", sql`${t.resetInterval} IN ('daily', 'weekly', 'monthly', 'lifetime')`),
        check2("workspace_budgets_limit_chk", sql`${t.limitMicros} > 0`),
        check2("workspace_budgets_epoch_chk", sql`${t.configEpoch} <= 2147483646`)
      ]
    );
    workspaceMembershipsTable2 = mysqlTable(
      "workspace_memberships",
      {
        id: varchar2("id", { length: 64 }).primaryKey(),
        membershipKey: varchar2("membership_key", { length: 64 }).notNull().unique(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        subject: varchar2("subject", { length: 255 }).notNull(),
        role: varchar2("role", { length: COL.STATUS }).notNull().default("member"),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        grantedBySubject: varchar2("granted_by_subject", { length: 255 }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        check2(
          "workspace_memberships_role_chk",
          sql`${t.role} IN ('admin', 'member')`
        ),
        check2(
          "workspace_memberships_status_chk",
          sql`${t.status} IN ('active', 'removed')`
        ),
        check2(
          "workspace_memberships_subject_chk",
          sql`CHAR_LENGTH(${t.subject}) BETWEEN 1 AND 255`
        ),
        check2(
          "workspace_memberships_key_chk",
          sql`CHAR_LENGTH(${t.membershipKey}) = 64`
        )
      ]
    );
    apiKeysTable2 = mysqlTable("api_keys", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      key: varchar2("key", { length: COL.KEY }).notNull(),
      keyHash: varchar2("key_hash", { length: 80 }),
      keyPreview: varchar2("key_preview", { length: 64 }),
      userId: varchar2("user_id", { length: COL.USER_ID }).notNull(),
      workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
      name: varchar2("name", { length: COL.NAME }),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      metadata: text3("metadata"),
      expiresAt: datetime("expires_at", { fsp: 6, mode: "string" }),
      limitMicros: bigint2("limit_micros", { mode: "number" }),
      limitReset: varchar2("limit_reset", { length: 16 }),
      includeByokInLimit: tinyint("include_byok_in_limit").notNull().default(0),
      limitEpoch: int("limit_epoch").notNull().default(0),
      lastUsedAt: timestamp2("last_used_at", { fsp: 6, mode: "string" }),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
    });
    managementApiKeysTable2 = mysqlTable(
      "management_api_keys",
      {
        id: varchar2("id", { length: 64 }).primaryKey(),
        keyHash: varchar2("key_hash", { length: 71 }).notNull().unique(),
        keyPreview: varchar2("key_preview", { length: 64 }).notNull(),
        accountType: varchar2("account_type", { length: COL.STATUS }).notNull(),
        personalOwnerUserId: varchar2("personal_owner_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "cascade" }),
        organizationId: varchar2("organization_id", { length: 255 }).references(
          () => organizationsTable2.id,
          { onDelete: "cascade" }
        ),
        name: varchar2("name", { length: 128 }).notNull(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        expiresAt: datetime("expires_at", { fsp: 6, mode: "string" }),
        lastUsedAt: datetime("last_used_at", { fsp: 6, mode: "string" }),
        createdByUserId: varchar2("created_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        index2("idx_management_api_keys_personal_created").on(
          t.personalOwnerUserId,
          t.createdAt
        ),
        index2("idx_management_api_keys_organization_created").on(
          t.organizationId,
          t.createdAt
        ),
        index2("idx_management_api_keys_status_expiry").on(t.status, t.expiresAt),
        check2(
          "management_api_keys_hash_chk",
          sql`CHAR_LENGTH(${t.keyHash}) = 71 AND ${t.keyHash} REGEXP '^sha256:[0-9a-f]{64}$'`
        ),
        check2(
          "management_api_keys_name_chk",
          sql`CHAR_LENGTH(${t.name}) BETWEEN 1 AND 128`
        ),
        check2(
          "management_api_keys_status_chk",
          sql`${t.status} IN ('active', 'revoked')`
        ),
        check2(
          "management_api_keys_account_type_chk",
          sql`${t.accountType} IN ('personal', 'organization')`
        ),
        check2(
          "management_api_keys_account_owner_chk",
          sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
		)`
        )
      ]
    );
    byokKeysTable2 = mysqlTable(
      "byok_keys",
      {
        id: varchar2("id", { length: 64 }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        provider: varchar2("provider", { length: 128 }).notNull(),
        name: varchar2("name", { length: 255 }),
        apiKeyEncrypted: text3("api_key_encrypted").notNull(),
        label: varchar2("label", { length: 512 }).notNull(),
        disabled: tinyint("disabled").notNull().default(0),
        isFallback: tinyint("is_fallback").notNull().default(0),
        alwaysUseForProvider: tinyint("always_use_for_provider").notNull().default(0),
        alwaysUseForMatchingModels: tinyint("always_use_for_matching_models").notNull().default(0),
        sortOrder: int("sort_order", { unsigned: true }).notNull(),
        allowedModelsJson: text3("allowed_models_json"),
        allowedUserIdsJson: text3("allowed_user_ids_json"),
        allowedApiKeyHashesJson: text3("allowed_api_key_hashes_json"),
        createdByManagementKeyId: varchar2("created_by_management_key_id", {
          length: 64
        }).references(() => managementApiKeysTable2.id, { onDelete: "set null" }),
        deletedAt: datetime("deleted_at", { fsp: 6, mode: "string" }),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        index2("idx_byok_keys_workspace_created").on(t.workspaceId, t.createdAt),
        index2("idx_byok_keys_runtime").on(
          t.workspaceId,
          t.provider,
          t.disabled,
          t.isFallback,
          t.sortOrder
        ),
        index2("idx_byok_keys_creator").on(t.createdByManagementKeyId, t.createdAt),
        check2(
          "byok_keys_always_use_priority_chk",
          sql`(${t.alwaysUseForProvider} = 0 AND ${t.alwaysUseForMatchingModels} = 0) OR ${t.isFallback} = 0`
        ),
        check2(
          "byok_keys_shared_capacity_policy_exclusive_chk",
          sql`${t.alwaysUseForProvider} = 0 OR ${t.alwaysUseForMatchingModels} = 0`
        )
      ]
    );
    providersTable2 = mysqlTable("providers", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      name: varchar2("name", { length: COL.PROVIDER_NAME }).notNull(),
      /** JSON: `{ openai?: { base?, endpoints? }, … }` */
      endpoints: text3("endpoints"),
      /** 该上游账号唯一 API Key */
      apiKey: text3("api_key").notNull().default(""),
      /** `active` | `disabled` */
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      description: text3("description"),
      /** 非空时该 provider 接受对应用户共享密钥池注入（openai/anthropic/zhipu/deepseek） */
      sharedChannelType: varchar2("shared_channel_type", { length: COL.VENDOR }),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    modelsTable2 = mysqlTable("models", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      displayName: text3("display_name"),
      vendor: varchar2("vendor", { length: COL.VENDOR }).notNull().default("other"),
      contextWindow: int("context_window"),
      /** Chat completion max output tokens; NULL for image-generation models. */
      maxTokens: int("max_tokens").default(8192),
      pricingProfile: text3("pricing_profile"),
      description: text3("description"),
      metadata: text3("metadata"),
      inputModalities: text3("input_modalities"),
      outputModalities: text3("output_modalities"),
      releasedAt: text3("released_at"),
      /** 路由策略配置 JSON；NULL=使用全局/代码默认 */
      routePolicy: text3("route_policy"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    modelEndpointsTable2 = mysqlTable(
      "model_endpoints",
      {
        /** 191 keeps the endpoint/route-target composite PK below InnoDB's key limit. */
        id: varchar2("id", { length: COL.ENDPOINT_ID }).primaryKey(),
        modelId: varchar2("model_id", { length: COL.MODEL_ID }).notNull().references(() => modelsTable2.id, { onDelete: "cascade" }),
        providerId: varchar2("provider_id", { length: COL.PROVIDER_ID }).notNull().references(() => providersTable2.id, { onDelete: "cascade" }),
        providerSlug: varchar2("provider_slug", { length: 255 }).notNull(),
        tag: varchar2("tag", { length: COL.TAG }).notNull(),
        /** Exact logical UNIQUE(model_id, provider_id, tag), without prefix indexes. */
        endpointIdentityKey: varchar2("endpoint_identity_key", {
          length: 64
        }).generatedAlwaysAs(
          sql`SHA2(CONCAT(CHAR_LENGTH(model_id), ':', model_id, CHAR_LENGTH(provider_id), ':', provider_id, CHAR_LENGTH(tag), ':', tag), 256)`,
          { mode: "stored" }
        ),
        endpointClass: varchar2("endpoint_class", { length: COL.STATUS }),
        region: varchar2("region", { length: 64 }),
        contextLength: int("context_length"),
        maxPromptTokens: int("max_prompt_tokens"),
        maxCompletionTokens: int("max_completion_tokens"),
        quantization: varchar2("quantization", { length: COL.STATUS }),
        supportedParameters: text3("supported_parameters").notNull().default("[]"),
        pricing: text3("pricing").notNull().default("{}"),
        supportsToolChoice: text3("supports_tool_choice").notNull().default('{"auto":null,"function":null,"none":null,"required":null}'),
        imageCapabilities: text3("image_capabilities").notNull().default("{}"),
        audioCapabilities: text3("audio_capabilities").notNull().default("{}"),
        /** Nullable boolean: NULL means the capability has not been verified. */
        supportsImplicitCaching: tinyint("supports_implicit_caching"),
        /** Nullable boolean: NULL means the capability has not been verified. */
        supportsVoiceCloning: tinyint("supports_voice_cloning"),
        evidenceUrl: text3("evidence_url"),
        verifiedBy: varchar2("verified_by", { length: COL.ID }),
        verifiedAt: timestamp2("verified_at", { fsp: 6, mode: "string" }),
        expiresAt: timestamp2("expires_at", { fsp: 6, mode: "string" }),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("draft"),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_model_endpoints_identity").on(t.endpointIdentityKey),
        index2("idx_model_endpoints_provider").on(t.providerId),
        index2("idx_model_endpoints_model_status").on(t.modelId, t.status),
        check2(
          "model_endpoints_status_chk",
          sql`${t.status} IN ('draft', 'verified', 'disabled')`
        ),
        check2(
          "model_endpoints_implicit_caching_chk",
          sql`${t.supportsImplicitCaching} IS NULL OR ${t.supportsImplicitCaching} IN (0, 1)`
        ),
        check2(
          "model_endpoints_voice_cloning_chk",
          sql`${t.supportsVoiceCloning} IS NULL OR ${t.supportsVoiceCloning} IN (0, 1)`
        ),
        check2(
          "model_endpoints_context_length_chk",
          sql`${t.contextLength} IS NULL OR ${t.contextLength} > 0`
        ),
        check2(
          "model_endpoints_max_prompt_tokens_chk",
          sql`${t.maxPromptTokens} IS NULL OR ${t.maxPromptTokens} > 0`
        ),
        check2(
          "model_endpoints_max_completion_tokens_chk",
          sql`${t.maxCompletionTokens} IS NULL OR ${t.maxCompletionTokens} > 0`
        )
      ]
    );
    routePoolsTable2 = mysqlTable("route_pools", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      modelId: varchar2("model_id", { length: COL.MODEL_ID }).notNull(),
      routeGroup: varchar2("route_group", { length: COL.ROUTE_GROUP }).notNull().default("default"),
      name: varchar2("name", { length: COL.NAME }).notNull(),
      strategy: varchar2("strategy", { length: COL.STATUS }),
      /** JSON map: {"10":"hash_affinity","0":"weight_priority"} — per-priority-tier overrides */
      tierStrategies: text3("tier_strategies"),
      stickyEnabled: int("sticky_enabled").notNull().default(0),
      stickyIdleTtlSeconds: int("sticky_idle_ttl_seconds").notNull().default(3600),
      /** Bumped on sticky config change to invalidate existing bindings */
      stickyEpoch: int("sticky_epoch").notNull().default(0),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
    });
    routePoolStickyBindingsTable2 = mysqlTable(
      "route_pool_sticky_bindings",
      {
        routePoolId: varchar2("route_pool_id", { length: COL.ID }).notNull(),
        affinityHash: varchar2("affinity_hash", { length: 64 }).notNull(),
        routeTargetId: varchar2("route_target_id", { length: COL.ID }).notNull(),
        bindingToken: varchar2("binding_token", { length: 64 }).notNull(),
        poolEpoch: int("pool_epoch").notNull().default(0),
        expiresAt: timestamp2("expires_at", { fsp: 6, mode: "string" }).notNull(),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      }
    );
    modelSurfacesTable2 = mysqlTable("model_surfaces", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      modelId: varchar2("model_id", { length: COL.MODEL_ID }).notNull(),
      routeGroup: varchar2("route_group", { length: COL.ROUTE_GROUP }).notNull().default("default"),
      requestProtocol: varchar2("request_protocol", {
        length: COL.STATUS
      }).notNull(),
      requestOperation: varchar2("request_operation", { length: 64 }).notNull().default("*"),
      routePoolId: varchar2("route_pool_id", { length: COL.ID }).notNull(),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
    });
    modelRoutesTable2 = mysqlTable("model_routes", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      modelId: varchar2("model_id", { length: COL.MODEL_ID }).notNull(),
      providerId: varchar2("provider_id", { length: COL.PROVIDER_ID }).notNull(),
      providerModelName: text3("provider_model_name").notNull(),
      priority: int("priority").notNull().default(0),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      routeGroup: varchar2("route_group", { length: COL.ROUTE_GROUP }).notNull().default("default"),
      /** 同 priority 层内权重 */
      weight: int("weight").notNull().default(1),
      priceOverride: text3("price_override"),
      customParams: text3("custom_params"),
      routingMetadata: text3("routing_metadata"),
      upstreamProtocol: varchar2("upstream_protocol", { length: COL.STATUS }).notNull().default("openai"),
      routePoolId: varchar2("route_pool_id", { length: COL.ID }),
      upstreamOperation: varchar2("upstream_operation", { length: 64 }).notNull().default("*"),
      adapter: varchar2("adapter", { length: 128 }).notNull().default("passthrough"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    modelEndpointRoutesTable2 = mysqlTable(
      "model_endpoint_routes",
      {
        endpointId: varchar2("endpoint_id", { length: COL.ENDPOINT_ID }).notNull().references(() => modelEndpointsTable2.id, { onDelete: "cascade" }),
        routeTargetId: varchar2("route_target_id", { length: COL.ID }).notNull().references(() => modelRoutesTable2.id, { onDelete: "cascade" }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        /** SHA-256 of the exact route/provider subject verified for this binding. */
        subjectFingerprint: asciiBinarySha256("subject_fingerprint")
      },
      (t) => [
        primaryKey3({ columns: [t.endpointId, t.routeTargetId] }),
        uniqueIndex2("uk_model_endpoint_routes_target").on(t.routeTargetId),
        check2(
          "model_endpoint_routes_subject_fingerprint_chk",
          sql`${t.subjectFingerprint} IS NULL OR ${t.subjectFingerprint} REGEXP '^[0-9a-f]{64}$'`
        )
      ]
    );
    apiKeyRequestLogsTable2 = mysqlTable("api_key_request_logs", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      userId: varchar2("user_id", { length: COL.USER_ID }),
      apiKeyId: varchar2("api_key_id", { length: COL.ID }),
      workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).references(
        () => workspacesTable2.id,
        { onDelete: "set null" }
      ),
      userEmail: varchar2("user_email", { length: COL.EMAIL }),
      modelId: varchar2("model_id", { length: COL.ID }),
      providerId: varchar2("provider_id", { length: COL.ID }),
      providerModelName: text3("provider_model_name"),
      modelName: text3("model_name"),
      providerName: text3("provider_name"),
      requestBody: text3("request_body"),
      upstreamRequestBody: text3("upstream_request_body"),
      requestProtocol: varchar2("request_protocol", { length: COL.STATUS }),
      requestOperation: varchar2("request_operation", { length: 64 }),
      upstreamProtocol: varchar2("upstream_protocol", { length: COL.STATUS }).notNull().default("openai"),
      upstreamOperation: varchar2("upstream_operation", { length: 64 }),
      modelSurfaceId: varchar2("model_surface_id", { length: COL.ID }),
      routePoolId: varchar2("route_pool_id", { length: COL.ID }),
      routeTargetId: varchar2("route_target_id", { length: COL.ID }),
      adapter: varchar2("adapter", { length: 128 }),
      routeTrace: text3("route_trace"),
      inputTokens: int("input_tokens").notNull().default(0),
      outputTokens: int("output_tokens").notNull().default(0),
      cacheReadTokens: int("cache_read_tokens").notNull().default(0),
      cacheWriteTokens: int("cache_write_tokens").notNull().default(0),
      reasoningTokens: int("reasoning_tokens").notNull().default(0),
      totalTokens: int("total_tokens").notNull().default(0),
      nativeTokensPrompt: bigint2("native_tokens_prompt", { mode: "number", unsigned: true }),
      nativeTokensCompletion: bigint2("native_tokens_completion", { mode: "number", unsigned: true }),
      nativeTokensCached: bigint2("native_tokens_cached", { mode: "number", unsigned: true }),
      nativeTokensReasoning: bigint2("native_tokens_reasoning", { mode: "number", unsigned: true }),
      nativeTokensCompletionImages: bigint2("native_tokens_completion_images", { mode: "number", unsigned: true }),
      meteredCost: decimal("metered_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      standardCost: decimal("standard_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      chargedCost: decimal("charged_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      /** Guardrail/user budget debit in integer micro-units; NULL marks a pre-ledger row. */
      budgetChargedMicros: bigint2("budget_charged_micros", { mode: "number" }),
      budgetAccountedAt: datetime("budget_accounted_at", {
        fsp: 6,
        mode: "string"
      }),
      routeGroup: varchar2("route_group", { length: COL.ROUTE_GROUP }).notNull().default("default"),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("success"),
      latencyMs: int("latency_ms"),
      gatewayOverheadMs: int("gateway_overhead_ms"),
      upstreamResponseMs: int("upstream_response_ms"),
      finalUpstreamHeadersMs: int("final_upstream_headers_ms"),
      firstReasoningTokenMs: int("first_reasoning_token_ms"),
      firstTokenMs: int("first_token_ms"),
      streamDurationMs: int("stream_duration_ms"),
      upstreamAttemptCount: int("upstream_attempt_count"),
      upstreamFailoverCount: int("upstream_failover_count"),
      timingMetadata: text3("timing_metadata"),
      errorMessage: text3("error_message"),
      rawUsage: text3("raw_usage"),
      /** 计费审计 JSON 字符串；结构见 `db/pricing-audit.ts` */
      pricingAudit: text3("pricing_audit"),
      providerKeyId: varchar2("provider_key_id", { length: COL.ID }),
      providerKeyLabel: varchar2("provider_key_label", { length: COL.NAME }),
      providerKeyFingerprint: varchar2("provider_key_fingerprint", { length: 64 }),
      upstreamRequestId: varchar2("upstream_request_id", { length: 200 }),
      upstreamMessageId: varchar2("upstream_message_id", { length: 200 }),
      billingKind: varchar2("billing_kind", { length: 32 }),
      inputImageCount: int("input_image_count").notNull().default(0),
      outputImageCount: int("output_image_count").notNull().default(0),
      audioDurationSeconds: double("audio_duration_seconds"),
      audioCharacters: int("audio_characters"),
      sessionId: varchar2("session_id", { length: 256 }),
      requestOrigin: varchar2("request_origin", { length: 512 }),
      httpReferer: varchar2("http_referer", { length: 512 }),
      userAgent: varchar2("user_agent", { length: 512 }),
      responseStreamed: tinyint("response_streamed"),
      dataRegion: varchar2("data_region", { length: 16 }),
      isByok: tinyint("is_byok"),
      chargedCostUsd: decimal("charged_cost_usd", { precision: 24, scale: 12 }),
      upstreamInferenceCostUsd: decimal("upstream_inference_cost_usd", { precision: 24, scale: 12 }),
      serviceTier: varchar2("service_tier", { length: 16 }),
      finishReason: varchar2("finish_reason", { length: 16 }),
      nativeFinishReason: varchar2("native_finish_reason", { length: 128 }),
      providerResponses: text3("provider_responses"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    providerAttemptAvailabilityTable2 = mysqlTable(
      "provider_attempt_availability",
      {
        requestLogId: varchar2("request_log_id", { length: COL.ID }).notNull().references(
          () => apiKeyRequestLogsTable2.id,
          { onDelete: "cascade" }
        ),
        attemptIndex: int("attempt_index").notNull(),
        routeTargetId: varchar2("route_target_id", { length: COL.ID }).notNull(),
        providerId: varchar2("provider_id", { length: COL.ID }).notNull(),
        outcome: varchar2("outcome", { length: 16 }).notNull(),
        reason: varchar2("reason", { length: 32 }).notNull(),
        httpStatus: int("http_status"),
        observedAt: datetime("observed_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey3({ columns: [t.requestLogId, t.attemptIndex] }),
        index2("idx_provider_attempt_availability_route_observed").on(t.routeTargetId, t.observedAt),
        index2("idx_provider_attempt_availability_observed").on(t.observedAt),
        check2(
          "provider_attempt_availability_attempt_index_chk",
          sql`${t.attemptIndex} BETWEEN 1 AND 128`
        ),
        check2(
          "provider_attempt_availability_outcome_chk",
          sql`${t.outcome} IN ('available', 'unavailable', 'excluded')`
        ),
        check2(
          "provider_attempt_availability_reason_chk",
          sql`${t.reason} IN ('accepted', 'provider_http_error', 'rate_limited', 'network_error', 'invalid_response', 'client_error', 'client_cancelled', 'unknown')`
        ),
        check2(
          "provider_attempt_availability_http_status_chk",
          sql`${t.httpStatus} IS NULL OR ${t.httpStatus} BETWEEN 100 AND 599`
        )
      ]
    );
    generationFeedbackTable2 = mysqlTable(
      "generation_feedback",
      {
        id: varchar2("id", { length: 40 }).primaryKey(),
        generationId: varchar2("generation_id", { length: COL.ID }).notNull().references(
          () => apiKeyRequestLogsTable2.id,
          { onDelete: "cascade" }
        ),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(
          () => workspacesTable2.id,
          { onDelete: "cascade" }
        ),
        managementApiKeyId: varchar2("management_api_key_id", { length: 64 }).notNull().references(
          () => managementApiKeysTable2.id,
          { onDelete: "cascade" }
        ),
        accountType: varchar2("account_type", { length: COL.STATUS }).notNull(),
        personalOwnerUserId: varchar2("personal_owner_user_id", { length: COL.USER_ID }).references(
          () => usersTable2.id,
          { onDelete: "cascade" }
        ),
        organizationId: varchar2("organization_id", { length: 255 }).references(
          () => organizationsTable2.id,
          { onDelete: "cascade" }
        ),
        category: varchar2("category", { length: COL.STATUS }).notNull(),
        comment: text3("comment"),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        index2("idx_generation_feedback_generation_created").on(t.generationId, t.createdAt),
        index2("idx_generation_feedback_personal_created").on(t.personalOwnerUserId, t.createdAt),
        index2("idx_generation_feedback_organization_created").on(t.organizationId, t.createdAt),
        check2("generation_feedback_id_chk", sql`CHAR_LENGTH(${t.id}) = 40 AND LEFT(${t.id}, 4) = 'gfb_'`),
        check2("generation_feedback_category_chk", sql`${t.category} IN ('latency', 'incoherence', 'incorrect_response', 'formatting', 'billing', 'api_error', 'other')`),
        check2("generation_feedback_comment_chk", sql`${t.comment} IS NULL OR CHAR_LENGTH(${t.comment}) <= 1000`),
        check2(
          "generation_feedback_account_owner_chk",
          sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
			)`
        )
      ]
    );
    publicModelDailyStatsTable2 = mysqlTable(
      "public_model_daily_stats",
      {
        statDate: varchar2("stat_date", { length: 10 }).notNull(),
        modelId: varchar2("model_id", { length: COL.MODEL_ID }).notNull(),
        shard: int("shard").notNull(),
        requestCount: bigint2("request_count", { mode: "number" }).notNull().default(0),
        successCount: bigint2("success_count", { mode: "number" }).notNull().default(0),
        errorCount: bigint2("error_count", { mode: "number" }).notNull().default(0),
        outputTokens: bigint2("output_tokens", { mode: "number" }).notNull().default(0),
        totalTokens: bigint2("total_tokens", { mode: "number" }).notNull().default(0),
        latencyTotalMs: bigint2("latency_total_ms", { mode: "number" }).notNull().default(0),
        latencySampleCount: bigint2("latency_sample_count", { mode: "number" }).notNull().default(0),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_public_model_daily_stats").on(
          t.statDate,
          t.modelId,
          t.shard
        ),
        check2("public_model_daily_stats_shard_chk", sql`shard >= 0 AND shard < 16`)
      ]
    );
    systemConfigTable2 = mysqlTable("system_config", {
      key: varchar2("key", { length: COL.SYSCONFIG_KEY }).primaryKey(),
      value: text3("value").notNull(),
      description: text3("description"),
      revision: varchar2("revision", { length: 36 }).notNull().default("legacy"),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
    });
    configGroupAuditTable2 = mysqlTable("config_group_audit", {
      id: char2("id", { length: 36 }).primaryKey(),
      family: varchar2("family", { length: 24 }).notNull(),
      provider: varchar2("provider", { length: 16 }),
      action: varchar2("action", { length: 16 }).notNull(),
      actorKind: varchar2("actor_kind", { length: 16 }).notNull(),
      actorId: varchar2("actor_id", { length: 617 }).notNull(),
      reason: varchar2("reason", { length: 600 }).notNull(),
      changedFieldsJson: text3("changed_fields_json").notNull(),
      activeBefore: varchar2("active_before", { length: 16 }),
      activeAfter: varchar2("active_after", { length: 16 }),
      credentialsJson: text3("credentials_json").notNull(),
      revisionBeforeJson: text3("revision_before_json").notNull(),
      revisionAfterJson: text3("revision_after_json").notNull(),
      source: varchar2("source", { length: 16 }).notNull(),
      createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull()
    }, (t) => [
      index2("idx_config_group_audit_family_created").on(t.family, sql`${t.createdAt} DESC`, sql`${t.id} DESC`),
      check2("config_group_audit_family_chk", sql`family IN ('web-search', 'web-fetch', 'web-deep-search', 'ai-detection')`),
      check2("config_group_audit_provider_chk", sql`provider IS NULL OR provider IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check2("config_group_audit_active_before_chk", sql`active_before IS NULL OR active_before IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check2("config_group_audit_active_after_chk", sql`active_after IS NULL OR active_after IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check2("config_group_audit_action_chk", sql`action IN ('save', 'save_activate', 'activate', 'legacy_save', 'reveal')`),
      check2("config_group_audit_actor_kind_chk", sql`actor_kind IN ('console', 'admin_key')`),
      check2("config_group_audit_actor_bounds_chk", sql`char_length(actor_id) BETWEEN 1 AND CASE WHEN actor_kind = 'console' THEN 617 ELSE 600 END`),
      check2("config_group_audit_reason_bounds_chk", sql`char_length(reason) BETWEEN 1 AND 600`),
      check2("config_group_audit_source_chk", sql`source IN ('admin_api', 'legacy_admin')`)
    ]);
    systemConfigWriteMutexTable = mysqlTable("system_config_write_mutex", {
      id: int("id").notNull().primaryKey()
    }, () => [check2("system_config_write_mutex_singleton_chk", sql`id = 1`)]);
    requestPresetsTable2 = mysqlTable(
      "request_presets",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        workspaceKey: varchar2("workspace_key", { length: 64 }).notNull(),
        ownerUserId: varchar2("owner_user_id", { length: COL.USER_ID }).notNull().references(() => usersTable2.id, { onDelete: "cascade" }),
        slug: varchar2("slug", { length: 128 }).notNull(),
        name: varchar2("name", { length: COL.NAME }).notNull(),
        description: text3("description"),
        visibility: varchar2("visibility", { length: 16 }).notNull().default("private"),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        designatedVersion: int("designated_version").notNull().default(1),
        latestVersion: int("latest_version").notNull().default(1),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_request_presets_workspace_slug").on(t.workspaceKey, t.slug),
        check2(
          "request_presets_visibility_chk",
          sql`${t.visibility} IN ('private', 'public')`
        ),
        check2(
          "request_presets_status_chk",
          sql`${t.status} IN ('active', 'archived')`
        ),
        check2(
          "request_presets_versions_chk",
          sql`${t.designatedVersion} >= 1 AND ${t.latestVersion} >= ${t.designatedVersion}`
        )
      ]
    );
    requestPresetVersionsTable2 = mysqlTable(
      "request_preset_versions",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        presetId: varchar2("preset_id", { length: COL.ID }).notNull().references(() => requestPresetsTable2.id, { onDelete: "cascade" }),
        version: int("version").notNull(),
        systemPrompt: text3("system_prompt"),
        configJson: text3("config_json").notNull(),
        createdByUserId: varchar2("created_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [uniqueIndex2("uk_request_preset_versions").on(t.presetId, t.version)]
    );
    guardrailsTable2 = mysqlTable(
      "guardrails",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        workspaceKey: varchar2("workspace_key", { length: 64 }).notNull(),
        ownerUserId: varchar2("owner_user_id", { length: COL.USER_ID }).notNull().references(() => usersTable2.id, { onDelete: "cascade" }),
        name: varchar2("name", { length: COL.NAME }).notNull(),
        description: text3("description"),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
        isWorkspaceDefault: tinyint("is_workspace_default").notNull().default(0),
        isAccountDefault: tinyint("is_account_default").notNull().default(0),
        accountScopeKey: varchar2("account_scope_key", { length: COL.WORKSPACE_ID }),
        workspaceDefaultKey: varchar2("workspace_default_key", { length: 64 }).generatedAlwaysAs(
          sql`CASE WHEN is_workspace_default = TRUE THEN SHA2(workspace_id, 256) ELSE NULL END`,
          { mode: "stored" }
        ),
        designatedVersion: int("designated_version").notNull().default(1),
        latestVersion: int("latest_version").notNull().default(1),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_guardrails_id_workspace").on(t.id, t.workspaceKey),
        uniqueIndex2("uk_guardrails_workspace_default").on(t.workspaceDefaultKey),
        uniqueIndex2("uk_guardrails_account_default").on(t.accountScopeKey),
        check2(
          "guardrails_default_kind_chk",
          sql`NOT (${t.isWorkspaceDefault} = TRUE AND ${t.isAccountDefault} = TRUE)`
        ),
        check2(
          "guardrails_account_scope_key_chk",
          sql`(${t.isAccountDefault} = TRUE AND ${t.accountScopeKey} IS NOT NULL) OR (${t.isAccountDefault} = FALSE AND ${t.accountScopeKey} IS NULL)`
        ),
        check2("guardrails_status_chk", sql`${t.status} IN ('active', 'archived')`),
        check2(
          "guardrails_versions_chk",
          sql`${t.designatedVersion} >= 1 AND ${t.latestVersion} >= ${t.designatedVersion}`
        )
      ]
    );
    guardrailVersionsTable2 = mysqlTable(
      "guardrail_versions",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        guardrailId: varchar2("guardrail_id", { length: COL.ID }).notNull().references(() => guardrailsTable2.id, { onDelete: "cascade" }),
        version: int("version").notNull(),
        configJson: text3("config_json").notNull(),
        createdByUserId: varchar2("created_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [uniqueIndex2("uk_guardrail_versions").on(t.guardrailId, t.version)]
    );
    guardrailAssignmentsTable2 = mysqlTable(
      "guardrail_assignments",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        workspaceKey: varchar2("workspace_key", { length: 64 }).notNull(),
        guardrailId: varchar2("guardrail_id", { length: COL.ID }).notNull().references(() => guardrailsTable2.id, { onDelete: "cascade" }),
        scopeType: varchar2("scope_type", { length: 16 }).notNull(),
        scopeId: varchar2("scope_id", { length: COL.ID }).notNull(),
        createdByUserId: varchar2("created_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        managementSource: varchar2("management_source", { length: 32 }),
        assignedByUserId: varchar2("assigned_by_user_id", {
          length: COL.USER_ID
        }).references(() => usersTable2.id, { onDelete: "set null" }),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_guardrail_assignments_workspace_scope").on(
          t.workspaceKey,
          t.scopeType,
          t.scopeId
        ),
        index2("idx_guardrail_assignments_assigned_by").on(t.assignedByUserId),
        index2("idx_guardrail_assignments_management_list").on(
          t.workspaceKey,
          t.managementSource,
          t.createdAt,
          t.id
        ),
        check2(
          "guardrail_assignments_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
        )
      ]
    );
    guardrailBudgetWindowsTable2 = mysqlTable(
      "guardrail_budget_windows",
      {
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        workspaceKey: varchar2("workspace_key", { length: 64 }).notNull(),
        scopeType: varchar2("scope_type", { length: 16 }).notNull(),
        scopeId: varchar2("scope_id", { length: COL.ID }).notNull(),
        period: varchar2("period", { length: 16 }).notNull(),
        periodStart: datetime("period_start", { fsp: 6, mode: "string" }).notNull(),
        periodEnd: datetime("period_end", { fsp: 6, mode: "string" }).notNull(),
        unreservedMicros: bigint2("unreserved_micros", { mode: "number" }).notNull().default(0),
        settledMicros: bigint2("settled_micros", { mode: "number" }).notNull().default(0),
        reservedMicros: bigint2("reserved_micros", { mode: "number" }).notNull().default(0),
        seedRequestId: varchar2("seed_request_id", { length: 128 }),
        seededAt: datetime("seeded_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey3({
          columns: [
            t.workspaceKey,
            t.scopeType,
            t.scopeId,
            t.period,
            t.periodStart
          ]
        }),
        check2(
          "guardrail_budget_windows_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
        ),
        check2(
          "guardrail_budget_windows_period_chk",
          sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
        ),
        check2(
          "guardrail_budget_windows_amount_chk",
          sql`${t.unreservedMicros} >= 0 AND ${t.settledMicros} >= 0 AND ${t.reservedMicros} >= 0`
        )
      ]
    );
    guardrailBudgetReservationsTable2 = mysqlTable(
      "guardrail_budget_reservations",
      {
        id: varchar2("id", { length: COL.ID }).primaryKey(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull().references(() => workspacesTable2.id, { onDelete: "cascade" }),
        workspaceKey: varchar2("workspace_key", { length: 64 }).notNull(),
        requestId: varchar2("request_id", { length: 128 }).notNull(),
        assignmentId: varchar2("assignment_id", { length: COL.ID }).notNull(),
        guardrailId: varchar2("guardrail_id", { length: COL.ID }).notNull(),
        guardrailVersion: int("guardrail_version").notNull(),
        scopeType: varchar2("scope_type", { length: 16 }).notNull(),
        scopeId: varchar2("scope_id", { length: COL.ID }).notNull(),
        period: varchar2("period", { length: 16 }).notNull(),
        periodStart: datetime("period_start", { fsp: 6, mode: "string" }).notNull(),
        periodEnd: datetime("period_end", { fsp: 6, mode: "string" }).notNull(),
        limitMicros: bigint2("limit_micros", { mode: "number" }).notNull(),
        reservedMicros: bigint2("reserved_micros", { mode: "number" }).notNull(),
        settledMicros: bigint2("settled_micros", { mode: "number" }).notNull().default(0),
        settlementBasis: varchar2("settlement_basis", { length: 32 }).notNull().default("charged"),
        state: varchar2("state", { length: 16 }).notNull().default("reserved"),
        expiresAt: datetime("expires_at", { fsp: 6, mode: "string" }).notNull(),
        dispatchedAt: datetime("dispatched_at", { fsp: 6, mode: "string" }),
        terminalAt: datetime("terminal_at", { fsp: 6, mode: "string" }),
        terminalReason: varchar2("terminal_reason", { length: 128 }),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_guardrail_budget_reservation_request_assignment").on(
          t.requestId,
          t.assignmentId
        ),
        check2(
          "guardrail_budget_reservations_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key')`
        ),
        check2(
          "guardrail_budget_reservations_period_chk",
          sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
        ),
        check2(
          "guardrail_budget_reservations_amount_chk",
          sql`${t.limitMicros} >= 0 AND ${t.reservedMicros} > 0 AND ${t.settledMicros} >= 0`
        ),
        check2(
          "guardrail_budget_reservations_state_chk",
          sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
        ),
        check2(
          "guardrail_budget_reservations_settlement_basis_chk",
          sql`${t.settlementBasis} IN ('charged', 'gateway_key_route')`
        )
      ]
    );
    userBudgetReservationsTable2 = mysqlTable(
      "user_budget_reservations",
      {
        requestId: varchar2("request_id", { length: 128 }).primaryKey(),
        userId: varchar2("user_id", { length: COL.USER_ID }).notNull(),
        apiKeyId: varchar2("api_key_id", { length: COL.ID }).notNull(),
        budgetEpoch: bigint2("budget_epoch", { mode: "number" }).notNull(),
        limitMicros: bigint2("limit_micros", { mode: "number" }).notNull(),
        reservedMicros: bigint2("reserved_micros", { mode: "number" }).notNull(),
        settledMicros: bigint2("settled_micros", { mode: "number" }).notNull().default(0),
        state: varchar2("state", { length: 16 }).notNull().default("reserved"),
        expiresAt: datetime("expires_at", { fsp: 6, mode: "string" }).notNull(),
        dispatchedAt: datetime("dispatched_at", { fsp: 6, mode: "string" }),
        terminalAt: datetime("terminal_at", { fsp: 6, mode: "string" }),
        terminalReason: varchar2("terminal_reason", { length: 128 }),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        check2(
          "user_budget_reservations_epoch_chk",
          sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
        ),
        check2(
          "user_budget_reservations_amount_chk",
          sql`${t.limitMicros} >= 0 AND ${t.limitMicros} <= 9007199254740991 AND ${t.reservedMicros} > 0 AND ${t.reservedMicros} <= 9007199254740991 AND ${t.settledMicros} >= 0 AND ${t.settledMicros} <= 9007199254740991`
        ),
        check2(
          "user_budget_reservations_state_chk",
          sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
        ),
        check2(
          "user_budget_reservations_range_chk",
          sql`${t.expiresAt} > ${t.createdAt}`
        )
      ]
    );
    routeDataPoliciesTable2 = mysqlTable(
      "route_data_policies",
      {
        routeTargetId: varchar2("route_target_id", { length: COL.ID }).primaryKey().references(() => modelRoutesTable2.id, { onDelete: "cascade" }),
        subjectFingerprint: asciiBinarySha256("subject_fingerprint"),
        retentionDays: int("retention_days"),
        trainingAllowed: int("training_allowed").notNull().default(1),
        zdrSupported: int("zdr_supported").notNull().default(0),
        evidenceUrl: text3("evidence_url"),
        verifiedBy: varchar2("verified_by", { length: COL.ID }),
        verifiedAt: timestamp2("verified_at", { fsp: 6, mode: "string" }),
        expiresAt: timestamp2("expires_at", { fsp: 6, mode: "string" }),
        status: varchar2("status", { length: 16 }).notNull().default("unknown"),
        invalidatedAt: timestamp2("invalidated_at", { fsp: 6, mode: "string" }),
        invalidationReason: varchar2("invalidation_reason", { length: 128 }),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        check2(
          "route_data_policies_retention_chk",
          sql`${t.retentionDays} IS NULL OR ${t.retentionDays} >= 0`
        ),
        check2(
          "route_data_policies_status_chk",
          sql`${t.status} IN ('verified', 'expired', 'unknown')`
        ),
        check2(
          "route_data_policies_subject_fingerprint_chk",
          sql`${t.subjectFingerprint} IS NULL OR ${t.subjectFingerprint} REGEXP '^[0-9a-f]{64}$'`
        )
      ]
    );
    routeDataPolicyAuditTable2 = mysqlTable("route_data_policy_audit", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      routeTargetId: varchar2("route_target_id", { length: COL.ID }).references(
        () => modelRoutesTable2.id,
        { onDelete: "set null" }
      ),
      snapshotJson: text3("snapshot_json").notNull(),
      actorId: varchar2("actor_id", { length: COL.ID }).notNull(),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    userAuditLogsTable2 = mysqlTable("user_audit_logs", {
      id: varchar2("id", { length: COL.ID }).primaryKey(),
      userId: varchar2("user_id", { length: COL.USER_ID }),
      apiKeyId: varchar2("api_key_id", { length: COL.ID }),
      eventType: varchar2("event_type", { length: COL.EVENT_TYPE }).notNull(),
      actorType: varchar2("actor_type", { length: COL.ACTOR_TYPE }).notNull().default("system"),
      requestLogId: varchar2("request_log_id", { length: COL.ID }),
      changePayload: text3("change_payload"),
      beforeUserSnapshot: text3("before_user_snapshot"),
      afterUserSnapshot: text3("after_user_snapshot"),
      changedFields: text3("changed_fields"),
      correlationId: varchar2("correlation_id", { length: COL.ID }),
      source: varchar2("source", { length: 128 }),
      actorId: varchar2("actor_id", { length: COL.ID }),
      reasonCode: varchar2("reason_code", { length: 128 }),
      reasonText: text3("reason_text"),
      createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    adminApiKeysTable2 = mysqlTable("admin_api_keys", {
      id: varchar2("id", { length: 128 }).primaryKey(),
      name: varchar2("name", { length: 255 }).notNull().unique(),
      description: text3("description"),
      secretKey: varchar2("secret_key", { length: COL.KEY }).notNull().unique(),
      secretKeyHash: varchar2("secret_key_hash", { length: 80 }),
      keyPrefix: varchar2("key_prefix", { length: 32 }).notNull(),
      permissionsJson: text3("permissions_json").notNull(),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("active"),
      lastUsedAt: timestamp2("last_used_at", { fsp: 6, mode: "string" }),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull(),
      revokedAt: timestamp2("revoked_at", { fsp: 6, mode: "string" })
    });
    adminAccessKeyAuditTable2 = mysqlTable("admin_access_key_audit", {
      id: char2("id", { length: 36 }).primaryKey(),
      keyId: varchar2("key_id", { length: 128 }).notNull(),
      action: varchar2("action", { length: 16 }).notNull(),
      changeMask: smallint2("change_mask", { unsigned: true }).notNull(),
      actorKind: varchar2("actor_kind", { length: 16 }).notNull(),
      actorId: varchar2("actor_id", { length: 272 }).notNull(),
      beforePermissionsJson: text3("before_permissions_json"),
      afterPermissionsJson: text3("after_permissions_json"),
      beforeStatus: varchar2("before_status", { length: 16 }),
      afterStatus: varchar2("after_status", { length: 16 }),
      createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull()
    });
    adminSharedKeyAuditTable2 = mysqlTable("admin_shared_key_audit", {
      id: char2("id", { length: 36 }).primaryKey(),
      keyId: varchar2("key_id", { length: 255 }).notNull(),
      action: varchar2("action", { length: 16 }).notNull(),
      changeMask: smallint2("change_mask", { unsigned: true }).notNull(),
      actorKind: varchar2("actor_kind", { length: 16 }).notNull(),
      actorId: varchar2("actor_id", { length: 617 }).notNull(),
      source: varchar2("source", { length: 16 }).notNull(),
      reason: varchar2("reason", { length: 600 }).notNull(),
      beforeStatus: varchar2("before_status", { length: 16 }).notNull(),
      beforeSellerPriority: int("before_seller_priority").notNull(),
      beforeWeight: int("before_weight").notNull(),
      beforeValidated: smallint2("before_validated").notNull(),
      afterStatus: varchar2("after_status", { length: 16 }),
      afterSellerPriority: int("after_seller_priority"),
      afterWeight: int("after_weight"),
      afterValidated: smallint2("after_validated"),
      beforeRevision: varchar2("before_revision", { length: 71 }).notNull(),
      afterRevision: varchar2("after_revision", { length: 71 }),
      createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull()
    }, (t) => [index2("idx_admin_shared_key_audit_key_created").on(t.keyId, t.createdAt, t.id)]);
    adminSessionsTable2 = mysqlTable("admin_sessions", {
      tokenHash: varchar2("token_hash", { length: 64 }).primaryKey(),
      username: varchar2("username", { length: 264 }).notNull(),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      expiresAt: timestamp2("expires_at", { fsp: 6, mode: "string" }).notNull()
    });
    portalSessionsTable2 = mysqlTable("portal_sessions", {
      tokenHash: varchar2("token_hash", { length: 64 }).primaryKey(),
      /** CinaAuth OIDC `sub` */
      subject: varchar2("subject", { length: 255 }).notNull(),
      email: varchar2("email", { length: 512 }).notNull(),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      expiresAt: timestamp2("expires_at", { fsp: 6, mode: "string" }).notNull()
    });
    sharedKeysTable2 = mysqlTable(
      "shared_keys",
      {
        id: varchar2("id", { length: 128 }).primaryKey(),
        sellerUserId: varchar2("seller_user_id", { length: COL.USER_ID }).notNull(),
        channelType: varchar2("channel_type", { length: COL.VENDOR }).notNull(),
        apiKey: text3("api_key").notNull(),
        keyFingerprint: varchar2("key_fingerprint", { length: 128 }).notNull(),
        label: varchar2("label", { length: COL.NAME }),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("validating"),
        sellerPriority: int("seller_priority").notNull().default(0),
        weight: int("weight").notNull().default(1),
        inputPrice: decimal("input_price", { precision: 18, scale: 6 }).notNull().default("0"),
        outputPrice: decimal("output_price", { precision: 18, scale: 6 }).notNull().default("0"),
        cacheReadPrice: decimal("cache_read_price", { precision: 18, scale: 6 }),
        cacheWritePrice: decimal("cache_write_price", { precision: 18, scale: 6 }),
        validatedAt: timestamp2("validated_at", { fsp: 6, mode: "string" }),
        lastUsedAt: timestamp2("last_used_at", { fsp: 6, mode: "string" }),
        lastFailureAt: timestamp2("last_failure_at", { fsp: 6, mode: "string" }),
        failureReason: text3("failure_reason"),
        servedInputTokens: bigint2("served_input_tokens", { mode: "number" }).notNull().default(0),
        servedOutputTokens: bigint2("served_output_tokens", { mode: "number" }).notNull().default(0),
        earnedTotal: decimal("earned_total", { precision: 18, scale: 6 }).notNull().default("0"),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_shared_keys_seller_fingerprint").on(
          t.sellerUserId,
          t.keyFingerprint
        )
      ]
    );
    sharedKeyEarningsTable2 = mysqlTable(
      "shared_key_earnings",
      {
        id: varchar2("id", { length: 128 }).primaryKey(),
        requestLogId: varchar2("request_log_id", { length: 128 }).notNull(),
        sharedKeyId: varchar2("shared_key_id", { length: 128 }).notNull(),
        sellerUserId: varchar2("seller_user_id", { length: COL.USER_ID }).notNull(),
        inputTokens: int("input_tokens").notNull().default(0),
        outputTokens: int("output_tokens").notNull().default(0),
        cacheReadTokens: int("cache_read_tokens").notNull().default(0),
        cacheWriteTokens: int("cache_write_tokens").notNull().default(0),
        grossAmount: decimal("gross_amount", { precision: 18, scale: 6 }).notNull().default("0"),
        platformFee: decimal("platform_fee", { precision: 18, scale: 6 }).notNull().default("0"),
        netAmount: decimal("net_amount", { precision: 18, scale: 6 }).notNull().default("0"),
        currency: varchar2("currency", { length: 16 }).notNull().default("USD"),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [uniqueIndex2("uk_shared_key_earnings_request_log").on(t.requestLogId)]
    );
    userEarningsTable2 = mysqlTable("user_earnings", {
      userId: varchar2("user_id", { length: COL.USER_ID }).primaryKey(),
      balance: decimal("balance", { precision: 18, scale: 6 }).notNull().default("0"),
      lockedAmount: decimal("locked_amount", { precision: 18, scale: 6 }).notNull().default("0"),
      lifetimeEarned: decimal("lifetime_earned", { precision: 18, scale: 6 }).notNull().default("0"),
      lifetimeWithdrawn: decimal("lifetime_withdrawn", { precision: 18, scale: 6 }).notNull().default("0"),
      contributionValue: decimal("contribution_value", { precision: 18, scale: 6 }).notNull().default("0"),
      walletAddress: varchar2("wallet_address", { length: 128 }),
      walletVerifiedAt: timestamp2("wallet_verified_at", { fsp: 6, mode: "string" }),
      highestBadgeTier: int("highest_badge_tier").notNull().default(0),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull()
    });
    withdrawalsTable2 = mysqlTable("withdrawals", {
      id: varchar2("id", { length: 128 }).primaryKey(),
      userId: varchar2("user_id", { length: COL.USER_ID }).notNull(),
      amount: decimal("amount", { precision: 18, scale: 6 }).notNull(),
      fee: decimal("fee", { precision: 18, scale: 6 }).notNull().default("0"),
      netAmount: decimal("net_amount", { precision: 18, scale: 6 }).notNull(),
      currency: varchar2("currency", { length: 16 }).notNull().default("USD"),
      walletAddress: varchar2("wallet_address", { length: 128 }).notNull(),
      status: varchar2("status", { length: COL.STATUS }).notNull().default("requested"),
      tokenAmount: decimal("token_amount", { precision: 18, scale: 6 }),
      txHash: varchar2("tx_hash", { length: 128 }),
      chainId: int("chain_id"),
      failureReason: text3("failure_reason"),
      createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
      updatedAt: timestamp2("updated_at", { fsp: 6, mode: "string" }).notNull(),
      confirmedAt: timestamp2("confirmed_at", { fsp: 6, mode: "string" })
    });
    nftMintsTable2 = mysqlTable(
      "nft_mints",
      {
        id: varchar2("id", { length: 128 }).primaryKey(),
        userId: varchar2("user_id", { length: COL.USER_ID }).notNull(),
        badgeTokenId: int("badge_token_id").notNull(),
        tierName: varchar2("tier_name", { length: COL.VENDOR }).notNull(),
        walletAddress: varchar2("wallet_address", { length: 128 }).notNull(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("pending"),
        txHash: varchar2("tx_hash", { length: 128 }),
        chainId: int("chain_id"),
        valueSnapshot: decimal("value_snapshot", { precision: 18, scale: 6 }).notNull().default("0"),
        failureReason: text3("failure_reason"),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        confirmedAt: timestamp2("confirmed_at", { fsp: 6, mode: "string" })
      },
      (t) => [uniqueIndex2("uk_nft_mints_user_badge").on(t.userId, t.badgeTokenId)]
    );
    signedChainTransaction = customType3({
      dataType: () => "longtext"
    });
    chainJobTransactionsTable = mysqlTable(
      "chain_job_transactions",
      {
        jobKind: varchar2("job_kind", { length: 32 }).notNull(),
        jobId: varchar2("job_id", { length: 128 }).notNull(),
        txHash: varchar2("tx_hash", { length: 128 }).notNull(),
        rawTransaction: signedChainTransaction("raw_transaction").notNull(),
        chainId: int("chain_id").notNull(),
        createdAt: timestamp2("created_at", { fsp: 6, mode: "string" }).notNull(),
        broadcastAt: timestamp2("broadcast_at", { fsp: 6, mode: "string" })
      },
      (t) => [
        primaryKey3({ columns: [t.jobKind, t.jobId] }),
        uniqueIndex2("uk_chain_job_transactions_hash").on(t.txHash),
        index2("idx_chain_job_transactions_created").on(t.createdAt, t.jobKind, t.jobId)
      ]
    );
    batchesTable2 = mysqlTable(
      "batches",
      {
        id: varchar2("id", { length: 128 }).primaryKey(),
        accountId: varchar2("account_id", { length: 1024 }).notNull(),
        workspaceId: varchar2("workspace_id", { length: COL.WORKSPACE_ID }).notNull(),
        workspaceKey: asciiBinarySha256("workspace_key").generatedAlwaysAs(
          sql`SHA2(workspace_id, 256)`,
          { mode: "stored" }
        ),
        userId: varchar2("user_id", { length: COL.USER_ID }).notNull(),
        apiKeyHash: varchar2("api_key_hash", { length: 71 }).notNull(),
        endpoint: varchar2("endpoint", { length: 32 }).notNull(),
        modelId: varchar2("model_id", { length: COL.ID }).notNull(),
        routeGroup: varchar2("route_group", { length: COL.ROUTE_GROUP }).notNull(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("validating"),
        completionWindow: varchar2("completion_window", { length: 8 }).notNull().default("24h"),
        idempotencyKeyHash: asciiBinarySha256("idempotency_key_hash"),
        idempotencyScopeKey: asciiBinarySha256("idempotency_scope_key").generatedAlwaysAs(
          sql`CASE WHEN idempotency_key_hash IS NULL THEN NULL ELSE SHA2(CONCAT(CHAR_LENGTH(workspace_id), ':', workspace_id, ':', api_key_hash, ':', idempotency_key_hash), 256) END`,
          { mode: "stored" }
        ),
        inputObjectKey: varchar2("input_object_key", { length: 1024 }).notNull(),
        inputSha256: asciiBinarySha256("input_sha256").notNull(),
        inputBytes: int("input_bytes", { unsigned: true }).notNull(),
        resultObjectKey: varchar2("result_object_key", { length: 1024 }),
        resultSha256: asciiBinarySha256("result_sha256"),
        requestCount: int("request_count", { unsigned: true }).notNull(),
        validationNextOrdinal: int("validation_next_ordinal", { unsigned: true }).notNull().default(0),
        validationInputOffset: int("validation_input_offset", { unsigned: true }).notNull().default(0),
        completedCount: int("completed_count", { unsigned: true }).notNull().default(0),
        failedCount: int("failed_count", { unsigned: true }).notNull().default(0),
        cancelledCount: int("cancelled_count", { unsigned: true }).notNull().default(0),
        promptTokens: bigint2("prompt_tokens", { mode: "number", unsigned: true }).notNull().default(0),
        completionTokens: bigint2("completion_tokens", { mode: "number", unsigned: true }).notNull().default(0),
        totalTokens: bigint2("total_tokens", { mode: "number", unsigned: true }).notNull().default(0),
        chargedCostMicros: bigint2("charged_cost_micros", {
          mode: "number",
          unsigned: true
        }).notNull().default(0),
        byokRequestCount: int("byok_request_count", { unsigned: true }).notNull().default(0),
        unknownCostCount: int("unknown_cost_count", { unsigned: true }).notNull().default(0),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        inProgressAt: datetime("in_progress_at", { fsp: 6, mode: "string" }),
        finalizingAt: datetime("finalizing_at", { fsp: 6, mode: "string" }),
        finalizedAt: datetime("finalized_at", { fsp: 6, mode: "string" }),
        expiresAt: datetime("expires_at", { fsp: 6, mode: "string" }).notNull(),
        retentionExpiresAt: datetime("retention_expires_at", { fsp: 6, mode: "string" }).notNull(),
        leaseOwner: varchar2("lease_owner", { length: 128 }),
        leaseExpiresAt: datetime("lease_expires_at", { fsp: 6, mode: "string" }),
        attemptCount: bigint2("attempt_count", { mode: "number", unsigned: true }).notNull().default(0),
        revision: bigint2("revision", { mode: "number", unsigned: true }).notNull().default(0),
        lastErrorCode: varchar2("last_error_code", { length: 128 }),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex2("uk_batches_idempotency").on(t.idempotencyScopeKey),
        index2("idx_batches_workspace_created").on(t.workspaceKey, t.createdAt, t.id),
        index2("idx_batches_status_lease").on(t.status, t.leaseExpiresAt),
        index2("idx_batches_retention").on(t.retentionExpiresAt),
        check2(
          "batches_status_chk",
          sql`${t.status} IN ('validating', 'in_progress', 'finalizing', 'completed', 'failed', 'expired', 'cancelling', 'cancelled')`
        ),
        check2(
          "batches_counts_chk",
          sql`${t.requestCount} BETWEEN 1 AND 1000000 AND ${t.completedCount} + ${t.failedCount} + ${t.cancelledCount} <= ${t.requestCount}`
        ),
        check2(
          "batches_validation_checkpoint_chk",
          sql`${t.inputBytes} BETWEEN 1 AND 52428800 AND ${t.validationNextOrdinal} <= ${t.requestCount} AND ${t.validationInputOffset} <= ${t.inputBytes}`
        )
      ]
    );
    batchItemsTable2 = mysqlTable(
      "batch_items",
      {
        id: varchar2("id", { length: 128 }).notNull().unique(),
        batchId: varchar2("batch_id", { length: 128 }).notNull(),
        ordinal: int("ordinal", { unsigned: true }).notNull(),
        customId: varchar2("custom_id", { length: 256 }).notNull(),
        status: varchar2("status", { length: COL.STATUS }).notNull().default("pending"),
        attemptCount: bigint2("attempt_count", { mode: "number", unsigned: true }).notNull().default(0),
        startedAt: datetime("started_at", { fsp: 6, mode: "string" }),
        dispatchStartedAt: datetime("dispatch_started_at", { fsp: 6, mode: "string" }),
        completedAt: datetime("completed_at", { fsp: 6, mode: "string" }),
        generationId: varchar2("generation_id", { length: COL.ID }),
        reservationId: varchar2("reservation_id", { length: COL.ID }),
        leaseOwner: varchar2("lease_owner", { length: 128 }),
        leaseExpiresAt: datetime("lease_expires_at", { fsp: 6, mode: "string" }),
        requestStartOffset: int("request_start_offset", { unsigned: true }).notNull(),
        requestEndOffset: int("request_end_offset", { unsigned: true }).notNull(),
        requestSha256: asciiBinarySha256("request_sha256").notNull(),
        resultObjectKey: varchar2("result_object_key", { length: 1024 }),
        resultSha256: asciiBinarySha256("result_sha256"),
        errorCode: varchar2("error_code", { length: 128 }),
        errorSummary: varchar2("error_summary", { length: 1e3 }),
        revision: bigint2("revision", { mode: "number", unsigned: true }).notNull().default(0),
        createdAt: datetime("created_at", { fsp: 6, mode: "string" }).notNull(),
        updatedAt: datetime("updated_at", { fsp: 6, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey3({ columns: [t.batchId, t.ordinal] }),
        uniqueIndex2("uk_batch_items_custom").on(t.batchId, t.customId),
        index2("idx_batch_items_status_ordinal").on(t.batchId, t.status, t.ordinal),
        check2(
          "batch_items_status_chk",
          sql`${t.status} IN ('pending', 'in_progress', 'completed', 'failed', 'cancelled')`
        ),
        check2(
          "batch_items_request_range_chk",
          sql`${t.requestStartOffset} BETWEEN 0 AND 52428799 AND ${t.requestEndOffset} BETWEEN 1 AND 52428800 AND ${t.requestEndOffset} > ${t.requestStartOffset} AND ${t.requestEndOffset} - ${t.requestStartOffset} <= 1048578`
        ),
        check2(
          "batch_items_lease_pair_chk",
          sql`(${t.leaseOwner} IS NULL AND ${t.leaseExpiresAt} IS NULL) OR (${t.leaseOwner} IS NOT NULL AND char_length(${t.leaseOwner}) BETWEEN 1 AND 128 AND ${t.leaseExpiresAt} IS NOT NULL)`
        ),
        check2(
          "batch_items_dispatch_chk",
          sql`(${t.dispatchStartedAt} IS NULL AND ${t.generationId} IS NULL AND ${t.reservationId} IS NULL) OR (${t.dispatchStartedAt} IS NOT NULL AND ${t.startedAt} IS NOT NULL AND ${t.generationId} IS NOT NULL AND char_length(${t.generationId}) BETWEEN 1 AND 512 AND ${t.reservationId} IS NOT NULL AND char_length(${t.reservationId}) BETWEEN 1 AND 512)`
        )
      ]
    );
  }
});

// node_modules/drizzle-orm/pg-core/alias.js
var init_alias3 = __esm({
  "node_modules/drizzle-orm/pg-core/alias.js"() {
    init_alias();
  }
});

// node_modules/drizzle-orm/pg-core/checks.js
function check3(name, value) {
  return new CheckBuilder3(name, value);
}
var CheckBuilder3, Check3;
var init_checks2 = __esm({
  "node_modules/drizzle-orm/pg-core/checks.js"() {
    init_entity();
    CheckBuilder3 = class {
      constructor(name, value) {
        this.name = name;
        this.value = value;
      }
      static [entityKind] = "PgCheckBuilder";
      brand;
      /** @internal */
      build(table) {
        return new Check3(table, this);
      }
    };
    Check3 = class {
      constructor(table, builder) {
        this.table = table;
        this.name = builder.name;
        this.value = builder.value;
      }
      static [entityKind] = "PgCheck";
      name;
      value;
    };
  }
});

// node_modules/drizzle-orm/pg-core/columns/index.js
var init_columns2 = __esm({
  "node_modules/drizzle-orm/pg-core/columns/index.js"() {
    init_bigint();
    init_bigserial();
    init_boolean();
    init_char();
    init_cidr();
    init_common();
    init_custom();
    init_date();
    init_double_precision();
    init_enum();
    init_inet();
    init_int_common();
    init_integer();
    init_interval();
    init_json();
    init_jsonb();
    init_line();
    init_macaddr();
    init_macaddr8();
    init_numeric();
    init_point();
    init_geometry();
    init_real();
    init_serial();
    init_smallint();
    init_smallserial();
    init_text();
    init_time();
    init_timestamp();
    init_uuid();
    init_varchar();
    init_bit();
    init_halfvec();
    init_sparsevec();
    init_vector();
  }
});

// node_modules/drizzle-orm/pg-core/indexes.js
function index3(name) {
  return new IndexBuilderOn3(false, name);
}
function uniqueIndex3(name) {
  return new IndexBuilderOn3(true, name);
}
var IndexBuilderOn3, IndexBuilder3, Index3;
var init_indexes2 = __esm({
  "node_modules/drizzle-orm/pg-core/indexes.js"() {
    init_sql();
    init_entity();
    init_columns2();
    IndexBuilderOn3 = class {
      constructor(unique, name) {
        this.unique = unique;
        this.name = name;
      }
      static [entityKind] = "PgIndexBuilderOn";
      on(...columns) {
        return new IndexBuilder3(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
            return clonedIndexedColumn;
          }),
          this.unique,
          false,
          this.name
        );
      }
      onOnly(...columns) {
        return new IndexBuilder3(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = it.defaultConfig;
            return clonedIndexedColumn;
          }),
          this.unique,
          true,
          this.name
        );
      }
      /**
       * Specify what index method to use. Choices are `btree`, `hash`, `gist`, `spgist`, `gin`, `brin`, or user-installed access methods like `bloom`. The default method is `btree.
       *
       * If you have the `pg_vector` extension installed in your database, you can use the `hnsw` and `ivfflat` options, which are predefined types.
       *
       * **You can always specify any string you want in the method, in case Drizzle doesn't have it natively in its types**
       *
       * @param method The name of the index method to be used
       * @param columns
       * @returns
       */
      using(method, ...columns) {
        return new IndexBuilder3(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
            return clonedIndexedColumn;
          }),
          this.unique,
          true,
          this.name,
          method
        );
      }
    };
    IndexBuilder3 = class {
      static [entityKind] = "PgIndexBuilder";
      /** @internal */
      config;
      constructor(columns, unique, only, name, method = "btree") {
        this.config = {
          name,
          columns,
          unique,
          only,
          method
        };
      }
      concurrently() {
        this.config.concurrently = true;
        return this;
      }
      with(obj) {
        this.config.with = obj;
        return this;
      }
      where(condition) {
        this.config.where = condition;
        return this;
      }
      /** @internal */
      build(table) {
        return new Index3(this.config, table);
      }
    };
    Index3 = class {
      static [entityKind] = "PgIndex";
      config;
      constructor(config, table) {
        this.config = { ...config, table };
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/policies.js
var PgPolicy;
var init_policies = __esm({
  "node_modules/drizzle-orm/pg-core/policies.js"() {
    init_entity();
    PgPolicy = class {
      constructor(name, config) {
        this.name = name;
        if (config) {
          this.as = config.as;
          this.for = config.for;
          this.to = config.to;
          this.using = config.using;
          this.withCheck = config.withCheck;
        }
      }
      static [entityKind] = "PgPolicy";
      as;
      for;
      to;
      using;
      withCheck;
      /** @internal */
      _linkedTable;
      link(table) {
        this._linkedTable = table;
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/view-common.js
var PgViewConfig;
var init_view_common3 = __esm({
  "node_modules/drizzle-orm/pg-core/view-common.js"() {
    PgViewConfig = /* @__PURE__ */ Symbol.for("drizzle:PgViewConfig");
  }
});

// node_modules/drizzle-orm/pg-core/view-base.js
var PgViewBase;
var init_view_base2 = __esm({
  "node_modules/drizzle-orm/pg-core/view-base.js"() {
    init_entity();
    init_sql();
    PgViewBase = class extends View {
      static [entityKind] = "PgViewBase";
    };
  }
});

// node_modules/drizzle-orm/pg-core/dialect.js
var PgDialect;
var init_dialect2 = __esm({
  "node_modules/drizzle-orm/pg-core/dialect.js"() {
    init_alias();
    init_casing();
    init_column();
    init_entity();
    init_errors();
    init_columns2();
    init_table2();
    init_relations();
    init_sql2();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    init_view_base2();
    PgDialect = class {
      static [entityKind] = "PgDialect";
      /** @internal */
      casing;
      constructor(config) {
        this.casing = new CasingCache(config?.casing);
      }
      async migrate(migrations, session, config) {
        const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
        const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
        const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint
			)
		`;
        await session.execute(sql`CREATE SCHEMA IF NOT EXISTS ${sql.identifier(migrationsSchema)}`);
        await session.execute(migrationTableCreate);
        const dbMigrations = await session.all(
          sql`select id, hash, created_at from ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} order by created_at desc limit 1`
        );
        const lastDbMigration = dbMigrations[0];
        await session.transaction(async (tx) => {
          for await (const migration of migrations) {
            if (!lastDbMigration || Number(lastDbMigration.created_at) < migration.folderMillis) {
              for (const stmt of migration.sql) {
                await tx.execute(sql.raw(stmt));
              }
              await tx.execute(
                sql`insert into ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} ("hash", "created_at") values(${migration.hash}, ${migration.folderMillis})`
              );
            }
          }
        });
      }
      escapeName(name) {
        return `"${name.replace(/"/g, '""')}"`;
      }
      escapeParam(num) {
        return `$${num + 1}`;
      }
      escapeString(str2) {
        return `'${str2.replace(/'/g, "''")}'`;
      }
      buildWithCTE(queries) {
        if (!queries?.length) return void 0;
        const withSqlChunks = [sql`with `];
        for (const [i, w] of queries.entries()) {
          withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
          if (i < queries.length - 1) {
            withSqlChunks.push(sql`, `);
          }
        }
        withSqlChunks.push(sql` `);
        return sql.join(withSqlChunks);
      }
      buildDeleteQuery({ table, where, returning, withList }) {
        const withSql = this.buildWithCTE(withList);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        return sql`${withSql}delete from ${table}${whereSql}${returningSql}`;
      }
      buildUpdateSet(table, set) {
        const tableColumns = table[Table.Symbol.Columns];
        const columnNames = Object.keys(tableColumns).filter(
          (colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0
        );
        const setSize = columnNames.length;
        return sql.join(columnNames.flatMap((colName, i) => {
          const col = tableColumns[colName];
          const onUpdateFnResult = col.onUpdateFn?.();
          const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
          const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
          if (i < setSize - 1) {
            return [res, sql.raw(", ")];
          }
          return [res];
        }));
      }
      buildUpdateQuery({ table, set, where, returning, withList, from, joins }) {
        const withSql = this.buildWithCTE(withList);
        const tableName = table[PgTable.Symbol.Name];
        const tableSchema = table[PgTable.Symbol.Schema];
        const origTableName = table[PgTable.Symbol.OriginalName];
        const alias = tableName === origTableName ? void 0 : tableName;
        const tableSql = sql`${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}`;
        const setSql = this.buildUpdateSet(table, set);
        const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
        const joinsSql = this.buildJoins(joins);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: !from })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        return sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}`;
      }
      /**
       * Builds selection SQL with provided fields/expressions
       *
       * Examples:
       *
       * `select <selection> from`
       *
       * `insert ... returning <selection>`
       *
       * If `isSingleTable` is true, then columns won't be prefixed with table name
       */
      buildSelection(fields, { isSingleTable = false } = {}) {
        const columnsLen = fields.length;
        const chunks = fields.flatMap(({ field }, i) => {
          const chunk = [];
          if (is(field, SQL.Aliased) && field.isSelectionField) {
            chunk.push(sql.identifier(field.fieldAlias));
          } else if (is(field, SQL.Aliased) || is(field, SQL)) {
            const query = is(field, SQL.Aliased) ? field.sql : field;
            if (isSingleTable) {
              chunk.push(
                new SQL(
                  query.queryChunks.map((c) => {
                    if (is(c, PgColumn)) {
                      return sql.identifier(this.casing.getColumnCasing(c));
                    }
                    return c;
                  })
                )
              );
            } else {
              chunk.push(query);
            }
            if (is(field, SQL.Aliased)) {
              chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
            }
          } else if (is(field, Column)) {
            if (isSingleTable) {
              chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
            } else {
              chunk.push(field);
            }
          } else if (is(field, Subquery)) {
            const entries = Object.entries(field._.selectedFields);
            if (entries.length === 1) {
              const entry = entries[0][1];
              const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
              if (fieldDecoder) {
                field._.sql.decoder = fieldDecoder;
              }
            }
            chunk.push(field);
          }
          if (i < columnsLen - 1) {
            chunk.push(sql`, `);
          }
          return chunk;
        });
        return sql.join(chunks);
      }
      buildJoins(joins) {
        if (!joins || joins.length === 0) {
          return void 0;
        }
        const joinsArray = [];
        for (const [index4, joinMeta] of joins.entries()) {
          if (index4 === 0) {
            joinsArray.push(sql` `);
          }
          const table = joinMeta.table;
          const lateralSql = joinMeta.lateral ? sql` lateral` : void 0;
          const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
          if (is(table, PgTable)) {
            const tableName = table[PgTable.Symbol.Name];
            const tableSchema = table[PgTable.Symbol.Schema];
            const origTableName = table[PgTable.Symbol.OriginalName];
            const alias = tableName === origTableName ? void 0 : joinMeta.alias;
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
            );
          } else if (is(table, View)) {
            const viewName = table[ViewBaseConfig].name;
            const viewSchema = table[ViewBaseConfig].schema;
            const origViewName = table[ViewBaseConfig].originalName;
            const alias = viewName === origViewName ? void 0 : joinMeta.alias;
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? sql`${sql.identifier(viewSchema)}.` : void 0}${sql.identifier(origViewName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
            );
          } else {
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`
            );
          }
          if (index4 < joins.length - 1) {
            joinsArray.push(sql` `);
          }
        }
        return sql.join(joinsArray);
      }
      buildFromTable(table) {
        if (is(table, Table) && table[Table.Symbol.IsAlias]) {
          let fullName = sql`${sql.identifier(table[Table.Symbol.OriginalName])}`;
          if (table[Table.Symbol.Schema]) {
            fullName = sql`${sql.identifier(table[Table.Symbol.Schema])}.${fullName}`;
          }
          return sql`${fullName} ${sql.identifier(table[Table.Symbol.Name])}`;
        }
        return table;
      }
      buildSelectQuery({
        withList,
        fields,
        fieldsFlat,
        where,
        having,
        table,
        joins,
        orderBy,
        groupBy,
        limit,
        offset,
        lockingClause,
        distinct,
        setOperators
      }) {
        const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
        for (const f of fieldsList) {
          if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, PgViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(
            ({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])
          ))(f.field.table)) {
            const tableName = getTableName(f.field.table);
            throw new Error(
              `Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`
            );
          }
        }
        const isSingleTable = !joins || joins.length === 0;
        const withSql = this.buildWithCTE(withList);
        let distinctSql;
        if (distinct) {
          distinctSql = distinct === true ? sql` distinct` : sql` distinct on (${sql.join(distinct.on, sql`, `)})`;
        }
        const selection = this.buildSelection(fieldsList, { isSingleTable });
        const tableSql = this.buildFromTable(table);
        const joinsSql = this.buildJoins(joins);
        const whereSql = where ? sql` where ${where}` : void 0;
        const havingSql = having ? sql` having ${having}` : void 0;
        let orderBySql;
        if (orderBy && orderBy.length > 0) {
          orderBySql = sql` order by ${sql.join(orderBy, sql`, `)}`;
        }
        let groupBySql;
        if (groupBy && groupBy.length > 0) {
          groupBySql = sql` group by ${sql.join(groupBy, sql`, `)}`;
        }
        const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        const lockingClauseSql = sql.empty();
        if (lockingClause) {
          const clauseSql = sql` for ${sql.raw(lockingClause.strength)}`;
          if (lockingClause.config.of) {
            clauseSql.append(
              sql` of ${sql.join(
                Array.isArray(lockingClause.config.of) ? lockingClause.config.of : [lockingClause.config.of],
                sql`, `
              )}`
            );
          }
          if (lockingClause.config.noWait) {
            clauseSql.append(sql` nowait`);
          } else if (lockingClause.config.skipLocked) {
            clauseSql.append(sql` skip locked`);
          }
          lockingClauseSql.append(clauseSql);
        }
        const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}`;
        if (setOperators.length > 0) {
          return this.buildSetOperations(finalQuery, setOperators);
        }
        return finalQuery;
      }
      buildSetOperations(leftSelect, setOperators) {
        const [setOperator, ...rest] = setOperators;
        if (!setOperator) {
          throw new Error("Cannot pass undefined values to any set operator");
        }
        if (rest.length === 0) {
          return this.buildSetOperationQuery({ leftSelect, setOperator });
        }
        return this.buildSetOperations(
          this.buildSetOperationQuery({ leftSelect, setOperator }),
          rest
        );
      }
      buildSetOperationQuery({
        leftSelect,
        setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
      }) {
        const leftChunk = sql`(${leftSelect.getSQL()}) `;
        const rightChunk = sql`(${rightSelect.getSQL()})`;
        let orderBySql;
        if (orderBy && orderBy.length > 0) {
          const orderByValues = [];
          for (const singleOrderBy of orderBy) {
            if (is(singleOrderBy, PgColumn)) {
              orderByValues.push(sql.identifier(singleOrderBy.name));
            } else if (is(singleOrderBy, SQL)) {
              for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
                const chunk = singleOrderBy.queryChunks[i];
                if (is(chunk, PgColumn)) {
                  singleOrderBy.queryChunks[i] = sql.identifier(chunk.name);
                }
              }
              orderByValues.push(sql`${singleOrderBy}`);
            } else {
              orderByValues.push(sql`${singleOrderBy}`);
            }
          }
          orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)} `;
        }
        const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
        const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
      }
      buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_ }) {
        const valuesSqlList = [];
        const columns = table[Table.Symbol.Columns];
        const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
        const insertOrder = colEntries.map(
          ([, column]) => sql.identifier(this.casing.getColumnCasing(column))
        );
        if (select) {
          const select2 = valuesOrSelect;
          if (is(select2, SQL)) {
            valuesSqlList.push(select2);
          } else {
            valuesSqlList.push(select2.getSQL());
          }
        } else {
          const values = valuesOrSelect;
          valuesSqlList.push(sql.raw("values "));
          for (const [valueIndex, value] of values.entries()) {
            const valueList = [];
            for (const [fieldName2, col] of colEntries) {
              const colValue = value[fieldName2];
              if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
                if (col.defaultFn !== void 0) {
                  const defaultFnResult = col.defaultFn();
                  const defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
                  valueList.push(defaultValue);
                } else if (!col.default && col.onUpdateFn !== void 0) {
                  const onUpdateFnResult = col.onUpdateFn();
                  const newValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
                  valueList.push(newValue);
                } else {
                  valueList.push(sql`default`);
                }
              } else {
                valueList.push(colValue);
              }
            }
            valuesSqlList.push(valueList);
            if (valueIndex < values.length - 1) {
              valuesSqlList.push(sql`, `);
            }
          }
        }
        const withSql = this.buildWithCTE(withList);
        const valuesSql = sql.join(valuesSqlList);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const onConflictSql = onConflict ? sql` on conflict ${onConflict}` : void 0;
        const overridingSql = overridingSystemValue_ === true ? sql`overriding system value ` : void 0;
        return sql`${withSql}insert into ${table} ${insertOrder} ${overridingSql}${valuesSql}${onConflictSql}${returningSql}`;
      }
      buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
        const concurrentlySql = concurrently ? sql` concurrently` : void 0;
        const withNoDataSql = withNoData ? sql` with no data` : void 0;
        return sql`refresh materialized view${concurrentlySql} ${view}${withNoDataSql}`;
      }
      prepareTyping(encoder8) {
        if (is(encoder8, PgJsonb) || is(encoder8, PgJson)) {
          return "json";
        } else if (is(encoder8, PgNumeric)) {
          return "decimal";
        } else if (is(encoder8, PgTime)) {
          return "time";
        } else if (is(encoder8, PgTimestamp) || is(encoder8, PgTimestampString)) {
          return "timestamp";
        } else if (is(encoder8, PgDate) || is(encoder8, PgDateString)) {
          return "date";
        } else if (is(encoder8, PgUUID)) {
          return "uuid";
        } else {
          return "none";
        }
      }
      sqlToQuery(sql2, invokeSource) {
        return sql2.toQuery({
          casing: this.casing,
          escapeName: this.escapeName,
          escapeParam: this.escapeParam,
          escapeString: this.escapeString,
          prepareTyping: this.prepareTyping,
          invokeSource
        });
      }
      // buildRelationalQueryWithPK({
      // 	fullSchema,
      // 	schema,
      // 	tableNamesMap,
      // 	table,
      // 	tableConfig,
      // 	queryConfig: config,
      // 	tableAlias,
      // 	isRoot = false,
      // 	joinOn,
      // }: {
      // 	fullSchema: Record<string, unknown>;
      // 	schema: TablesRelationalConfig;
      // 	tableNamesMap: Record<string, string>;
      // 	table: PgTable;
      // 	tableConfig: TableRelationalConfig;
      // 	queryConfig: true | DBQueryConfig<'many', true>;
      // 	tableAlias: string;
      // 	isRoot?: boolean;
      // 	joinOn?: SQL;
      // }): BuildRelationalQueryResult<PgTable, PgColumn> {
      // 	// For { "<relation>": true }, return a table with selection of all columns
      // 	if (config === true) {
      // 		const selectionEntries = Object.entries(tableConfig.columns);
      // 		const selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = selectionEntries.map((
      // 			[key, value],
      // 		) => ({
      // 			dbKey: value.name,
      // 			tsKey: key,
      // 			field: value as PgColumn,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 		return {
      // 			tableTsKey: tableConfig.tsName,
      // 			sql: table,
      // 			selection,
      // 		};
      // 	}
      // 	// let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
      // 	// let selectionForBuild = selection;
      // 	const aliasedColumns = Object.fromEntries(
      // 		Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]),
      // 	);
      // 	const aliasedRelations = Object.fromEntries(
      // 		Object.entries(tableConfig.relations).map(([key, value]) => [key, aliasedRelation(value, tableAlias)]),
      // 	);
      // 	const aliasedFields = Object.assign({}, aliasedColumns, aliasedRelations);
      // 	let where, hasUserDefinedWhere;
      // 	if (config.where) {
      // 		const whereSql = typeof config.where === 'function' ? config.where(aliasedFields, operators) : config.where;
      // 		where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
      // 		hasUserDefinedWhere = !!where;
      // 	}
      // 	where = and(joinOn, where);
      // 	// const fieldsSelection: { tsKey: string; value: PgColumn | SQL.Aliased; isExtra?: boolean }[] = [];
      // 	let joins: Join[] = [];
      // 	let selectedColumns: string[] = [];
      // 	// Figure out which columns to select
      // 	if (config.columns) {
      // 		let isIncludeMode = false;
      // 		for (const [field, value] of Object.entries(config.columns)) {
      // 			if (value === undefined) {
      // 				continue;
      // 			}
      // 			if (field in tableConfig.columns) {
      // 				if (!isIncludeMode && value === true) {
      // 					isIncludeMode = true;
      // 				}
      // 				selectedColumns.push(field);
      // 			}
      // 		}
      // 		if (selectedColumns.length > 0) {
      // 			selectedColumns = isIncludeMode
      // 				? selectedColumns.filter((c) => config.columns?.[c] === true)
      // 				: Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
      // 		}
      // 	} else {
      // 		// Select all columns if selection is not specified
      // 		selectedColumns = Object.keys(tableConfig.columns);
      // 	}
      // 	// for (const field of selectedColumns) {
      // 	// 	const column = tableConfig.columns[field]! as PgColumn;
      // 	// 	fieldsSelection.push({ tsKey: field, value: column });
      // 	// }
      // 	let initiallySelectedRelations: {
      // 		tsKey: string;
      // 		queryConfig: true | DBQueryConfig<'many', false>;
      // 		relation: Relation;
      // 	}[] = [];
      // 	// let selectedRelations: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
      // 	// Figure out which relations to select
      // 	if (config.with) {
      // 		initiallySelectedRelations = Object.entries(config.with)
      // 			.filter((entry): entry is [typeof entry[0], NonNullable<typeof entry[1]>] => !!entry[1])
      // 			.map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey]! }));
      // 	}
      // 	const manyRelations = initiallySelectedRelations.filter((r) =>
      // 		is(r.relation, Many)
      // 		&& (schema[tableNamesMap[r.relation.referencedTable[Table.Symbol.Name]]!]?.primaryKey.length ?? 0) > 0
      // 	);
      // 	// If this is the last Many relation (or there are no Many relations), we are on the innermost subquery level
      // 	const isInnermostQuery = manyRelations.length < 2;
      // 	const selectedExtras: {
      // 		tsKey: string;
      // 		value: SQL.Aliased;
      // 	}[] = [];
      // 	// Figure out which extras to select
      // 	if (isInnermostQuery && config.extras) {
      // 		const extras = typeof config.extras === 'function'
      // 			? config.extras(aliasedFields, { sql })
      // 			: config.extras;
      // 		for (const [tsKey, value] of Object.entries(extras)) {
      // 			selectedExtras.push({
      // 				tsKey,
      // 				value: mapColumnsInAliasedSQLToAlias(value, tableAlias),
      // 			});
      // 		}
      // 	}
      // 	// Transform `fieldsSelection` into `selection`
      // 	// `fieldsSelection` shouldn't be used after this point
      // 	// for (const { tsKey, value, isExtra } of fieldsSelection) {
      // 	// 	selection.push({
      // 	// 		dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey]!.name,
      // 	// 		tsKey,
      // 	// 		field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
      // 	// 		relationTableTsKey: undefined,
      // 	// 		isJson: false,
      // 	// 		isExtra,
      // 	// 		selection: [],
      // 	// 	});
      // 	// }
      // 	let orderByOrig = typeof config.orderBy === 'function'
      // 		? config.orderBy(aliasedFields, orderByOperators)
      // 		: config.orderBy ?? [];
      // 	if (!Array.isArray(orderByOrig)) {
      // 		orderByOrig = [orderByOrig];
      // 	}
      // 	const orderBy = orderByOrig.map((orderByValue) => {
      // 		if (is(orderByValue, Column)) {
      // 			return aliasedTableColumn(orderByValue, tableAlias) as PgColumn;
      // 		}
      // 		return mapColumnsInSQLToAlias(orderByValue, tableAlias);
      // 	});
      // 	const limit = isInnermostQuery ? config.limit : undefined;
      // 	const offset = isInnermostQuery ? config.offset : undefined;
      // 	// For non-root queries without additional config except columns, return a table with selection
      // 	if (
      // 		!isRoot
      // 		&& initiallySelectedRelations.length === 0
      // 		&& selectedExtras.length === 0
      // 		&& !where
      // 		&& orderBy.length === 0
      // 		&& limit === undefined
      // 		&& offset === undefined
      // 	) {
      // 		return {
      // 			tableTsKey: tableConfig.tsName,
      // 			sql: table,
      // 			selection: selectedColumns.map((key) => ({
      // 				dbKey: tableConfig.columns[key]!.name,
      // 				tsKey: key,
      // 				field: tableConfig.columns[key] as PgColumn,
      // 				relationTableTsKey: undefined,
      // 				isJson: false,
      // 				selection: [],
      // 			})),
      // 		};
      // 	}
      // 	const selectedRelationsWithoutPK:
      // 	// Process all relations without primary keys, because they need to be joined differently and will all be on the same query level
      // 	for (
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationConfigValue,
      // 			relation,
      // 		} of initiallySelectedRelations
      // 	) {
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTable = schema[relationTableTsName]!;
      // 		if (relationTable.primaryKey.length > 0) {
      // 			continue;
      // 		}
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelation = this.buildRelationalQueryWithoutPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationConfigValue,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 			nestedQueryRelation: relation,
      // 		});
      // 		const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier('data')}`.as(selectedRelationTsKey);
      // 		joins.push({
      // 			on: sql`true`,
      // 			table: new Subquery(builtRelation.sql as SQL, {}, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: true,
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelation.selection,
      // 		});
      // 	}
      // 	const oneRelations = initiallySelectedRelations.filter((r): r is typeof r & { relation: One } =>
      // 		is(r.relation, One)
      // 	);
      // 	// Process all One relations with PKs, because they can all be joined on the same level
      // 	for (
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationConfigValue,
      // 			relation,
      // 		} of oneRelations
      // 	) {
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const relationTable = schema[relationTableTsName]!;
      // 		if (relationTable.primaryKey.length === 0) {
      // 			continue;
      // 		}
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelation = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationConfigValue,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 		});
      // 		const field = sql`case when ${sql.identifier(relationTableAlias)} is null then null else json_build_array(${
      // 			sql.join(
      // 				builtRelation.selection.map(({ field }) =>
      // 					is(field, SQL.Aliased)
      // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
      // 						: is(field, Column)
      // 						? aliasedTableColumn(field, relationTableAlias)
      // 						: field
      // 				),
      // 				sql`, `,
      // 			)
      // 		}) end`.as(selectedRelationTsKey);
      // 		const isLateralJoin = is(builtRelation.sql, SQL);
      // 		joins.push({
      // 			on: isLateralJoin ? sql`true` : joinOn,
      // 			table: is(builtRelation.sql, SQL)
      // 				? new Subquery(builtRelation.sql, {}, relationTableAlias)
      // 				: aliasedTable(builtRelation.sql, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: is(builtRelation.sql, SQL),
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelation.selection,
      // 		});
      // 	}
      // 	let distinct: PgSelectConfig['distinct'];
      // 	let tableFrom: PgTable | Subquery = table;
      // 	// Process first Many relation - each one requires a nested subquery
      // 	const manyRelation = manyRelations[0];
      // 	if (manyRelation) {
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationQueryConfig,
      // 			relation,
      // 		} = manyRelation;
      // 		distinct = {
      // 			on: tableConfig.primaryKey.map((c) => aliasedTableColumn(c as PgColumn, tableAlias)),
      // 		};
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelationJoin = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationQueryConfig,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 		});
      // 		const builtRelationSelectionField = sql`case when ${
      // 			sql.identifier(relationTableAlias)
      // 		} is null then '[]' else json_agg(json_build_array(${
      // 			sql.join(
      // 				builtRelationJoin.selection.map(({ field }) =>
      // 					is(field, SQL.Aliased)
      // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
      // 						: is(field, Column)
      // 						? aliasedTableColumn(field, relationTableAlias)
      // 						: field
      // 				),
      // 				sql`, `,
      // 			)
      // 		})) over (partition by ${sql.join(distinct.on, sql`, `)}) end`.as(selectedRelationTsKey);
      // 		const isLateralJoin = is(builtRelationJoin.sql, SQL);
      // 		joins.push({
      // 			on: isLateralJoin ? sql`true` : joinOn,
      // 			table: isLateralJoin
      // 				? new Subquery(builtRelationJoin.sql as SQL, {}, relationTableAlias)
      // 				: aliasedTable(builtRelationJoin.sql as PgTable, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: isLateralJoin,
      // 		});
      // 		// Build the "from" subquery with the remaining Many relations
      // 		const builtTableFrom = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table,
      // 			tableConfig,
      // 			queryConfig: {
      // 				...config,
      // 				where: undefined,
      // 				orderBy: undefined,
      // 				limit: undefined,
      // 				offset: undefined,
      // 				with: manyRelations.slice(1).reduce<NonNullable<typeof config['with']>>(
      // 					(result, { tsKey, queryConfig: configValue }) => {
      // 						result[tsKey] = configValue;
      // 						return result;
      // 					},
      // 					{},
      // 				),
      // 			},
      // 			tableAlias,
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field: builtRelationSelectionField,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelationJoin.selection,
      // 		});
      // 		// selection = builtTableFrom.selection.map((item) =>
      // 		// 	is(item.field, SQL.Aliased)
      // 		// 		? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
      // 		// 		: item
      // 		// );
      // 		// selectionForBuild = [{
      // 		// 	dbKey: '*',
      // 		// 	tsKey: '*',
      // 		// 	field: sql`${sql.identifier(tableAlias)}.*`,
      // 		// 	selection: [],
      // 		// 	isJson: false,
      // 		// 	relationTableTsKey: undefined,
      // 		// }];
      // 		// const newSelectionItem: (typeof selection)[number] = {
      // 		// 	dbKey: selectedRelationTsKey,
      // 		// 	tsKey: selectedRelationTsKey,
      // 		// 	field,
      // 		// 	relationTableTsKey: relationTableTsName,
      // 		// 	isJson: true,
      // 		// 	selection: builtRelationJoin.selection,
      // 		// };
      // 		// selection.push(newSelectionItem);
      // 		// selectionForBuild.push(newSelectionItem);
      // 		tableFrom = is(builtTableFrom.sql, PgTable)
      // 			? builtTableFrom.sql
      // 			: new Subquery(builtTableFrom.sql, {}, tableAlias);
      // 	}
      // 	if (selectedColumns.length === 0 && selectedRelations.length === 0 && selectedExtras.length === 0) {
      // 		throw new DrizzleError(`No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")`);
      // 	}
      // 	let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'];
      // 	function prepareSelectedColumns() {
      // 		return selectedColumns.map((key) => ({
      // 			dbKey: tableConfig.columns[key]!.name,
      // 			tsKey: key,
      // 			field: tableConfig.columns[key] as PgColumn,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 	}
      // 	function prepareSelectedExtras() {
      // 		return selectedExtras.map((item) => ({
      // 			dbKey: item.value.fieldAlias,
      // 			tsKey: item.tsKey,
      // 			field: item.value,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 	}
      // 	if (isRoot) {
      // 		selection = [
      // 			...prepareSelectedColumns(),
      // 			...prepareSelectedExtras(),
      // 		];
      // 	}
      // 	if (hasUserDefinedWhere || orderBy.length > 0) {
      // 		tableFrom = new Subquery(
      // 			this.buildSelectQuery({
      // 				table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
      // 				fields: {},
      // 				fieldsFlat: selectionForBuild.map(({ field }) => ({
      // 					path: [],
      // 					field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
      // 				})),
      // 				joins,
      // 				distinct,
      // 			}),
      // 			{},
      // 			tableAlias,
      // 		);
      // 		selectionForBuild = selection.map((item) =>
      // 			is(item.field, SQL.Aliased)
      // 				? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
      // 				: item
      // 		);
      // 		joins = [];
      // 		distinct = undefined;
      // 	}
      // 	const result = this.buildSelectQuery({
      // 		table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
      // 		fields: {},
      // 		fieldsFlat: selectionForBuild.map(({ field }) => ({
      // 			path: [],
      // 			field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
      // 		})),
      // 		where,
      // 		limit,
      // 		offset,
      // 		joins,
      // 		orderBy,
      // 		distinct,
      // 	});
      // 	return {
      // 		tableTsKey: tableConfig.tsName,
      // 		sql: result,
      // 		selection,
      // 	};
      // }
      buildRelationalQueryWithoutPK({
        fullSchema,
        schema,
        tableNamesMap,
        table,
        tableConfig,
        queryConfig: config,
        tableAlias,
        nestedQueryRelation,
        joinOn
      }) {
        let selection = [];
        let limit, offset, orderBy = [], where;
        const joins = [];
        if (config === true) {
          const selectionEntries = Object.entries(tableConfig.columns);
          selection = selectionEntries.map(([key, value]) => ({
            dbKey: value.name,
            tsKey: key,
            field: aliasedTableColumn(value, tableAlias),
            relationTableTsKey: void 0,
            isJson: false,
            selection: []
          }));
        } else {
          const aliasedColumns = Object.fromEntries(
            Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)])
          );
          if (config.where) {
            const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
            where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
          }
          const fieldsSelection = [];
          let selectedColumns = [];
          if (config.columns) {
            let isIncludeMode = false;
            for (const [field, value] of Object.entries(config.columns)) {
              if (value === void 0) {
                continue;
              }
              if (field in tableConfig.columns) {
                if (!isIncludeMode && value === true) {
                  isIncludeMode = true;
                }
                selectedColumns.push(field);
              }
            }
            if (selectedColumns.length > 0) {
              selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
            }
          } else {
            selectedColumns = Object.keys(tableConfig.columns);
          }
          for (const field of selectedColumns) {
            const column = tableConfig.columns[field];
            fieldsSelection.push({ tsKey: field, value: column });
          }
          let selectedRelations = [];
          if (config.with) {
            selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey] }));
          }
          let extras;
          if (config.extras) {
            extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
            for (const [tsKey, value] of Object.entries(extras)) {
              fieldsSelection.push({
                tsKey,
                value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
              });
            }
          }
          for (const { tsKey, value } of fieldsSelection) {
            selection.push({
              dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
              tsKey,
              field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
              relationTableTsKey: void 0,
              isJson: false,
              selection: []
            });
          }
          let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
          if (!Array.isArray(orderByOrig)) {
            orderByOrig = [orderByOrig];
          }
          orderBy = orderByOrig.map((orderByValue) => {
            if (is(orderByValue, Column)) {
              return aliasedTableColumn(orderByValue, tableAlias);
            }
            return mapColumnsInSQLToAlias(orderByValue, tableAlias);
          });
          limit = config.limit;
          offset = config.offset;
          for (const {
            tsKey: selectedRelationTsKey,
            queryConfig: selectedRelationConfigValue,
            relation
          } of selectedRelations) {
            const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
            const relationTableName = getTableUniqueName(relation.referencedTable);
            const relationTableTsName = tableNamesMap[relationTableName];
            const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
            const joinOn2 = and(
              ...normalizedRelation.fields.map(
                (field2, i) => eq(
                  aliasedTableColumn(normalizedRelation.references[i], relationTableAlias),
                  aliasedTableColumn(field2, tableAlias)
                )
              )
            );
            const builtRelation = this.buildRelationalQueryWithoutPK({
              fullSchema,
              schema,
              tableNamesMap,
              table: fullSchema[relationTableTsName],
              tableConfig: schema[relationTableTsName],
              queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
              tableAlias: relationTableAlias,
              joinOn: joinOn2,
              nestedQueryRelation: relation
            });
            const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier("data")}`.as(selectedRelationTsKey);
            joins.push({
              on: sql`true`,
              table: new Subquery(builtRelation.sql, {}, relationTableAlias),
              alias: relationTableAlias,
              joinType: "left",
              lateral: true
            });
            selection.push({
              dbKey: selectedRelationTsKey,
              tsKey: selectedRelationTsKey,
              field,
              relationTableTsKey: relationTableTsName,
              isJson: true,
              selection: builtRelation.selection
            });
          }
        }
        if (selection.length === 0) {
          throw new DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")` });
        }
        let result;
        where = and(joinOn, where);
        if (nestedQueryRelation) {
          let field = sql`json_build_array(${sql.join(
            selection.map(
              ({ field: field2, tsKey, isJson }) => isJson ? sql`${sql.identifier(`${tableAlias}_${tsKey}`)}.${sql.identifier("data")}` : is(field2, SQL.Aliased) ? field2.sql : field2
            ),
            sql`, `
          )})`;
          if (is(nestedQueryRelation, Many)) {
            field = sql`coalesce(json_agg(${field}${orderBy.length > 0 ? sql` order by ${sql.join(orderBy, sql`, `)}` : void 0}), '[]'::json)`;
          }
          const nestedSelection = [{
            dbKey: "data",
            tsKey: "data",
            field: field.as("data"),
            isJson: true,
            relationTableTsKey: tableConfig.tsName,
            selection
          }];
          const needsSubquery = limit !== void 0 || offset !== void 0 || orderBy.length > 0;
          if (needsSubquery) {
            result = this.buildSelectQuery({
              table: aliasedTable(table, tableAlias),
              fields: {},
              fieldsFlat: [{
                path: [],
                field: sql.raw("*")
              }],
              where,
              limit,
              offset,
              orderBy,
              setOperators: []
            });
            where = void 0;
            limit = void 0;
            offset = void 0;
            orderBy = [];
          } else {
            result = aliasedTable(table, tableAlias);
          }
          result = this.buildSelectQuery({
            table: is(result, PgTable) ? result : new Subquery(result, {}, tableAlias),
            fields: {},
            fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
              path: [],
              field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        } else {
          result = this.buildSelectQuery({
            table: aliasedTable(table, tableAlias),
            fields: {},
            fieldsFlat: selection.map(({ field }) => ({
              path: [],
              field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        }
        return {
          tableTsKey: tableConfig.tsName,
          sql: result,
          selection
        };
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/select.js
function createSetOperator3(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
var PgSelectBuilder, PgSelectQueryBuilderBase, PgSelectBase, getPgSetOperators, union3, unionAll3, intersect3, intersectAll2, except3, exceptAll2;
var init_select3 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/select.js"() {
    init_entity();
    init_view_base2();
    init_query_builder();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_table();
    init_tracing();
    init_utils();
    init_utils();
    init_view_common();
    init_utils4();
    PgSelectBuilder = class {
      static [entityKind] = "PgSelectBuilder";
      fields;
      session;
      dialect;
      withList = [];
      distinct;
      constructor(config) {
        this.fields = config.fields;
        this.session = config.session;
        this.dialect = config.dialect;
        if (config.withList) {
          this.withList = config.withList;
        }
        this.distinct = config.distinct;
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      /**
       * Specify the table, subquery, or other target that you're
       * building a select query against.
       *
       * {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FROM | Postgres from documentation}
       */
      from(source) {
        const isPartialSelect = !!this.fields;
        const src = source;
        let fields;
        if (this.fields) {
          fields = this.fields;
        } else if (is(src, Subquery)) {
          fields = Object.fromEntries(
            Object.keys(src._.selectedFields).map((key) => [key, src[key]])
          );
        } else if (is(src, PgViewBase)) {
          fields = src[ViewBaseConfig].selectedFields;
        } else if (is(src, SQL)) {
          fields = {};
        } else {
          fields = getTableColumns(src);
        }
        return new PgSelectBase({
          table: src,
          fields,
          isPartialSelect,
          session: this.session,
          dialect: this.dialect,
          withList: this.withList,
          distinct: this.distinct
        }).setToken(this.authToken);
      }
    };
    PgSelectQueryBuilderBase = class extends TypedQueryBuilder {
      static [entityKind] = "PgSelectQueryBuilder";
      _;
      config;
      joinsNotNullableMap;
      tableName;
      isPartialSelect;
      session;
      dialect;
      cacheConfig = void 0;
      usedTables = /* @__PURE__ */ new Set();
      constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
        super();
        this.config = {
          withList,
          table,
          fields: { ...fields },
          distinct,
          setOperators: []
        };
        this.isPartialSelect = isPartialSelect;
        this.session = session;
        this.dialect = dialect;
        this._ = {
          selectedFields: fields,
          config: this.config
        };
        this.tableName = getTableLikeName(table);
        this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
        for (const item of extractUsedTable3(table)) this.usedTables.add(item);
      }
      /** @internal */
      getUsedTables() {
        return [...this.usedTables];
      }
      createJoin(joinType, lateral) {
        return (table, on) => {
          const baseTableName = this.tableName;
          const tableName = getTableLikeName(table);
          for (const item of extractUsedTable3(table)) this.usedTables.add(item);
          if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
            throw new Error(`Alias "${tableName}" is already used in this query`);
          }
          if (!this.isPartialSelect) {
            if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
              this.config.fields = {
                [baseTableName]: this.config.fields
              };
            }
            if (typeof tableName === "string" && !is(table, SQL)) {
              const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
              this.config.fields[tableName] = selection;
            }
          }
          if (typeof on === "function") {
            on = on(
              new Proxy(
                this.config.fields,
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              )
            );
          }
          if (!this.config.joins) {
            this.config.joins = [];
          }
          this.config.joins.push({ on, table, joinType, alias: tableName, lateral });
          if (typeof tableName === "string") {
            switch (joinType) {
              case "left": {
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
              case "right": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "cross":
              case "inner": {
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "full": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
            }
          }
          return this;
        };
      }
      /**
       * Executes a `left join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      leftJoin = this.createJoin("left", false);
      /**
       * Executes a `left join lateral` operation by adding subquery to the current query.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      leftJoinLateral = this.createJoin("left", true);
      /**
       * Executes a `right join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      rightJoin = this.createJoin("right", false);
      /**
       * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      innerJoin = this.createJoin("inner", false);
      /**
       * Executes an `inner join lateral` operation, creating a new table by combining rows from two queries that have matching values.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      innerJoinLateral = this.createJoin("inner", true);
      /**
       * Executes a `full join` operation by combining rows from two tables into a new table.
       *
       * Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
       *   .from(users)
       *   .fullJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .fullJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      fullJoin = this.createJoin("full", false);
      /**
       * Executes a `cross join` operation by combining rows from two tables into a new table.
       *
       * Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
       *
       * @param table the table to join.
       *
       * @example
       *
       * ```ts
       * // Select all users, each user with every pet
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .crossJoin(pets)
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .crossJoin(pets)
       * ```
       */
      crossJoin = this.createJoin("cross", false);
      /**
       * Executes a `cross join lateral` operation by combining rows from two queries into a new table.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves all rows from both main and joined queries, merging all rows from each query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join-lateral}
       *
       * @param table the query to join.
       */
      crossJoinLateral = this.createJoin("cross", true);
      createSetOperator(type, isAll) {
        return (rightSelection) => {
          const rightSelect = typeof rightSelection === "function" ? rightSelection(getPgSetOperators()) : rightSelection;
          if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
            throw new Error(
              "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
            );
          }
          this.config.setOperators.push({ type, isAll, rightSelect });
          return this;
        };
      }
      /**
       * Adds `union` set operator to the query.
       *
       * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
       *
       * @example
       *
       * ```ts
       * // Select all unique names from customers and users tables
       * await db.select({ name: users.name })
       *   .from(users)
       *   .union(
       *     db.select({ name: customers.name }).from(customers)
       *   );
       * // or
       * import { union } from 'drizzle-orm/pg-core'
       *
       * await union(
       *   db.select({ name: users.name }).from(users),
       *   db.select({ name: customers.name }).from(customers)
       * );
       * ```
       */
      union = this.createSetOperator("union", false);
      /**
       * Adds `union all` set operator to the query.
       *
       * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
       *
       * @example
       *
       * ```ts
       * // Select all transaction ids from both online and in-store sales
       * await db.select({ transaction: onlineSales.transactionId })
       *   .from(onlineSales)
       *   .unionAll(
       *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       *   );
       * // or
       * import { unionAll } from 'drizzle-orm/pg-core'
       *
       * await unionAll(
       *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
       *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       * );
       * ```
       */
      unionAll = this.createSetOperator("union", true);
      /**
       * Adds `intersect` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
       *
       * @example
       *
       * ```ts
       * // Select course names that are offered in both departments A and B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .intersect(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { intersect } from 'drizzle-orm/pg-core'
       *
       * await intersect(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      intersect = this.createSetOperator("intersect", false);
      /**
       * Adds `intersect all` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets including all duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect-all}
       *
       * @example
       *
       * ```ts
       * // Select all products and quantities that are ordered by both regular and VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered
       * })
       * .from(regularCustomerOrders)
       * .intersectAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { intersectAll } from 'drizzle-orm/pg-core'
       *
       * await intersectAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      intersectAll = this.createSetOperator("intersect", true);
      /**
       * Adds `except` set operator to the query.
       *
       * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
       *
       * @example
       *
       * ```ts
       * // Select all courses offered in department A but not in department B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .except(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { except } from 'drizzle-orm/pg-core'
       *
       * await except(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      except = this.createSetOperator("except", false);
      /**
       * Adds `except all` set operator to the query.
       *
       * Calling this method will retrieve all rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except-all}
       *
       * @example
       *
       * ```ts
       * // Select all products that are ordered by regular customers but not by VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered,
       * })
       * .from(regularCustomerOrders)
       * .exceptAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered,
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { exceptAll } from 'drizzle-orm/pg-core'
       *
       * await exceptAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      exceptAll = this.createSetOperator("except", true);
      /** @internal */
      addSetOperators(setOperators) {
        this.config.setOperators.push(...setOperators);
        return this;
      }
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be selected.
       *
       * ```ts
       * // Select all cars with green color
       * await db.select().from(cars).where(eq(cars.color, 'green'));
       * // or
       * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Select all BMW cars with a green color
       * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Select all cars with the green or blue color
       * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        if (typeof where === "function") {
          where = where(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.where = where;
        return this;
      }
      /**
       * Adds a `having` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
       *
       * @param having the `having` clause.
       *
       * @example
       *
       * ```ts
       * // Select all brands with more than one car
       * await db.select({
       * 	brand: cars.brand,
       * 	count: sql<number>`cast(count(${cars.id}) as int)`,
       * })
       *   .from(cars)
       *   .groupBy(cars.brand)
       *   .having(({ count }) => gt(count, 1));
       * ```
       */
      having(having) {
        if (typeof having === "function") {
          having = having(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.having = having;
        return this;
      }
      groupBy(...columns) {
        if (typeof columns[0] === "function") {
          const groupBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
        } else {
          this.config.groupBy = columns;
        }
        return this;
      }
      orderBy(...columns) {
        if (typeof columns[0] === "function") {
          const orderBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        } else {
          const orderByArray = columns;
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        }
        return this;
      }
      /**
       * Adds a `limit` clause to the query.
       *
       * Calling this method will set the maximum number of rows that will be returned by this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param limit the `limit` clause.
       *
       * @example
       *
       * ```ts
       * // Get the first 10 people from this query.
       * await db.select().from(people).limit(10);
       * ```
       */
      limit(limit) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).limit = limit;
        } else {
          this.config.limit = limit;
        }
        return this;
      }
      /**
       * Adds an `offset` clause to the query.
       *
       * Calling this method will skip a number of rows when returning results from this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param offset the `offset` clause.
       *
       * @example
       *
       * ```ts
       * // Get the 10th-20th people from this query.
       * await db.select().from(people).offset(10).limit(10);
       * ```
       */
      offset(offset) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).offset = offset;
        } else {
          this.config.offset = offset;
        }
        return this;
      }
      /**
       * Adds a `for` clause to the query.
       *
       * Calling this method will specify a lock strength for this query that controls how strictly it acquires exclusive access to the rows being queried.
       *
       * See docs: {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FOR-UPDATE-SHARE}
       *
       * @param strength the lock strength.
       * @param config the lock configuration.
       */
      for(strength, config = {}) {
        this.config.lockingClause = { strength, config };
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildSelectQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      as(alias) {
        const usedTables = [];
        usedTables.push(...extractUsedTable3(this.config.table));
        if (this.config.joins) {
          for (const it of this.config.joins) usedTables.push(...extractUsedTable3(it.table));
        }
        return new Proxy(
          new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]),
          new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      /** @internal */
      getSelectedFields() {
        return new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      $dynamic() {
        return this;
      }
      $withCache(config) {
        this.cacheConfig = config === void 0 ? { config: {}, enable: true, autoInvalidate: true } : config === false ? { enable: false } : { enable: true, autoInvalidate: true, ...config };
        return this;
      }
    };
    PgSelectBase = class extends PgSelectQueryBuilderBase {
      static [entityKind] = "PgSelect";
      /** @internal */
      _prepare(name) {
        const { session, config, dialect, joinsNotNullableMap, authToken, cacheConfig, usedTables } = this;
        if (!session) {
          throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
        }
        const { fields } = config;
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          const fieldsList = orderSelectedFields(fields);
          const query = session.prepareQuery(dialect.sqlToQuery(this.getSQL()), fieldsList, name, true, void 0, {
            type: "select",
            tables: [...usedTables]
          }, cacheConfig);
          query.joinsNotNullableMap = joinsNotNullableMap;
          return query.setToken(authToken);
        });
      }
      /**
       * Create a prepared statement for this query. This allows
       * the database to remember this query for the given session
       * and call it by name, rather than specifying the full query.
       *
       * {@link https://www.postgresql.org/docs/current/sql-prepare.html | Postgres prepare documentation}
       */
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = (placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      };
    };
    applyMixins(PgSelectBase, [QueryPromise]);
    getPgSetOperators = () => ({
      union: union3,
      unionAll: unionAll3,
      intersect: intersect3,
      intersectAll: intersectAll2,
      except: except3,
      exceptAll: exceptAll2
    });
    union3 = createSetOperator3("union", false);
    unionAll3 = createSetOperator3("union", true);
    intersect3 = createSetOperator3("intersect", false);
    intersectAll2 = createSetOperator3("intersect", true);
    except3 = createSetOperator3("except", false);
    exceptAll2 = createSetOperator3("except", true);
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/query-builder.js
var QueryBuilder3;
var init_query_builder3 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/query-builder.js"() {
    init_entity();
    init_dialect2();
    init_selection_proxy();
    init_subquery();
    init_select3();
    QueryBuilder3 = class {
      static [entityKind] = "PgQueryBuilder";
      dialect;
      dialectConfig;
      constructor(dialect) {
        this.dialect = is(dialect, PgDialect) ? dialect : void 0;
        this.dialectConfig = is(dialect, PgDialect) ? void 0 : dialect;
      }
      $with = (alias, selection) => {
        const queryBuilder = this;
        const as = (qb) => {
          if (typeof qb === "function") {
            qb = qb(queryBuilder);
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        };
        return { as };
      };
      with(...queries) {
        const self = this;
        function select(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            withList: queries
          });
        }
        function selectDistinct(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            distinct: true
          });
        }
        function selectDistinctOn(on, fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            distinct: { on }
          });
        }
        return { select, selectDistinct, selectDistinctOn };
      }
      select(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect()
        });
      }
      selectDistinct(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect(),
          distinct: true
        });
      }
      selectDistinctOn(on, fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect(),
          distinct: { on }
        });
      }
      // Lazy load dialect to avoid circular dependency
      getDialect() {
        if (!this.dialect) {
          this.dialect = new PgDialect(this.dialectConfig);
        }
        return this.dialect;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/view.js
function pgViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualViewBuilder3(name, selection, schema);
  }
  return new ViewBuilder3(name, schema);
}
function pgMaterializedViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualMaterializedViewBuilder(name, selection, schema);
  }
  return new MaterializedViewBuilder(name, schema);
}
var DefaultViewBuilderCore, ViewBuilder3, ManualViewBuilder3, MaterializedViewBuilderCore, MaterializedViewBuilder, ManualMaterializedViewBuilder, PgView, PgMaterializedViewConfig, PgMaterializedView;
var init_view2 = __esm({
  "node_modules/drizzle-orm/pg-core/view.js"() {
    init_entity();
    init_selection_proxy();
    init_utils();
    init_query_builder3();
    init_table2();
    init_view_base2();
    init_view_common3();
    DefaultViewBuilderCore = class {
      constructor(name, schema) {
        this.name = name;
        this.schema = schema;
      }
      static [entityKind] = "PgDefaultViewBuilderCore";
      config = {};
      with(config) {
        this.config.with = config;
        return this;
      }
    };
    ViewBuilder3 = class extends DefaultViewBuilderCore {
      static [entityKind] = "PgViewBuilder";
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder3());
        }
        const selectionProxy = new SelectionProxyHandler({
          alias: this.name,
          sqlBehavior: "error",
          sqlAliasedBehavior: "alias",
          replaceOriginalName: true
        });
        const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
        return new Proxy(
          new PgView({
            pgConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: aliasedSelection,
              query: qb.getSQL().inlineParams()
            }
          }),
          selectionProxy
        );
      }
    };
    ManualViewBuilder3 = class extends DefaultViewBuilderCore {
      static [entityKind] = "PgManualViewBuilder";
      columns;
      constructor(name, columns, schema) {
        super(name, schema);
        this.columns = getTableColumns(pgTable(name, columns));
      }
      existing() {
        return new Proxy(
          new PgView({
            pgConfig: void 0,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: void 0
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
      as(query) {
        return new Proxy(
          new PgView({
            pgConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: query.inlineParams()
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
    };
    MaterializedViewBuilderCore = class {
      constructor(name, schema) {
        this.name = name;
        this.schema = schema;
      }
      static [entityKind] = "PgMaterializedViewBuilderCore";
      config = {};
      using(using) {
        this.config.using = using;
        return this;
      }
      with(config) {
        this.config.with = config;
        return this;
      }
      tablespace(tablespace) {
        this.config.tablespace = tablespace;
        return this;
      }
      withNoData() {
        this.config.withNoData = true;
        return this;
      }
    };
    MaterializedViewBuilder = class extends MaterializedViewBuilderCore {
      static [entityKind] = "PgMaterializedViewBuilder";
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder3());
        }
        const selectionProxy = new SelectionProxyHandler({
          alias: this.name,
          sqlBehavior: "error",
          sqlAliasedBehavior: "alias",
          replaceOriginalName: true
        });
        const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              with: this.config.with,
              using: this.config.using,
              tablespace: this.config.tablespace,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: aliasedSelection,
              query: qb.getSQL().inlineParams()
            }
          }),
          selectionProxy
        );
      }
    };
    ManualMaterializedViewBuilder = class extends MaterializedViewBuilderCore {
      static [entityKind] = "PgManualMaterializedViewBuilder";
      columns;
      constructor(name, columns, schema) {
        super(name, schema);
        this.columns = getTableColumns(pgTable(name, columns));
      }
      existing() {
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              tablespace: this.config.tablespace,
              using: this.config.using,
              with: this.config.with,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: void 0
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
      as(query) {
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              tablespace: this.config.tablespace,
              using: this.config.using,
              with: this.config.with,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: query.inlineParams()
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
    };
    PgView = class extends PgViewBase {
      static [entityKind] = "PgView";
      [PgViewConfig];
      constructor({ pgConfig, config }) {
        super(config);
        if (pgConfig) {
          this[PgViewConfig] = {
            with: pgConfig.with
          };
        }
      }
    };
    PgMaterializedViewConfig = /* @__PURE__ */ Symbol.for("drizzle:PgMaterializedViewConfig");
    PgMaterializedView = class extends PgViewBase {
      static [entityKind] = "PgMaterializedView";
      [PgMaterializedViewConfig];
      constructor({ pgConfig, config }) {
        super(config);
        this[PgMaterializedViewConfig] = {
          with: pgConfig?.with,
          using: pgConfig?.using,
          tablespace: pgConfig?.tablespace,
          withNoData: pgConfig?.withNoData
        };
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/utils.js
function extractUsedTable3(table) {
  if (is(table, PgTable)) {
    return [table[Schema] ? `${table[Schema]}.${table[Table.Symbol.BaseName]}` : table[Table.Symbol.BaseName]];
  }
  if (is(table, Subquery)) {
    return table._.usedTables ?? [];
  }
  if (is(table, SQL)) {
    return table.usedTables ?? [];
  }
  return [];
}
var init_utils4 = __esm({
  "node_modules/drizzle-orm/pg-core/utils.js"() {
    init_entity();
    init_table2();
    init_sql();
    init_subquery();
    init_table();
    init_view_common();
    init_checks2();
    init_foreign_keys();
    init_indexes2();
    init_policies();
    init_primary_keys();
    init_unique_constraint();
    init_view_common3();
    init_view2();
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/delete.js
var PgDeleteBase;
var init_delete2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/delete.js"() {
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_table();
    init_tracing();
    init_utils();
    init_utils4();
    PgDeleteBase = class extends QueryPromise {
      constructor(table, session, dialect, withList) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { table, withList };
      }
      static [entityKind] = "PgDelete";
      config;
      cacheConfig;
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will delete only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be deleted.
       *
       * ```ts
       * // Delete all cars with green color
       * await db.delete(cars).where(eq(cars.color, 'green'));
       * // or
       * await db.delete(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Delete all BMW cars with a green color
       * await db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Delete all cars with the green or blue color
       * await db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      returning(fields = this.config.table[Table.Symbol.Columns]) {
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildDeleteQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
            type: "delete",
            tables: extractUsedTable3(this.config.table)
          }, this.cacheConfig);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = (placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      };
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/insert.js
var PgInsertBuilder, PgInsertBase;
var init_insert2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/insert.js"() {
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_table();
    init_tracing();
    init_utils();
    init_utils4();
    init_query_builder3();
    PgInsertBuilder = class {
      constructor(table, session, dialect, withList, overridingSystemValue_) {
        this.table = table;
        this.session = session;
        this.dialect = dialect;
        this.withList = withList;
        this.overridingSystemValue_ = overridingSystemValue_;
      }
      static [entityKind] = "PgInsertBuilder";
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      overridingSystemValue() {
        this.overridingSystemValue_ = true;
        return this;
      }
      values(values) {
        values = Array.isArray(values) ? values : [values];
        if (values.length === 0) {
          throw new Error("values() must be called with at least one value");
        }
        const mappedValues = values.map((entry) => {
          const result = {};
          const cols = this.table[Table.Symbol.Columns];
          for (const colKey of Object.keys(entry)) {
            const colValue = entry[colKey];
            result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
          }
          return result;
        });
        return new PgInsertBase(
          this.table,
          mappedValues,
          this.session,
          this.dialect,
          this.withList,
          false,
          this.overridingSystemValue_
        ).setToken(this.authToken);
      }
      select(selectQuery) {
        const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder3()) : selectQuery;
        if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) {
          throw new Error(
            "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
          );
        }
        return new PgInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
      }
    };
    PgInsertBase = class extends QueryPromise {
      constructor(table, values, session, dialect, withList, select, overridingSystemValue_) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { table, values, withList, select, overridingSystemValue_ };
      }
      static [entityKind] = "PgInsert";
      config;
      cacheConfig;
      returning(fields = this.config.table[Table.Symbol.Columns]) {
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /**
       * Adds an `on conflict do nothing` clause to the query.
       *
       * Calling this method simply avoids inserting a row as its alternative action.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
       *
       * @param config The `target` and `where` clauses.
       *
       * @example
       * ```ts
       * // Insert one row and cancel the insert if there's a conflict
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoNothing();
       *
       * // Explicitly specify conflict target
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoNothing({ target: cars.id });
       * ```
       */
      onConflictDoNothing(config = {}) {
        if (config.target === void 0) {
          this.config.onConflict = sql`do nothing`;
        } else {
          let targetColumn = "";
          targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
          const whereSql = config.where ? sql` where ${config.where}` : void 0;
          this.config.onConflict = sql`(${sql.raw(targetColumn)})${whereSql} do nothing`;
        }
        return this;
      }
      /**
       * Adds an `on conflict do update` clause to the query.
       *
       * Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
       *
       * @param config The `target`, `set` and `where` clauses.
       *
       * @example
       * ```ts
       * // Update the row if there's a conflict
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoUpdate({
       *     target: cars.id,
       *     set: { brand: 'Porsche' }
       *   });
       *
       * // Upsert with 'where' clause
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoUpdate({
       *     target: cars.id,
       *     set: { brand: 'newBMW' },
       *     targetWhere: sql`${cars.createdAt} > '2023-01-01'::date`,
       *   });
       * ```
       */
      onConflictDoUpdate(config) {
        if (config.where && (config.targetWhere || config.setWhere)) {
          throw new Error(
            'You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.'
          );
        }
        const whereSql = config.where ? sql` where ${config.where}` : void 0;
        const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : void 0;
        const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : void 0;
        const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
        let targetColumn = "";
        targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
        this.config.onConflict = sql`(${sql.raw(targetColumn)})${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildInsertQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
            type: "insert",
            tables: extractUsedTable3(this.config.table)
          }, this.cacheConfig);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = (placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      };
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/refresh-materialized-view.js
var PgRefreshMaterializedView;
var init_refresh_materialized_view = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/refresh-materialized-view.js"() {
    init_entity();
    init_query_promise();
    init_tracing();
    PgRefreshMaterializedView = class extends QueryPromise {
      constructor(view, session, dialect) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { view };
      }
      static [entityKind] = "PgRefreshMaterializedView";
      config;
      concurrently() {
        if (this.config.withNoData !== void 0) {
          throw new Error("Cannot use concurrently and withNoData together");
        }
        this.config.concurrently = true;
        return this;
      }
      withNoData() {
        if (this.config.concurrently !== void 0) {
          throw new Error("Cannot use concurrently and withNoData together");
        }
        this.config.withNoData = true;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildRefreshMaterializedViewQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), void 0, name, true);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = (placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      };
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/select.types.js
var init_select_types2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/select.types.js"() {
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/update.js
var PgUpdateBuilder, PgUpdateBase;
var init_update2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/update.js"() {
    init_entity();
    init_table2();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    init_utils4();
    PgUpdateBuilder = class {
      constructor(table, session, dialect, withList) {
        this.table = table;
        this.session = session;
        this.dialect = dialect;
        this.withList = withList;
      }
      static [entityKind] = "PgUpdateBuilder";
      authToken;
      setToken(token) {
        this.authToken = token;
        return this;
      }
      set(values) {
        return new PgUpdateBase(
          this.table,
          mapUpdateSet(this.table, values),
          this.session,
          this.dialect,
          this.withList
        ).setToken(this.authToken);
      }
    };
    PgUpdateBase = class extends QueryPromise {
      constructor(table, set, session, dialect, withList) {
        super();
        this.session = session;
        this.dialect = dialect;
        this.config = { set, table, withList, joins: [] };
        this.tableName = getTableLikeName(table);
        this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
      }
      static [entityKind] = "PgUpdate";
      config;
      tableName;
      joinsNotNullableMap;
      cacheConfig;
      from(source) {
        const src = source;
        const tableName = getTableLikeName(src);
        if (typeof tableName === "string") {
          this.joinsNotNullableMap[tableName] = true;
        }
        this.config.from = src;
        return this;
      }
      getTableLikeFields(table) {
        if (is(table, PgTable)) {
          return table[Table.Symbol.Columns];
        } else if (is(table, Subquery)) {
          return table._.selectedFields;
        }
        return table[ViewBaseConfig].selectedFields;
      }
      createJoin(joinType) {
        return (table, on) => {
          const tableName = getTableLikeName(table);
          if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) {
            throw new Error(`Alias "${tableName}" is already used in this query`);
          }
          if (typeof on === "function") {
            const from = this.config.from && !is(this.config.from, SQL) ? this.getTableLikeFields(this.config.from) : void 0;
            on = on(
              new Proxy(
                this.config.table[Table.Symbol.Columns],
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              ),
              from && new Proxy(
                from,
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              )
            );
          }
          this.config.joins.push({ on, table, joinType, alias: tableName });
          if (typeof tableName === "string") {
            switch (joinType) {
              case "left": {
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
              case "right": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "inner": {
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "full": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
            }
          }
          return this;
        };
      }
      leftJoin = this.createJoin("left");
      rightJoin = this.createJoin("right");
      innerJoin = this.createJoin("inner");
      fullJoin = this.createJoin("full");
      /**
       * Adds a 'where' clause to the query.
       *
       * Calling this method will update only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param where the 'where' clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be updated.
       *
       * ```ts
       * // Update all cars with green color
       * await db.update(cars).set({ color: 'red' })
       *   .where(eq(cars.color, 'green'));
       * // or
       * await db.update(cars).set({ color: 'red' })
       *   .where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Update all BMW cars with a green color
       * await db.update(cars).set({ color: 'red' })
       *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Update all cars with the green or blue color
       * await db.update(cars).set({ color: 'red' })
       *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      returning(fields) {
        if (!fields) {
          fields = Object.assign({}, this.config.table[Table.Symbol.Columns]);
          if (this.config.from) {
            const tableName = getTableLikeName(this.config.from);
            if (typeof tableName === "string" && this.config.from && !is(this.config.from, SQL)) {
              const fromFields = this.getTableLikeFields(this.config.from);
              fields[tableName] = fromFields;
            }
            for (const join of this.config.joins) {
              const tableName2 = getTableLikeName(join.table);
              if (typeof tableName2 === "string" && !is(join.table, SQL)) {
                const fromFields = this.getTableLikeFields(join.table);
                fields[tableName2] = fromFields;
              }
            }
          }
        }
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildUpdateQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        const query = this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
          type: "insert",
          tables: extractUsedTable3(this.config.table)
        }, this.cacheConfig);
        query.joinsNotNullableMap = this.joinsNotNullableMap;
        return query;
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = (placeholderValues) => {
        return this._prepare().execute(placeholderValues, this.authToken);
      };
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/index.js
var init_query_builders2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/index.js"() {
    init_delete2();
    init_insert2();
    init_query_builder3();
    init_refresh_materialized_view();
    init_select3();
    init_select_types2();
    init_update2();
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/count.js
var PgCountBuilder;
var init_count2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/count.js"() {
    init_entity();
    init_sql();
    PgCountBuilder = class _PgCountBuilder extends SQL {
      constructor(params) {
        super(_PgCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
        this.params = params;
        this.mapWith(Number);
        this.session = params.session;
        this.sql = _PgCountBuilder.buildCount(
          params.source,
          params.filters
        );
      }
      sql;
      token;
      static [entityKind] = "PgCountBuilder";
      [Symbol.toStringTag] = "PgCountBuilder";
      session;
      static buildEmbeddedCount(source, filters) {
        return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
      }
      static buildCount(source, filters) {
        return sql`select count(*) as count from ${source}${sql.raw(" where ").if(filters)}${filters};`;
      }
      /** @intrnal */
      setToken(token) {
        this.token = token;
        return this;
      }
      then(onfulfilled, onrejected) {
        return Promise.resolve(this.session.count(this.sql, this.token)).then(
          onfulfilled,
          onrejected
        );
      }
      catch(onRejected) {
        return this.then(void 0, onRejected);
      }
      finally(onFinally) {
        return this.then(
          (value) => {
            onFinally?.();
            return value;
          },
          (reason) => {
            onFinally?.();
            throw reason;
          }
        );
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/query.js
var RelationalQueryBuilder3, PgRelationalQuery;
var init_query2 = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/query.js"() {
    init_entity();
    init_query_promise();
    init_relations();
    init_tracing();
    RelationalQueryBuilder3 = class {
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect;
        this.session = session;
      }
      static [entityKind] = "PgRelationalQueryBuilder";
      findMany(config) {
        return new PgRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? config : {},
          "many"
        );
      }
      findFirst(config) {
        return new PgRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? { ...config, limit: 1 } : { limit: 1 },
          "first"
        );
      }
    };
    PgRelationalQuery = class extends QueryPromise {
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
        super();
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect;
        this.session = session;
        this.config = config;
        this.mode = mode;
      }
      static [entityKind] = "PgRelationalQuery";
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          const { query, builtQuery } = this._toSQL();
          return this.session.prepareQuery(
            builtQuery,
            void 0,
            name,
            true,
            (rawRows, mapColumnValue) => {
              const rows = rawRows.map(
                (row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue)
              );
              if (this.mode === "first") {
                return rows[0];
              }
              return rows;
            }
          );
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      _getQuery() {
        return this.dialect.buildRelationalQueryWithoutPK({
          fullSchema: this.fullSchema,
          schema: this.schema,
          tableNamesMap: this.tableNamesMap,
          table: this.table,
          tableConfig: this.tableConfig,
          queryConfig: this.config,
          tableAlias: this.tableConfig.tsName
        });
      }
      /** @internal */
      getSQL() {
        return this._getQuery().sql;
      }
      _toSQL() {
        const query = this._getQuery();
        const builtQuery = this.dialect.sqlToQuery(query.sql);
        return { query, builtQuery };
      }
      toSQL() {
        return this._toSQL().builtQuery;
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute() {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(void 0, this.authToken);
        });
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/query-builders/raw.js
var PgRaw;
var init_raw = __esm({
  "node_modules/drizzle-orm/pg-core/query-builders/raw.js"() {
    init_entity();
    init_query_promise();
    PgRaw = class extends QueryPromise {
      constructor(execute, sql2, query, mapBatchResult) {
        super();
        this.execute = execute;
        this.sql = sql2;
        this.query = query;
        this.mapBatchResult = mapBatchResult;
      }
      static [entityKind] = "PgRaw";
      /** @internal */
      getSQL() {
        return this.sql;
      }
      getQuery() {
        return this.query;
      }
      mapResult(result, isFromBatch) {
        return isFromBatch ? this.mapBatchResult(result) : result;
      }
      _prepare() {
        return this;
      }
      /** @internal */
      isResponseInArrayMode() {
        return false;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/db.js
var PgDatabase;
var init_db2 = __esm({
  "node_modules/drizzle-orm/pg-core/db.js"() {
    init_entity();
    init_query_builders2();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_count2();
    init_query2();
    init_raw();
    init_refresh_materialized_view();
    PgDatabase = class {
      constructor(dialect, session, schema) {
        this.dialect = dialect;
        this.session = session;
        this._ = schema ? {
          schema: schema.schema,
          fullSchema: schema.fullSchema,
          tableNamesMap: schema.tableNamesMap,
          session
        } : {
          schema: void 0,
          fullSchema: {},
          tableNamesMap: {},
          session
        };
        this.query = {};
        if (this._.schema) {
          for (const [tableName, columns] of Object.entries(this._.schema)) {
            this.query[tableName] = new RelationalQueryBuilder3(
              schema.fullSchema,
              this._.schema,
              this._.tableNamesMap,
              schema.fullSchema[tableName],
              columns,
              dialect,
              session
            );
          }
        }
        this.$cache = { invalidate: async (_params) => {
        } };
      }
      static [entityKind] = "PgDatabase";
      query;
      /**
       * Creates a subquery that defines a temporary named result set as a CTE.
       *
       * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param alias The alias for the subquery.
       *
       * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
       *
       * @example
       *
       * ```ts
       * // Create a subquery with alias 'sq' and use it in the select query
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * const result = await db.with(sq).select().from(sq);
       * ```
       *
       * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
       *
       * ```ts
       * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
       * const sq = db.$with('sq').as(db.select({
       *   name: sql<string>`upper(${users.name})`.as('name'),
       * })
       * .from(users));
       *
       * const result = await db.with(sq).select({ name: sq.name }).from(sq);
       * ```
       */
      $with = (alias, selection) => {
        const self = this;
        const as = (qb) => {
          if (typeof qb === "function") {
            qb = qb(new QueryBuilder3(self.dialect));
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        };
        return { as };
      };
      $count(source, filters) {
        return new PgCountBuilder({ source, filters, session: this.session });
      }
      $cache;
      /**
       * Incorporates a previously defined CTE (using `$with`) into the main query.
       *
       * This method allows the main query to reference a temporary named result set.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param queries The CTEs to incorporate into the main query.
       *
       * @example
       *
       * ```ts
       * // Define a subquery 'sq' as a CTE using $with
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * // Incorporate the CTE 'sq' into the main query and select from it
       * const result = await db.with(sq).select().from(sq);
       * ```
       */
      with(...queries) {
        const self = this;
        function select(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries
          });
        }
        function selectDistinct(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries,
            distinct: true
          });
        }
        function selectDistinctOn(on, fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries,
            distinct: { on }
          });
        }
        function update(table) {
          return new PgUpdateBuilder(table, self.session, self.dialect, queries);
        }
        function insert(table) {
          return new PgInsertBuilder(table, self.session, self.dialect, queries);
        }
        function delete_(table) {
          return new PgDeleteBase(table, self.session, self.dialect, queries);
        }
        return { select, selectDistinct, selectDistinctOn, update, insert, delete: delete_ };
      }
      select(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect
        });
      }
      selectDistinct(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect,
          distinct: true
        });
      }
      selectDistinctOn(on, fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect,
          distinct: { on }
        });
      }
      /**
       * Creates an update query.
       *
       * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
       *
       * Use `.set()` method to specify which values to update.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param table The table to update.
       *
       * @example
       *
       * ```ts
       * // Update all rows in the 'cars' table
       * await db.update(cars).set({ color: 'red' });
       *
       * // Update rows with filters and conditions
       * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
       *
       * // Update with returning clause
       * const updatedCar: Car[] = await db.update(cars)
       *   .set({ color: 'red' })
       *   .where(eq(cars.id, 1))
       *   .returning();
       * ```
       */
      update(table) {
        return new PgUpdateBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates an insert query.
       *
       * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert}
       *
       * @param table The table to insert into.
       *
       * @example
       *
       * ```ts
       * // Insert one row
       * await db.insert(cars).values({ brand: 'BMW' });
       *
       * // Insert multiple rows
       * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
       *
       * // Insert with returning clause
       * const insertedCar: Car[] = await db.insert(cars)
       *   .values({ brand: 'BMW' })
       *   .returning();
       * ```
       */
      insert(table) {
        return new PgInsertBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates a delete query.
       *
       * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param table The table to delete from.
       *
       * @example
       *
       * ```ts
       * // Delete all rows in the 'cars' table
       * await db.delete(cars);
       *
       * // Delete rows with filters and conditions
       * await db.delete(cars).where(eq(cars.color, 'green'));
       *
       * // Delete with returning clause
       * const deletedCar: Car[] = await db.delete(cars)
       *   .where(eq(cars.id, 1))
       *   .returning();
       * ```
       */
      delete(table) {
        return new PgDeleteBase(table, this.session, this.dialect);
      }
      refreshMaterializedView(view) {
        return new PgRefreshMaterializedView(view, this.session, this.dialect);
      }
      authToken;
      execute(query) {
        const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
        const builtQuery = this.dialect.sqlToQuery(sequel);
        const prepared = this.session.prepareQuery(
          builtQuery,
          void 0,
          void 0,
          false
        );
        return new PgRaw(
          () => prepared.execute(void 0, this.authToken),
          sequel,
          builtQuery,
          (result) => prepared.mapResult(result, true)
        );
      }
      transaction(transaction, config) {
        return this.session.transaction(transaction, config);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/roles.js
var PgRole;
var init_roles = __esm({
  "node_modules/drizzle-orm/pg-core/roles.js"() {
    init_entity();
    PgRole = class {
      constructor(name, config) {
        this.name = name;
        if (config) {
          this.createDb = config.createDb;
          this.createRole = config.createRole;
          this.inherit = config.inherit;
        }
      }
      static [entityKind] = "PgRole";
      /** @internal */
      _existing;
      /** @internal */
      createDb;
      /** @internal */
      createRole;
      /** @internal */
      inherit;
      existing() {
        this._existing = true;
        return this;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/sequence.js
function pgSequenceWithSchema(name, options, schema) {
  return new PgSequence(name, options, schema);
}
var PgSequence;
var init_sequence = __esm({
  "node_modules/drizzle-orm/pg-core/sequence.js"() {
    init_entity();
    PgSequence = class {
      constructor(seqName, seqOptions, schema) {
        this.seqName = seqName;
        this.seqOptions = seqOptions;
        this.schema = schema;
      }
      static [entityKind] = "PgSequence";
    };
  }
});

// node_modules/drizzle-orm/pg-core/schema.js
function pgSchema(name) {
  if (name === "public") {
    throw new Error(
      `You can't specify 'public' as schema name. Postgres is using public schema by default. If you want to use 'public' schema, just use pgTable() instead of creating a schema`
    );
  }
  return new PgSchema(name);
}
var PgSchema;
var init_schema2 = __esm({
  "node_modules/drizzle-orm/pg-core/schema.js"() {
    init_entity();
    init_sql();
    init_enum();
    init_sequence();
    init_table2();
    init_view2();
    PgSchema = class {
      constructor(schemaName) {
        this.schemaName = schemaName;
      }
      static [entityKind] = "PgSchema";
      table = (name, columns, extraConfig) => {
        return pgTableWithSchema(name, columns, extraConfig, this.schemaName);
      };
      view = (name, columns) => {
        return pgViewWithSchema(name, columns, this.schemaName);
      };
      materializedView = (name, columns) => {
        return pgMaterializedViewWithSchema(name, columns, this.schemaName);
      };
      enum(enumName, input) {
        return Array.isArray(input) ? pgEnumWithSchema(
          enumName,
          [...input],
          this.schemaName
        ) : pgEnumObjectWithSchema(enumName, input, this.schemaName);
      }
      sequence = (name, options) => {
        return pgSequenceWithSchema(name, options, this.schemaName);
      };
      getSQL() {
        return new SQL([sql.identifier(this.schemaName)]);
      }
      shouldOmitSQLParens() {
        return true;
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/session.js
var PgPreparedQuery, PgSession, PgTransaction;
var init_session2 = __esm({
  "node_modules/drizzle-orm/pg-core/session.js"() {
    init_cache();
    init_entity();
    init_errors();
    init_sql2();
    init_tracing();
    init_db2();
    PgPreparedQuery = class {
      constructor(query, cache, queryMetadata, cacheConfig) {
        this.query = query;
        this.cache = cache;
        this.queryMetadata = queryMetadata;
        this.cacheConfig = cacheConfig;
        if (cache && cache.strategy() === "all" && cacheConfig === void 0) {
          this.cacheConfig = { enable: true, autoInvalidate: true };
        }
        if (!this.cacheConfig?.enable) {
          this.cacheConfig = void 0;
        }
      }
      authToken;
      getQuery() {
        return this.query;
      }
      mapResult(response, _isFromBatch) {
        return response;
      }
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      static [entityKind] = "PgPreparedQuery";
      /** @internal */
      joinsNotNullableMap;
      /** @internal */
      async queryWithCache(queryString, params, query) {
        if (this.cache === void 0 || is(this.cache, NoopCache) || this.queryMetadata === void 0) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (this.cacheConfig && !this.cacheConfig.enable) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) {
          try {
            const [res] = await Promise.all([
              query(),
              this.cache.onMutate({ tables: this.queryMetadata.tables })
            ]);
            return res;
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (!this.cacheConfig) {
          try {
            return await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
        }
        if (this.queryMetadata.type === "select") {
          const fromCache = await this.cache.get(
            this.cacheConfig.tag ?? await hashQuery(queryString, params),
            this.queryMetadata.tables,
            this.cacheConfig.tag !== void 0,
            this.cacheConfig.autoInvalidate
          );
          if (fromCache === void 0) {
            let result;
            try {
              result = await query();
            } catch (e) {
              throw new DrizzleQueryError(queryString, params, e);
            }
            await this.cache.put(
              this.cacheConfig.tag ?? await hashQuery(queryString, params),
              result,
              // make sure we send tables that were used in a query only if user wants to invalidate it on each write
              this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [],
              this.cacheConfig.tag !== void 0,
              this.cacheConfig.config
            );
            return result;
          }
          return fromCache;
        }
        try {
          return await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
    };
    PgSession = class {
      constructor(dialect) {
        this.dialect = dialect;
      }
      static [entityKind] = "PgSession";
      /** @internal */
      execute(query, token) {
        return tracer.startActiveSpan("drizzle.operation", () => {
          const prepared = tracer.startActiveSpan("drizzle.prepareQuery", () => {
            return this.prepareQuery(
              this.dialect.sqlToQuery(query),
              void 0,
              void 0,
              false
            );
          });
          return prepared.setToken(token).execute(void 0, token);
        });
      }
      all(query) {
        return this.prepareQuery(
          this.dialect.sqlToQuery(query),
          void 0,
          void 0,
          false
        ).all();
      }
      /** @internal */
      async count(sql2, token) {
        const res = await this.execute(sql2, token);
        return Number(
          res[0]["count"]
        );
      }
    };
    PgTransaction = class extends PgDatabase {
      constructor(dialect, session, schema, nestedIndex = 0) {
        super(dialect, session, schema);
        this.schema = schema;
        this.nestedIndex = nestedIndex;
      }
      static [entityKind] = "PgTransaction";
      rollback() {
        throw new TransactionRollbackError();
      }
      /** @internal */
      getTransactionConfigSQL(config) {
        const chunks = [];
        if (config.isolationLevel) {
          chunks.push(`isolation level ${config.isolationLevel}`);
        }
        if (config.accessMode) {
          chunks.push(config.accessMode);
        }
        if (typeof config.deferrable === "boolean") {
          chunks.push(config.deferrable ? "deferrable" : "not deferrable");
        }
        return sql.raw(chunks.join(" "));
      }
      setTransaction(config) {
        return this.session.execute(sql`set transaction ${this.getTransactionConfigSQL(config)}`);
      }
    };
  }
});

// node_modules/drizzle-orm/pg-core/subquery.js
var init_subquery3 = __esm({
  "node_modules/drizzle-orm/pg-core/subquery.js"() {
  }
});

// node_modules/drizzle-orm/pg-core/utils/index.js
var init_utils5 = __esm({
  "node_modules/drizzle-orm/pg-core/utils/index.js"() {
    init_array();
  }
});

// node_modules/drizzle-orm/pg-core/index.js
var init_pg_core = __esm({
  "node_modules/drizzle-orm/pg-core/index.js"() {
    init_alias3();
    init_checks2();
    init_columns2();
    init_db2();
    init_dialect2();
    init_foreign_keys();
    init_indexes2();
    init_policies();
    init_primary_keys();
    init_query_builders2();
    init_roles();
    init_schema2();
    init_sequence();
    init_session2();
    init_subquery3();
    init_table2();
    init_unique_constraint();
    init_utils4();
    init_utils5();
    init_view_common3();
    init_view2();
  }
});

// packages/core/src/storage/drizzle/schema.pg.ts
var gatewaySchema, usersTable3, organizationsTable3, organizationMembershipsTable3, identityEventInboxTable3, workspacesTable3, workspaceBudgetsTable3, workspaceMembershipsTable3, apiKeysTable3, managementApiKeysTable3, byokKeysTable3, providersTable3, modelsTable3, modelEndpointsTable3, routePoolsTable3, routePoolStickyBindingsTable3, modelSurfacesTable3, modelRoutesTable3, modelEndpointRoutesTable3, apiKeyRequestLogsTable3, providerAttemptAvailabilityTable3, generationFeedbackTable3, publicModelDailyStatsTable3, systemConfigTable3, configGroupAuditTable3, systemConfigWriteMutexTable2, requestPresetsTable3, requestPresetVersionsTable3, guardrailsTable3, guardrailVersionsTable3, guardrailAssignmentsTable3, guardrailBudgetWindowsTable3, guardrailBudgetReservationsTable3, userBudgetReservationsTable3, routeDataPoliciesTable3, routeDataPolicyAuditTable3, userAuditLogsTable3, adminApiKeysTable3, adminAccessKeyAuditTable3, adminSharedKeyAuditTable3, adminSessionsTable3, portalSessionsTable3, sharedKeysTable3, sharedKeyEarningsTable3, userEarningsTable3, portalLedgerEntriesTable, withdrawalsTable3, nftMintsTable3, chainJobTransactionsTable2, batchesTable3, batchItemsTable3;
var init_schema_pg = __esm({
  "packages/core/src/storage/drizzle/schema.pg.ts"() {
    "use strict";
    init_drizzle_orm();
    init_pg_core();
    gatewaySchema = pgSchema("cinatoken_gateway");
    usersTable3 = gatewaySchema.table(
      "users",
      {
        id: text("id").primaryKey(),
        /**
         * 在 `external_system` 命名空间内唯一（含 internal 用户，即 `external_system IS NULL`）；
         * 由两条 partial unique index 落实，见表选项末尾。
         */
        email: text("email").notNull(),
        budgetMax: numeric("budget_max", { precision: 18, scale: 6 }),
        budgetBase: numeric("budget_base", { precision: 18, scale: 6 }).notNull().default("0"),
        budgetSpent: numeric("budget_spent", { precision: 18, scale: 6 }).notNull().default("0"),
        budgetPeriod: text("budget_period").notNull().default("none"),
        budgetResetAt: timestamp("budget_reset_at", {
          withTimezone: true,
          mode: "string"
        }),
        budgetEpoch: bigint("budget_epoch", { mode: "number" }).notNull().default(0),
        budgetReservedMicros: bigint("budget_reserved_micros", { mode: "number" }).notNull().default(0),
        status: text("status").notNull().default("active"),
        metadata: text("metadata"),
        /** `{ "<models.id>": factor }` JSON；NULL 表示无用户级 Charged 折扣 */
        chargedCostFactors: text("charged_cost_factors"),
        /** 上游命名空间（产品/租户），与 external_user_id 成对做幂等；纯网关用户二者皆空。 */
        externalSystem: text("external_system"),
        externalUserId: text("external_user_id"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_users_external_system_user_id").on(
          t.externalSystem,
          t.externalUserId
        ),
        uniqueIndex3("uk_users_external_system_email").on(t.externalSystem, t.email).where(sql`external_system IS NOT NULL`),
        uniqueIndex3("uk_users_internal_email").on(t.email).where(sql`external_system IS NULL`),
        check3(
          "users_external_pair_chk",
          sql`(external_system IS NULL AND external_user_id IS NULL) OR (external_system IS NOT NULL AND external_user_id IS NOT NULL)`
        ),
        check3(
          "users_external_system_nonempty_chk",
          sql`external_system IS NULL OR length(external_system) > 0`
        ),
        check3(
          "users_budget_epoch_chk",
          sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
        ),
        check3(
          "users_budget_reserved_micros_chk",
          sql`${t.budgetReservedMicros} >= 0 AND ${t.budgetReservedMicros} <= 9007199254740991`
        )
      ]
    );
    organizationsTable3 = gatewaySchema.table(
      "organizations",
      {
        id: text("id").primaryKey(),
        source: text("source").notNull(),
        name: text("name").notNull(),
        slug: text("slug"),
        status: text("status").notNull().default("active"),
        metadataJson: text("metadata_json"),
        sourceUpdatedAt: timestamp("source_updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        check3(
          "organizations_status_chk",
          sql`${t.status} IN ('pending', 'active', 'suspended', 'deleted')`
        ),
        check3("organizations_source_nonempty_chk", sql`length(${t.source}) > 0`)
      ]
    );
    organizationMembershipsTable3 = gatewaySchema.table(
      "organization_memberships",
      {
        organizationId: text("organization_id").notNull().references(() => organizationsTable3.id, { onDelete: "cascade" }),
        subject: text("subject").notNull(),
        userId: text("user_id").references(() => usersTable3.id, {
          onDelete: "set null"
        }),
        email: text("email"),
        rolesJson: text("roles_json").notNull().default("[]"),
        status: text("status").notNull().default("active"),
        sourceUpdatedAt: timestamp("source_updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        primaryKey({ columns: [t.organizationId, t.subject] }),
        check3(
          "organization_memberships_status_chk",
          sql`${t.status} IN ('active', 'suspended', 'removed')`
        ),
        check3(
          "organization_memberships_subject_nonempty_chk",
          sql`length(${t.subject}) > 0`
        )
      ]
    );
    identityEventInboxTable3 = gatewaySchema.table(
      "identity_event_inbox",
      {
        source: text("source").notNull(),
        eventId: text("event_id").notNull(),
        eventType: text("event_type").notNull(),
        aggregateType: text("aggregate_type").notNull(),
        aggregateId: text("aggregate_id").notNull(),
        payloadSha256: text("payload_sha256").notNull(),
        processorToken: text("processor_token").notNull().unique(),
        occurredAt: timestamp("occurred_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        processedAt: timestamp("processed_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [primaryKey({ columns: [t.source, t.eventId] })]
    );
    workspacesTable3 = gatewaySchema.table(
      "workspaces",
      {
        id: text("id").primaryKey(),
        scopeType: text("scope_type").notNull(),
        organizationId: text("organization_id").references(
          () => organizationsTable3.id,
          { onDelete: "cascade" }
        ),
        personalOwnerUserId: text("personal_owner_user_id").references(
          () => usersTable3.id,
          { onDelete: "cascade" }
        ),
        name: text("name").notNull(),
        slug: text("slug").notNull(),
        description: text("description"),
        isDefault: boolean("is_default").notNull().default(false),
        defaultScopeKey: text("default_scope_key").unique(),
        status: text("status").notNull().default("active"),
        settingsJson: text("settings_json"),
        createdByUserId: text("created_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_workspaces_personal_slug").on(t.personalOwnerUserId, t.slug).where(sql`${t.personalOwnerUserId} IS NOT NULL`),
        uniqueIndex3("uk_workspaces_organization_slug").on(t.organizationId, t.slug).where(sql`${t.organizationId} IS NOT NULL`),
        check3(
          "workspaces_scope_type_chk",
          sql`${t.scopeType} IN ('personal', 'organization')`
        ),
        check3("workspaces_status_chk", sql`${t.status} IN ('active', 'archived')`),
        check3(
          "workspaces_scope_owner_chk",
          sql`(
			(${t.scopeType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.scopeType} = 'organization' AND ${t.organizationId} IS NOT NULL AND ${t.personalOwnerUserId} IS NULL)
		)`
        ),
        check3(
          "workspaces_default_key_chk",
          sql`(
			(${t.isDefault} AND ${t.defaultScopeKey} IS NOT NULL)
			OR (NOT ${t.isDefault} AND ${t.defaultScopeKey} IS NULL)
		)`
        )
      ]
    );
    workspaceBudgetsTable3 = gatewaySchema.table(
      "workspace_budgets",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        resetInterval: text("reset_interval").notNull(),
        limitMicros: bigint("limit_micros", { mode: "number" }).notNull(),
        configEpoch: integer("config_epoch").notNull().default(0),
        createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull(),
        updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_workspace_budgets_interval").on(t.workspaceId, t.resetInterval),
        index3("idx_workspace_budgets_workspace").on(t.workspaceId),
        check3("workspace_budgets_interval_chk", sql`${t.resetInterval} IN ('daily', 'weekly', 'monthly', 'lifetime')`),
        check3("workspace_budgets_limit_chk", sql`${t.limitMicros} > 0 AND ${t.limitMicros} <= 9007199254740991`),
        check3("workspace_budgets_epoch_chk", sql`${t.configEpoch} >= 0 AND ${t.configEpoch} <= 2147483646`)
      ]
    );
    workspaceMembershipsTable3 = gatewaySchema.table(
      "workspace_memberships",
      {
        id: text("id").primaryKey(),
        membershipKey: text("membership_key").notNull().unique(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        subject: text("subject").notNull(),
        role: text("role").notNull().default("member"),
        status: text("status").notNull().default("active"),
        grantedBySubject: text("granted_by_subject"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        check3(
          "workspace_memberships_role_chk",
          sql`${t.role} IN ('admin', 'member')`
        ),
        check3(
          "workspace_memberships_status_chk",
          sql`${t.status} IN ('active', 'removed')`
        ),
        check3(
          "workspace_memberships_subject_chk",
          sql`length(${t.subject}) BETWEEN 1 AND 255`
        ),
        check3(
          "workspace_memberships_key_chk",
          sql`length(${t.membershipKey}) = 64`
        )
      ]
    );
    apiKeysTable3 = gatewaySchema.table("api_keys", {
      id: text("id").primaryKey(),
      key: text("key").notNull(),
      keyHash: text("key_hash"),
      keyPreview: text("key_preview"),
      userId: text("user_id").notNull(),
      workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
      name: text("name"),
      status: text("status").notNull().default("active"),
      metadata: text("metadata"),
      expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }),
      limitMicros: bigint("limit_micros", { mode: "number" }),
      limitReset: text("limit_reset"),
      includeByokInLimit: boolean("include_byok_in_limit").notNull().default(false),
      limitEpoch: integer("limit_epoch").notNull().default(0),
      lastUsedAt: timestamp("last_used_at", { withTimezone: true, mode: "string" }),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    managementApiKeysTable3 = gatewaySchema.table(
      "management_api_keys",
      {
        id: text("id").primaryKey(),
        keyHash: text("key_hash").notNull().unique(),
        keyPreview: text("key_preview").notNull(),
        accountType: text("account_type").notNull(),
        personalOwnerUserId: text("personal_owner_user_id").references(
          () => usersTable3.id,
          { onDelete: "cascade" }
        ),
        organizationId: text("organization_id").references(
          () => organizationsTable3.id,
          { onDelete: "cascade" }
        ),
        name: text("name").notNull(),
        status: text("status").notNull().default("active"),
        expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }),
        lastUsedAt: timestamp("last_used_at", {
          withTimezone: true,
          mode: "string"
        }),
        createdByUserId: text("created_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        index3("idx_management_api_keys_personal_created").on(
          t.personalOwnerUserId,
          t.createdAt
        ),
        index3("idx_management_api_keys_organization_created").on(
          t.organizationId,
          t.createdAt
        ),
        index3("idx_management_api_keys_status_expiry").on(t.status, t.expiresAt),
        check3(
          "management_api_keys_hash_chk",
          sql`${t.keyHash} ~ '^sha256:[0-9a-f]{64}$'`
        ),
        check3(
          "management_api_keys_name_chk",
          sql`length(${t.name}) BETWEEN 1 AND 128`
        ),
        check3(
          "management_api_keys_status_chk",
          sql`${t.status} IN ('active', 'revoked')`
        ),
        check3(
          "management_api_keys_account_type_chk",
          sql`${t.accountType} IN ('personal', 'organization')`
        ),
        check3(
          "management_api_keys_account_owner_chk",
          sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
		)`
        )
      ]
    );
    byokKeysTable3 = gatewaySchema.table(
      "byok_keys",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(
          () => workspacesTable3.id,
          { onDelete: "cascade" }
        ),
        provider: text("provider").notNull(),
        name: text("name"),
        apiKeyEncrypted: text("api_key_encrypted").notNull(),
        label: text("label").notNull(),
        disabled: boolean("disabled").notNull().default(false),
        isFallback: boolean("is_fallback").notNull().default(false),
        alwaysUseForProvider: boolean("always_use_for_provider").notNull().default(false),
        alwaysUseForMatchingModels: boolean("always_use_for_matching_models").notNull().default(false),
        sortOrder: integer("sort_order").notNull(),
        allowedModelsJson: text("allowed_models_json"),
        allowedUserIdsJson: text("allowed_user_ids_json"),
        allowedApiKeyHashesJson: text("allowed_api_key_hashes_json"),
        createdByManagementKeyId: text("created_by_management_key_id").references(
          () => managementApiKeysTable3.id,
          { onDelete: "set null" }
        ),
        deletedAt: timestamp("deleted_at", { withTimezone: true, mode: "string" }),
        createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull(),
        updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_byok_keys_active_order").on(t.workspaceId, t.provider, t.sortOrder).where(sql`${t.deletedAt} IS NULL`),
        index3("idx_byok_keys_workspace_created").on(t.workspaceId, t.createdAt),
        index3("idx_byok_keys_runtime").on(
          t.workspaceId,
          t.provider,
          t.disabled,
          t.isFallback,
          t.sortOrder
        ),
        index3("idx_byok_keys_creator").on(t.createdByManagementKeyId, t.createdAt),
        check3(
          "byok_keys_always_use_priority_chk",
          sql`(NOT ${t.alwaysUseForProvider} AND NOT ${t.alwaysUseForMatchingModels}) OR NOT ${t.isFallback}`
        ),
        check3(
          "byok_keys_shared_capacity_policy_exclusive_chk",
          sql`NOT ${t.alwaysUseForProvider} OR NOT ${t.alwaysUseForMatchingModels}`
        )
      ]
    );
    providersTable3 = gatewaySchema.table("providers", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      /** JSON: `{ openai?: { base?, endpoints? }, … }` */
      endpoints: text("endpoints"),
      /** 该上游账号唯一 API Key */
      apiKey: text("api_key").notNull().default(""),
      /** `active` | `disabled` */
      status: text("status").notNull().default("active"),
      description: text("description"),
      /** 非空时该 provider 接受对应用户共享密钥池注入（openai/anthropic/zhipu/deepseek） */
      sharedChannelType: text("shared_channel_type"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    modelsTable3 = gatewaySchema.table("models", {
      id: text("id").primaryKey(),
      displayName: text("display_name"),
      vendor: text("vendor").notNull().default("other"),
      contextWindow: integer("context_window"),
      /** Chat completion max output tokens; NULL for image-generation models. */
      maxTokens: integer("max_tokens").default(8192),
      pricingProfile: text("pricing_profile"),
      description: text("description"),
      metadata: text("metadata"),
      inputModalities: text("input_modalities"),
      outputModalities: text("output_modalities"),
      releasedAt: text("released_at"),
      /** 路由策略配置 JSON；NULL=使用全局/代码默认 */
      routePolicy: text("route_policy"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    modelEndpointsTable3 = gatewaySchema.table(
      "model_endpoints",
      {
        id: text("id").primaryKey(),
        modelId: text("model_id").notNull().references(() => modelsTable3.id, { onDelete: "cascade" }),
        providerId: text("provider_id").notNull().references(() => providersTable3.id, { onDelete: "cascade" }),
        providerSlug: text("provider_slug").notNull(),
        tag: text("tag").notNull(),
        endpointClass: text("endpoint_class"),
        region: text("region"),
        contextLength: integer("context_length"),
        maxPromptTokens: integer("max_prompt_tokens"),
        maxCompletionTokens: integer("max_completion_tokens"),
        quantization: text("quantization"),
        supportedParameters: text("supported_parameters").notNull().default("[]"),
        pricing: text("pricing").notNull().default("{}"),
        supportsToolChoice: text("supports_tool_choice").notNull().default('{"auto":null,"function":null,"none":null,"required":null}'),
        imageCapabilities: text("image_capabilities").notNull().default("{}"),
        audioCapabilities: text("audio_capabilities").notNull().default("{}"),
        /** Nullable boolean: NULL means the capability has not been verified. */
        supportsImplicitCaching: boolean("supports_implicit_caching"),
        /** Nullable boolean: NULL means the capability has not been verified. */
        supportsVoiceCloning: boolean("supports_voice_cloning"),
        evidenceUrl: text("evidence_url"),
        verifiedBy: text("verified_by"),
        verifiedAt: timestamp("verified_at", {
          withTimezone: true,
          mode: "string"
        }),
        expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }),
        status: text("status").notNull().default("draft"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_model_endpoints_identity").on(
          t.modelId,
          t.providerId,
          t.tag
        ),
        index3("idx_model_endpoints_provider").on(t.providerId),
        index3("idx_model_endpoints_model_status").on(t.modelId, t.status),
        check3(
          "model_endpoints_status_chk",
          sql`${t.status} IN ('draft', 'verified', 'disabled')`
        ),
        check3(
          "model_endpoints_context_length_chk",
          sql`${t.contextLength} IS NULL OR ${t.contextLength} > 0`
        ),
        check3(
          "model_endpoints_max_prompt_tokens_chk",
          sql`${t.maxPromptTokens} IS NULL OR ${t.maxPromptTokens} > 0`
        ),
        check3(
          "model_endpoints_max_completion_tokens_chk",
          sql`${t.maxCompletionTokens} IS NULL OR ${t.maxCompletionTokens} > 0`
        )
      ]
    );
    routePoolsTable3 = gatewaySchema.table("route_pools", {
      id: text("id").primaryKey(),
      modelId: text("model_id").notNull(),
      routeGroup: text("route_group").notNull().default("default"),
      name: text("name").notNull(),
      strategy: text("strategy"),
      /** JSON map: {"10":"hash_affinity","0":"weight_priority"} — per-priority-tier overrides */
      tierStrategies: text("tier_strategies"),
      stickyEnabled: boolean("sticky_enabled").notNull().default(false),
      stickyIdleTtlSeconds: integer("sticky_idle_ttl_seconds").notNull().default(3600),
      /** Bumped on sticky config change to invalidate existing bindings */
      stickyEpoch: integer("sticky_epoch").notNull().default(0),
      status: text("status").notNull().default("active"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    routePoolStickyBindingsTable3 = gatewaySchema.table(
      "route_pool_sticky_bindings",
      {
        routePoolId: text("route_pool_id").notNull(),
        affinityHash: text("affinity_hash").notNull(),
        routeTargetId: text("route_target_id").notNull(),
        bindingToken: text("binding_token").notNull(),
        poolEpoch: integer("pool_epoch").notNull().default(0),
        expiresAt: timestamp("expires_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      }
    );
    modelSurfacesTable3 = gatewaySchema.table("model_surfaces", {
      id: text("id").primaryKey(),
      modelId: text("model_id").notNull(),
      routeGroup: text("route_group").notNull().default("default"),
      requestProtocol: text("request_protocol").notNull(),
      requestOperation: text("request_operation").notNull().default("*"),
      routePoolId: text("route_pool_id").notNull(),
      status: text("status").notNull().default("active"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    modelRoutesTable3 = gatewaySchema.table("model_routes", {
      id: text("id").primaryKey(),
      modelId: text("model_id").notNull(),
      providerId: text("provider_id").notNull(),
      providerModelName: text("provider_model_name").notNull(),
      priority: integer("priority").notNull().default(0),
      status: text("status").notNull().default("active"),
      routeGroup: text("route_group").notNull().default("default"),
      /** 同 priority 层内权重 */
      weight: integer("weight").notNull().default(1),
      priceOverride: text("price_override"),
      customParams: text("custom_params"),
      routingMetadata: text("routing_metadata"),
      upstreamProtocol: text("upstream_protocol").notNull().default("openai"),
      routePoolId: text("route_pool_id"),
      upstreamOperation: text("upstream_operation").notNull().default("*"),
      adapter: text("adapter").notNull().default("passthrough"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    modelEndpointRoutesTable3 = gatewaySchema.table(
      "model_endpoint_routes",
      {
        endpointId: text("endpoint_id").notNull().references(() => modelEndpointsTable3.id, { onDelete: "cascade" }),
        routeTargetId: text("route_target_id").notNull().references(() => modelRoutesTable3.id, { onDelete: "cascade" }),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        /** SHA-256 of the exact route/provider subject verified for this binding. */
        subjectFingerprint: text("subject_fingerprint")
      },
      (t) => [
        primaryKey({ columns: [t.endpointId, t.routeTargetId] }),
        uniqueIndex3("uk_model_endpoint_routes_target").on(t.routeTargetId),
        check3(
          "model_endpoint_routes_subject_fingerprint_chk",
          sql`${t.subjectFingerprint} IS NULL OR ${t.subjectFingerprint} ~ '^[0-9a-f]{64}$'`
        )
      ]
    );
    apiKeyRequestLogsTable3 = gatewaySchema.table("api_key_request_logs", {
      id: text("id").primaryKey(),
      userId: text("user_id"),
      apiKeyId: text("api_key_id"),
      workspaceId: text("workspace_id").references(() => workspacesTable3.id, {
        onDelete: "set null"
      }),
      userEmail: text("user_email"),
      modelId: text("model_id"),
      providerId: text("provider_id"),
      providerModelName: text("provider_model_name"),
      modelName: text("model_name"),
      providerName: text("provider_name"),
      requestBody: text("request_body"),
      upstreamRequestBody: text("upstream_request_body"),
      requestProtocol: text("request_protocol"),
      requestOperation: text("request_operation"),
      upstreamProtocol: text("upstream_protocol").notNull().default("openai"),
      upstreamOperation: text("upstream_operation"),
      modelSurfaceId: text("model_surface_id"),
      routePoolId: text("route_pool_id"),
      routeTargetId: text("route_target_id"),
      adapter: text("adapter"),
      routeTrace: text("route_trace"),
      inputTokens: integer("input_tokens").notNull().default(0),
      outputTokens: integer("output_tokens").notNull().default(0),
      cacheReadTokens: integer("cache_read_tokens").notNull().default(0),
      cacheWriteTokens: integer("cache_write_tokens").notNull().default(0),
      reasoningTokens: integer("reasoning_tokens").notNull().default(0),
      totalTokens: integer("total_tokens").notNull().default(0),
      nativeTokensPrompt: bigint("native_tokens_prompt", { mode: "number" }),
      nativeTokensCompletion: bigint("native_tokens_completion", { mode: "number" }),
      nativeTokensCached: bigint("native_tokens_cached", { mode: "number" }),
      nativeTokensReasoning: bigint("native_tokens_reasoning", { mode: "number" }),
      nativeTokensCompletionImages: bigint("native_tokens_completion_images", { mode: "number" }),
      meteredCost: numeric("metered_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      standardCost: numeric("standard_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      chargedCost: numeric("charged_cost", { precision: 18, scale: 6 }).notNull().default("0"),
      /** Guardrail/user budget debit in integer micro-units; NULL marks a pre-ledger row. */
      budgetChargedMicros: bigint("budget_charged_micros", { mode: "number" }),
      budgetAccountedAt: timestamp("budget_accounted_at", {
        withTimezone: true,
        mode: "string"
      }),
      routeGroup: text("route_group").notNull().default("default"),
      status: text("status").notNull().default("success"),
      latencyMs: integer("latency_ms"),
      gatewayOverheadMs: integer("gateway_overhead_ms"),
      upstreamResponseMs: integer("upstream_response_ms"),
      finalUpstreamHeadersMs: integer("final_upstream_headers_ms"),
      firstReasoningTokenMs: integer("first_reasoning_token_ms"),
      firstTokenMs: integer("first_token_ms"),
      streamDurationMs: integer("stream_duration_ms"),
      upstreamAttemptCount: integer("upstream_attempt_count"),
      upstreamFailoverCount: integer("upstream_failover_count"),
      timingMetadata: text("timing_metadata"),
      errorMessage: text("error_message"),
      rawUsage: text("raw_usage"),
      /** 计费审计 JSON 字符串；结构见 `db/pricing-audit.ts` */
      pricingAudit: text("pricing_audit"),
      providerKeyId: text("provider_key_id"),
      providerKeyLabel: text("provider_key_label"),
      providerKeyFingerprint: text("provider_key_fingerprint"),
      upstreamRequestId: text("upstream_request_id"),
      upstreamMessageId: text("upstream_message_id"),
      billingKind: text("billing_kind"),
      inputImageCount: integer("input_image_count").notNull().default(0),
      outputImageCount: integer("output_image_count").notNull().default(0),
      audioDurationSeconds: real("audio_duration_seconds"),
      audioCharacters: integer("audio_characters"),
      sessionId: text("session_id"),
      requestOrigin: text("request_origin"),
      httpReferer: text("http_referer"),
      userAgent: text("user_agent"),
      responseStreamed: boolean("response_streamed"),
      dataRegion: text("data_region"),
      isByok: boolean("is_byok"),
      chargedCostUsd: numeric("charged_cost_usd", { precision: 24, scale: 12 }),
      upstreamInferenceCostUsd: numeric("upstream_inference_cost_usd", { precision: 24, scale: 12 }),
      serviceTier: text("service_tier"),
      finishReason: text("finish_reason"),
      nativeFinishReason: text("native_finish_reason"),
      providerResponses: text("provider_responses"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    providerAttemptAvailabilityTable3 = gatewaySchema.table(
      "provider_attempt_availability",
      {
        requestLogId: text("request_log_id").notNull().references(
          () => apiKeyRequestLogsTable3.id,
          { onDelete: "cascade" }
        ),
        attemptIndex: integer("attempt_index").notNull(),
        routeTargetId: text("route_target_id").notNull(),
        providerId: text("provider_id").notNull(),
        outcome: text("outcome").notNull(),
        reason: text("reason").notNull(),
        httpStatus: integer("http_status"),
        observedAt: timestamp("observed_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey({ columns: [t.requestLogId, t.attemptIndex] }),
        index3("idx_provider_attempt_availability_route_observed").on(t.routeTargetId, t.observedAt),
        index3("idx_provider_attempt_availability_observed").on(t.observedAt),
        check3(
          "provider_attempt_availability_attempt_index_chk",
          sql`${t.attemptIndex} BETWEEN 1 AND 128`
        ),
        check3(
          "provider_attempt_availability_outcome_chk",
          sql`${t.outcome} IN ('available', 'unavailable', 'excluded')`
        ),
        check3(
          "provider_attempt_availability_reason_chk",
          sql`${t.reason} IN ('accepted', 'provider_http_error', 'rate_limited', 'network_error', 'invalid_response', 'client_error', 'client_cancelled', 'unknown')`
        ),
        check3(
          "provider_attempt_availability_http_status_chk",
          sql`${t.httpStatus} IS NULL OR ${t.httpStatus} BETWEEN 100 AND 599`
        )
      ]
    );
    generationFeedbackTable3 = gatewaySchema.table(
      "generation_feedback",
      {
        id: text("id").primaryKey(),
        generationId: text("generation_id").notNull().references(
          () => apiKeyRequestLogsTable3.id,
          { onDelete: "cascade" }
        ),
        workspaceId: text("workspace_id").notNull().references(
          () => workspacesTable3.id,
          { onDelete: "cascade" }
        ),
        managementApiKeyId: text("management_api_key_id").notNull().references(
          () => managementApiKeysTable3.id,
          { onDelete: "cascade" }
        ),
        accountType: text("account_type").notNull(),
        personalOwnerUserId: text("personal_owner_user_id").references(
          () => usersTable3.id,
          { onDelete: "cascade" }
        ),
        organizationId: text("organization_id").references(
          () => organizationsTable3.id,
          { onDelete: "cascade" }
        ),
        category: text("category").notNull(),
        comment: text("comment"),
        createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        index3("idx_generation_feedback_generation_created").on(t.generationId, t.createdAt),
        index3("idx_generation_feedback_personal_created").on(t.personalOwnerUserId, t.createdAt).where(sql`${t.personalOwnerUserId} IS NOT NULL`),
        index3("idx_generation_feedback_organization_created").on(t.organizationId, t.createdAt).where(sql`${t.organizationId} IS NOT NULL`),
        check3("generation_feedback_id_chk", sql`length(${t.id}) = 40 AND left(${t.id}, 4) = 'gfb_'`),
        check3("generation_feedback_category_chk", sql`${t.category} IN ('latency', 'incoherence', 'incorrect_response', 'formatting', 'billing', 'api_error', 'other')`),
        check3("generation_feedback_comment_chk", sql`${t.comment} IS NULL OR length(${t.comment}) <= 1000`),
        check3(
          "generation_feedback_account_owner_chk",
          sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
			)`
        )
      ]
    );
    publicModelDailyStatsTable3 = gatewaySchema.table(
      "public_model_daily_stats",
      {
        statDate: text("stat_date").notNull(),
        modelId: text("model_id").notNull(),
        shard: integer("shard").notNull(),
        requestCount: bigint("request_count", { mode: "number" }).notNull().default(0),
        successCount: bigint("success_count", { mode: "number" }).notNull().default(0),
        errorCount: bigint("error_count", { mode: "number" }).notNull().default(0),
        outputTokens: bigint("output_tokens", { mode: "number" }).notNull().default(0),
        totalTokens: bigint("total_tokens", { mode: "number" }).notNull().default(0),
        latencyTotalMs: bigint("latency_total_ms", { mode: "number" }).notNull().default(0),
        latencySampleCount: bigint("latency_sample_count", { mode: "number" }).notNull().default(0),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_public_model_daily_stats").on(
          t.statDate,
          t.modelId,
          t.shard
        ),
        check3("public_model_daily_stats_shard_chk", sql`shard >= 0 AND shard < 16`)
      ]
    );
    systemConfigTable3 = gatewaySchema.table("system_config", {
      key: text("key").primaryKey(),
      value: text("value").notNull(),
      description: text("description"),
      revision: text("revision").notNull().default("legacy"),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    configGroupAuditTable3 = gatewaySchema.table("config_group_audit", {
      id: text("id").primaryKey(),
      family: text("family").notNull(),
      provider: text("provider"),
      action: text("action").notNull(),
      actorKind: text("actor_kind").notNull(),
      actorId: text("actor_id").notNull(),
      reason: text("reason").notNull(),
      changedFieldsJson: text("changed_fields_json").notNull(),
      activeBefore: text("active_before"),
      activeAfter: text("active_after"),
      credentialsJson: text("credentials_json").notNull(),
      revisionBeforeJson: text("revision_before_json").notNull(),
      revisionAfterJson: text("revision_after_json").notNull(),
      source: text("source").notNull(),
      createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull()
    }, (t) => [
      index3("idx_config_group_audit_family_created").on(t.family, t.createdAt.desc(), t.id.desc()),
      check3("config_group_audit_family_chk", sql`family IN ('web-search', 'web-fetch', 'web-deep-search', 'ai-detection')`),
      check3("config_group_audit_provider_chk", sql`provider IS NULL OR provider IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check3("config_group_audit_active_before_chk", sql`active_before IS NULL OR active_before IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check3("config_group_audit_active_after_chk", sql`active_after IS NULL OR active_after IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
      check3("config_group_audit_action_chk", sql`action IN ('save', 'save_activate', 'activate', 'legacy_save', 'reveal')`),
      check3("config_group_audit_actor_kind_chk", sql`actor_kind IN ('console', 'admin_key')`),
      check3("config_group_audit_actor_bounds_chk", sql`char_length(actor_id) BETWEEN 1 AND CASE WHEN actor_kind = 'console' THEN 617 ELSE 600 END`),
      check3("config_group_audit_reason_bounds_chk", sql`char_length(reason) BETWEEN 1 AND 600`),
      check3("config_group_audit_source_chk", sql`source IN ('admin_api', 'legacy_admin')`)
    ]);
    systemConfigWriteMutexTable2 = gatewaySchema.table("system_config_write_mutex", {
      id: integer("id").notNull().primaryKey()
    }, () => [check3("system_config_write_mutex_singleton_chk", sql`id = 1`)]);
    requestPresetsTable3 = gatewaySchema.table(
      "request_presets",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        ownerUserId: text("owner_user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
        slug: text("slug").notNull(),
        name: text("name").notNull(),
        description: text("description"),
        visibility: text("visibility").notNull().default("private"),
        status: text("status").notNull().default("active"),
        designatedVersion: integer("designated_version").notNull().default(1),
        latestVersion: integer("latest_version").notNull().default(1),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_request_presets_workspace_slug").on(t.workspaceId, t.slug),
        check3(
          "request_presets_visibility_chk",
          sql`${t.visibility} IN ('private', 'public')`
        ),
        check3(
          "request_presets_status_chk",
          sql`${t.status} IN ('active', 'archived')`
        ),
        check3(
          "request_presets_versions_chk",
          sql`${t.designatedVersion} >= 1 AND ${t.latestVersion} >= ${t.designatedVersion}`
        )
      ]
    );
    requestPresetVersionsTable3 = gatewaySchema.table(
      "request_preset_versions",
      {
        id: text("id").primaryKey(),
        presetId: text("preset_id").notNull().references(() => requestPresetsTable3.id, { onDelete: "cascade" }),
        version: integer("version").notNull(),
        systemPrompt: text("system_prompt"),
        configJson: text("config_json").notNull(),
        createdByUserId: text("created_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [uniqueIndex3("uk_request_preset_versions").on(t.presetId, t.version)]
    );
    guardrailsTable3 = gatewaySchema.table(
      "guardrails",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        ownerUserId: text("owner_user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
        name: text("name").notNull(),
        description: text("description"),
        status: text("status").notNull().default("active"),
        isWorkspaceDefault: boolean("is_workspace_default").notNull().default(false),
        isAccountDefault: boolean("is_account_default").notNull().default(false),
        accountScopeKey: text("account_scope_key"),
        designatedVersion: integer("designated_version").notNull().default(1),
        latestVersion: integer("latest_version").notNull().default(1),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_guardrails_id_workspace").on(t.id, t.workspaceId),
        uniqueIndex3("uk_guardrails_workspace_default").on(t.workspaceId).where(sql`${t.isWorkspaceDefault}`),
        uniqueIndex3("uk_guardrails_account_default").on(t.accountScopeKey).where(sql`${t.isAccountDefault}`),
        check3(
          "guardrails_default_kind_chk",
          sql`NOT (${t.isWorkspaceDefault} AND ${t.isAccountDefault})`
        ),
        check3(
          "guardrails_account_scope_key_chk",
          sql`${t.isAccountDefault} = (${t.accountScopeKey} IS NOT NULL)`
        ),
        check3("guardrails_status_chk", sql`${t.status} IN ('active', 'archived')`),
        check3(
          "guardrails_versions_chk",
          sql`${t.designatedVersion} >= 1 AND ${t.latestVersion} >= ${t.designatedVersion}`
        )
      ]
    );
    guardrailVersionsTable3 = gatewaySchema.table(
      "guardrail_versions",
      {
        id: text("id").primaryKey(),
        guardrailId: text("guardrail_id").notNull().references(() => guardrailsTable3.id, { onDelete: "cascade" }),
        version: integer("version").notNull(),
        configJson: text("config_json").notNull(),
        createdByUserId: text("created_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [uniqueIndex3("uk_guardrail_versions").on(t.guardrailId, t.version)]
    );
    guardrailAssignmentsTable3 = gatewaySchema.table(
      "guardrail_assignments",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        guardrailId: text("guardrail_id").notNull().references(() => guardrailsTable3.id, { onDelete: "cascade" }),
        scopeType: text("scope_type").notNull(),
        scopeId: text("scope_id").notNull(),
        createdByUserId: text("created_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        managementSource: text("management_source"),
        assignedByUserId: text("assigned_by_user_id").references(
          () => usersTable3.id,
          { onDelete: "set null" }
        ),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_guardrail_assignments_workspace_scope").on(
          t.workspaceId,
          t.scopeType,
          t.scopeId
        ),
        index3("idx_guardrail_assignments_assigned_by").on(t.assignedByUserId),
        index3("idx_guardrail_assignments_management_list").on(t.workspaceId, t.managementSource, t.createdAt, t.id).where(sql`${t.managementSource} IS NOT NULL`),
        check3(
          "guardrail_assignments_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
        )
      ]
    );
    guardrailBudgetWindowsTable3 = gatewaySchema.table(
      "guardrail_budget_windows",
      {
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        scopeType: text("scope_type").notNull(),
        scopeId: text("scope_id").notNull(),
        period: text("period").notNull(),
        periodStart: timestamp("period_start", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        periodEnd: timestamp("period_end", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        unreservedMicros: bigint("unreserved_micros", { mode: "number" }).notNull().default(0),
        settledMicros: bigint("settled_micros", { mode: "number" }).notNull().default(0),
        reservedMicros: bigint("reserved_micros", { mode: "number" }).notNull().default(0),
        seedRequestId: text("seed_request_id"),
        seededAt: timestamp("seeded_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        primaryKey({
          columns: [t.workspaceId, t.scopeType, t.scopeId, t.period, t.periodStart]
        }),
        check3(
          "guardrail_budget_windows_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
        ),
        check3(
          "guardrail_budget_windows_period_chk",
          sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
        ),
        check3(
          "guardrail_budget_windows_amount_chk",
          sql`${t.unreservedMicros} >= 0 AND ${t.settledMicros} >= 0 AND ${t.reservedMicros} >= 0`
        )
      ]
    );
    guardrailBudgetReservationsTable3 = gatewaySchema.table(
      "guardrail_budget_reservations",
      {
        id: text("id").primaryKey(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "cascade" }),
        requestId: text("request_id").notNull(),
        assignmentId: text("assignment_id").notNull(),
        guardrailId: text("guardrail_id").notNull(),
        guardrailVersion: integer("guardrail_version").notNull(),
        scopeType: text("scope_type").notNull(),
        scopeId: text("scope_id").notNull(),
        period: text("period").notNull(),
        periodStart: timestamp("period_start", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        periodEnd: timestamp("period_end", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        limitMicros: bigint("limit_micros", { mode: "number" }).notNull(),
        reservedMicros: bigint("reserved_micros", { mode: "number" }).notNull(),
        settledMicros: bigint("settled_micros", { mode: "number" }).notNull().default(0),
        settlementBasis: text("settlement_basis").notNull().default("charged"),
        state: text("state").notNull().default("reserved"),
        expiresAt: timestamp("expires_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        dispatchedAt: timestamp("dispatched_at", {
          withTimezone: true,
          mode: "string"
        }),
        terminalAt: timestamp("terminal_at", {
          withTimezone: true,
          mode: "string"
        }),
        terminalReason: text("terminal_reason"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_guardrail_budget_reservation_request_assignment").on(
          t.requestId,
          t.assignmentId
        ),
        check3(
          "guardrail_budget_reservations_scope_chk",
          sql`${t.scopeType} IN ('user', 'api_key')`
        ),
        check3(
          "guardrail_budget_reservations_period_chk",
          sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
        ),
        check3(
          "guardrail_budget_reservations_amount_chk",
          sql`${t.limitMicros} >= 0 AND ${t.reservedMicros} > 0 AND ${t.settledMicros} >= 0`
        ),
        check3(
          "guardrail_budget_reservations_state_chk",
          sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
        ),
        check3(
          "guardrail_budget_reservations_settlement_basis_chk",
          sql`${t.settlementBasis} IN ('charged', 'gateway_key_route')`
        )
      ]
    );
    userBudgetReservationsTable3 = gatewaySchema.table(
      "user_budget_reservations",
      {
        requestId: text("request_id").primaryKey(),
        userId: text("user_id").notNull(),
        apiKeyId: text("api_key_id").notNull(),
        budgetEpoch: bigint("budget_epoch", { mode: "number" }).notNull(),
        limitMicros: bigint("limit_micros", { mode: "number" }).notNull(),
        reservedMicros: bigint("reserved_micros", { mode: "number" }).notNull(),
        settledMicros: bigint("settled_micros", { mode: "number" }).notNull().default(0),
        state: text("state").notNull().default("reserved"),
        expiresAt: timestamp("expires_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        dispatchedAt: timestamp("dispatched_at", {
          withTimezone: true,
          mode: "string"
        }),
        terminalAt: timestamp("terminal_at", {
          withTimezone: true,
          mode: "string"
        }),
        terminalReason: text("terminal_reason"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        check3(
          "user_budget_reservations_epoch_chk",
          sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
        ),
        check3(
          "user_budget_reservations_amount_chk",
          sql`${t.limitMicros} >= 0 AND ${t.limitMicros} <= 9007199254740991 AND ${t.reservedMicros} > 0 AND ${t.reservedMicros} <= 9007199254740991 AND ${t.settledMicros} >= 0 AND ${t.settledMicros} <= 9007199254740991`
        ),
        check3(
          "user_budget_reservations_state_chk",
          sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
        ),
        check3(
          "user_budget_reservations_range_chk",
          sql`${t.expiresAt} > ${t.createdAt}`
        ),
        check3(
          "user_budget_reservations_request_id_chk",
          sql`length(${t.requestId}) BETWEEN 1 AND 128`
        ),
        check3(
          "user_budget_reservations_user_id_chk",
          sql`length(${t.userId}) BETWEEN 1 AND 512`
        ),
        check3(
          "user_budget_reservations_api_key_id_chk",
          sql`length(${t.apiKeyId}) BETWEEN 1 AND 512`
        )
      ]
    );
    routeDataPoliciesTable3 = gatewaySchema.table(
      "route_data_policies",
      {
        routeTargetId: text("route_target_id").primaryKey().references(() => modelRoutesTable3.id, { onDelete: "cascade" }),
        subjectFingerprint: text("subject_fingerprint"),
        retentionDays: integer("retention_days"),
        trainingAllowed: boolean("training_allowed").notNull().default(true),
        zdrSupported: boolean("zdr_supported").notNull().default(false),
        evidenceUrl: text("evidence_url"),
        verifiedBy: text("verified_by"),
        verifiedAt: timestamp("verified_at", {
          withTimezone: true,
          mode: "string"
        }),
        expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }),
        status: text("status").notNull().default("unknown"),
        invalidatedAt: timestamp("invalidated_at", {
          withTimezone: true,
          mode: "string"
        }),
        invalidationReason: text("invalidation_reason"),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        check3(
          "route_data_policies_retention_chk",
          sql`${t.retentionDays} IS NULL OR ${t.retentionDays} >= 0`
        ),
        check3(
          "route_data_policies_status_chk",
          sql`${t.status} IN ('verified', 'expired', 'unknown')`
        ),
        check3(
          "route_data_policies_subject_fingerprint_chk",
          sql`${t.subjectFingerprint} IS NULL OR ${t.subjectFingerprint} ~ '^[0-9a-f]{64}$'`
        )
      ]
    );
    routeDataPolicyAuditTable3 = gatewaySchema.table("route_data_policy_audit", {
      id: text("id").primaryKey(),
      routeTargetId: text("route_target_id").references(() => modelRoutesTable3.id, {
        onDelete: "set null"
      }),
      snapshotJson: text("snapshot_json").notNull(),
      actorId: text("actor_id").notNull(),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    userAuditLogsTable3 = gatewaySchema.table("user_audit_logs", {
      id: text("id").primaryKey(),
      userId: text("user_id"),
      apiKeyId: text("api_key_id"),
      eventType: text("event_type").notNull(),
      actorType: text("actor_type").notNull().default("system"),
      requestLogId: text("request_log_id"),
      changePayload: text("change_payload"),
      beforeUserSnapshot: text("before_user_snapshot"),
      afterUserSnapshot: text("after_user_snapshot"),
      changedFields: text("changed_fields"),
      correlationId: text("correlation_id"),
      source: text("source"),
      actorId: text("actor_id"),
      reasonCode: text("reason_code"),
      reasonText: text("reason_text"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    adminApiKeysTable3 = gatewaySchema.table("admin_api_keys", {
      id: text("id").primaryKey(),
      name: text("name").notNull().unique(),
      description: text("description"),
      secretKey: text("secret_key").notNull().unique(),
      secretKeyHash: text("secret_key_hash"),
      keyPrefix: text("key_prefix").notNull(),
      permissionsJson: text("permissions_json").notNull().default("[]"),
      status: text("status").notNull().default("active"),
      lastUsedAt: timestamp("last_used_at", { withTimezone: true, mode: "string" }),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      revokedAt: timestamp("revoked_at", { withTimezone: true, mode: "string" })
    });
    adminAccessKeyAuditTable3 = gatewaySchema.table("admin_access_key_audit", {
      id: text("id").primaryKey(),
      keyId: text("key_id").notNull(),
      action: text("action").notNull(),
      changeMask: integer("change_mask").notNull(),
      actorKind: text("actor_kind").notNull(),
      actorId: text("actor_id").notNull(),
      beforePermissionsJson: text("before_permissions_json"),
      afterPermissionsJson: text("after_permissions_json"),
      beforeStatus: text("before_status"),
      afterStatus: text("after_status"),
      createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull()
    });
    adminSharedKeyAuditTable3 = gatewaySchema.table("admin_shared_key_audit", {
      id: text("id").primaryKey(),
      keyId: text("key_id").notNull(),
      action: text("action").notNull(),
      changeMask: integer("change_mask").notNull(),
      actorKind: text("actor_kind").notNull(),
      actorId: text("actor_id").notNull(),
      source: text("source").notNull(),
      reason: text("reason").notNull(),
      beforeStatus: text("before_status").notNull(),
      beforeSellerPriority: integer("before_seller_priority").notNull(),
      beforeWeight: integer("before_weight").notNull(),
      beforeValidated: integer("before_validated").notNull(),
      afterStatus: text("after_status"),
      afterSellerPriority: integer("after_seller_priority"),
      afterWeight: integer("after_weight"),
      afterValidated: integer("after_validated"),
      beforeRevision: text("before_revision").notNull(),
      afterRevision: text("after_revision"),
      createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull()
    }, (t) => [index3("idx_admin_shared_key_audit_key_created").on(t.keyId, t.createdAt, t.id)]);
    adminSessionsTable3 = gatewaySchema.table("admin_sessions", {
      tokenHash: text("token_hash").primaryKey(),
      username: text("username").notNull(),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      expiresAt: timestamp("expires_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    portalSessionsTable3 = gatewaySchema.table("portal_sessions", {
      tokenHash: text("token_hash").primaryKey(),
      /** CinaAuth OIDC `sub` */
      subject: text("subject").notNull(),
      email: text("email").notNull(),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      expiresAt: timestamp("expires_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    sharedKeysTable3 = gatewaySchema.table(
      "shared_keys",
      {
        id: text("id").primaryKey(),
        sellerUserId: text("seller_user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
        /** openai | anthropic | zhipu | deepseek */
        channelType: text("channel_type").notNull(),
        apiKey: text("api_key").notNull(),
        keyFingerprint: text("key_fingerprint").notNull(),
        label: text("label"),
        /** validating | active | paused | invalid | disabled */
        status: text("status").notNull().default("validating"),
        sellerPriority: integer("seller_priority").notNull().default(0),
        weight: integer("weight").notNull().default(1),
        inputPrice: numeric("input_price", { precision: 18, scale: 6 }).notNull().default("0"),
        outputPrice: numeric("output_price", { precision: 18, scale: 6 }).notNull().default("0"),
        cacheReadPrice: numeric("cache_read_price", { precision: 18, scale: 6 }),
        cacheWritePrice: numeric("cache_write_price", { precision: 18, scale: 6 }),
        validatedAt: timestamp("validated_at", {
          withTimezone: true,
          mode: "string"
        }),
        lastUsedAt: timestamp("last_used_at", {
          withTimezone: true,
          mode: "string"
        }),
        lastFailureAt: timestamp("last_failure_at", {
          withTimezone: true,
          mode: "string"
        }),
        failureReason: text("failure_reason"),
        servedInputTokens: bigint("served_input_tokens", { mode: "number" }).notNull().default(0),
        servedOutputTokens: bigint("served_output_tokens", { mode: "number" }).notNull().default(0),
        earnedTotal: numeric("earned_total", { precision: 18, scale: 6 }).notNull().default("0"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        updatedAt: timestamp("updated_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_shared_keys_seller_fingerprint").on(
          t.sellerUserId,
          t.keyFingerprint
        )
      ]
    );
    sharedKeyEarningsTable3 = gatewaySchema.table(
      "shared_key_earnings",
      {
        id: text("id").primaryKey(),
        requestLogId: text("request_log_id").notNull(),
        sharedKeyId: text("shared_key_id").notNull(),
        sellerUserId: text("seller_user_id").notNull(),
        inputTokens: integer("input_tokens").notNull().default(0),
        outputTokens: integer("output_tokens").notNull().default(0),
        cacheReadTokens: integer("cache_read_tokens").notNull().default(0),
        cacheWriteTokens: integer("cache_write_tokens").notNull().default(0),
        grossAmount: numeric("gross_amount", { precision: 18, scale: 6 }).notNull().default("0"),
        platformFee: numeric("platform_fee", { precision: 18, scale: 6 }).notNull().default("0"),
        netAmount: numeric("net_amount", { precision: 18, scale: 6 }).notNull().default("0"),
        currency: text("currency").notNull().default("USD"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [uniqueIndex3("uk_shared_key_earnings_request_log").on(t.requestLogId)]
    );
    userEarningsTable3 = gatewaySchema.table("user_earnings", {
      userId: text("user_id").primaryKey().references(() => usersTable3.id, { onDelete: "cascade" }),
      balance: numeric("balance", { precision: 18, scale: 6 }).notNull().default("0"),
      lockedAmount: numeric("locked_amount", { precision: 18, scale: 6 }).notNull().default("0"),
      lifetimeEarned: numeric("lifetime_earned", { precision: 18, scale: 6 }).notNull().default("0"),
      lifetimeWithdrawn: numeric("lifetime_withdrawn", { precision: 18, scale: 6 }).notNull().default("0"),
      contributionValue: numeric("contribution_value", { precision: 18, scale: 6 }).notNull().default("0"),
      /** Canonical monetary state; NUMERIC columns above are compatibility projections. */
      balanceMicros: bigint("balance_micros", { mode: "bigint" }).notNull().default(sql`0`),
      lockedAmountMicros: bigint("locked_amount_micros", { mode: "bigint" }).notNull().default(sql`0`),
      lifetimeEarnedMicros: bigint("lifetime_earned_micros", { mode: "bigint" }).notNull().default(sql`0`),
      lifetimeWithdrawnMicros: bigint("lifetime_withdrawn_micros", {
        mode: "bigint"
      }).notNull().default(sql`0`),
      contributionValueMicros: bigint("contribution_value_micros", {
        mode: "bigint"
      }).notNull().default(sql`0`),
      walletAddress: text("wallet_address"),
      walletVerifiedAt: timestamp("wallet_verified_at", {
        withTimezone: true,
        mode: "string"
      }),
      highestBadgeTier: integer("highest_badge_tier").notNull().default(0),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull()
    });
    portalLedgerEntriesTable = gatewaySchema.table(
      "portal_ledger_entries",
      {
        id: text("id").primaryKey(),
        userId: text("user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
        kind: text("kind").notNull(),
        amountMicros: bigint("amount_micros", { mode: "bigint" }).notNull(),
        balanceAfterMicros: bigint("balance_after_micros", {
          mode: "bigint"
        }).notNull(),
        lockedAfterMicros: bigint("locked_after_micros", {
          mode: "bigint"
        }).notNull(),
        referenceType: text("reference_type").notNull(),
        referenceId: text("reference_id").notNull(),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull()
      },
      (t) => [
        uniqueIndex3("portal_ledger_entries_reference_unique").on(
          t.referenceType,
          t.referenceId,
          t.kind
        )
      ]
    );
    withdrawalsTable3 = gatewaySchema.table("withdrawals", {
      id: text("id").primaryKey(),
      userId: text("user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
      amount: numeric("amount", { precision: 18, scale: 6 }).notNull(),
      fee: numeric("fee", { precision: 18, scale: 6 }).notNull().default("0"),
      netAmount: numeric("net_amount", { precision: 18, scale: 6 }).notNull(),
      amountMicros: bigint("amount_micros", { mode: "bigint" }).notNull().default(sql`0`),
      feeMicros: bigint("fee_micros", { mode: "bigint" }).notNull().default(sql`0`),
      netAmountMicros: bigint("net_amount_micros", { mode: "bigint" }).notNull().default(sql`0`),
      currency: text("currency").notNull().default("USD"),
      walletAddress: text("wallet_address").notNull(),
      /** requested | processing | submitted | confirmed | failed */
      status: text("status").notNull().default("requested"),
      tokenAmount: numeric("token_amount", { precision: 18, scale: 6 }),
      txHash: text("tx_hash"),
      chainId: integer("chain_id"),
      failureReason: text("failure_reason"),
      createdAt: timestamp("created_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      updatedAt: timestamp("updated_at", {
        withTimezone: true,
        mode: "string"
      }).notNull(),
      confirmedAt: timestamp("confirmed_at", {
        withTimezone: true,
        mode: "string"
      })
    });
    nftMintsTable3 = gatewaySchema.table(
      "nft_mints",
      {
        id: text("id").primaryKey(),
        userId: text("user_id").notNull().references(() => usersTable3.id, { onDelete: "cascade" }),
        badgeTokenId: integer("badge_token_id").notNull(),
        tierName: text("tier_name").notNull(),
        walletAddress: text("wallet_address").notNull(),
        /** pending | submitted | confirmed | failed */
        status: text("status").notNull().default("pending"),
        txHash: text("tx_hash"),
        chainId: integer("chain_id"),
        valueSnapshot: numeric("value_snapshot", { precision: 18, scale: 6 }).notNull().default("0"),
        failureReason: text("failure_reason"),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        confirmedAt: timestamp("confirmed_at", {
          withTimezone: true,
          mode: "string"
        })
      },
      (t) => [uniqueIndex3("uk_nft_mints_user_badge").on(t.userId, t.badgeTokenId)]
    );
    chainJobTransactionsTable2 = gatewaySchema.table(
      "chain_job_transactions",
      {
        jobKind: text("job_kind").notNull(),
        jobId: text("job_id").notNull(),
        txHash: text("tx_hash").notNull().unique(),
        rawTransaction: text("raw_transaction").notNull(),
        chainId: integer("chain_id").notNull(),
        createdAt: timestamp("created_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        broadcastAt: timestamp("broadcast_at", {
          withTimezone: true,
          mode: "string"
        })
      },
      (t) => [primaryKey({ columns: [t.jobKind, t.jobId] })]
    );
    batchesTable3 = gatewaySchema.table(
      "batches",
      {
        id: text("id").primaryKey(),
        accountId: text("account_id").notNull(),
        workspaceId: text("workspace_id").notNull().references(() => workspacesTable3.id, { onDelete: "restrict" }),
        userId: text("user_id").notNull().references(() => usersTable3.id, { onDelete: "restrict" }),
        apiKeyHash: text("api_key_hash").notNull(),
        endpoint: text("endpoint").notNull(),
        modelId: text("model_id").notNull(),
        routeGroup: text("route_group").notNull(),
        status: text("status").notNull().default("validating"),
        completionWindow: text("completion_window").notNull().default("24h"),
        idempotencyKeyHash: text("idempotency_key_hash"),
        inputObjectKey: text("input_object_key").notNull(),
        inputSha256: text("input_sha256").notNull(),
        inputBytes: integer("input_bytes").notNull(),
        resultObjectKey: text("result_object_key"),
        resultSha256: text("result_sha256"),
        requestCount: integer("request_count").notNull(),
        validationNextOrdinal: integer("validation_next_ordinal").notNull().default(0),
        validationInputOffset: integer("validation_input_offset").notNull().default(0),
        completedCount: integer("completed_count").notNull().default(0),
        failedCount: integer("failed_count").notNull().default(0),
        cancelledCount: integer("cancelled_count").notNull().default(0),
        promptTokens: bigint("prompt_tokens", { mode: "number" }).notNull().default(0),
        completionTokens: bigint("completion_tokens", { mode: "number" }).notNull().default(0),
        totalTokens: bigint("total_tokens", { mode: "number" }).notNull().default(0),
        chargedCostMicros: bigint("charged_cost_micros", { mode: "number" }).notNull().default(0),
        byokRequestCount: integer("byok_request_count").notNull().default(0),
        unknownCostCount: integer("unknown_cost_count").notNull().default(0),
        createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull(),
        inProgressAt: timestamp("in_progress_at", { withTimezone: true, mode: "string" }),
        finalizingAt: timestamp("finalizing_at", { withTimezone: true, mode: "string" }),
        finalizedAt: timestamp("finalized_at", { withTimezone: true, mode: "string" }),
        expiresAt: timestamp("expires_at", { withTimezone: true, mode: "string" }).notNull(),
        retentionExpiresAt: timestamp("retention_expires_at", {
          withTimezone: true,
          mode: "string"
        }).notNull(),
        leaseOwner: text("lease_owner"),
        leaseExpiresAt: timestamp("lease_expires_at", {
          withTimezone: true,
          mode: "string"
        }),
        attemptCount: bigint("attempt_count", { mode: "number" }).notNull().default(0),
        revision: bigint("revision", { mode: "number" }).notNull().default(0),
        lastErrorCode: text("last_error_code"),
        updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        uniqueIndex3("uk_batches_idempotency").on(t.workspaceId, t.apiKeyHash, t.idempotencyKeyHash).where(sql`idempotency_key_hash IS NOT NULL`),
        index3("idx_batches_workspace_created").on(t.workspaceId, t.createdAt, t.id),
        index3("idx_batches_status_lease").on(t.status, t.leaseExpiresAt),
        index3("idx_batches_retention").on(t.retentionExpiresAt),
        check3(
          "batches_status_chk",
          sql`${t.status} IN ('validating', 'in_progress', 'finalizing', 'completed', 'failed', 'expired', 'cancelling', 'cancelled')`
        ),
        check3(
          "batches_counts_chk",
          sql`${t.requestCount} BETWEEN 1 AND 1000000 AND ${t.completedCount} + ${t.failedCount} + ${t.cancelledCount} <= ${t.requestCount}`
        ),
        check3(
          "batches_validation_checkpoint_chk",
          sql`${t.inputBytes} BETWEEN 1 AND 52428800 AND ${t.validationNextOrdinal} BETWEEN 0 AND ${t.requestCount} AND ${t.validationInputOffset} BETWEEN 0 AND ${t.inputBytes}`
        )
      ]
    );
    batchItemsTable3 = gatewaySchema.table(
      "batch_items",
      {
        id: text("id").notNull().unique(),
        batchId: text("batch_id").notNull().references(() => batchesTable3.id, { onDelete: "cascade" }),
        ordinal: integer("ordinal").notNull(),
        customId: text("custom_id").notNull(),
        status: text("status").notNull().default("pending"),
        attemptCount: bigint("attempt_count", { mode: "number" }).notNull().default(0),
        startedAt: timestamp("started_at", { withTimezone: true, mode: "string" }),
        dispatchStartedAt: timestamp("dispatch_started_at", {
          withTimezone: true,
          mode: "string"
        }),
        completedAt: timestamp("completed_at", { withTimezone: true, mode: "string" }),
        generationId: text("generation_id"),
        reservationId: text("reservation_id"),
        leaseOwner: text("lease_owner"),
        leaseExpiresAt: timestamp("lease_expires_at", {
          withTimezone: true,
          mode: "string"
        }),
        requestStartOffset: integer("request_start_offset").notNull(),
        requestEndOffset: integer("request_end_offset").notNull(),
        requestSha256: text("request_sha256").notNull(),
        resultObjectKey: text("result_object_key"),
        resultSha256: text("result_sha256"),
        errorCode: text("error_code"),
        errorSummary: text("error_summary"),
        revision: bigint("revision", { mode: "number" }).notNull().default(0),
        createdAt: timestamp("created_at", { withTimezone: true, mode: "string" }).notNull(),
        updatedAt: timestamp("updated_at", { withTimezone: true, mode: "string" }).notNull()
      },
      (t) => [
        primaryKey({ columns: [t.batchId, t.ordinal] }),
        uniqueIndex3("uk_batch_items_custom").on(t.batchId, t.customId),
        index3("idx_batch_items_status_ordinal").on(t.batchId, t.status, t.ordinal),
        check3(
          "batch_items_status_chk",
          sql`${t.status} IN ('pending', 'in_progress', 'completed', 'failed', 'cancelled')`
        ),
        check3(
          "batch_items_request_range_chk",
          sql`${t.requestStartOffset} BETWEEN 0 AND 52428799 AND ${t.requestEndOffset} BETWEEN 1 AND 52428800 AND ${t.requestEndOffset} > ${t.requestStartOffset} AND ${t.requestEndOffset} - ${t.requestStartOffset} <= 1048578`
        ),
        check3(
          "batch_items_lease_pair_chk",
          sql`(${t.leaseOwner} IS NULL AND ${t.leaseExpiresAt} IS NULL) OR (${t.leaseOwner} IS NOT NULL AND length(${t.leaseOwner}) BETWEEN 1 AND 128 AND ${t.leaseExpiresAt} IS NOT NULL)`
        ),
        check3(
          "batch_items_dispatch_chk",
          sql`(${t.dispatchStartedAt} IS NULL AND ${t.generationId} IS NULL AND ${t.reservationId} IS NULL) OR (${t.dispatchStartedAt} IS NOT NULL AND ${t.startedAt} IS NOT NULL AND ${t.generationId} IS NOT NULL AND length(${t.generationId}) BETWEEN 1 AND 512 AND ${t.reservationId} IS NOT NULL AND length(${t.reservationId}) BETWEEN 1 AND 512)`
        )
      ]
    );
  }
});

// packages/proxy/src/services/resource-completion.ts
function observeResourceCleanup(operation) {
  try {
    return operation().then(() => "confirmed", () => "unconfirmed");
  } catch {
    return Promise.resolve("unconfirmed");
  }
}
function createResourceCompletionGroup() {
  let pending = 0;
  let sealed = false;
  let outcome = "confirmed";
  let resolve;
  const completion = new Promise((done) => {
    resolve = done;
  });
  const finish = () => {
    if (sealed && pending === 0) resolve(outcome);
  };
  return {
    completion,
    track(task) {
      if (sealed) {
        void task.catch(() => void 0);
        throw new Error("Resource completion group is sealed");
      }
      pending++;
      void task.then((value) => {
        if (value !== "confirmed") outcome = "unconfirmed";
      }, () => {
        outcome = "unconfirmed";
      }).then(() => {
        pending--;
        finish();
      });
    },
    seal() {
      sealed = true;
      finish();
    }
  };
}

// packages/proxy/src/services/egress/owned-upstream-response.ts
function ownUpstreamResponse(response, signal) {
  if (!response.body) return { response, resourceCompletion: Promise.resolve("confirmed") };
  let reader = response.body.getReader();
  let controller;
  let closed = false;
  let resolve;
  const resourceCompletion = new Promise((done) => {
    resolve = done;
  });
  const finish = (outcome) => {
    if (closed) return;
    closed = true;
    signal?.removeEventListener("abort", abort);
    reader?.releaseLock();
    reader = void 0;
    resolve(outcome);
  };
  const cancel = () => {
    if (closed) return;
    const source = reader;
    finish(observeResourceCleanup(() => source.cancel("upstream_response_stopped")));
  };
  const abort = () => {
    if (closed) return;
    cancel();
    controller.error(new Error("Upstream response body stopped"));
  };
  const body = new ReadableStream({
    start(value) {
      controller = value;
    },
    async pull(value) {
      if (closed) return;
      try {
        const next = await reader.read();
        if (closed) return;
        if (next.done) {
          value.close();
          finish("confirmed");
        } else value.enqueue(next.value);
      } catch {
        if (closed) return;
        cancel();
        value.error(new Error("Upstream response body unavailable"));
      }
    },
    cancel
  }, { highWaterMark: 0 });
  const owned = new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers });
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) abort();
  return { response: owned, resourceCompletion };
}

// packages/proxy/src/services/egress/json-upload-body.ts
import { createHash } from "node:crypto";

// packages/proxy/src/services/egress/compact-json-string-page.ts
var JSON_TEXT_PAGE_CHARS = 64 * 1024;
var CompactJsonStringPage = class _CompactJsonStringPage {
  #bytes;
  #length;
  constructor(text5, byteLength) {
    this.#length = text5.length;
    this.#bytes = new Uint8Array(byteLength);
    let offset = 0;
    for (let i = 0; i < text5.length; i++) {
      let code = text5.charCodeAt(i);
      if (code < 128) this.#bytes[offset++] = code;
      else if (code === 65533) this.#bytes[offset++] = 255;
      else if (code < 2048) {
        this.#bytes[offset++] = 192 | code >> 6;
        this.#bytes[offset++] = 128 | code & 63;
      } else {
        const low = text5.charCodeAt(i + 1);
        if (code >= 55296 && code <= 56319 && low >= 56320 && low <= 57343) {
          code = 65536 + (code - 55296 << 10) + low - 56320;
          i++;
          this.#bytes[offset++] = 240 | code >> 18;
          this.#bytes[offset++] = 128 | code >> 12 & 63;
        } else this.#bytes[offset++] = 224 | code >> 12;
        this.#bytes[offset++] = 128 | code >> 6 & 63;
        this.#bytes[offset++] = 128 | code & 63;
      }
    }
    Object.freeze(this);
  }
  static from(text5) {
    if (typeof text5 !== "string" || text5.length > JSON_TEXT_PAGE_CHARS) throw new RangeError("Invalid JSON string page");
    if (text5.length < 1024 || !/[^\u0000-\u00ff]/.test(text5)) return text5;
    let bytes = 0;
    for (let i = 0; i < text5.length; i++) {
      const code = text5.charCodeAt(i), low = text5.charCodeAt(i + 1);
      if (code < 128 || code === 65533) bytes++;
      else if (code < 2048) bytes += 2;
      else if (code >= 55296 && code <= 56319 && low >= 56320 && low <= 57343) {
        bytes += 4;
        i++;
      } else bytes += 3;
    }
    return bytes + 64 < text5.length * 2 ? new _CompactJsonStringPage(text5, bytes) : text5;
  }
  get length() {
    return this.#length;
  }
  get byteLength() {
    return this.#bytes.length;
  }
  decode() {
    const units = new Uint16Array(this.#length), bytes = this.#bytes;
    let offset = 0;
    for (let i = 0; i < bytes.length; ) {
      const lead = bytes[i++];
      if (lead < 128) units[offset++] = lead;
      else if (lead === 255) units[offset++] = 65533;
      else if (lead < 224) units[offset++] = (lead & 31) << 6 | bytes[i++] & 63;
      else if (lead < 240) units[offset++] = (lead & 15) << 12 | (bytes[i++] & 63) << 6 | bytes[i++] & 63;
      else {
        const point2 = ((lead & 7) << 18 | (bytes[i++] & 63) << 12 | (bytes[i++] & 63) << 6 | bytes[i++] & 63) - 65536;
        units[offset++] = 55296 | point2 >> 10;
        units[offset++] = 56320 | point2 & 1023;
      }
    }
    const pieces = [];
    for (let i = 0; i < units.length; i += 4096) pieces.push(String.fromCharCode(...units.subarray(i, i + 4096)));
    return pieces.join("");
  }
  toJSON() {
    throw new TypeError("Compact JSON pages are internal only");
  }
  [Symbol.toPrimitive]() {
    throw new TypeError("Compact JSON pages require explicit decoding");
  }
};
var decodeJsonStringPage = (page) => typeof page === "string" ? page : page.decode();

// packages/proxy/src/services/egress/json-string-pages.ts
var JsonStringPages = class _JsonStringPages {
  #pages;
  #length;
  constructor(pages) {
    for (const page of pages) {
      if (typeof page !== "string" && !(page instanceof CompactJsonStringPage) || page.length > JSON_TEXT_PAGE_CHARS) throw new RangeError("Invalid JSON string page");
    }
    this.#pages = Object.freeze([...pages]);
    this.#length = pages.reduce((length, page) => length + page.length, 0);
    Object.freeze(this);
  }
  get length() {
    return this.#length;
  }
  *chunks() {
    for (const page of this.#pages) yield decodeJsonStringPage(page);
  }
  /** Explicit legacy boundary only. Do not retain the full copy in this object. */
  materialize() {
    return [...this.chunks()].join("");
  }
  /** Decode only trim boundaries; share all immutable interior storage pages. */
  trim(checkActive) {
    checkActive?.();
    let first = 0, last = this.#pages.length - 1, start = "", end = "", changed = false;
    while (first <= last) {
      checkActive?.();
      const page = decodeJsonStringPage(this.#pages[first]);
      start = page.trimStart();
      if (start) {
        changed ||= start.length !== page.length;
        break;
      }
      changed = true;
      first++;
    }
    if (first > last) return "";
    while (last >= first) {
      checkActive?.();
      const page = last === first ? start : decodeJsonStringPage(this.#pages[last]);
      end = page.trimEnd();
      if (end) {
        changed ||= end.length !== page.length;
        break;
      }
      changed = true;
      last--;
    }
    if (!changed) return this;
    return new _JsonStringPages(first === last ? [end] : [start, ...this.#pages.slice(first + 1, last), end]);
  }
  toJSON() {
    throw new TypeError("Paged JSON strings require the streaming encoder");
  }
  [Symbol.toPrimitive]() {
    throw new TypeError("Paged JSON strings require explicit materialization");
  }
};
function isJsonString(value) {
  return typeof value === "string" || value instanceof JsonStringPages;
}
function* jsonStringChunks(value) {
  if (value instanceof JsonStringPages) {
    yield* value.chunks();
    return;
  }
  for (let start = 0; start < value.length; start += JSON_TEXT_PAGE_CHARS) {
    yield value.slice(start, start + JSON_TEXT_PAGE_CHARS);
  }
}

// packages/proxy/src/services/egress/stream-json-body.ts
var JSON_OUTPUT_PAGE_BYTES = 64 * 1024;
var JSON_STRING_PIECE_CHARS = 8 * 1024;
var NEEDS_JSON_ESCAPING = /["\\\u0000-\u001f\ud800-\udfff]/;
function assertJsonTree(value, limits, checkActive) {
  if (!Number.isSafeInteger(limits.maxDepth) || limits.maxDepth < 1 || !Number.isSafeInteger(limits.maxNodes) || limits.maxNodes < 1) throw new RangeError("Invalid JSON encoding limits");
  let nodes = 0;
  const active = /* @__PURE__ */ new Set();
  const count = () => {
    if (++nodes > limits.maxNodes) throw new RangeError("JSON encoding structure exceeds its limit");
    checkActive?.();
  };
  const visit = (item, depth) => {
    count();
    if (item === null || isJsonString(item) || typeof item === "boolean" || typeof item === "number") return;
    if (typeof item !== "object" || depth >= limits.maxDepth || active.has(item)) throw new TypeError("Expected a bounded JSON tree");
    if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
      throw new TypeError("Expected a plain JSON object");
    }
    active.add(item);
    const inspectProperty = (key) => {
      const descriptor = Object.getOwnPropertyDescriptor(item, key);
      if (!descriptor || !("value" in descriptor)) throw new TypeError("JSON accessors and sparse arrays are not supported");
      const child = descriptor.value;
      visit(child, depth + 1);
    };
    if (Array.isArray(item)) {
      for (let index4 = 0; index4 < item.length; index4++) inspectProperty(String(index4));
    } else {
      for (const key of Object.keys(item)) {
        count();
        inspectProperty(key);
      }
    }
    active.delete(item);
  };
  visit(value, 0);
}
function* stringPieces(value) {
  yield '"';
  let highSurrogate = "";
  for (const chunk of jsonStringChunks(value)) {
    for (let start = 0; start < chunk.length; ) {
      const end = Math.min(chunk.length, start + JSON_STRING_PIECE_CHARS - highSurrogate.length);
      let piece = highSurrogate + chunk.slice(start, end);
      start = end;
      highSurrogate = "";
      const last = piece.charCodeAt(piece.length - 1);
      if (last >= 55296 && last <= 56319) {
        highSurrogate = piece.slice(-1);
        piece = piece.slice(0, -1);
      }
      if (piece) yield NEEDS_JSON_ESCAPING.test(piece) ? JSON.stringify(piece).slice(1, -1) : piece;
    }
  }
  if (highSurrogate) yield JSON.stringify(highSurrogate).slice(1, -1);
  yield '"';
}
function* valuePieces(value) {
  if (isJsonString(value)) {
    yield* stringPieces(value);
    return;
  }
  if (value === null || typeof value !== "object") {
    yield JSON.stringify(value);
    return;
  }
  if (Array.isArray(value)) {
    yield "[";
    for (let index4 = 0; index4 < value.length; index4++) {
      if (index4) yield ",";
      yield* valuePieces(value[index4]);
    }
    yield "]";
  } else {
    yield "{";
    let first = true;
    for (const key of Object.keys(value)) {
      if (!first) yield ",";
      first = false;
      yield* stringPieces(key);
      yield ":";
      yield* valuePieces(value[key]);
    }
    yield "}";
  }
}
function stringByteLength(value, checkActive) {
  let length = 2, highSurrogate = false;
  for (const chunk of jsonStringChunks(value)) {
    for (let index4 = 0; index4 < chunk.length; index4++) {
      if (index4 % JSON_STRING_PIECE_CHARS === 0) checkActive?.();
      const code = chunk.charCodeAt(index4);
      if (highSurrogate) {
        highSurrogate = false;
        if (code >= 56320 && code <= 57343) {
          length += 4;
          continue;
        }
        length += 6;
      }
      if (code >= 55296 && code <= 56319) highSurrogate = true;
      else if (code >= 56320 && code <= 57343) length += 6;
      else if (code < 32) length += code === 8 || code === 9 || code === 10 || code === 12 || code === 13 ? 2 : 6;
      else if (code === 34 || code === 92) length += 2;
      else length += code < 128 ? 1 : code < 2048 ? 2 : 3;
    }
  }
  return length + (highSurrogate ? 6 : 0);
}
function jsonBodyByteLength(value, limits, checkActive) {
  assertJsonTree(value, limits, checkActive);
  let length = 0;
  const add = (bytes) => {
    length += bytes;
    if (!Number.isSafeInteger(length)) throw new RangeError("JSON wire length exceeds the safe integer range");
  };
  const count = (item) => {
    checkActive?.();
    if (isJsonString(item)) {
      add(stringByteLength(item, checkActive));
      return;
    }
    if (item === null || typeof item !== "object") {
      add(JSON.stringify(item).length);
      return;
    }
    if (Array.isArray(item)) {
      add(2 + Math.max(0, item.length - 1));
      for (let index4 = 0; index4 < item.length; index4++) count(item[index4]);
    } else {
      const keys = Object.keys(item);
      add(2 + Math.max(0, keys.length - 1));
      for (const key of keys) {
        add(stringByteLength(key, checkActive) + 1);
        count(item[key]);
      }
    }
  };
  count(value);
  return length;
}
function streamJsonBody(value, limits, lifecycle = {}) {
  lifecycle.signal?.throwIfAborted();
  lifecycle.checkActive?.();
  assertJsonTree(value, limits, lifecycle.checkActive);
  let iterator = valuePieces(value);
  value = void 0;
  let pending = "";
  let closed = false;
  let controller;
  const encoder8 = new TextEncoder();
  const finish = () => {
    if (closed) return;
    closed = true;
    lifecycle.signal?.removeEventListener("abort", onAbort);
    iterator?.return();
    iterator = void 0;
    pending = "";
    const onFinished = lifecycle.onFinished;
    lifecycle = {};
    onFinished?.();
  };
  const fail = () => {
    if (closed) return;
    finish();
    controller.error(new Error("JSON response delivery was interrupted"));
  };
  const onAbort = () => fail();
  return new ReadableStream({
    start(target) {
      controller = target;
      lifecycle.signal?.addEventListener("abort", onAbort, { once: true });
      if (lifecycle.signal?.aborted) onAbort();
    },
    pull(target) {
      if (closed) return;
      try {
        lifecycle.checkActive?.();
        lifecycle.signal?.throwIfAborted();
        if (closed) return;
        const page = new Uint8Array(JSON_OUTPUT_PAGE_BYTES);
        let used = 0;
        while (used < page.length) {
          if (!pending) {
            const next = iterator.next();
            if (next.done) {
              finish();
              break;
            }
            pending = next.value;
            if (!pending) continue;
          }
          const { read, written } = encoder8.encodeInto(pending, page.subarray(used));
          if (read === 0) break;
          used += written;
          pending = pending.slice(read);
        }
        if (used) target.enqueue(used === page.length ? page : page.subarray(0, used));
        if (closed) target.close();
      } catch {
        fail();
      }
    },
    cancel() {
      finish();
    }
  }, { highWaterMark: 0 });
}

// packages/proxy/src/services/egress/json-upload-body.ts
var ENCODING_LIMITS = Object.freeze({ maxDepth: Number.MAX_SAFE_INTEGER, maxNodes: Number.MAX_SAFE_INTEGER });
function snapshotJson(value, checkActive, active = /* @__PURE__ */ new Set(), key = "") {
  checkActive();
  if (value instanceof JsonStringPages) return value;
  if (value !== null && typeof value === "object" || typeof value === "bigint") {
    const toJSON = value.toJSON;
    if (typeof toJSON === "function") value = Reflect.apply(toJSON, value, [key]);
  }
  if (value instanceof Number) value = Number(value);
  else if (value instanceof String) value = String(value);
  else if (value instanceof Boolean) value = Boolean.prototype.valueOf.call(value);
  else if (value instanceof BigInt) throw new TypeError("JSON request bigint is not supported");
  if (typeof value === "function" || typeof value === "symbol") return void 0;
  if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" || value === void 0) return value;
  if (typeof value !== "object" || active.has(value)) throw new TypeError("Expected a JSON request without cycles or bigint");
  active.add(value);
  const source = value;
  const property = (name) => snapshotJson(source[name], checkActive, active, name);
  let result;
  if (Array.isArray(value)) {
    const array2 = [];
    const length = value.length;
    for (let index4 = 0; index4 < length; index4++) array2.push(property(String(index4)) ?? null);
    result = array2;
  } else {
    const object = {};
    for (const key2 of Object.keys(value)) {
      const child = property(key2);
      if (child !== void 0) Object.defineProperty(object, key2, { value: child, enumerable: true, configurable: true, writable: true });
    }
    result = object;
  }
  active.delete(value);
  return Object.freeze(result);
}
function createJsonUploadBody(value, signal, checkActive) {
  const assertActive = () => {
    signal.throwIfAborted();
    checkActive();
  };
  const snapshot = snapshotJson(value, assertActive);
  const contentLength = jsonBodyByteLength(snapshot, ENCODING_LIMITS, assertActive);
  const owner = new AbortController();
  const onAbort = () => {
    owner.abort();
  };
  const onFinished = () => {
    signal.removeEventListener("abort", onAbort);
  };
  signal.addEventListener("abort", onAbort, { once: true });
  try {
    assertActive();
    const body = streamJsonBody(snapshot, ENCODING_LIMITS, { signal: owner.signal, checkActive: assertActive, onFinished });
    const digestSha256 = async () => {
      const hash = createHash("sha256");
      const digestBody = streamJsonBody(snapshot, ENCODING_LIMITS, {
        signal,
        checkActive: assertActive
      });
      const reader = digestBody.getReader();
      let bytes = 0;
      try {
        while (true) {
          assertActive();
          const part = await reader.read();
          assertActive();
          if (part.done) break;
          bytes += part.value.byteLength;
          if (bytes > contentLength) throw new Error("JSON upload digest length mismatch");
          hash.update(part.value);
        }
        if (bytes !== contentLength) throw new Error("JSON upload digest length mismatch");
        return hash.digest("hex");
      } finally {
        void reader.cancel("json_upload_digest_finished").catch(() => void 0);
        reader.releaseLock();
      }
    };
    return {
      body,
      contentLength,
      preparedSnapshot: snapshot,
      digestSha256,
      dispose: () => {
        onFinished();
        owner.abort();
      }
    };
  } catch (error) {
    onFinished();
    throw error;
  }
}

// packages/proxy/src/services/egress/owned-json-upload-body.ts
function createOwnedJsonUploadBody(value, signal) {
  const raw = createJsonUploadBody(value, new AbortController().signal, () => signal.throwIfAborted());
  return ownEncoder(raw, signal);
}
function ownEncoder(raw, signal) {
  let reader;
  let controller;
  let closed = false, pulled = false;
  let resolveResource;
  const resourceCompletion = new Promise((resolve) => {
    resolveResource = resolve;
  });
  const finish = (outcome) => {
    if (closed) return;
    closed = true;
    signal.removeEventListener("abort", stop);
    raw.dispose();
    reader?.releaseLock();
    reader = void 0;
    resolveResource(outcome);
  };
  const streamSource = {
    // workerd's declared source length, not a manually forced HTTP header.
    expectedLength: raw.contentLength,
    start(source) {
      controller = source;
    },
    async pull(source) {
      if (closed) return;
      pulled = true;
      try {
        reader ??= raw.body.getReader();
        const next = await reader.read();
        if (closed) return;
        if (next.done) {
          source.close();
          finish("confirmed");
        } else source.enqueue(next.value);
      } catch {
        if (!closed) {
          source.error(new Error("JSON upload encoding failed"));
          finish("unconfirmed");
        }
      }
    },
    cancel() {
      const completion = observeResourceCleanup(() => reader ? reader.cancel() : raw.body.cancel());
      finish(completion);
      return completion.then(() => void 0);
    }
  };
  const body = new ReadableStream(streamSource, { highWaterMark: 0 });
  function stop() {
    if (closed) return;
    const untouched = !pulled && !body.locked;
    controller.error(new Error("JSON upload stopped"));
    finish(untouched ? "confirmed" : "unconfirmed");
  }
  signal.addEventListener("abort", stop, { once: true });
  if (signal.aborted) stop();
  return {
    body,
    contentLength: raw.contentLength,
    preparedSnapshot: raw.preparedSnapshot,
    digestSha256: raw.digestSha256,
    resourceCompletion,
    stop
  };
}

// packages/proxy/src/services/egress/with-owned-json-upload.ts
async function withOwnedJsonUpload(value, signal, run) {
  const resources = createResourceCompletionGroup();
  const upload = createOwnedJsonUploadBody(value, signal ?? new AbortController().signal);
  resources.track(upload.resourceCompletion);
  try {
    const result = await run(upload);
    if (result.resourceCompletion) resources.track(result.resourceCompletion);
    return { ...result, resourceCompletion: resources.completion };
  } finally {
    upload.stop();
    resources.seal();
  }
}

// packages/proxy/src/services/egress/prepared-text-attempt.ts
import { createHash as createHash2 } from "node:crypto";
var SHA256_HEX = /^[a-f0-9]{64}$/;
var ROUTE_DOMAIN = "cinatoken.text.route-source.v1\n";
var CREDENTIAL_DOMAIN = "cinatoken.text.wire-credentials.v1\n";
var sha256 = (value) => createHash2("sha256").update(value).digest("hex");
function captureTextRouteIdentity(route2) {
  const source = JSON.stringify([
    route2.targetId,
    route2.providerId,
    route2.endpoint?.id ?? null,
    route2.providerKeyId ?? null,
    route2.providerModelName,
    route2.upstreamProtocol,
    route2.upstreamOperation,
    route2.providerEndpoints,
    route2.providerApiKey
  ]);
  if (!source || !route2.targetId || !route2.providerId || !route2.providerModelName) {
    throw new TypeError("Incomplete text route identity");
  }
  return Object.freeze({
    targetId: route2.targetId,
    providerId: route2.providerId,
    endpointId: route2.endpoint?.id ?? null,
    providerKeyId: route2.providerKeyId ?? null,
    providerModelName: route2.providerModelName,
    upstreamProtocol: route2.upstreamProtocol,
    upstreamOperation: route2.upstreamOperation,
    routeSourceSha256: createHash2("sha256").update(ROUTE_DOMAIN).update(source).digest("hex")
  });
}
function createPreparedTextAttempt(params) {
  if (!SHA256_HEX.test(params.outboundBodySha256) || params.outboundBodyCanonicalSha256 !== void 0 && !SHA256_HEX.test(params.outboundBodyCanonicalSha256) || !Number.isSafeInteger(params.outboundBodyBytes) || params.outboundBodyBytes < 0) {
    throw new TypeError("Invalid prepared text body identity");
  }
  const url = new URL(params.url);
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new TypeError("Invalid prepared text upstream URL");
  }
  const headers = new Headers(params.headers);
  const bindings = [];
  const authorization = headers.get("authorization");
  if (authorization) {
    const bearer = /^Bearer (.*)$/i.exec(authorization);
    if (!bearer) throw new TypeError("Unsupported text authorization identity");
    bindings.push(Object.freeze({ location: "authorization-bearer", sha256: sha256(bearer[1]) }));
  }
  const apiKey = headers.get("x-api-key");
  if (apiKey !== null) bindings.push(Object.freeze({ location: "x-api-key", sha256: sha256(apiKey) }));
  for (const queryKey of url.searchParams.getAll("key")) {
    bindings.push(Object.freeze({ location: "query-key", sha256: sha256(queryKey) }));
  }
  if (url.username || url.password) {
    bindings.push(Object.freeze({ location: "url-userinfo", sha256: sha256(`${url.username}:${url.password}`) }));
  }
  if (bindings.length === 0) throw new TypeError("Missing prepared text credential identity");
  const credentialBindings = Object.freeze(bindings);
  return Object.freeze({
    kind: "text-json-v1",
    routeIdentity: params.routeIdentity,
    method: params.method,
    upstreamUrlSha256: sha256(params.url),
    outboundBodySha256: params.outboundBodySha256,
    outboundBodyBytes: params.outboundBodyBytes,
    ...params.outboundBodyCanonicalSha256 === void 0 ? {} : { outboundBodyCanonicalSha256: params.outboundBodyCanonicalSha256 },
    credentialBindings,
    credentialFingerprintSha256: createHash2("sha256").update(CREDENTIAL_DOMAIN).update(JSON.stringify(credentialBindings)).digest("hex")
  });
}

// packages/core/src/index.ts
init_upstream_protocol();
init_provider_endpoints();
init_gemini_upstream_url();

// packages/core/src/gcp-oauth-lifecycle.ts
var GCP_OAUTH_TIMEOUT_MS = 3e4;
var GCP_OAUTH_MAX_RESPONSE_BYTES = 64 * 1024;
var GcpTokenExchangeError = class extends Error {
  constructor(code, status) {
    const messages = {
      cancelled: "GCP token exchange cancelled",
      timeout: "GCP token exchange timed out",
      failed: "GCP token exchange failed",
      invalid_response: "GCP token exchange returned an invalid response",
      response_too_large: "GCP token exchange response exceeds the limit",
      http_error: "GCP token exchange was rejected"
    };
    super(messages[code]);
    this.code = code;
    this.status = status;
    this.name = "GcpTokenExchangeError";
  }
};
function createGcpOAuthLifecycle(parentSignal, timeoutMs = GCP_OAUTH_TIMEOUT_MS) {
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > GCP_OAUTH_TIMEOUT_MS) {
    throw new RangeError("Invalid GCP OAuth timeout");
  }
  const controller = new AbortController();
  const deadlineAtMs = Date.now() + timeoutMs;
  let closed = false;
  const stop = (code) => controller.abort(new GcpTokenExchangeError(code));
  const onParentAbort = () => stop("cancelled");
  if (parentSignal?.aborted) onParentAbort();
  else parentSignal?.addEventListener("abort", onParentAbort, { once: true });
  const timer = setTimeout(() => stop("timeout"), timeoutMs);
  if (typeof timer === "object" && timer !== null && "unref" in timer) timer.unref();
  const check4 = () => {
    if (!controller.signal.aborted && Date.now() >= deadlineAtMs) stop("timeout");
    controller.signal.throwIfAborted();
    if (closed) throw new GcpTokenExchangeError("cancelled");
  };
  async function wait(operation, discard) {
    check4();
    return new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => controller.signal.removeEventListener("abort", onAbort);
      const onAbort = () => {
        settled = true;
        cleanup();
        reject(controller.signal.reason);
      };
      controller.signal.addEventListener("abort", onAbort, { once: true });
      if (controller.signal.aborted) {
        onAbort();
        return;
      }
      void Promise.resolve().then(() => {
        check4();
        return operation();
      }).then((value) => {
        cleanup();
        if (settled) {
          discard?.(value);
          return;
        }
        try {
          check4();
        } catch (error) {
          settled = true;
          discard?.(value);
          reject(error);
          return;
        }
        settled = true;
        resolve(value);
      }, (error) => {
        cleanup();
        settled = true;
        reject(error);
      }).catch(reject);
    });
  }
  return {
    signal: controller.signal,
    check: check4,
    wait,
    dispose() {
      closed = true;
      clearTimeout(timer);
      parentSignal?.removeEventListener("abort", onParentAbort);
    }
  };
}
function discardGcpOAuthResponse(response) {
  void response.body?.cancel("gcp_oauth_stopped").catch(() => void 0);
}
async function readGcpOAuthResponse(response, owner) {
  try {
    owner.check();
  } catch (error) {
    discardGcpOAuthResponse(response);
    throw error;
  }
  if (Number(response.headers.get("content-length")) > GCP_OAUTH_MAX_RESPONSE_BYTES) {
    discardGcpOAuthResponse(response);
    throw new GcpTokenExchangeError("response_too_large");
  }
  if (!response.body) return "";
  const reader = response.body.getReader();
  const bytes = new Uint8Array(GCP_OAUTH_MAX_RESPONSE_BYTES);
  let size = 0;
  let eof = false;
  try {
    while (true) {
      const { done, value } = await owner.wait(() => reader.read());
      if (done) {
        eof = true;
        break;
      }
      if (value.byteLength > bytes.byteLength - size) throw new GcpTokenExchangeError("response_too_large");
      bytes.set(value, size);
      size += value.byteLength;
    }
    owner.check();
    return new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes.subarray(0, size));
  } finally {
    if (!eof) void reader.cancel("gcp_oauth_stopped").catch(() => void 0);
    reader.releaseLock();
  }
}

// packages/core/src/request-auxiliary-auth-budget.ts
var RequestAuxiliaryAuthLimitError = class extends Error {
  constructor() {
    super("Request auxiliary authentication limit reached");
    this.name = "RequestAuxiliaryAuthLimitError";
  }
};

// packages/core/src/gcp-service-account-token.ts
var GCP_OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token";
var GCP_CLOUD_PLATFORM_SCOPE = "https://www.googleapis.com/auth/cloud-platform";
var TOKEN_REFRESH_SKEW_MS = 5 * 60 * 1e3;
var JWT_LIFETIME_SECONDS = 3600;
var GCP_TOKEN_CACHE_MAX_ENTRIES = 256;
var tokenCache = /* @__PURE__ */ new Map();
var cacheGeneration = {};
function parseGcpServiceAccountJson(raw) {
  const trimmed = raw.trim();
  if (!trimmed.startsWith("{")) return null;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed.type !== "service_account") return null;
    const clientEmail = typeof parsed.client_email === "string" ? parsed.client_email.trim() : "";
    const privateKey = typeof parsed.private_key === "string" ? parsed.private_key : "";
    if (!clientEmail || !privateKey.includes("BEGIN") || !privateKey.includes("PRIVATE KEY")) {
      return null;
    }
    const tokenUri = typeof parsed.token_uri === "string" ? parsed.token_uri.trim() : "";
    return {
      type: "service_account",
      client_email: clientEmail,
      private_key: privateKey.replace(/\\n/g, "\n"),
      ...tokenUri ? { token_uri: tokenUri } : {}
    };
  } catch {
    return null;
  }
}
function gcpServiceAccountCacheKey(account) {
  return JSON.stringify([account.client_email, account.private_key, account.token_uri?.trim() || GCP_OAUTH_TOKEN_URL, GCP_CLOUD_PLATFORM_SCOPE]);
}
async function resolveProviderUpstreamSecret(raw, options = {}) {
  if (options.signal?.aborted) throw new GcpTokenExchangeError("cancelled");
  const account = parseGcpServiceAccountJson(raw);
  if (!account) {
    return { secret: raw, isServiceAccount: false };
  }
  const accessToken = await getGcpAccessToken(account, options);
  return {
    secret: accessToken,
    isServiceAccount: true,
    clientEmail: account.client_email
  };
}
async function getGcpAccessToken(account, options = {}) {
  const nowMs = options.nowMs ?? Date.now;
  const owner = createGcpOAuthLifecycle(options.signal, options.timeoutMs);
  const generation = cacheGeneration;
  try {
    const digest2 = await owner.wait(() => crypto.subtle.digest("SHA-256", new TextEncoder().encode(gcpServiceAccountCacheKey(account))));
    const cacheKey = base64UrlEncode(new Uint8Array(digest2));
    for (const [key, token2] of tokenCache) {
      if (token2.expiresAtMs - TOKEN_REFRESH_SKEW_MS <= nowMs()) tokenCache.delete(key);
    }
    const cached = tokenCache.get(cacheKey);
    if (cached) {
      tokenCache.delete(cacheKey);
      tokenCache.set(cacheKey, cached);
      return cached.accessToken;
    }
    const token = await exchangeGcpAccessToken(account, options, owner);
    owner.check();
    if (generation === cacheGeneration && token.expiresAtMs - TOKEN_REFRESH_SKEW_MS > nowMs()) {
      tokenCache.delete(cacheKey);
      while (tokenCache.size >= GCP_TOKEN_CACHE_MAX_ENTRIES) {
        const oldest = tokenCache.keys().next();
        if (!oldest.done) tokenCache.delete(oldest.value);
      }
      tokenCache.set(cacheKey, token);
    }
    return token.accessToken;
  } catch (error) {
    owner.check();
    if (error instanceof RequestAuxiliaryAuthLimitError) throw error;
    throw error instanceof GcpTokenExchangeError ? error : new GcpTokenExchangeError("failed");
  } finally {
    owner.dispose();
  }
}
async function exchangeGcpAccessToken(account, options, owner) {
  const nowMs = options.nowMs ?? Date.now;
  const fetchImpl = options.fetchImpl ?? fetch;
  const tokenUrl = account.token_uri?.trim() || GCP_OAUTH_TOKEN_URL;
  options.auxiliaryAuth?.assertAvailable();
  const assertion = await signGcpServiceAccountJwt(account, tokenUrl, nowMs, owner);
  const body = new URLSearchParams({
    grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
    assertion
  });
  const requestedAtMs = nowMs();
  const response = await owner.wait(() => {
    options.auxiliaryAuth?.consume();
    return fetchImpl(tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      signal: owner.signal,
      redirect: "manual"
    });
  }, discardGcpOAuthResponse);
  if (!response.ok) {
    discardGcpOAuthResponse(response);
    throw new GcpTokenExchangeError("http_error", response.status);
  }
  const text5 = await readGcpOAuthResponse(response, owner);
  let payload;
  try {
    payload = JSON.parse(text5);
  } catch {
    throw new GcpTokenExchangeError("invalid_response");
  }
  if (payload == null || typeof payload !== "object" || Array.isArray(payload) || !("access_token" in payload) || typeof payload.access_token !== "string" || !/^[\x21-\x7e]+$/.test(payload.access_token) || !("expires_in" in payload) || typeof payload.expires_in !== "number" || !Number.isFinite(payload.expires_in) || payload.expires_in <= 0 || "token_type" in payload && (typeof payload.token_type !== "string" || payload.token_type.toLowerCase() !== "bearer")) {
    throw new GcpTokenExchangeError("invalid_response");
  }
  const expiresAtMs = requestedAtMs + Math.min(JWT_LIFETIME_SECONDS, payload.expires_in) * 1e3;
  if (expiresAtMs <= nowMs()) throw new GcpTokenExchangeError("invalid_response");
  return {
    accessToken: payload.access_token,
    expiresAtMs
  };
}
async function signGcpServiceAccountJwt(account, audience, nowMs = Date.now, owner) {
  owner?.check();
  const nowSeconds = Math.floor(nowMs() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    iss: account.client_email,
    sub: account.client_email,
    aud: audience,
    iat: nowSeconds,
    exp: nowSeconds + JWT_LIFETIME_SECONDS,
    scope: GCP_CLOUD_PLATFORM_SCOPE
  };
  const signingInput = `${base64UrlJson(header)}.${base64UrlJson(claims)}`;
  const key = await (owner ? owner.wait(() => importRsaPrivateKey(account.private_key)) : importRsaPrivateKey(account.private_key));
  const sign = () => crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    bytesToArrayBuffer(new TextEncoder().encode(signingInput))
  );
  const signature = await (owner ? owner.wait(sign) : sign());
  return `${signingInput}.${base64UrlEncode(new Uint8Array(signature))}`;
}
async function importRsaPrivateKey(pem) {
  return crypto.subtle.importKey(
    "pkcs8",
    bytesToArrayBuffer(decodePemToDer(pem)),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
}
function bytesToArrayBuffer(bytes) {
  const copy = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(copy).set(bytes);
  return copy;
}
function decodePemToDer(pem) {
  const normalized = pem.replace(/\\n/g, "\n").trim();
  const pkcs8 = normalized.match(/-----BEGIN PRIVATE KEY-----([\s\S]+?)-----END PRIVATE KEY-----/);
  if (pkcs8?.[1]) return uint8FromBase64(pkcs8[1]);
  const pkcs1 = normalized.match(/-----BEGIN RSA PRIVATE KEY-----([\s\S]+?)-----END RSA PRIVATE KEY-----/);
  if (pkcs1?.[1]) {
    return wrapPkcs1ToPkcs8(uint8FromBase64(pkcs1[1]));
  }
  throw new Error("GCP service account private_key must be a PEM PRIVATE KEY");
}
function wrapPkcs1ToPkcs8(pkcs1) {
  const version2 = new Uint8Array([2, 1, 0]);
  const rsaOid = new Uint8Array([
    48,
    13,
    6,
    9,
    42,
    134,
    72,
    134,
    247,
    13,
    1,
    1,
    1,
    5,
    0
  ]);
  const octet = encodeDer(4, pkcs1);
  return encodeDer(48, concatBytes(version2, rsaOid, octet));
}
function encodeDer(tag, content) {
  const length = encodeDerLength(content.length);
  const out = new Uint8Array(1 + length.length + content.length);
  out[0] = tag;
  out.set(length, 1);
  out.set(content, 1 + length.length);
  return out;
}
function encodeDerLength(length) {
  if (length < 128) return new Uint8Array([length]);
  const bytes = [];
  let value = length;
  while (value > 0) {
    bytes.unshift(value & 255);
    value >>= 8;
  }
  return new Uint8Array([128 | bytes.length, ...bytes]);
}
function concatBytes(...parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}
function base64UrlJson(value) {
  return base64UrlEncode(new TextEncoder().encode(JSON.stringify(value)));
}
function base64UrlEncode(bytes) {
  return base64Encode(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function base64Encode(bytes) {
  let binary2 = "";
  for (const byte of bytes) binary2 += String.fromCharCode(byte);
  return btoa(binary2);
}
function uint8FromBase64(base64) {
  const cleaned = base64.replace(/\s+/g, "");
  const binary2 = atob(cleaned);
  const bytes = new Uint8Array(binary2.length);
  for (let i = 0; i < binary2.length; i++) bytes[i] = binary2.charCodeAt(i);
  return bytes;
}

// packages/core/src/request-deadline.ts
var RequestExecutionStoppedError = class extends Error {
  constructor(reason) {
    super(reason === "deadline_exceeded" ? "Request deadline exceeded" : "Request was cancelled");
    this.reason = reason;
    this.name = "RequestExecutionStoppedError";
  }
};

// packages/core/src/index.ts
init_preparation_control();

// packages/core/src/vertex-openai-model.ts
function isVertexOpenAiCompatibleUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.toLowerCase().endsWith("aiplatform.googleapis.com") && parsed.pathname.includes("/endpoints/openapi");
  } catch {
    return false;
  }
}
function applyVertexOpenAiModelPrefix(upstreamUrl, modelName) {
  const trimmed = modelName.trim();
  if (!trimmed || !isVertexOpenAiCompatibleUrl(upstreamUrl)) return trimmed;
  if (trimmed.includes("/")) return trimmed;
  return `google/${trimmed}`;
}

// packages/core/src/index.ts
init_route_topology();

// packages/core/src/request-presets.ts
var REQUEST_PRESET_MAX_CONFIG_BYTES = 64 * 1024;
var REQUEST_PRESET_MAX_SYSTEM_PROMPT_BYTES = 32 * 1024;

// packages/core/src/guardrails.ts
init_route_data_policy();
init_guardrail_budget_types();

// packages/core/src/guardrail-builtins.ts
var PRIVATE_KEY_BLOCK_MAX_CHARACTERS = 32 * 1024;

// packages/core/src/guardrails.ts
var GUARDRAIL_MAX_CONFIG_BYTES = 64 * 1024;
var GUARDRAIL_MAX_SCANNED_TEXT_BYTES = 256 * 1024;

// packages/core/src/db/pricing-schedule.ts
var MINUTES_PER_DAY = 24 * 60;
var WEEK_MINUTES = 7 * MINUTES_PER_DAY;

// packages/core/src/route-performance.ts
var ROUTE_PERFORMANCE_WINDOW_MS = 5 * 60 * 1e3;

// packages/core/src/db/route-routing-metadata.ts
var ROUTE_QUANTIZATIONS = [
  "int4",
  "int8",
  "fp4",
  "mxfp4",
  "nvfp4",
  "fp6",
  "fp8",
  "mxfp8",
  "fp16",
  "bf16",
  "fp32",
  "unknown"
];
var QUANTIZATIONS = new Set(ROUTE_QUANTIZATIONS);

// packages/core/src/model-endpoint-catalog.ts
var AUDIO_ENDPOINT_PRICING_OPERATIONS = [
  "audio.transcriptions",
  "audio.transcriptions.multimodal",
  "audio.transcriptions.async",
  "audio.transcriptions.realtime.inference",
  "audio.transcriptions.realtime.session",
  "audio.speech",
  "audio.speech.stream",
  "audio.speech.multimodal",
  "audio.speech.realtime.inference"
];
var PRICE_KEYS = [
  "audio",
  "audio_output",
  "completion",
  "discount",
  "image",
  "image_output",
  "image_token",
  "input_audio_cache",
  "input_cache_read",
  "input_cache_write",
  "input_cache_write_1h",
  "internal_reasoning",
  "prompt",
  "request",
  "web_search",
  "currency"
];
var OPTIONAL_DECIMAL_PRICE_KEYS = PRICE_KEYS.filter(
  (key) => !["currency", "prompt", "completion", "discount"].includes(key)
);

// packages/core/src/model-endpoint-runtime.ts
var QUANTIZATIONS2 = new Set(ROUTE_QUANTIZATIONS);

// packages/core/src/route-planner-preview.ts
init_route_data_policy();

// packages/core/src/lib/provider-key-environment.ts
init_provider_endpoints();
init_preparation_control();

// packages/core/src/route-planner-preview.ts
init_upstream_protocol();
init_provider_endpoints();

// packages/core/src/index.ts
init_gateway_key_limits();
init_workspace_budgets();

// packages/core/src/management-workspaces.ts
var MANAGEMENT_WORKSPACE_PROVIDER_SORTS = [
  "price",
  "throughput",
  "latency",
  "exacto"
];
var PROVIDER_SORTS = new Set(MANAGEMENT_WORKSPACE_PROVIDER_SORTS);

// packages/core/src/management-guardrails.ts
var MANAGEMENT_GUARDRAIL_MAX_BODY_BYTES = 96 * 1024;
var MANAGEMENT_GUARDRAIL_ASSIGNMENT_MAX_BODY_BYTES = 64 * 1024;
var CREATE_FIELDS = /* @__PURE__ */ new Set([
  "allowed_models",
  "allowed_providers",
  "content_filter_builtins",
  "content_filters",
  "data_collection",
  "description",
  "enable_free_model_publication",
  "enable_free_model_training",
  "enable_paid_model_training",
  "enforce_zdr",
  "enforce_zdr_anthropic",
  "enforce_zdr_google",
  "enforce_zdr_openai",
  "enforce_zdr_other",
  "enforce_zdr_xai",
  "ignored_models",
  "ignored_providers",
  "include_byok_in_budgets",
  "limit_usd",
  "name",
  "reset_interval",
  "workspace_id"
]);
var PATCH_FIELDS = new Set([...CREATE_FIELDS].filter((field) => field !== "workspace_id"));

// packages/core/src/index.ts
init_route_data_policy();

// packages/core/src/organization-identity.ts
var CINAUTH_ORGANIZATION_EVENT_TYPES = [
  "organization.upserted",
  "organization.deleted",
  "organization.membership.upserted",
  "organization.membership.removed"
];
var EVENT_TYPE_SET = new Set(CINAUTH_ORGANIZATION_EVENT_TYPES);

// packages/core/src/index.ts
init_workspaces();

// node_modules/drizzle-orm/d1/driver.js
init_entity();
init_logger();
init_relations();

// node_modules/drizzle-orm/sqlite-core/db.js
init_entity();
init_selection_proxy();
init_sql();

// node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
init_entity();
init_query_promise();
init_selection_proxy();

// node_modules/drizzle-orm/sqlite-core/table.js
init_entity();
init_table();

// node_modules/drizzle-orm/sqlite-core/columns/blob.js
init_entity();
init_utils();

// node_modules/drizzle-orm/sqlite-core/columns/common.js
init_column_builder();
init_column();
init_entity();

// node_modules/drizzle-orm/sqlite-core/foreign-keys.js
init_entity();
init_table_utils();
var ForeignKeyBuilder2 = class {
  static [entityKind] = "SQLiteForeignKeyBuilder";
  /** @internal */
  reference;
  /** @internal */
  _onUpdate;
  /** @internal */
  _onDelete;
  constructor(config, actions) {
    this.reference = () => {
      const { name, columns, foreignColumns } = config();
      return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
    };
    if (actions) {
      this._onUpdate = actions.onUpdate;
      this._onDelete = actions.onDelete;
    }
  }
  onUpdate(action) {
    this._onUpdate = action;
    return this;
  }
  onDelete(action) {
    this._onDelete = action;
    return this;
  }
  /** @internal */
  build(table) {
    return new ForeignKey2(table, this);
  }
};
var ForeignKey2 = class {
  constructor(table, builder) {
    this.table = table;
    this.reference = builder.reference;
    this.onUpdate = builder._onUpdate;
    this.onDelete = builder._onDelete;
  }
  static [entityKind] = "SQLiteForeignKey";
  reference;
  onUpdate;
  onDelete;
  getName() {
    const { name, columns, foreignColumns } = this.reference();
    const columnNames = columns.map((column) => column.name);
    const foreignColumnNames = foreignColumns.map((column) => column.name);
    const chunks = [
      this.table[TableName],
      ...columnNames,
      foreignColumns[0].table[TableName],
      ...foreignColumnNames
    ];
    return name ?? `${chunks.join("_")}_fk`;
  }
};

// node_modules/drizzle-orm/sqlite-core/unique-constraint.js
init_entity();
init_table_utils();
function uniqueKeyName2(table, columns) {
  return `${table[TableName]}_${columns.join("_")}_unique`;
}
var UniqueConstraintBuilder2 = class {
  constructor(columns, name) {
    this.name = name;
    this.columns = columns;
  }
  static [entityKind] = "SQLiteUniqueConstraintBuilder";
  /** @internal */
  columns;
  /** @internal */
  build(table) {
    return new UniqueConstraint2(table, this.columns, this.name);
  }
};
var UniqueOnConstraintBuilder2 = class {
  static [entityKind] = "SQLiteUniqueOnConstraintBuilder";
  /** @internal */
  name;
  constructor(name) {
    this.name = name;
  }
  on(...columns) {
    return new UniqueConstraintBuilder2(columns, this.name);
  }
};
var UniqueConstraint2 = class {
  constructor(table, columns, name) {
    this.table = table;
    this.columns = columns;
    this.name = name ?? uniqueKeyName2(this.table, this.columns.map((column) => column.name));
  }
  static [entityKind] = "SQLiteUniqueConstraint";
  columns;
  name;
  getName() {
    return this.name;
  }
};

// node_modules/drizzle-orm/sqlite-core/columns/common.js
var SQLiteColumnBuilder = class extends ColumnBuilder {
  static [entityKind] = "SQLiteColumnBuilder";
  foreignKeyConfigs = [];
  references(ref, actions = {}) {
    this.foreignKeyConfigs.push({ ref, actions });
    return this;
  }
  unique(name) {
    this.config.isUnique = true;
    this.config.uniqueName = name;
    return this;
  }
  generatedAlwaysAs(as, config) {
    this.config.generated = {
      as,
      type: "always",
      mode: config?.mode ?? "virtual"
    };
    return this;
  }
  /** @internal */
  buildForeignKeys(column, table) {
    return this.foreignKeyConfigs.map(({ ref, actions }) => {
      return ((ref2, actions2) => {
        const builder = new ForeignKeyBuilder2(() => {
          const foreignColumn = ref2();
          return { columns: [column], foreignColumns: [foreignColumn] };
        });
        if (actions2.onUpdate) {
          builder.onUpdate(actions2.onUpdate);
        }
        if (actions2.onDelete) {
          builder.onDelete(actions2.onDelete);
        }
        return builder.build(table);
      })(ref, actions);
    });
  }
};
var SQLiteColumn = class extends Column {
  constructor(table, config) {
    if (!config.uniqueName) {
      config.uniqueName = uniqueKeyName2(table, [config.name]);
    }
    super(table, config);
    this.table = table;
  }
  static [entityKind] = "SQLiteColumn";
};

// node_modules/drizzle-orm/sqlite-core/columns/blob.js
var SQLiteBigIntBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteBigIntBuilder";
  constructor(name) {
    super(name, "bigint", "SQLiteBigInt");
  }
  /** @internal */
  build(table) {
    return new SQLiteBigInt(table, this.config);
  }
};
var SQLiteBigInt = class extends SQLiteColumn {
  static [entityKind] = "SQLiteBigInt";
  getSQLType() {
    return "blob";
  }
  mapFromDriverValue(value) {
    if (typeof Buffer !== "undefined" && Buffer.from) {
      const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
      return BigInt(buf.toString("utf8"));
    }
    return BigInt(textDecoder.decode(value));
  }
  mapToDriverValue(value) {
    return Buffer.from(value.toString());
  }
};
var SQLiteBlobJsonBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteBlobJsonBuilder";
  constructor(name) {
    super(name, "json", "SQLiteBlobJson");
  }
  /** @internal */
  build(table) {
    return new SQLiteBlobJson(
      table,
      this.config
    );
  }
};
var SQLiteBlobJson = class extends SQLiteColumn {
  static [entityKind] = "SQLiteBlobJson";
  getSQLType() {
    return "blob";
  }
  mapFromDriverValue(value) {
    if (typeof Buffer !== "undefined" && Buffer.from) {
      const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
      return JSON.parse(buf.toString("utf8"));
    }
    return JSON.parse(textDecoder.decode(value));
  }
  mapToDriverValue(value) {
    return Buffer.from(JSON.stringify(value));
  }
};
var SQLiteBlobBufferBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteBlobBufferBuilder";
  constructor(name) {
    super(name, "buffer", "SQLiteBlobBuffer");
  }
  /** @internal */
  build(table) {
    return new SQLiteBlobBuffer(table, this.config);
  }
};
var SQLiteBlobBuffer = class extends SQLiteColumn {
  static [entityKind] = "SQLiteBlobBuffer";
  mapFromDriverValue(value) {
    if (Buffer.isBuffer(value)) {
      return value;
    }
    return Buffer.from(value);
  }
  getSQLType() {
    return "blob";
  }
};
function blob(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "json") {
    return new SQLiteBlobJsonBuilder(name);
  }
  if (config?.mode === "bigint") {
    return new SQLiteBigIntBuilder(name);
  }
  return new SQLiteBlobBufferBuilder(name);
}

// node_modules/drizzle-orm/sqlite-core/columns/custom.js
init_entity();
init_utils();
var SQLiteCustomColumnBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteCustomColumnBuilder";
  constructor(name, fieldConfig, customTypeParams) {
    super(name, "custom", "SQLiteCustomColumn");
    this.config.fieldConfig = fieldConfig;
    this.config.customTypeParams = customTypeParams;
  }
  /** @internal */
  build(table) {
    return new SQLiteCustomColumn(
      table,
      this.config
    );
  }
};
var SQLiteCustomColumn = class extends SQLiteColumn {
  static [entityKind] = "SQLiteCustomColumn";
  sqlName;
  mapTo;
  mapFrom;
  constructor(table, config) {
    super(table, config);
    this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
    this.mapTo = config.customTypeParams.toDriver;
    this.mapFrom = config.customTypeParams.fromDriver;
  }
  getSQLType() {
    return this.sqlName;
  }
  mapFromDriverValue(value) {
    return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
  }
  mapToDriverValue(value) {
    return typeof this.mapTo === "function" ? this.mapTo(value) : value;
  }
};
function customType2(customTypeParams) {
  return (a, b) => {
    const { name, config } = getColumnNameAndConfig(a, b);
    return new SQLiteCustomColumnBuilder(
      name,
      config,
      customTypeParams
    );
  };
}

// node_modules/drizzle-orm/sqlite-core/columns/integer.js
init_entity();
init_sql();
init_utils();
var SQLiteBaseIntegerBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteBaseIntegerBuilder";
  constructor(name, dataType, columnType) {
    super(name, dataType, columnType);
    this.config.autoIncrement = false;
  }
  primaryKey(config) {
    if (config?.autoIncrement) {
      this.config.autoIncrement = true;
    }
    this.config.hasDefault = true;
    return super.primaryKey();
  }
};
var SQLiteBaseInteger = class extends SQLiteColumn {
  static [entityKind] = "SQLiteBaseInteger";
  autoIncrement = this.config.autoIncrement;
  getSQLType() {
    return "integer";
  }
};
var SQLiteIntegerBuilder = class extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteIntegerBuilder";
  constructor(name) {
    super(name, "number", "SQLiteInteger");
  }
  build(table) {
    return new SQLiteInteger(
      table,
      this.config
    );
  }
};
var SQLiteInteger = class extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteInteger";
};
var SQLiteTimestampBuilder = class extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteTimestampBuilder";
  constructor(name, mode) {
    super(name, "date", "SQLiteTimestamp");
    this.config.mode = mode;
  }
  /**
   * @deprecated Use `default()` with your own expression instead.
   *
   * Adds `DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer))` to the column, which is the current epoch timestamp in milliseconds.
   */
  defaultNow() {
    return this.default(sql`(cast((julianday('now') - 2440587.5)*86400000 as integer))`);
  }
  build(table) {
    return new SQLiteTimestamp(
      table,
      this.config
    );
  }
};
var SQLiteTimestamp = class extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteTimestamp";
  mode = this.config.mode;
  mapFromDriverValue(value) {
    if (this.config.mode === "timestamp") {
      return new Date(value * 1e3);
    }
    return new Date(value);
  }
  mapToDriverValue(value) {
    const unix = value.getTime();
    if (this.config.mode === "timestamp") {
      return Math.floor(unix / 1e3);
    }
    return unix;
  }
};
var SQLiteBooleanBuilder = class extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteBooleanBuilder";
  constructor(name, mode) {
    super(name, "boolean", "SQLiteBoolean");
    this.config.mode = mode;
  }
  build(table) {
    return new SQLiteBoolean(
      table,
      this.config
    );
  }
};
var SQLiteBoolean = class extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteBoolean";
  mode = this.config.mode;
  mapFromDriverValue(value) {
    return Number(value) === 1;
  }
  mapToDriverValue(value) {
    return value ? 1 : 0;
  }
};
function integer2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "timestamp" || config?.mode === "timestamp_ms") {
    return new SQLiteTimestampBuilder(name, config.mode);
  }
  if (config?.mode === "boolean") {
    return new SQLiteBooleanBuilder(name, config.mode);
  }
  return new SQLiteIntegerBuilder(name);
}

// node_modules/drizzle-orm/sqlite-core/columns/numeric.js
init_entity();
init_utils();
var SQLiteNumericBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteNumericBuilder";
  constructor(name) {
    super(name, "string", "SQLiteNumeric");
  }
  /** @internal */
  build(table) {
    return new SQLiteNumeric(
      table,
      this.config
    );
  }
};
var SQLiteNumeric = class extends SQLiteColumn {
  static [entityKind] = "SQLiteNumeric";
  mapFromDriverValue(value) {
    if (typeof value === "string") return value;
    return String(value);
  }
  getSQLType() {
    return "numeric";
  }
};
var SQLiteNumericNumberBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteNumericNumberBuilder";
  constructor(name) {
    super(name, "number", "SQLiteNumericNumber");
  }
  /** @internal */
  build(table) {
    return new SQLiteNumericNumber(
      table,
      this.config
    );
  }
};
var SQLiteNumericNumber = class extends SQLiteColumn {
  static [entityKind] = "SQLiteNumericNumber";
  mapFromDriverValue(value) {
    if (typeof value === "number") return value;
    return Number(value);
  }
  mapToDriverValue = String;
  getSQLType() {
    return "numeric";
  }
};
var SQLiteNumericBigIntBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteNumericBigIntBuilder";
  constructor(name) {
    super(name, "bigint", "SQLiteNumericBigInt");
  }
  /** @internal */
  build(table) {
    return new SQLiteNumericBigInt(
      table,
      this.config
    );
  }
};
var SQLiteNumericBigInt = class extends SQLiteColumn {
  static [entityKind] = "SQLiteNumericBigInt";
  mapFromDriverValue = BigInt;
  mapToDriverValue = String;
  getSQLType() {
    return "numeric";
  }
};
function numeric2(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  const mode = config?.mode;
  return mode === "number" ? new SQLiteNumericNumberBuilder(name) : mode === "bigint" ? new SQLiteNumericBigIntBuilder(name) : new SQLiteNumericBuilder(name);
}

// node_modules/drizzle-orm/sqlite-core/columns/real.js
init_entity();
var SQLiteRealBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteRealBuilder";
  constructor(name) {
    super(name, "number", "SQLiteReal");
  }
  /** @internal */
  build(table) {
    return new SQLiteReal(table, this.config);
  }
};
var SQLiteReal = class extends SQLiteColumn {
  static [entityKind] = "SQLiteReal";
  getSQLType() {
    return "real";
  }
};
function real2(name) {
  return new SQLiteRealBuilder(name ?? "");
}

// node_modules/drizzle-orm/sqlite-core/columns/text.js
init_entity();
init_utils();
var SQLiteTextBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteTextBuilder";
  constructor(name, config) {
    super(name, "string", "SQLiteText");
    this.config.enumValues = config.enum;
    this.config.length = config.length;
  }
  /** @internal */
  build(table) {
    return new SQLiteText(
      table,
      this.config
    );
  }
};
var SQLiteText = class extends SQLiteColumn {
  static [entityKind] = "SQLiteText";
  enumValues = this.config.enumValues;
  length = this.config.length;
  constructor(table, config) {
    super(table, config);
  }
  getSQLType() {
    return `text${this.config.length ? `(${this.config.length})` : ""}`;
  }
};
var SQLiteTextJsonBuilder = class extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteTextJsonBuilder";
  constructor(name) {
    super(name, "json", "SQLiteTextJson");
  }
  /** @internal */
  build(table) {
    return new SQLiteTextJson(
      table,
      this.config
    );
  }
};
var SQLiteTextJson = class extends SQLiteColumn {
  static [entityKind] = "SQLiteTextJson";
  getSQLType() {
    return "text";
  }
  mapFromDriverValue(value) {
    return JSON.parse(value);
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
};
function text2(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config.mode === "json") {
    return new SQLiteTextJsonBuilder(name);
  }
  return new SQLiteTextBuilder(name, config);
}

// node_modules/drizzle-orm/sqlite-core/columns/all.js
function getSQLiteColumnBuilders() {
  return {
    blob,
    customType: customType2,
    integer: integer2,
    numeric: numeric2,
    real: real2,
    text: text2
  };
}

// node_modules/drizzle-orm/sqlite-core/table.js
var InlineForeignKeys2 = /* @__PURE__ */ Symbol.for("drizzle:SQLiteInlineForeignKeys");
var SQLiteTable = class extends Table {
  static [entityKind] = "SQLiteTable";
  /** @internal */
  static Symbol = Object.assign({}, Table.Symbol, {
    InlineForeignKeys: InlineForeignKeys2
  });
  /** @internal */
  [Table.Symbol.Columns];
  /** @internal */
  [InlineForeignKeys2] = [];
  /** @internal */
  [Table.Symbol.ExtraConfigBuilder] = void 0;
};
function sqliteTableBase(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new SQLiteTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns(getSQLiteColumnBuilders()) : columns;
  const builtColumns = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.build(rawTable);
      rawTable[InlineForeignKeys2].push(...colBuilder.buildForeignKeys(column, rawTable));
      return [name2, column];
    })
  );
  const table = Object.assign(rawTable, builtColumns);
  table[Table.Symbol.Columns] = builtColumns;
  table[Table.Symbol.ExtraConfigColumns] = builtColumns;
  if (extraConfig) {
    table[SQLiteTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return table;
}
var sqliteTable = (name, columns, extraConfig) => {
  return sqliteTableBase(name, columns, extraConfig);
};

// node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
init_table();
init_utils();

// node_modules/drizzle-orm/sqlite-core/utils.js
init_entity();
init_sql();
init_subquery();
init_table();
init_view_common();

// node_modules/drizzle-orm/sqlite-core/checks.js
init_entity();
var CheckBuilder = class {
  constructor(name, value) {
    this.name = name;
    this.value = value;
  }
  static [entityKind] = "SQLiteCheckBuilder";
  brand;
  build(table) {
    return new Check(table, this);
  }
};
var Check = class {
  constructor(table, builder) {
    this.table = table;
    this.name = builder.name;
    this.value = builder.value;
  }
  static [entityKind] = "SQLiteCheck";
  name;
  value;
};
function check(name, value) {
  return new CheckBuilder(name, value);
}

// node_modules/drizzle-orm/sqlite-core/indexes.js
init_entity();
var IndexBuilderOn = class {
  constructor(name, unique) {
    this.name = name;
    this.unique = unique;
  }
  static [entityKind] = "SQLiteIndexBuilderOn";
  on(...columns) {
    return new IndexBuilder(this.name, columns, this.unique);
  }
};
var IndexBuilder = class {
  static [entityKind] = "SQLiteIndexBuilder";
  /** @internal */
  config;
  constructor(name, columns, unique) {
    this.config = {
      name,
      columns,
      unique,
      where: void 0
    };
  }
  /**
   * Condition for partial index.
   */
  where(condition) {
    this.config.where = condition;
    return this;
  }
  /** @internal */
  build(table) {
    return new Index(this.config, table);
  }
};
var Index = class {
  static [entityKind] = "SQLiteIndex";
  config;
  constructor(config, table) {
    this.config = { ...config, table };
  }
};
function index(name) {
  return new IndexBuilderOn(name, false);
}
function uniqueIndex(name) {
  return new IndexBuilderOn(name, true);
}

// node_modules/drizzle-orm/sqlite-core/primary-keys.js
init_entity();
function primaryKey2(...config) {
  if (config[0].columns) {
    return new PrimaryKeyBuilder2(config[0].columns, config[0].name);
  }
  return new PrimaryKeyBuilder2(config);
}
var PrimaryKeyBuilder2 = class {
  static [entityKind] = "SQLitePrimaryKeyBuilder";
  /** @internal */
  columns;
  /** @internal */
  name;
  constructor(columns, name) {
    this.columns = columns;
    this.name = name;
  }
  /** @internal */
  build(table) {
    return new PrimaryKey2(table, this.columns, this.name);
  }
};
var PrimaryKey2 = class {
  constructor(table, columns, name) {
    this.table = table;
    this.columns = columns;
    this.name = name;
  }
  static [entityKind] = "SQLitePrimaryKey";
  columns;
  name;
  getName() {
    return this.name ?? `${this.table[SQLiteTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
  }
};

// node_modules/drizzle-orm/sqlite-core/utils.js
function extractUsedTable(table) {
  if (is(table, SQLiteTable)) {
    return [`${table[Table.Symbol.BaseName]}`];
  }
  if (is(table, Subquery)) {
    return table._.usedTables ?? [];
  }
  if (is(table, SQL)) {
    return table.usedTables ?? [];
  }
  return [];
}

// node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
var SQLiteDeleteBase = class extends QueryPromise {
  constructor(table, session, dialect, withList) {
    super();
    this.table = table;
    this.session = session;
    this.dialect = dialect;
    this.config = { table, withList };
  }
  static [entityKind] = "SQLiteDelete";
  /** @internal */
  config;
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will delete only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be deleted.
   *
   * ```ts
   * // Delete all cars with green color
   * db.delete(cars).where(eq(cars.color, 'green'));
   * // or
   * db.delete(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Delete all BMW cars with a green color
   * db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Delete all cars with the green or blue color
   * db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    this.config.where = where;
    return this;
  }
  orderBy(...columns) {
    if (typeof columns[0] === "function") {
      const orderBy = columns[0](
        new Proxy(
          this.config.table[Table.Symbol.Columns],
          new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
      this.config.orderBy = orderByArray;
    } else {
      const orderByArray = columns;
      this.config.orderBy = orderByArray;
    }
    return this;
  }
  limit(limit) {
    this.config.limit = limit;
    return this;
  }
  returning(fields = this.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildDeleteQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      true,
      void 0,
      {
        type: "delete",
        tables: extractUsedTable(this.config.table)
      }
    );
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute(placeholderValues) {
    return this._prepare().execute(placeholderValues);
  }
  $dynamic() {
    return this;
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
init_entity();
init_query_promise();
init_sql();
init_table();
init_utils();

// node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
init_entity();
init_selection_proxy();

// node_modules/drizzle-orm/sqlite-core/dialect.js
init_alias();
init_casing();
init_column();
init_entity();
init_errors();
init_relations();
init_sql2();
init_sql();
init_subquery();
init_table();
init_utils();
init_view_common();

// node_modules/drizzle-orm/sqlite-core/view-base.js
init_entity();
init_sql();
var SQLiteViewBase = class extends View {
  static [entityKind] = "SQLiteViewBase";
};

// node_modules/drizzle-orm/sqlite-core/dialect.js
var SQLiteDialect = class {
  static [entityKind] = "SQLiteDialect";
  /** @internal */
  casing;
  constructor(config) {
    this.casing = new CasingCache(config?.casing);
  }
  escapeName(name) {
    return `"${name.replace(/"/g, '""')}"`;
  }
  escapeParam(_num) {
    return "?";
  }
  escapeString(str2) {
    return `'${str2.replace(/'/g, "''")}'`;
  }
  buildWithCTE(queries) {
    if (!queries?.length) return void 0;
    const withSqlChunks = [sql`with `];
    for (const [i, w] of queries.entries()) {
      withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
      if (i < queries.length - 1) {
        withSqlChunks.push(sql`, `);
      }
    }
    withSqlChunks.push(sql` `);
    return sql.join(withSqlChunks);
  }
  buildDeleteQuery({
    table,
    where,
    returning,
    withList,
    limit,
    orderBy
  }) {
    const withSql = this.buildWithCTE(withList);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
    const whereSql = where ? sql` where ${where}` : void 0;
    const orderBySql = this.buildOrderBy(orderBy);
    const limitSql = this.buildLimit(limit);
    return sql`${withSql}delete from ${table}${whereSql}${returningSql}${orderBySql}${limitSql}`;
  }
  buildUpdateSet(table, set) {
    const tableColumns = table[Table.Symbol.Columns];
    const columnNames = Object.keys(tableColumns).filter(
      (colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0
    );
    const setSize = columnNames.length;
    return sql.join(
      columnNames.flatMap((colName, i) => {
        const col = tableColumns[colName];
        const onUpdateFnResult = col.onUpdateFn?.();
        const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
        const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
        if (i < setSize - 1) {
          return [res, sql.raw(", ")];
        }
        return [res];
      })
    );
  }
  buildUpdateQuery({
    table,
    set,
    where,
    returning,
    withList,
    joins,
    from,
    limit,
    orderBy
  }) {
    const withSql = this.buildWithCTE(withList);
    const setSql = this.buildUpdateSet(table, set);
    const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
    const joinsSql = this.buildJoins(joins);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
    const whereSql = where ? sql` where ${where}` : void 0;
    const orderBySql = this.buildOrderBy(orderBy);
    const limitSql = this.buildLimit(limit);
    return sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}${orderBySql}${limitSql}`;
  }
  /**
   * Builds selection SQL with provided fields/expressions
   *
   * Examples:
   *
   * `select <selection> from`
   *
   * `insert ... returning <selection>`
   *
   * If `isSingleTable` is true, then columns won't be prefixed with table name
   */
  buildSelection(fields, { isSingleTable = false } = {}) {
    const columnsLen = fields.length;
    const chunks = fields.flatMap(({ field }, i) => {
      const chunk = [];
      if (is(field, SQL.Aliased) && field.isSelectionField) {
        chunk.push(sql.identifier(field.fieldAlias));
      } else if (is(field, SQL.Aliased) || is(field, SQL)) {
        const query = is(field, SQL.Aliased) ? field.sql : field;
        if (isSingleTable) {
          chunk.push(
            new SQL(
              query.queryChunks.map((c) => {
                if (is(c, Column)) {
                  return sql.identifier(this.casing.getColumnCasing(c));
                }
                return c;
              })
            )
          );
        } else {
          chunk.push(query);
        }
        if (is(field, SQL.Aliased)) {
          chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
        }
      } else if (is(field, Column)) {
        const tableName = field.table[Table.Symbol.Name];
        if (field.columnType === "SQLiteNumericBigInt") {
          if (isSingleTable) {
            chunk.push(
              sql`cast(${sql.identifier(this.casing.getColumnCasing(field))} as text)`
            );
          } else {
            chunk.push(
              sql`cast(${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))} as text)`
            );
          }
        } else {
          if (isSingleTable) {
            chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
          } else {
            chunk.push(
              sql`${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))}`
            );
          }
        }
      } else if (is(field, Subquery)) {
        const entries = Object.entries(field._.selectedFields);
        if (entries.length === 1) {
          const entry = entries[0][1];
          const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
          if (fieldDecoder) field._.sql.decoder = fieldDecoder;
        }
        chunk.push(field);
      }
      if (i < columnsLen - 1) {
        chunk.push(sql`, `);
      }
      return chunk;
    });
    return sql.join(chunks);
  }
  buildJoins(joins) {
    if (!joins || joins.length === 0) {
      return void 0;
    }
    const joinsArray = [];
    if (joins) {
      for (const [index4, joinMeta] of joins.entries()) {
        if (index4 === 0) {
          joinsArray.push(sql` `);
        }
        const table = joinMeta.table;
        const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
        if (is(table, SQLiteTable)) {
          const tableName = table[SQLiteTable.Symbol.Name];
          const tableSchema = table[SQLiteTable.Symbol.Schema];
          const origTableName = table[SQLiteTable.Symbol.OriginalName];
          const alias = tableName === origTableName ? void 0 : joinMeta.alias;
          joinsArray.push(
            sql`${sql.raw(joinMeta.joinType)} join ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(
              origTableName
            )}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
          );
        } else {
          joinsArray.push(
            sql`${sql.raw(joinMeta.joinType)} join ${table}${onSql}`
          );
        }
        if (index4 < joins.length - 1) {
          joinsArray.push(sql` `);
        }
      }
    }
    return sql.join(joinsArray);
  }
  buildLimit(limit) {
    return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
  }
  buildOrderBy(orderBy) {
    const orderByList = [];
    if (orderBy) {
      for (const [index4, orderByValue] of orderBy.entries()) {
        orderByList.push(orderByValue);
        if (index4 < orderBy.length - 1) {
          orderByList.push(sql`, `);
        }
      }
    }
    return orderByList.length > 0 ? sql` order by ${sql.join(orderByList)}` : void 0;
  }
  buildFromTable(table) {
    if (is(table, Table) && table[Table.Symbol.IsAlias]) {
      return sql`${sql`${sql.identifier(table[Table.Symbol.Schema] ?? "")}.`.if(table[Table.Symbol.Schema])}${sql.identifier(
        table[Table.Symbol.OriginalName]
      )} ${sql.identifier(table[Table.Symbol.Name])}`;
    }
    return table;
  }
  buildSelectQuery({
    withList,
    fields,
    fieldsFlat,
    where,
    having,
    table,
    joins,
    orderBy,
    groupBy,
    limit,
    offset,
    distinct,
    setOperators
  }) {
    const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
    for (const f of fieldsList) {
      if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, SQLiteViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(
        ({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])
      ))(f.field.table)) {
        const tableName = getTableName(f.field.table);
        throw new Error(
          `Your "${f.path.join(
            "->"
          )}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`
        );
      }
    }
    const isSingleTable = !joins || joins.length === 0;
    const withSql = this.buildWithCTE(withList);
    const distinctSql = distinct ? sql` distinct` : void 0;
    const selection = this.buildSelection(fieldsList, { isSingleTable });
    const tableSql = this.buildFromTable(table);
    const joinsSql = this.buildJoins(joins);
    const whereSql = where ? sql` where ${where}` : void 0;
    const havingSql = having ? sql` having ${having}` : void 0;
    const groupByList = [];
    if (groupBy) {
      for (const [index4, groupByValue] of groupBy.entries()) {
        groupByList.push(groupByValue);
        if (index4 < groupBy.length - 1) {
          groupByList.push(sql`, `);
        }
      }
    }
    const groupBySql = groupByList.length > 0 ? sql` group by ${sql.join(groupByList)}` : void 0;
    const orderBySql = this.buildOrderBy(orderBy);
    const limitSql = this.buildLimit(limit);
    const offsetSql = offset ? sql` offset ${offset}` : void 0;
    const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}`;
    if (setOperators.length > 0) {
      return this.buildSetOperations(finalQuery, setOperators);
    }
    return finalQuery;
  }
  buildSetOperations(leftSelect, setOperators) {
    const [setOperator, ...rest] = setOperators;
    if (!setOperator) {
      throw new Error("Cannot pass undefined values to any set operator");
    }
    if (rest.length === 0) {
      return this.buildSetOperationQuery({ leftSelect, setOperator });
    }
    return this.buildSetOperations(
      this.buildSetOperationQuery({ leftSelect, setOperator }),
      rest
    );
  }
  buildSetOperationQuery({
    leftSelect,
    setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
  }) {
    const leftChunk = sql`${leftSelect.getSQL()} `;
    const rightChunk = sql`${rightSelect.getSQL()}`;
    let orderBySql;
    if (orderBy && orderBy.length > 0) {
      const orderByValues = [];
      for (const singleOrderBy of orderBy) {
        if (is(singleOrderBy, SQLiteColumn)) {
          orderByValues.push(sql.identifier(singleOrderBy.name));
        } else if (is(singleOrderBy, SQL)) {
          for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
            const chunk = singleOrderBy.queryChunks[i];
            if (is(chunk, SQLiteColumn)) {
              singleOrderBy.queryChunks[i] = sql.identifier(
                this.casing.getColumnCasing(chunk)
              );
            }
          }
          orderByValues.push(sql`${singleOrderBy}`);
        } else {
          orderByValues.push(sql`${singleOrderBy}`);
        }
      }
      orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)}`;
    }
    const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
    const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
    const offsetSql = offset ? sql` offset ${offset}` : void 0;
    return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
  }
  buildInsertQuery({
    table,
    values: valuesOrSelect,
    onConflict,
    returning,
    withList,
    select
  }) {
    const valuesSqlList = [];
    const columns = table[Table.Symbol.Columns];
    const colEntries = Object.entries(columns).filter(
      ([_, col]) => !col.shouldDisableInsert()
    );
    const insertOrder = colEntries.map(([, column]) => sql.identifier(this.casing.getColumnCasing(column)));
    if (select) {
      const select2 = valuesOrSelect;
      if (is(select2, SQL)) {
        valuesSqlList.push(select2);
      } else {
        valuesSqlList.push(select2.getSQL());
      }
    } else {
      const values = valuesOrSelect;
      valuesSqlList.push(sql.raw("values "));
      for (const [valueIndex, value] of values.entries()) {
        const valueList = [];
        for (const [fieldName2, col] of colEntries) {
          const colValue = value[fieldName2];
          if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
            let defaultValue;
            if (col.default !== null && col.default !== void 0) {
              defaultValue = is(col.default, SQL) ? col.default : sql.param(col.default, col);
            } else if (col.defaultFn !== void 0) {
              const defaultFnResult = col.defaultFn();
              defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
            } else if (!col.default && col.onUpdateFn !== void 0) {
              const onUpdateFnResult = col.onUpdateFn();
              defaultValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
            } else {
              defaultValue = sql`null`;
            }
            valueList.push(defaultValue);
          } else {
            valueList.push(colValue);
          }
        }
        valuesSqlList.push(valueList);
        if (valueIndex < values.length - 1) {
          valuesSqlList.push(sql`, `);
        }
      }
    }
    const withSql = this.buildWithCTE(withList);
    const valuesSql = sql.join(valuesSqlList);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
    const onConflictSql = onConflict?.length ? sql.join(onConflict) : void 0;
    return sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflictSql}${returningSql}`;
  }
  sqlToQuery(sql2, invokeSource) {
    return sql2.toQuery({
      casing: this.casing,
      escapeName: this.escapeName,
      escapeParam: this.escapeParam,
      escapeString: this.escapeString,
      invokeSource
    });
  }
  buildRelationalQuery({
    fullSchema,
    schema,
    tableNamesMap,
    table,
    tableConfig,
    queryConfig: config,
    tableAlias,
    nestedQueryRelation,
    joinOn
  }) {
    let selection = [];
    let limit, offset, orderBy = [], where;
    const joins = [];
    if (config === true) {
      const selectionEntries = Object.entries(tableConfig.columns);
      selection = selectionEntries.map(([key, value]) => ({
        dbKey: value.name,
        tsKey: key,
        field: aliasedTableColumn(value, tableAlias),
        relationTableTsKey: void 0,
        isJson: false,
        selection: []
      }));
    } else {
      const aliasedColumns = Object.fromEntries(
        Object.entries(tableConfig.columns).map(([key, value]) => [
          key,
          aliasedTableColumn(value, tableAlias)
        ])
      );
      if (config.where) {
        const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
        where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
      }
      const fieldsSelection = [];
      let selectedColumns = [];
      if (config.columns) {
        let isIncludeMode = false;
        for (const [field, value] of Object.entries(config.columns)) {
          if (value === void 0) {
            continue;
          }
          if (field in tableConfig.columns) {
            if (!isIncludeMode && value === true) {
              isIncludeMode = true;
            }
            selectedColumns.push(field);
          }
        }
        if (selectedColumns.length > 0) {
          selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter(
            (key) => !selectedColumns.includes(key)
          );
        }
      } else {
        selectedColumns = Object.keys(tableConfig.columns);
      }
      for (const field of selectedColumns) {
        const column = tableConfig.columns[field];
        fieldsSelection.push({ tsKey: field, value: column });
      }
      let selectedRelations = [];
      if (config.with) {
        selectedRelations = Object.entries(config.with).filter(
          (entry) => !!entry[1]
        ).map(([tsKey, queryConfig]) => ({
          tsKey,
          queryConfig,
          relation: tableConfig.relations[tsKey]
        }));
      }
      let extras;
      if (config.extras) {
        extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
        for (const [tsKey, value] of Object.entries(extras)) {
          fieldsSelection.push({
            tsKey,
            value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
          });
        }
      }
      for (const { tsKey, value } of fieldsSelection) {
        selection.push({
          dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
          tsKey,
          field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
          relationTableTsKey: void 0,
          isJson: false,
          selection: []
        });
      }
      let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
      if (!Array.isArray(orderByOrig)) {
        orderByOrig = [orderByOrig];
      }
      orderBy = orderByOrig.map((orderByValue) => {
        if (is(orderByValue, Column)) {
          return aliasedTableColumn(orderByValue, tableAlias);
        }
        return mapColumnsInSQLToAlias(orderByValue, tableAlias);
      });
      limit = config.limit;
      offset = config.offset;
      for (const {
        tsKey: selectedRelationTsKey,
        queryConfig: selectedRelationConfigValue,
        relation
      } of selectedRelations) {
        const normalizedRelation = normalizeRelation(
          schema,
          tableNamesMap,
          relation
        );
        const relationTableName = getTableUniqueName(relation.referencedTable);
        const relationTableTsName = tableNamesMap[relationTableName];
        const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
        const joinOn2 = and(
          ...normalizedRelation.fields.map(
            (field2, i) => eq(
              aliasedTableColumn(
                normalizedRelation.references[i],
                relationTableAlias
              ),
              aliasedTableColumn(field2, tableAlias)
            )
          )
        );
        const builtRelation = this.buildRelationalQuery({
          fullSchema,
          schema,
          tableNamesMap,
          table: fullSchema[relationTableTsName],
          tableConfig: schema[relationTableTsName],
          queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
          tableAlias: relationTableAlias,
          joinOn: joinOn2,
          nestedQueryRelation: relation
        });
        const field = sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
        selection.push({
          dbKey: selectedRelationTsKey,
          tsKey: selectedRelationTsKey,
          field,
          relationTableTsKey: relationTableTsName,
          isJson: true,
          selection: builtRelation.selection
        });
      }
    }
    if (selection.length === 0) {
      throw new DrizzleError({
        message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.`
      });
    }
    let result;
    where = and(joinOn, where);
    if (nestedQueryRelation) {
      let field = sql`json_array(${sql.join(
        selection.map(
          ({ field: field2 }) => is(field2, SQLiteColumn) ? sql.identifier(this.casing.getColumnCasing(field2)) : is(field2, SQL.Aliased) ? field2.sql : field2
        ),
        sql`, `
      )})`;
      if (is(nestedQueryRelation, Many)) {
        field = sql`coalesce(json_group_array(${field}), json_array())`;
      }
      const nestedSelection = [
        {
          dbKey: "data",
          tsKey: "data",
          field: field.as("data"),
          isJson: true,
          relationTableTsKey: tableConfig.tsName,
          selection
        }
      ];
      const needsSubquery = limit !== void 0 || offset !== void 0 || orderBy.length > 0;
      if (needsSubquery) {
        result = this.buildSelectQuery({
          table: aliasedTable(table, tableAlias),
          fields: {},
          fieldsFlat: [
            {
              path: [],
              field: sql.raw("*")
            }
          ],
          where,
          limit,
          offset,
          orderBy,
          setOperators: []
        });
        where = void 0;
        limit = void 0;
        offset = void 0;
        orderBy = void 0;
      } else {
        result = aliasedTable(table, tableAlias);
      }
      result = this.buildSelectQuery({
        table: is(result, SQLiteTable) ? result : new Subquery(result, {}, tableAlias),
        fields: {},
        fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
          path: [],
          field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    } else {
      result = this.buildSelectQuery({
        table: aliasedTable(table, tableAlias),
        fields: {},
        fieldsFlat: selection.map(({ field }) => ({
          path: [],
          field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    }
    return {
      tableTsKey: tableConfig.tsName,
      sql: result,
      selection
    };
  }
};
var SQLiteSyncDialect = class extends SQLiteDialect {
  static [entityKind] = "SQLiteSyncDialect";
  migrate(migrations, session, config) {
    const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
    const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
    session.run(migrationTableCreate);
    const dbMigrations = session.values(
      sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`
    );
    const lastDbMigration = dbMigrations[0] ?? void 0;
    session.run(sql`BEGIN`);
    try {
      for (const migration of migrations) {
        if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
          for (const stmt of migration.sql) {
            session.run(sql.raw(stmt));
          }
          session.run(
            sql`INSERT INTO ${sql.identifier(
              migrationsTable
            )} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`
          );
        }
      }
      session.run(sql`COMMIT`);
    } catch (e) {
      session.run(sql`ROLLBACK`);
      throw e;
    }
  }
};
var SQLiteAsyncDialect = class extends SQLiteDialect {
  static [entityKind] = "SQLiteAsyncDialect";
  async migrate(migrations, session, config) {
    const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
    const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
    await session.run(migrationTableCreate);
    const dbMigrations = await session.values(
      sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`
    );
    const lastDbMigration = dbMigrations[0] ?? void 0;
    await session.transaction(async (tx) => {
      for (const migration of migrations) {
        if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
          for (const stmt of migration.sql) {
            await tx.run(sql.raw(stmt));
          }
          await tx.run(
            sql`INSERT INTO ${sql.identifier(
              migrationsTable
            )} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`
          );
        }
      }
    });
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
init_subquery();

// node_modules/drizzle-orm/sqlite-core/query-builders/select.js
init_entity();
init_query_builder();
init_query_promise();
init_selection_proxy();
init_sql();
init_subquery();
init_table();
init_utils();
init_view_common();
var SQLiteSelectBuilder = class {
  static [entityKind] = "SQLiteSelectBuilder";
  fields;
  session;
  dialect;
  withList;
  distinct;
  constructor(config) {
    this.fields = config.fields;
    this.session = config.session;
    this.dialect = config.dialect;
    this.withList = config.withList;
    this.distinct = config.distinct;
  }
  from(source) {
    const isPartialSelect = !!this.fields;
    let fields;
    if (this.fields) {
      fields = this.fields;
    } else if (is(source, Subquery)) {
      fields = Object.fromEntries(
        Object.keys(source._.selectedFields).map((key) => [key, source[key]])
      );
    } else if (is(source, SQLiteViewBase)) {
      fields = source[ViewBaseConfig].selectedFields;
    } else if (is(source, SQL)) {
      fields = {};
    } else {
      fields = getTableColumns(source);
    }
    return new SQLiteSelectBase({
      table: source,
      fields,
      isPartialSelect,
      session: this.session,
      dialect: this.dialect,
      withList: this.withList,
      distinct: this.distinct
    });
  }
};
var SQLiteSelectQueryBuilderBase = class extends TypedQueryBuilder {
  static [entityKind] = "SQLiteSelectQueryBuilder";
  _;
  /** @internal */
  config;
  joinsNotNullableMap;
  tableName;
  isPartialSelect;
  session;
  dialect;
  cacheConfig = void 0;
  usedTables = /* @__PURE__ */ new Set();
  constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
    super();
    this.config = {
      withList,
      table,
      fields: { ...fields },
      distinct,
      setOperators: []
    };
    this.isPartialSelect = isPartialSelect;
    this.session = session;
    this.dialect = dialect;
    this._ = {
      selectedFields: fields,
      config: this.config
    };
    this.tableName = getTableLikeName(table);
    this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
    for (const item of extractUsedTable(table)) this.usedTables.add(item);
  }
  /** @internal */
  getUsedTables() {
    return [...this.usedTables];
  }
  createJoin(joinType) {
    return (table, on) => {
      const baseTableName = this.tableName;
      const tableName = getTableLikeName(table);
      for (const item of extractUsedTable(table)) this.usedTables.add(item);
      if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
        throw new Error(`Alias "${tableName}" is already used in this query`);
      }
      if (!this.isPartialSelect) {
        if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
          this.config.fields = {
            [baseTableName]: this.config.fields
          };
        }
        if (typeof tableName === "string" && !is(table, SQL)) {
          const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
          this.config.fields[tableName] = selection;
        }
      }
      if (typeof on === "function") {
        on = on(
          new Proxy(
            this.config.fields,
            new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          )
        );
      }
      if (!this.config.joins) {
        this.config.joins = [];
      }
      this.config.joins.push({ on, table, joinType, alias: tableName });
      if (typeof tableName === "string") {
        switch (joinType) {
          case "left": {
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
          case "right": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "cross":
          case "inner": {
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "full": {
            this.joinsNotNullableMap = Object.fromEntries(
              Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
            );
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
        }
      }
      return this;
    };
  }
  /**
   * Executes a `left join` operation by adding another table to the current query.
   *
   * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
   *   .from(users)
   *   .leftJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .leftJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  leftJoin = this.createJoin("left");
  /**
   * Executes a `right join` operation by adding another table to the current query.
   *
   * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .rightJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .rightJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  rightJoin = this.createJoin("right");
  /**
   * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
   *
   * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .innerJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .innerJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  innerJoin = this.createJoin("inner");
  /**
   * Executes a `full join` operation by combining rows from two tables into a new table.
   *
   * Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
   *
   * @param table the table to join.
   * @param on the `on` clause.
   *
   * @example
   *
   * ```ts
   * // Select all users and their pets
   * const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
   *   .from(users)
   *   .fullJoin(pets, eq(users.id, pets.ownerId))
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .fullJoin(pets, eq(users.id, pets.ownerId))
   * ```
   */
  fullJoin = this.createJoin("full");
  /**
   * Executes a `cross join` operation by combining rows from two tables into a new table.
   *
   * Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
   *
   * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
   *
   * @param table the table to join.
   *
   * @example
   *
   * ```ts
   * // Select all users, each user with every pet
   * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
   *   .from(users)
   *   .crossJoin(pets)
   *
   * // Select userId and petId
   * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
   *   userId: users.id,
   *   petId: pets.id,
   * })
   *   .from(users)
   *   .crossJoin(pets)
   * ```
   */
  crossJoin = this.createJoin("cross");
  createSetOperator(type, isAll) {
    return (rightSelection) => {
      const rightSelect = typeof rightSelection === "function" ? rightSelection(getSQLiteSetOperators()) : rightSelection;
      if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
      this.config.setOperators.push({ type, isAll, rightSelect });
      return this;
    };
  }
  /**
   * Adds `union` set operator to the query.
   *
   * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
   *
   * @example
   *
   * ```ts
   * // Select all unique names from customers and users tables
   * await db.select({ name: users.name })
   *   .from(users)
   *   .union(
   *     db.select({ name: customers.name }).from(customers)
   *   );
   * // or
   * import { union } from 'drizzle-orm/sqlite-core'
   *
   * await union(
   *   db.select({ name: users.name }).from(users),
   *   db.select({ name: customers.name }).from(customers)
   * );
   * ```
   */
  union = this.createSetOperator("union", false);
  /**
   * Adds `union all` set operator to the query.
   *
   * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
   *
   * @example
   *
   * ```ts
   * // Select all transaction ids from both online and in-store sales
   * await db.select({ transaction: onlineSales.transactionId })
   *   .from(onlineSales)
   *   .unionAll(
   *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
   *   );
   * // or
   * import { unionAll } from 'drizzle-orm/sqlite-core'
   *
   * await unionAll(
   *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
   *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
   * );
   * ```
   */
  unionAll = this.createSetOperator("union", true);
  /**
   * Adds `intersect` set operator to the query.
   *
   * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
   *
   * @example
   *
   * ```ts
   * // Select course names that are offered in both departments A and B
   * await db.select({ courseName: depA.courseName })
   *   .from(depA)
   *   .intersect(
   *     db.select({ courseName: depB.courseName }).from(depB)
   *   );
   * // or
   * import { intersect } from 'drizzle-orm/sqlite-core'
   *
   * await intersect(
   *   db.select({ courseName: depA.courseName }).from(depA),
   *   db.select({ courseName: depB.courseName }).from(depB)
   * );
   * ```
   */
  intersect = this.createSetOperator("intersect", false);
  /**
   * Adds `except` set operator to the query.
   *
   * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
   *
   * @example
   *
   * ```ts
   * // Select all courses offered in department A but not in department B
   * await db.select({ courseName: depA.courseName })
   *   .from(depA)
   *   .except(
   *     db.select({ courseName: depB.courseName }).from(depB)
   *   );
   * // or
   * import { except } from 'drizzle-orm/sqlite-core'
   *
   * await except(
   *   db.select({ courseName: depA.courseName }).from(depA),
   *   db.select({ courseName: depB.courseName }).from(depB)
   * );
   * ```
   */
  except = this.createSetOperator("except", false);
  /** @internal */
  addSetOperators(setOperators) {
    this.config.setOperators.push(...setOperators);
    return this;
  }
  /**
   * Adds a `where` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
   *
   * @param where the `where` clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be selected.
   *
   * ```ts
   * // Select all cars with green color
   * await db.select().from(cars).where(eq(cars.color, 'green'));
   * // or
   * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Select all BMW cars with a green color
   * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Select all cars with the green or blue color
   * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    if (typeof where === "function") {
      where = where(
        new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
        )
      );
    }
    this.config.where = where;
    return this;
  }
  /**
   * Adds a `having` clause to the query.
   *
   * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
   *
   * @param having the `having` clause.
   *
   * @example
   *
   * ```ts
   * // Select all brands with more than one car
   * await db.select({
   * 	brand: cars.brand,
   * 	count: sql<number>`cast(count(${cars.id}) as int)`,
   * })
   *   .from(cars)
   *   .groupBy(cars.brand)
   *   .having(({ count }) => gt(count, 1));
   * ```
   */
  having(having) {
    if (typeof having === "function") {
      having = having(
        new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
        )
      );
    }
    this.config.having = having;
    return this;
  }
  groupBy(...columns) {
    if (typeof columns[0] === "function") {
      const groupBy = columns[0](
        new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
    } else {
      this.config.groupBy = columns;
    }
    return this;
  }
  orderBy(...columns) {
    if (typeof columns[0] === "function") {
      const orderBy = columns[0](
        new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    } else {
      const orderByArray = columns;
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    }
    return this;
  }
  /**
   * Adds a `limit` clause to the query.
   *
   * Calling this method will set the maximum number of rows that will be returned by this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param limit the `limit` clause.
   *
   * @example
   *
   * ```ts
   * // Get the first 10 people from this query.
   * await db.select().from(people).limit(10);
   * ```
   */
  limit(limit) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).limit = limit;
    } else {
      this.config.limit = limit;
    }
    return this;
  }
  /**
   * Adds an `offset` clause to the query.
   *
   * Calling this method will skip a number of rows when returning results from this query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
   *
   * @param offset the `offset` clause.
   *
   * @example
   *
   * ```ts
   * // Get the 10th-20th people from this query.
   * await db.select().from(people).offset(10).limit(10);
   * ```
   */
  offset(offset) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).offset = offset;
    } else {
      this.config.offset = offset;
    }
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildSelectQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  as(alias) {
    const usedTables = [];
    usedTables.push(...extractUsedTable(this.config.table));
    if (this.config.joins) {
      for (const it of this.config.joins) usedTables.push(...extractUsedTable(it.table));
    }
    return new Proxy(
      new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]),
      new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  /** @internal */
  getSelectedFields() {
    return new Proxy(
      this.config.fields,
      new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
    );
  }
  $dynamic() {
    return this;
  }
};
var SQLiteSelectBase = class extends SQLiteSelectQueryBuilderBase {
  static [entityKind] = "SQLiteSelect";
  /** @internal */
  _prepare(isOneTimeQuery = true) {
    if (!this.session) {
      throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
    }
    const fieldsList = orderSelectedFields(this.config.fields);
    const query = this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      fieldsList,
      "all",
      true,
      void 0,
      {
        type: "select",
        tables: [...this.usedTables]
      },
      this.cacheConfig
    );
    query.joinsNotNullableMap = this.joinsNotNullableMap;
    return query;
  }
  $withCache(config) {
    this.cacheConfig = config === void 0 ? { config: {}, enable: true, autoInvalidate: true } : config === false ? { enable: false } : { enable: true, autoInvalidate: true, ...config };
    return this;
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.all();
  }
};
applyMixins(SQLiteSelectBase, [QueryPromise]);
function createSetOperator(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
var getSQLiteSetOperators = () => ({
  union,
  unionAll,
  intersect,
  except
});
var union = createSetOperator("union", false);
var unionAll = createSetOperator("union", true);
var intersect = createSetOperator("intersect", false);
var except = createSetOperator("except", false);

// node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
var QueryBuilder = class {
  static [entityKind] = "SQLiteQueryBuilder";
  dialect;
  dialectConfig;
  constructor(dialect) {
    this.dialect = is(dialect, SQLiteDialect) ? dialect : void 0;
    this.dialectConfig = is(dialect, SQLiteDialect) ? void 0 : dialect;
  }
  $with = (alias, selection) => {
    const queryBuilder = this;
    const as = (qb) => {
      if (typeof qb === "function") {
        qb = qb(queryBuilder);
      }
      return new Proxy(
        new WithSubquery(
          qb.getSQL(),
          selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
          alias,
          true
        ),
        new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      );
    };
    return { as };
  };
  with(...queries) {
    const self = this;
    function select(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? void 0,
        session: void 0,
        dialect: self.getDialect(),
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? void 0,
        session: void 0,
        dialect: self.getDialect(),
        withList: queries,
        distinct: true
      });
    }
    return { select, selectDistinct };
  }
  select(fields) {
    return new SQLiteSelectBuilder({ fields: fields ?? void 0, session: void 0, dialect: this.getDialect() });
  }
  selectDistinct(fields) {
    return new SQLiteSelectBuilder({
      fields: fields ?? void 0,
      session: void 0,
      dialect: this.getDialect(),
      distinct: true
    });
  }
  // Lazy load dialect to avoid circular dependency
  getDialect() {
    if (!this.dialect) {
      this.dialect = new SQLiteSyncDialect(this.dialectConfig);
    }
    return this.dialect;
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
var SQLiteInsertBuilder = class {
  constructor(table, session, dialect, withList) {
    this.table = table;
    this.session = session;
    this.dialect = dialect;
    this.withList = withList;
  }
  static [entityKind] = "SQLiteInsertBuilder";
  values(values) {
    values = Array.isArray(values) ? values : [values];
    if (values.length === 0) {
      throw new Error("values() must be called with at least one value");
    }
    const mappedValues = values.map((entry) => {
      const result = {};
      const cols = this.table[Table.Symbol.Columns];
      for (const colKey of Object.keys(entry)) {
        const colValue = entry[colKey];
        result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
      }
      return result;
    });
    return new SQLiteInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList);
  }
  select(selectQuery) {
    const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder()) : selectQuery;
    if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) {
      throw new Error(
        "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
      );
    }
    return new SQLiteInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
  }
};
var SQLiteInsertBase = class extends QueryPromise {
  constructor(table, values, session, dialect, withList, select) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { table, values, withList, select };
  }
  static [entityKind] = "SQLiteInsert";
  /** @internal */
  config;
  returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  /**
   * Adds an `on conflict do nothing` clause to the query.
   *
   * Calling this method simply avoids inserting a row as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
   *
   * @param config The `target` and `where` clauses.
   *
   * @example
   * ```ts
   * // Insert one row and cancel the insert if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing();
   *
   * // Explicitly specify conflict target
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoNothing({ target: cars.id });
   * ```
   */
  onConflictDoNothing(config = {}) {
    if (!this.config.onConflict) this.config.onConflict = [];
    if (config.target === void 0) {
      this.config.onConflict.push(sql` on conflict do nothing`);
    } else {
      const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
      const whereSql = config.where ? sql` where ${config.where}` : sql``;
      this.config.onConflict.push(sql` on conflict ${targetSql} do nothing${whereSql}`);
    }
    return this;
  }
  /**
   * Adds an `on conflict do update` clause to the query.
   *
   * Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
   *
   * @param config The `target`, `set` and `where` clauses.
   *
   * @example
   * ```ts
   * // Update the row if there's a conflict
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'Porsche' }
   *   });
   *
   * // Upsert with 'where' clause
   * await db.insert(cars)
   *   .values({ id: 1, brand: 'BMW' })
   *   .onConflictDoUpdate({
   *     target: cars.id,
   *     set: { brand: 'newBMW' },
   *     where: sql`${cars.createdAt} > '2023-01-01'::date`,
   *   });
   * ```
   */
  onConflictDoUpdate(config) {
    if (config.where && (config.targetWhere || config.setWhere)) {
      throw new Error(
        'You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.'
      );
    }
    if (!this.config.onConflict) this.config.onConflict = [];
    const whereSql = config.where ? sql` where ${config.where}` : void 0;
    const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : void 0;
    const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : void 0;
    const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
    const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
    this.config.onConflict.push(
      sql` on conflict ${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`
    );
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildInsertQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      true,
      void 0,
      {
        type: "insert",
        tables: extractUsedTable(this.config.table)
      }
    );
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/update.js
init_entity();
init_query_promise();
init_selection_proxy();
init_subquery();
init_table();
init_utils();
init_view_common();
var SQLiteUpdateBuilder = class {
  constructor(table, session, dialect, withList) {
    this.table = table;
    this.session = session;
    this.dialect = dialect;
    this.withList = withList;
  }
  static [entityKind] = "SQLiteUpdateBuilder";
  set(values) {
    return new SQLiteUpdateBase(
      this.table,
      mapUpdateSet(this.table, values),
      this.session,
      this.dialect,
      this.withList
    );
  }
};
var SQLiteUpdateBase = class extends QueryPromise {
  constructor(table, set, session, dialect, withList) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { set, table, withList, joins: [] };
  }
  static [entityKind] = "SQLiteUpdate";
  /** @internal */
  config;
  from(source) {
    this.config.from = source;
    return this;
  }
  createJoin(joinType) {
    return (table, on) => {
      const tableName = getTableLikeName(table);
      if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) {
        throw new Error(`Alias "${tableName}" is already used in this query`);
      }
      if (typeof on === "function") {
        const from = this.config.from ? is(table, SQLiteTable) ? table[Table.Symbol.Columns] : is(table, Subquery) ? table._.selectedFields : is(table, SQLiteViewBase) ? table[ViewBaseConfig].selectedFields : void 0 : void 0;
        on = on(
          new Proxy(
            this.config.table[Table.Symbol.Columns],
            new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          ),
          from && new Proxy(
            from,
            new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
          )
        );
      }
      this.config.joins.push({ on, table, joinType, alias: tableName });
      return this;
    };
  }
  leftJoin = this.createJoin("left");
  rightJoin = this.createJoin("right");
  innerJoin = this.createJoin("inner");
  fullJoin = this.createJoin("full");
  /**
   * Adds a 'where' clause to the query.
   *
   * Calling this method will update only those rows that fulfill a specified condition.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param where the 'where' clause.
   *
   * @example
   * You can use conditional operators and `sql function` to filter the rows to be updated.
   *
   * ```ts
   * // Update all cars with green color
   * db.update(cars).set({ color: 'red' })
   *   .where(eq(cars.color, 'green'));
   * // or
   * db.update(cars).set({ color: 'red' })
   *   .where(sql`${cars.color} = 'green'`)
   * ```
   *
   * You can logically combine conditional operators with `and()` and `or()` operators:
   *
   * ```ts
   * // Update all BMW cars with a green color
   * db.update(cars).set({ color: 'red' })
   *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
   *
   * // Update all cars with the green or blue color
   * db.update(cars).set({ color: 'red' })
   *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
   * ```
   */
  where(where) {
    this.config.where = where;
    return this;
  }
  orderBy(...columns) {
    if (typeof columns[0] === "function") {
      const orderBy = columns[0](
        new Proxy(
          this.config.table[Table.Symbol.Columns],
          new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
        )
      );
      const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
      this.config.orderBy = orderByArray;
    } else {
      const orderByArray = columns;
      this.config.orderBy = orderByArray;
    }
    return this;
  }
  limit(limit) {
    this.config.limit = limit;
    return this;
  }
  returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  /** @internal */
  getSQL() {
    return this.dialect.buildUpdateQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  /** @internal */
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](
      this.dialect.sqlToQuery(this.getSQL()),
      this.config.returning,
      this.config.returning ? "all" : "run",
      true,
      void 0,
      {
        type: "insert",
        tables: extractUsedTable(this.config.table)
      }
    );
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
};

// node_modules/drizzle-orm/sqlite-core/db.js
init_subquery();

// node_modules/drizzle-orm/sqlite-core/query-builders/count.js
init_entity();
init_sql();
var SQLiteCountBuilder = class _SQLiteCountBuilder extends SQL {
  constructor(params) {
    super(_SQLiteCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
    this.params = params;
    this.session = params.session;
    this.sql = _SQLiteCountBuilder.buildCount(
      params.source,
      params.filters
    );
  }
  sql;
  static [entityKind] = "SQLiteCountBuilderAsync";
  [Symbol.toStringTag] = "SQLiteCountBuilderAsync";
  session;
  static buildEmbeddedCount(source, filters) {
    return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
  }
  static buildCount(source, filters) {
    return sql`select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters}`;
  }
  then(onfulfilled, onrejected) {
    return Promise.resolve(this.session.count(this.sql)).then(
      onfulfilled,
      onrejected
    );
  }
  catch(onRejected) {
    return this.then(void 0, onRejected);
  }
  finally(onFinally) {
    return this.then(
      (value) => {
        onFinally?.();
        return value;
      },
      (reason) => {
        onFinally?.();
        throw reason;
      }
    );
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/query.js
init_entity();
init_query_promise();
init_relations();
var RelationalQueryBuilder = class {
  constructor(mode, fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
    this.mode = mode;
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table;
    this.tableConfig = tableConfig;
    this.dialect = dialect;
    this.session = session;
  }
  static [entityKind] = "SQLiteAsyncRelationalQueryBuilder";
  findMany(config) {
    return this.mode === "sync" ? new SQLiteSyncRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? config : {},
      "many"
    ) : new SQLiteRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? config : {},
      "many"
    );
  }
  findFirst(config) {
    return this.mode === "sync" ? new SQLiteSyncRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? { ...config, limit: 1 } : { limit: 1 },
      "first"
    ) : new SQLiteRelationalQuery(
      this.fullSchema,
      this.schema,
      this.tableNamesMap,
      this.table,
      this.tableConfig,
      this.dialect,
      this.session,
      config ? { ...config, limit: 1 } : { limit: 1 },
      "first"
    );
  }
};
var SQLiteRelationalQuery = class extends QueryPromise {
  constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
    super();
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table;
    this.tableConfig = tableConfig;
    this.dialect = dialect;
    this.session = session;
    this.config = config;
    this.mode = mode;
  }
  static [entityKind] = "SQLiteAsyncRelationalQuery";
  /** @internal */
  mode;
  /** @internal */
  getSQL() {
    return this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    }).sql;
  }
  /** @internal */
  _prepare(isOneTimeQuery = false) {
    const { query, builtQuery } = this._toSQL();
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](
      builtQuery,
      void 0,
      this.mode === "first" ? "get" : "all",
      true,
      (rawRows, mapColumnValue) => {
        const rows = rawRows.map(
          (row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue)
        );
        if (this.mode === "first") {
          return rows[0];
        }
        return rows;
      }
    );
  }
  prepare() {
    return this._prepare(false);
  }
  _toSQL() {
    const query = this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    });
    const builtQuery = this.dialect.sqlToQuery(query.sql);
    return { query, builtQuery };
  }
  toSQL() {
    return this._toSQL().builtQuery;
  }
  /** @internal */
  executeRaw() {
    if (this.mode === "first") {
      return this._prepare(false).get();
    }
    return this._prepare(false).all();
  }
  async execute() {
    return this.executeRaw();
  }
};
var SQLiteSyncRelationalQuery = class extends SQLiteRelationalQuery {
  static [entityKind] = "SQLiteSyncRelationalQuery";
  sync() {
    return this.executeRaw();
  }
};

// node_modules/drizzle-orm/sqlite-core/query-builders/raw.js
init_entity();
init_query_promise();
var SQLiteRaw = class extends QueryPromise {
  constructor(execute, getSQL, action, dialect, mapBatchResult) {
    super();
    this.execute = execute;
    this.getSQL = getSQL;
    this.dialect = dialect;
    this.mapBatchResult = mapBatchResult;
    this.config = { action };
  }
  static [entityKind] = "SQLiteRaw";
  /** @internal */
  config;
  getQuery() {
    return { ...this.dialect.sqlToQuery(this.getSQL()), method: this.config.action };
  }
  mapResult(result, isFromBatch) {
    return isFromBatch ? this.mapBatchResult(result) : result;
  }
  _prepare() {
    return this;
  }
  /** @internal */
  isResponseInArrayMode() {
    return false;
  }
};

// node_modules/drizzle-orm/sqlite-core/db.js
var BaseSQLiteDatabase = class {
  constructor(resultKind, dialect, session, schema) {
    this.resultKind = resultKind;
    this.dialect = dialect;
    this.session = session;
    this._ = schema ? {
      schema: schema.schema,
      fullSchema: schema.fullSchema,
      tableNamesMap: schema.tableNamesMap
    } : {
      schema: void 0,
      fullSchema: {},
      tableNamesMap: {}
    };
    this.query = {};
    const query = this.query;
    if (this._.schema) {
      for (const [tableName, columns] of Object.entries(this._.schema)) {
        query[tableName] = new RelationalQueryBuilder(
          resultKind,
          schema.fullSchema,
          this._.schema,
          this._.tableNamesMap,
          schema.fullSchema[tableName],
          columns,
          dialect,
          session
        );
      }
    }
    this.$cache = { invalidate: async (_params) => {
    } };
  }
  static [entityKind] = "BaseSQLiteDatabase";
  query;
  /**
   * Creates a subquery that defines a temporary named result set as a CTE.
   *
   * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
   *
   * @param alias The alias for the subquery.
   *
   * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
   *
   * @example
   *
   * ```ts
   * // Create a subquery with alias 'sq' and use it in the select query
   * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
   *
   * const result = await db.with(sq).select().from(sq);
   * ```
   *
   * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
   *
   * ```ts
   * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
   * const sq = db.$with('sq').as(db.select({
   *   name: sql<string>`upper(${users.name})`.as('name'),
   * })
   * .from(users));
   *
   * const result = await db.with(sq).select({ name: sq.name }).from(sq);
   * ```
   */
  $with = (alias, selection) => {
    const self = this;
    const as = (qb) => {
      if (typeof qb === "function") {
        qb = qb(new QueryBuilder(self.dialect));
      }
      return new Proxy(
        new WithSubquery(
          qb.getSQL(),
          selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
          alias,
          true
        ),
        new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
      );
    };
    return { as };
  };
  $count(source, filters) {
    return new SQLiteCountBuilder({ source, filters, session: this.session });
  }
  /**
   * Incorporates a previously defined CTE (using `$with`) into the main query.
   *
   * This method allows the main query to reference a temporary named result set.
   *
   * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
   *
   * @param queries The CTEs to incorporate into the main query.
   *
   * @example
   *
   * ```ts
   * // Define a subquery 'sq' as a CTE using $with
   * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
   *
   * // Incorporate the CTE 'sq' into the main query and select from it
   * const result = await db.with(sq).select().from(sq);
   * ```
   */
  with(...queries) {
    const self = this;
    function select(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? void 0,
        session: self.session,
        dialect: self.dialect,
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? void 0,
        session: self.session,
        dialect: self.dialect,
        withList: queries,
        distinct: true
      });
    }
    function update(table) {
      return new SQLiteUpdateBuilder(table, self.session, self.dialect, queries);
    }
    function insert(into) {
      return new SQLiteInsertBuilder(into, self.session, self.dialect, queries);
    }
    function delete_(from) {
      return new SQLiteDeleteBase(from, self.session, self.dialect, queries);
    }
    return { select, selectDistinct, update, insert, delete: delete_ };
  }
  select(fields) {
    return new SQLiteSelectBuilder({ fields: fields ?? void 0, session: this.session, dialect: this.dialect });
  }
  selectDistinct(fields) {
    return new SQLiteSelectBuilder({
      fields: fields ?? void 0,
      session: this.session,
      dialect: this.dialect,
      distinct: true
    });
  }
  /**
   * Creates an update query.
   *
   * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
   *
   * Use `.set()` method to specify which values to update.
   *
   * See docs: {@link https://orm.drizzle.team/docs/update}
   *
   * @param table The table to update.
   *
   * @example
   *
   * ```ts
   * // Update all rows in the 'cars' table
   * await db.update(cars).set({ color: 'red' });
   *
   * // Update rows with filters and conditions
   * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
   *
   * // Update with returning clause
   * const updatedCar: Car[] = await db.update(cars)
   *   .set({ color: 'red' })
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  update(table) {
    return new SQLiteUpdateBuilder(table, this.session, this.dialect);
  }
  $cache;
  /**
   * Creates an insert query.
   *
   * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
   *
   * See docs: {@link https://orm.drizzle.team/docs/insert}
   *
   * @param table The table to insert into.
   *
   * @example
   *
   * ```ts
   * // Insert one row
   * await db.insert(cars).values({ brand: 'BMW' });
   *
   * // Insert multiple rows
   * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
   *
   * // Insert with returning clause
   * const insertedCar: Car[] = await db.insert(cars)
   *   .values({ brand: 'BMW' })
   *   .returning();
   * ```
   */
  insert(into) {
    return new SQLiteInsertBuilder(into, this.session, this.dialect);
  }
  /**
   * Creates a delete query.
   *
   * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
   *
   * See docs: {@link https://orm.drizzle.team/docs/delete}
   *
   * @param table The table to delete from.
   *
   * @example
   *
   * ```ts
   * // Delete all rows in the 'cars' table
   * await db.delete(cars);
   *
   * // Delete rows with filters and conditions
   * await db.delete(cars).where(eq(cars.color, 'green'));
   *
   * // Delete with returning clause
   * const deletedCar: Car[] = await db.delete(cars)
   *   .where(eq(cars.id, 1))
   *   .returning();
   * ```
   */
  delete(from) {
    return new SQLiteDeleteBase(from, this.session, this.dialect);
  }
  run(query) {
    const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(
        async () => this.session.run(sequel),
        () => sequel,
        "run",
        this.dialect,
        this.session.extractRawRunValueFromBatchResult.bind(this.session)
      );
    }
    return this.session.run(sequel);
  }
  all(query) {
    const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(
        async () => this.session.all(sequel),
        () => sequel,
        "all",
        this.dialect,
        this.session.extractRawAllValueFromBatchResult.bind(this.session)
      );
    }
    return this.session.all(sequel);
  }
  get(query) {
    const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(
        async () => this.session.get(sequel),
        () => sequel,
        "get",
        this.dialect,
        this.session.extractRawGetValueFromBatchResult.bind(this.session)
      );
    }
    return this.session.get(sequel);
  }
  values(query) {
    const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(
        async () => this.session.values(sequel),
        () => sequel,
        "values",
        this.dialect,
        this.session.extractRawValuesValueFromBatchResult.bind(this.session)
      );
    }
    return this.session.values(sequel);
  }
  transaction(transaction, config) {
    return this.session.transaction(transaction, config);
  }
};

// node_modules/drizzle-orm/d1/session.js
init_core();
init_entity();
init_logger();
init_sql();

// node_modules/drizzle-orm/sqlite-core/alias.js
init_alias();

// node_modules/drizzle-orm/sqlite-core/session.js
init_cache();
init_entity();
init_errors();
init_query_promise();
var ExecuteResultSync = class extends QueryPromise {
  constructor(resultCb) {
    super();
    this.resultCb = resultCb;
  }
  static [entityKind] = "ExecuteResultSync";
  async execute() {
    return this.resultCb();
  }
  sync() {
    return this.resultCb();
  }
};
var SQLitePreparedQuery = class {
  constructor(mode, executeMethod, query, cache, queryMetadata, cacheConfig) {
    this.mode = mode;
    this.executeMethod = executeMethod;
    this.query = query;
    this.cache = cache;
    this.queryMetadata = queryMetadata;
    this.cacheConfig = cacheConfig;
    if (cache && cache.strategy() === "all" && cacheConfig === void 0) {
      this.cacheConfig = { enable: true, autoInvalidate: true };
    }
    if (!this.cacheConfig?.enable) {
      this.cacheConfig = void 0;
    }
  }
  static [entityKind] = "PreparedQuery";
  /** @internal */
  joinsNotNullableMap;
  /** @internal */
  async queryWithCache(queryString, params, query) {
    if (this.cache === void 0 || is(this.cache, NoopCache) || this.queryMetadata === void 0) {
      try {
        return await query();
      } catch (e) {
        throw new DrizzleQueryError(queryString, params, e);
      }
    }
    if (this.cacheConfig && !this.cacheConfig.enable) {
      try {
        return await query();
      } catch (e) {
        throw new DrizzleQueryError(queryString, params, e);
      }
    }
    if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) {
      try {
        const [res] = await Promise.all([
          query(),
          this.cache.onMutate({ tables: this.queryMetadata.tables })
        ]);
        return res;
      } catch (e) {
        throw new DrizzleQueryError(queryString, params, e);
      }
    }
    if (!this.cacheConfig) {
      try {
        return await query();
      } catch (e) {
        throw new DrizzleQueryError(queryString, params, e);
      }
    }
    if (this.queryMetadata.type === "select") {
      const fromCache = await this.cache.get(
        this.cacheConfig.tag ?? await hashQuery(queryString, params),
        this.queryMetadata.tables,
        this.cacheConfig.tag !== void 0,
        this.cacheConfig.autoInvalidate
      );
      if (fromCache === void 0) {
        let result;
        try {
          result = await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
        await this.cache.put(
          this.cacheConfig.tag ?? await hashQuery(queryString, params),
          result,
          // make sure we send tables that were used in a query only if user wants to invalidate it on each write
          this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [],
          this.cacheConfig.tag !== void 0,
          this.cacheConfig.config
        );
        return result;
      }
      return fromCache;
    }
    try {
      return await query();
    } catch (e) {
      throw new DrizzleQueryError(queryString, params, e);
    }
  }
  getQuery() {
    return this.query;
  }
  mapRunResult(result, _isFromBatch) {
    return result;
  }
  mapAllResult(_result, _isFromBatch) {
    throw new Error("Not implemented");
  }
  mapGetResult(_result, _isFromBatch) {
    throw new Error("Not implemented");
  }
  execute(placeholderValues) {
    if (this.mode === "async") {
      return this[this.executeMethod](placeholderValues);
    }
    return new ExecuteResultSync(() => this[this.executeMethod](placeholderValues));
  }
  mapResult(response, isFromBatch) {
    switch (this.executeMethod) {
      case "run": {
        return this.mapRunResult(response, isFromBatch);
      }
      case "all": {
        return this.mapAllResult(response, isFromBatch);
      }
      case "get": {
        return this.mapGetResult(response, isFromBatch);
      }
    }
  }
};
var SQLiteSession = class {
  constructor(dialect) {
    this.dialect = dialect;
  }
  static [entityKind] = "SQLiteSession";
  prepareOneTimeQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
    return this.prepareQuery(
      query,
      fields,
      executeMethod,
      isResponseInArrayMode,
      customResultMapper,
      queryMetadata,
      cacheConfig
    );
  }
  run(query) {
    const staticQuery = this.dialect.sqlToQuery(query);
    try {
      return this.prepareOneTimeQuery(staticQuery, void 0, "run", false).run();
    } catch (err) {
      throw new DrizzleError({ cause: err, message: `Failed to run the query '${staticQuery.sql}'` });
    }
  }
  /** @internal */
  extractRawRunValueFromBatchResult(result) {
    return result;
  }
  all(query) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).all();
  }
  /** @internal */
  extractRawAllValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
  get(query) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).get();
  }
  /** @internal */
  extractRawGetValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
  values(query) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).values();
  }
  async count(sql2) {
    const result = await this.values(sql2);
    return result[0][0];
  }
  /** @internal */
  extractRawValuesValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
};
var SQLiteTransaction = class extends BaseSQLiteDatabase {
  constructor(resultType, dialect, session, schema, nestedIndex = 0) {
    super(resultType, dialect, session, schema);
    this.schema = schema;
    this.nestedIndex = nestedIndex;
  }
  static [entityKind] = "SQLiteTransaction";
  rollback() {
    throw new TransactionRollbackError();
  }
};

// node_modules/drizzle-orm/sqlite-core/view.js
init_entity();
init_selection_proxy();
init_utils();
var ViewBuilderCore = class {
  constructor(name) {
    this.name = name;
  }
  static [entityKind] = "SQLiteViewBuilderCore";
  config = {};
};
var ViewBuilder = class extends ViewBuilderCore {
  static [entityKind] = "SQLiteViewBuilder";
  as(qb) {
    if (typeof qb === "function") {
      qb = qb(new QueryBuilder());
    }
    const selectionProxy = new SelectionProxyHandler({
      alias: this.name,
      sqlBehavior: "error",
      sqlAliasedBehavior: "alias",
      replaceOriginalName: true
    });
    const aliasedSelectedFields = qb.getSelectedFields();
    return new Proxy(
      new SQLiteView({
        // sqliteConfig: this.config,
        config: {
          name: this.name,
          schema: void 0,
          selectedFields: aliasedSelectedFields,
          query: qb.getSQL().inlineParams()
        }
      }),
      selectionProxy
    );
  }
};
var ManualViewBuilder = class extends ViewBuilderCore {
  static [entityKind] = "SQLiteManualViewBuilder";
  columns;
  constructor(name, columns) {
    super(name);
    this.columns = getTableColumns(sqliteTable(name, columns));
  }
  existing() {
    return new Proxy(
      new SQLiteView({
        config: {
          name: this.name,
          schema: void 0,
          selectedFields: this.columns,
          query: void 0
        }
      }),
      new SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
  as(query) {
    return new Proxy(
      new SQLiteView({
        config: {
          name: this.name,
          schema: void 0,
          selectedFields: this.columns,
          query: query.inlineParams()
        }
      }),
      new SelectionProxyHandler({
        alias: this.name,
        sqlBehavior: "error",
        sqlAliasedBehavior: "alias",
        replaceOriginalName: true
      })
    );
  }
};
var SQLiteView = class extends SQLiteViewBase {
  static [entityKind] = "SQLiteView";
  constructor({ config }) {
    super(config);
  }
};

// node_modules/drizzle-orm/d1/session.js
init_utils();
var SQLiteD1Session = class extends SQLiteSession {
  constructor(client, dialect, schema, options = {}) {
    super(dialect);
    this.client = client;
    this.schema = schema;
    this.options = options;
    this.logger = options.logger ?? new NoopLogger();
    this.cache = options.cache ?? new NoopCache();
  }
  static [entityKind] = "SQLiteD1Session";
  logger;
  cache;
  prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
    const stmt = this.client.prepare(query.sql);
    return new D1PreparedQuery(
      stmt,
      query,
      this.logger,
      this.cache,
      queryMetadata,
      cacheConfig,
      fields,
      executeMethod,
      isResponseInArrayMode,
      customResultMapper
    );
  }
  async batch(queries) {
    const preparedQueries = [];
    const builtQueries = [];
    for (const query of queries) {
      const preparedQuery = query._prepare();
      const builtQuery = preparedQuery.getQuery();
      preparedQueries.push(preparedQuery);
      if (builtQuery.params.length > 0) {
        builtQueries.push(preparedQuery.stmt.bind(...builtQuery.params));
      } else {
        const builtQuery2 = preparedQuery.getQuery();
        builtQueries.push(
          this.client.prepare(builtQuery2.sql).bind(...builtQuery2.params)
        );
      }
    }
    const batchResults = await this.client.batch(builtQueries);
    return batchResults.map((result, i) => preparedQueries[i].mapResult(result, true));
  }
  extractRawAllValueFromBatchResult(result) {
    return result.results;
  }
  extractRawGetValueFromBatchResult(result) {
    return result.results[0];
  }
  extractRawValuesValueFromBatchResult(result) {
    return d1ToRawMapping(result.results);
  }
  async transaction(transaction, config) {
    const tx = new D1Transaction("async", this.dialect, this, this.schema);
    await this.run(sql.raw(`begin${config?.behavior ? " " + config.behavior : ""}`));
    try {
      const result = await transaction(tx);
      await this.run(sql`commit`);
      return result;
    } catch (err) {
      await this.run(sql`rollback`);
      throw err;
    }
  }
};
var D1Transaction = class _D1Transaction extends SQLiteTransaction {
  static [entityKind] = "D1Transaction";
  async transaction(transaction) {
    const savepointName = `sp${this.nestedIndex}`;
    const tx = new _D1Transaction("async", this.dialect, this.session, this.schema, this.nestedIndex + 1);
    await this.session.run(sql.raw(`savepoint ${savepointName}`));
    try {
      const result = await transaction(tx);
      await this.session.run(sql.raw(`release savepoint ${savepointName}`));
      return result;
    } catch (err) {
      await this.session.run(sql.raw(`rollback to savepoint ${savepointName}`));
      throw err;
    }
  }
};
function d1ToRawMapping(results) {
  const rows = [];
  for (const row of results) {
    const entry = Object.keys(row).map((k) => row[k]);
    rows.push(entry);
  }
  return rows;
}
var D1PreparedQuery = class extends SQLitePreparedQuery {
  constructor(stmt, query, logger, cache, queryMetadata, cacheConfig, fields, executeMethod, _isResponseInArrayMode, customResultMapper) {
    super("async", executeMethod, query, cache, queryMetadata, cacheConfig);
    this.logger = logger;
    this._isResponseInArrayMode = _isResponseInArrayMode;
    this.customResultMapper = customResultMapper;
    this.fields = fields;
    this.stmt = stmt;
  }
  static [entityKind] = "D1PreparedQuery";
  /** @internal */
  customResultMapper;
  /** @internal */
  fields;
  /** @internal */
  stmt;
  async run(placeholderValues) {
    const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
    this.logger.logQuery(this.query.sql, params);
    return await this.queryWithCache(this.query.sql, params, async () => {
      return this.stmt.bind(...params).run();
    });
  }
  async all(placeholderValues) {
    const { fields, query, logger, stmt, customResultMapper } = this;
    if (!fields && !customResultMapper) {
      const params = fillPlaceholders(query.params, placeholderValues ?? {});
      logger.logQuery(query.sql, params);
      return await this.queryWithCache(query.sql, params, async () => {
        return stmt.bind(...params).all().then(({ results }) => this.mapAllResult(results));
      });
    }
    const rows = await this.values(placeholderValues);
    return this.mapAllResult(rows);
  }
  mapAllResult(rows, isFromBatch) {
    if (isFromBatch) {
      rows = d1ToRawMapping(rows.results);
    }
    if (!this.fields && !this.customResultMapper) {
      return rows;
    }
    if (this.customResultMapper) {
      return this.customResultMapper(rows);
    }
    return rows.map((row) => mapResultRow(this.fields, row, this.joinsNotNullableMap));
  }
  async get(placeholderValues) {
    const { fields, joinsNotNullableMap, query, logger, stmt, customResultMapper } = this;
    if (!fields && !customResultMapper) {
      const params = fillPlaceholders(query.params, placeholderValues ?? {});
      logger.logQuery(query.sql, params);
      return await this.queryWithCache(query.sql, params, async () => {
        return stmt.bind(...params).all().then(({ results }) => results[0]);
      });
    }
    const rows = await this.values(placeholderValues);
    if (!rows[0]) {
      return void 0;
    }
    if (customResultMapper) {
      return customResultMapper(rows);
    }
    return mapResultRow(fields, rows[0], joinsNotNullableMap);
  }
  mapGetResult(result, isFromBatch) {
    if (isFromBatch) {
      result = d1ToRawMapping(result.results)[0];
    }
    if (!this.fields && !this.customResultMapper) {
      return result;
    }
    if (this.customResultMapper) {
      return this.customResultMapper([result]);
    }
    return mapResultRow(this.fields, result, this.joinsNotNullableMap);
  }
  async values(placeholderValues) {
    const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
    this.logger.logQuery(this.query.sql, params);
    return await this.queryWithCache(this.query.sql, params, async () => {
      return this.stmt.bind(...params).raw();
    });
  }
  /** @internal */
  isResponseInArrayMode() {
    return this._isResponseInArrayMode;
  }
};

// node_modules/drizzle-orm/d1/driver.js
var DrizzleD1Database = class extends BaseSQLiteDatabase {
  static [entityKind] = "D1Database";
  async batch(batch) {
    return this.session.batch(batch);
  }
};

// packages/core/src/storage/drizzle/schema.d1.ts
init_drizzle_orm();
var usersTable = sqliteTable(
  "users",
  {
    id: text2("id").primaryKey(),
    /**
     * 在 `external_system` 命名空间内唯一（含 internal 用户，即 `external_system IS NULL`）；
     * 由两条 partial unique index 落实，见表选项末尾。
     */
    email: text2("email").notNull(),
    budgetMax: real2("budget_max"),
    budgetBase: real2("budget_base").notNull().default(0),
    budgetSpent: real2("budget_spent").notNull().default(0),
    /** D1 ordinary-budget accounting source of truth; REAL above is a compatibility mirror. */
    budgetSpentMicros: integer2("budget_spent_micros").notNull().default(0),
    budgetPeriod: text2("budget_period").notNull().default("none"),
    budgetResetAt: text2("budget_reset_at"),
    budgetEpoch: integer2("budget_epoch").notNull().default(0),
    budgetReservedMicros: integer2("budget_reserved_micros").notNull().default(0),
    status: text2("status").notNull().default("active"),
    metadata: text2("metadata"),
    /** `{ "<models.id>": factor }` JSON；NULL 表示无用户级 Charged 折扣 */
    chargedCostFactors: text2("charged_cost_factors"),
    /** 上游命名空间（产品/租户），与 external_user_id 成对做幂等；纯网关用户二者皆空。 */
    externalSystem: text2("external_system"),
    externalUserId: text2("external_user_id"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_users_external_system_user_id").on(
      t.externalSystem,
      t.externalUserId
    ),
    uniqueIndex("uk_users_external_system_email").on(t.externalSystem, t.email).where(sql`external_system IS NOT NULL`),
    uniqueIndex("uk_users_internal_email").on(t.email).where(sql`external_system IS NULL`),
    check(
      "users_external_pair_chk",
      sql`(external_system IS NULL AND external_user_id IS NULL) OR (external_system IS NOT NULL AND external_user_id IS NOT NULL)`
    ),
    check(
      "users_budget_epoch_chk",
      sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
    ),
    check(
      "users_budget_reserved_micros_chk",
      sql`${t.budgetReservedMicros} >= 0 AND ${t.budgetReservedMicros} <= 9007199254740991`
    ),
    check(
      "users_budget_spent_micros_chk",
      sql`${t.budgetSpentMicros} >= 0 AND ${t.budgetSpentMicros} <= 9007199254740991`
    )
  ]
);
var organizationsTable = sqliteTable(
  "organizations",
  {
    id: text2("id").primaryKey(),
    source: text2("source").notNull(),
    name: text2("name").notNull(),
    slug: text2("slug"),
    status: text2("status").notNull().default("active"),
    metadataJson: text2("metadata_json"),
    sourceUpdatedAt: text2("source_updated_at").notNull(),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    check(
      "organizations_status_chk",
      sql`${t.status} IN ('pending', 'active', 'suspended', 'deleted')`
    ),
    check("organizations_source_nonempty_chk", sql`length(${t.source}) > 0`)
  ]
);
var organizationMembershipsTable = sqliteTable(
  "organization_memberships",
  {
    organizationId: text2("organization_id").notNull().references(() => organizationsTable.id, { onDelete: "cascade" }),
    subject: text2("subject").notNull(),
    userId: text2("user_id").references(() => usersTable.id, {
      onDelete: "set null"
    }),
    email: text2("email"),
    rolesJson: text2("roles_json").notNull().default("[]"),
    status: text2("status").notNull().default("active"),
    sourceUpdatedAt: text2("source_updated_at").notNull(),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    primaryKey2({ columns: [t.organizationId, t.subject] }),
    check(
      "organization_memberships_status_chk",
      sql`${t.status} IN ('active', 'suspended', 'removed')`
    ),
    check(
      "organization_memberships_subject_nonempty_chk",
      sql`length(${t.subject}) > 0`
    )
  ]
);
var identityEventInboxTable = sqliteTable(
  "identity_event_inbox",
  {
    source: text2("source").notNull(),
    eventId: text2("event_id").notNull(),
    eventType: text2("event_type").notNull(),
    aggregateType: text2("aggregate_type").notNull(),
    aggregateId: text2("aggregate_id").notNull(),
    payloadSha256: text2("payload_sha256").notNull(),
    processorToken: text2("processor_token").notNull().unique(),
    occurredAt: text2("occurred_at").notNull(),
    processedAt: text2("processed_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [primaryKey2({ columns: [t.source, t.eventId] })]
);
var workspacesTable = sqliteTable(
  "workspaces",
  {
    id: text2("id").primaryKey(),
    scopeType: text2("scope_type").notNull(),
    organizationId: text2("organization_id").references(
      () => organizationsTable.id,
      { onDelete: "cascade" }
    ),
    personalOwnerUserId: text2("personal_owner_user_id").references(
      () => usersTable.id,
      { onDelete: "cascade" }
    ),
    name: text2("name").notNull(),
    slug: text2("slug").notNull(),
    description: text2("description"),
    isDefault: integer2("is_default").notNull().default(0),
    defaultScopeKey: text2("default_scope_key").unique(),
    status: text2("status").notNull().default("active"),
    settingsJson: text2("settings_json"),
    createdByUserId: text2("created_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_workspaces_personal_slug").on(t.personalOwnerUserId, t.slug).where(sql`${t.personalOwnerUserId} IS NOT NULL`),
    uniqueIndex("uk_workspaces_organization_slug").on(t.organizationId, t.slug).where(sql`${t.organizationId} IS NOT NULL`),
    check(
      "workspaces_scope_type_chk",
      sql`${t.scopeType} IN ('personal', 'organization')`
    ),
    check("workspaces_status_chk", sql`${t.status} IN ('active', 'archived')`),
    check("workspaces_default_flag_chk", sql`${t.isDefault} IN (0, 1)`),
    check(
      "workspaces_scope_owner_chk",
      sql`(
			(${t.scopeType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.scopeType} = 'organization' AND ${t.organizationId} IS NOT NULL AND ${t.personalOwnerUserId} IS NULL)
		)`
    ),
    check(
      "workspaces_default_key_chk",
      sql`(
			(${t.isDefault} = 1 AND ${t.defaultScopeKey} IS NOT NULL)
			OR (${t.isDefault} = 0 AND ${t.defaultScopeKey} IS NULL)
		)`
    )
  ]
);
var workspaceBudgetsTable = sqliteTable(
  "workspace_budgets",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    resetInterval: text2("reset_interval").notNull(),
    limitMicros: integer2("limit_micros").notNull(),
    configEpoch: integer2("config_epoch").notNull().default(0),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_workspace_budgets_interval").on(t.workspaceId, t.resetInterval),
    index("idx_workspace_budgets_workspace").on(t.workspaceId),
    check("workspace_budgets_interval_chk", sql`${t.resetInterval} IN ('daily', 'weekly', 'monthly', 'lifetime')`),
    check("workspace_budgets_limit_chk", sql`${t.limitMicros} > 0 AND ${t.limitMicros} <= 9007199254740991`),
    check("workspace_budgets_epoch_chk", sql`${t.configEpoch} >= 0 AND ${t.configEpoch} <= 2147483646`)
  ]
);
var workspaceMembershipsTable = sqliteTable(
  "workspace_memberships",
  {
    id: text2("id").primaryKey(),
    membershipKey: text2("membership_key").notNull().unique(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    subject: text2("subject").notNull(),
    role: text2("role").notNull().default("member"),
    status: text2("status").notNull().default("active"),
    grantedBySubject: text2("granted_by_subject"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    check(
      "workspace_memberships_role_chk",
      sql`${t.role} IN ('admin', 'member')`
    ),
    check(
      "workspace_memberships_status_chk",
      sql`${t.status} IN ('active', 'removed')`
    ),
    check(
      "workspace_memberships_subject_chk",
      sql`length(${t.subject}) BETWEEN 1 AND 255`
    ),
    check(
      "workspace_memberships_key_chk",
      sql`length(${t.membershipKey}) = 64`
    )
  ]
);
var apiKeysTable = sqliteTable("api_keys", {
  id: text2("id").primaryKey(),
  key: text2("key").notNull(),
  keyHash: text2("key_hash"),
  keyPreview: text2("key_preview"),
  userId: text2("user_id").notNull(),
  workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
  name: text2("name"),
  status: text2("status").notNull().default("active"),
  metadata: text2("metadata"),
  expiresAt: text2("expires_at"),
  limitMicros: integer2("limit_micros"),
  limitReset: text2("limit_reset"),
  includeByokInLimit: integer2("include_byok_in_limit", { mode: "boolean" }).notNull().default(false),
  limitEpoch: integer2("limit_epoch").notNull().default(0),
  lastUsedAt: text2("last_used_at"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var managementApiKeysTable = sqliteTable(
  "management_api_keys",
  {
    id: text2("id").primaryKey(),
    keyHash: text2("key_hash").notNull().unique(),
    keyPreview: text2("key_preview").notNull(),
    accountType: text2("account_type").notNull(),
    personalOwnerUserId: text2("personal_owner_user_id").references(
      () => usersTable.id,
      { onDelete: "cascade" }
    ),
    organizationId: text2("organization_id").references(
      () => organizationsTable.id,
      { onDelete: "cascade" }
    ),
    name: text2("name").notNull(),
    status: text2("status").notNull().default("active"),
    expiresAt: text2("expires_at"),
    lastUsedAt: text2("last_used_at"),
    createdByUserId: text2("created_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    index("idx_management_api_keys_personal_created").on(
      t.personalOwnerUserId,
      t.createdAt
    ),
    index("idx_management_api_keys_organization_created").on(
      t.organizationId,
      t.createdAt
    ),
    index("idx_management_api_keys_status_expiry").on(t.status, t.expiresAt),
    check(
      "management_api_keys_hash_chk",
      sql`length(${t.keyHash}) = 71 AND substr(${t.keyHash}, 1, 7) = 'sha256:'`
    ),
    check(
      "management_api_keys_name_chk",
      sql`length(${t.name}) BETWEEN 1 AND 128`
    ),
    check(
      "management_api_keys_status_chk",
      sql`${t.status} IN ('active', 'revoked')`
    ),
    check(
      "management_api_keys_account_type_chk",
      sql`${t.accountType} IN ('personal', 'organization')`
    ),
    check(
      "management_api_keys_account_owner_chk",
      sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
		)`
    )
  ]
);
var byokKeysTable = sqliteTable(
  "byok_keys",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(
      () => workspacesTable.id,
      { onDelete: "cascade" }
    ),
    provider: text2("provider").notNull(),
    name: text2("name"),
    apiKeyEncrypted: text2("api_key_encrypted").notNull(),
    label: text2("label").notNull(),
    disabled: integer2("disabled", { mode: "boolean" }).notNull().default(false),
    isFallback: integer2("is_fallback", { mode: "boolean" }).notNull().default(false),
    alwaysUseForProvider: integer2("always_use_for_provider", { mode: "boolean" }).notNull().default(false),
    alwaysUseForMatchingModels: integer2("always_use_for_matching_models", { mode: "boolean" }).notNull().default(false),
    sortOrder: integer2("sort_order").notNull(),
    allowedModelsJson: text2("allowed_models_json"),
    allowedUserIdsJson: text2("allowed_user_ids_json"),
    allowedApiKeyHashesJson: text2("allowed_api_key_hashes_json"),
    createdByManagementKeyId: text2("created_by_management_key_id").references(
      () => managementApiKeysTable.id,
      { onDelete: "set null" }
    ),
    deletedAt: text2("deleted_at"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_byok_keys_active_order").on(t.workspaceId, t.provider, t.sortOrder).where(sql`${t.deletedAt} IS NULL`),
    index("idx_byok_keys_workspace_created").on(t.workspaceId, t.createdAt),
    index("idx_byok_keys_runtime").on(
      t.workspaceId,
      t.provider,
      t.disabled,
      t.isFallback,
      t.sortOrder
    ),
    index("idx_byok_keys_creator").on(t.createdByManagementKeyId, t.createdAt),
    check(
      "byok_keys_always_use_priority_chk",
      sql`(${t.alwaysUseForProvider} = 0 AND ${t.alwaysUseForMatchingModels} = 0) OR ${t.isFallback} = 0`
    ),
    check(
      "byok_keys_shared_capacity_policy_exclusive_chk",
      sql`${t.alwaysUseForProvider} = 0 OR ${t.alwaysUseForMatchingModels} = 0`
    )
  ]
);
var providersTable = sqliteTable("providers", {
  id: text2("id").primaryKey(),
  name: text2("name").notNull(),
  /** JSON: `{ openai?: { base?, endpoints? }, … }` */
  endpoints: text2("endpoints"),
  /** 该上游账号唯一 API Key */
  apiKey: text2("api_key").notNull().default(""),
  /** `active` | `disabled` */
  status: text2("status").notNull().default("active"),
  description: text2("description"),
  /** 非空时该 provider 接受对应用户共享密钥池注入（openai/anthropic/zhipu/deepseek） */
  sharedChannelType: text2("shared_channel_type"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var modelsTable = sqliteTable("models", {
  id: text2("id").primaryKey(),
  displayName: text2("display_name"),
  vendor: text2("vendor").notNull().default("other"),
  contextWindow: integer2("context_window"),
  /** Chat completion max output tokens; NULL for image-generation models. */
  maxTokens: integer2("max_tokens").default(8192),
  /** JSON：统一阶梯/固定价（`models` 列价真源）。 */
  pricingProfile: text2("pricing_profile"),
  description: text2("description"),
  metadata: text2("metadata"),
  inputModalities: text2("input_modalities"),
  outputModalities: text2("output_modalities"),
  releasedAt: text2("released_at"),
  /** 路由策略配置 JSON；NULL=使用全局/代码默认 */
  routePolicy: text2("route_policy"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var modelEndpointsTable = sqliteTable(
  "model_endpoints",
  {
    id: text2("id").primaryKey(),
    modelId: text2("model_id").notNull().references(() => modelsTable.id, { onDelete: "cascade" }),
    providerId: text2("provider_id").notNull().references(() => providersTable.id, { onDelete: "cascade" }),
    providerSlug: text2("provider_slug").notNull(),
    tag: text2("tag").notNull(),
    endpointClass: text2("endpoint_class"),
    region: text2("region"),
    contextLength: integer2("context_length"),
    maxPromptTokens: integer2("max_prompt_tokens"),
    maxCompletionTokens: integer2("max_completion_tokens"),
    quantization: text2("quantization"),
    supportedParameters: text2("supported_parameters").notNull().default("[]"),
    pricing: text2("pricing").notNull().default("{}"),
    supportsToolChoice: text2("supports_tool_choice").notNull().default('{"auto":null,"function":null,"none":null,"required":null}'),
    imageCapabilities: text2("image_capabilities").notNull().default("{}"),
    audioCapabilities: text2("audio_capabilities").notNull().default("{}"),
    /** Nullable boolean: NULL means the capability has not been verified. */
    supportsImplicitCaching: integer2("supports_implicit_caching"),
    /** Nullable boolean: NULL means the capability has not been verified. */
    supportsVoiceCloning: integer2("supports_voice_cloning"),
    evidenceUrl: text2("evidence_url"),
    verifiedBy: text2("verified_by"),
    verifiedAt: text2("verified_at"),
    expiresAt: text2("expires_at"),
    status: text2("status").notNull().default("draft"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_model_endpoints_identity").on(
      t.modelId,
      t.providerId,
      t.tag
    ),
    index("idx_model_endpoints_provider").on(t.providerId),
    index("idx_model_endpoints_model_status").on(t.modelId, t.status),
    check(
      "model_endpoints_status_chk",
      sql`${t.status} IN ('draft', 'verified', 'disabled')`
    ),
    check(
      "model_endpoints_implicit_caching_chk",
      sql`${t.supportsImplicitCaching} IS NULL OR ${t.supportsImplicitCaching} IN (0, 1)`
    ),
    check(
      "model_endpoints_voice_cloning_chk",
      sql`${t.supportsVoiceCloning} IS NULL OR ${t.supportsVoiceCloning} IN (0, 1)`
    ),
    check(
      "model_endpoints_context_length_chk",
      sql`${t.contextLength} IS NULL OR ${t.contextLength} > 0`
    ),
    check(
      "model_endpoints_max_prompt_tokens_chk",
      sql`${t.maxPromptTokens} IS NULL OR ${t.maxPromptTokens} > 0`
    ),
    check(
      "model_endpoints_max_completion_tokens_chk",
      sql`${t.maxCompletionTokens} IS NULL OR ${t.maxCompletionTokens} > 0`
    )
  ]
);
var routePoolsTable = sqliteTable("route_pools", {
  id: text2("id").primaryKey(),
  modelId: text2("model_id").notNull(),
  routeGroup: text2("route_group").notNull().default("default"),
  name: text2("name").notNull(),
  strategy: text2("strategy"),
  /** JSON map: {"10":"hash_affinity","0":"weight_priority"} — per-priority-tier overrides */
  tierStrategies: text2("tier_strategies"),
  /** Provider sticky routing: 0/1 */
  stickyEnabled: integer2("sticky_enabled").notNull().default(0),
  stickyIdleTtlSeconds: integer2("sticky_idle_ttl_seconds").notNull().default(3600),
  /** Bumped on sticky config change to invalidate existing bindings */
  stickyEpoch: integer2("sticky_epoch").notNull().default(0),
  status: text2("status").notNull().default("active"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var routePoolStickyBindingsTable = sqliteTable(
  "route_pool_sticky_bindings",
  {
    routePoolId: text2("route_pool_id").notNull(),
    affinityHash: text2("affinity_hash").notNull(),
    routeTargetId: text2("route_target_id").notNull(),
    bindingToken: text2("binding_token").notNull(),
    poolEpoch: integer2("pool_epoch").notNull().default(0),
    expiresAt: text2("expires_at").notNull(),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  }
);
var modelSurfacesTable = sqliteTable("model_surfaces", {
  id: text2("id").primaryKey(),
  modelId: text2("model_id").notNull(),
  routeGroup: text2("route_group").notNull().default("default"),
  requestProtocol: text2("request_protocol").notNull(),
  requestOperation: text2("request_operation").notNull().default("*"),
  routePoolId: text2("route_pool_id").notNull(),
  status: text2("status").notNull().default("active"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var modelRoutesTable = sqliteTable("model_routes", {
  id: text2("id").primaryKey(),
  modelId: text2("model_id").notNull(),
  providerId: text2("provider_id").notNull(),
  providerModelName: text2("provider_model_name").notNull(),
  priority: integer2("priority").notNull().default(0),
  status: text2("status").notNull().default("active"),
  routeGroup: text2("route_group").notNull().default("default"),
  /** 同 priority 层内权重 */
  weight: integer2("weight").notNull().default(1),
  priceOverride: text2("price_override"),
  customParams: text2("custom_params"),
  routingMetadata: text2("routing_metadata"),
  upstreamProtocol: text2("upstream_protocol").notNull().default("openai"),
  routePoolId: text2("route_pool_id"),
  upstreamOperation: text2("upstream_operation").notNull().default("*"),
  adapter: text2("adapter").notNull().default("passthrough"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var modelEndpointRoutesTable = sqliteTable(
  "model_endpoint_routes",
  {
    endpointId: text2("endpoint_id").notNull().references(() => modelEndpointsTable.id, { onDelete: "cascade" }),
    routeTargetId: text2("route_target_id").notNull().references(() => modelRoutesTable.id, { onDelete: "cascade" }),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    /** SHA-256 of the exact route/provider subject verified for this binding. */
    subjectFingerprint: text2("subject_fingerprint")
  },
  (t) => [
    primaryKey2({ columns: [t.endpointId, t.routeTargetId] }),
    uniqueIndex("uk_model_endpoint_routes_target").on(t.routeTargetId),
    check(
      "model_endpoint_routes_subject_fingerprint_chk",
      sql`${t.subjectFingerprint} IS NULL OR (length(${t.subjectFingerprint}) = 64 AND ${t.subjectFingerprint} NOT GLOB '*[^0-9a-f]*')`
    )
  ]
);
var apiKeyRequestLogsTable = sqliteTable("api_key_request_logs", {
  id: text2("id").primaryKey(),
  userId: text2("user_id"),
  apiKeyId: text2("api_key_id"),
  workspaceId: text2("workspace_id").references(() => workspacesTable.id, {
    onDelete: "set null"
  }),
  userEmail: text2("user_email"),
  modelId: text2("model_id"),
  providerId: text2("provider_id"),
  providerModelName: text2("provider_model_name"),
  modelName: text2("model_name"),
  providerName: text2("provider_name"),
  requestBody: text2("request_body"),
  upstreamRequestBody: text2("upstream_request_body"),
  requestProtocol: text2("request_protocol"),
  requestOperation: text2("request_operation"),
  upstreamProtocol: text2("upstream_protocol").notNull().default("openai"),
  upstreamOperation: text2("upstream_operation"),
  modelSurfaceId: text2("model_surface_id"),
  routePoolId: text2("route_pool_id"),
  routeTargetId: text2("route_target_id"),
  adapter: text2("adapter"),
  routeTrace: text2("route_trace"),
  inputTokens: integer2("input_tokens").notNull().default(0),
  outputTokens: integer2("output_tokens").notNull().default(0),
  cacheReadTokens: integer2("cache_read_tokens").notNull().default(0),
  cacheWriteTokens: integer2("cache_write_tokens").notNull().default(0),
  reasoningTokens: integer2("reasoning_tokens").notNull().default(0),
  totalTokens: integer2("total_tokens").notNull().default(0),
  nativeTokensPrompt: integer2("native_tokens_prompt"),
  nativeTokensCompletion: integer2("native_tokens_completion"),
  nativeTokensCached: integer2("native_tokens_cached"),
  nativeTokensReasoning: integer2("native_tokens_reasoning"),
  nativeTokensCompletionImages: integer2("native_tokens_completion_images"),
  meteredCost: real2("metered_cost").notNull().default(0),
  standardCost: real2("standard_cost").notNull().default(0),
  chargedCost: real2("charged_cost").notNull().default(0),
  /** Guardrail/user budget debit in integer micro-units; NULL marks a pre-ledger row. */
  budgetChargedMicros: integer2("budget_charged_micros"),
  budgetAccountedAt: text2("budget_accounted_at"),
  routeGroup: text2("route_group").notNull().default("default"),
  status: text2("status").notNull().default("success"),
  latencyMs: integer2("latency_ms"),
  gatewayOverheadMs: integer2("gateway_overhead_ms"),
  upstreamResponseMs: integer2("upstream_response_ms"),
  finalUpstreamHeadersMs: integer2("final_upstream_headers_ms"),
  firstReasoningTokenMs: integer2("first_reasoning_token_ms"),
  firstTokenMs: integer2("first_token_ms"),
  streamDurationMs: integer2("stream_duration_ms"),
  upstreamAttemptCount: integer2("upstream_attempt_count"),
  upstreamFailoverCount: integer2("upstream_failover_count"),
  timingMetadata: text2("timing_metadata"),
  errorMessage: text2("error_message"),
  rawUsage: text2("raw_usage"),
  /** 计费审计 JSON 字符串；结构见 `db/pricing-audit.ts` */
  pricingAudit: text2("pricing_audit"),
  providerKeyId: text2("provider_key_id"),
  providerKeyLabel: text2("provider_key_label"),
  providerKeyFingerprint: text2("provider_key_fingerprint"),
  upstreamRequestId: text2("upstream_request_id"),
  upstreamMessageId: text2("upstream_message_id"),
  billingKind: text2("billing_kind"),
  inputImageCount: integer2("input_image_count").notNull().default(0),
  outputImageCount: integer2("output_image_count").notNull().default(0),
  audioDurationSeconds: real2("audio_duration_seconds"),
  audioCharacters: integer2("audio_characters"),
  sessionId: text2("session_id"),
  requestOrigin: text2("request_origin"),
  httpReferer: text2("http_referer"),
  userAgent: text2("user_agent"),
  responseStreamed: integer2("response_streamed", { mode: "boolean" }),
  dataRegion: text2("data_region"),
  isByok: integer2("is_byok", { mode: "boolean" }),
  chargedCostUsd: real2("charged_cost_usd"),
  upstreamInferenceCostUsd: real2("upstream_inference_cost_usd"),
  serviceTier: text2("service_tier"),
  finishReason: text2("finish_reason"),
  nativeFinishReason: text2("native_finish_reason"),
  providerResponses: text2("provider_responses"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var providerAttemptAvailabilityTable = sqliteTable(
  "provider_attempt_availability",
  {
    requestLogId: text2("request_log_id").notNull().references(
      () => apiKeyRequestLogsTable.id,
      { onDelete: "cascade" }
    ),
    attemptIndex: integer2("attempt_index").notNull(),
    routeTargetId: text2("route_target_id").notNull(),
    providerId: text2("provider_id").notNull(),
    outcome: text2("outcome").notNull(),
    reason: text2("reason").notNull(),
    httpStatus: integer2("http_status"),
    observedAt: text2("observed_at").notNull()
  },
  (t) => [
    primaryKey2({ columns: [t.requestLogId, t.attemptIndex] }),
    index("idx_provider_attempt_availability_route_observed").on(t.routeTargetId, t.observedAt),
    index("idx_provider_attempt_availability_observed").on(t.observedAt),
    check(
      "provider_attempt_availability_attempt_index_chk",
      sql`${t.attemptIndex} BETWEEN 1 AND 128`
    ),
    check(
      "provider_attempt_availability_outcome_chk",
      sql`${t.outcome} IN ('available', 'unavailable', 'excluded')`
    ),
    check(
      "provider_attempt_availability_reason_chk",
      sql`${t.reason} IN ('accepted', 'provider_http_error', 'rate_limited', 'network_error', 'invalid_response', 'client_error', 'client_cancelled', 'unknown')`
    ),
    check(
      "provider_attempt_availability_http_status_chk",
      sql`${t.httpStatus} IS NULL OR ${t.httpStatus} BETWEEN 100 AND 599`
    )
  ]
);
var generationFeedbackTable = sqliteTable(
  "generation_feedback",
  {
    id: text2("id").primaryKey(),
    generationId: text2("generation_id").notNull().references(
      () => apiKeyRequestLogsTable.id,
      { onDelete: "cascade" }
    ),
    workspaceId: text2("workspace_id").notNull().references(
      () => workspacesTable.id,
      { onDelete: "cascade" }
    ),
    managementApiKeyId: text2("management_api_key_id").notNull().references(
      () => managementApiKeysTable.id,
      { onDelete: "cascade" }
    ),
    accountType: text2("account_type").notNull(),
    personalOwnerUserId: text2("personal_owner_user_id").references(
      () => usersTable.id,
      { onDelete: "cascade" }
    ),
    organizationId: text2("organization_id").references(
      () => organizationsTable.id,
      { onDelete: "cascade" }
    ),
    category: text2("category").notNull(),
    comment: text2("comment"),
    createdAt: text2("created_at").notNull()
  },
  (t) => [
    index("idx_generation_feedback_generation_created").on(t.generationId, t.createdAt),
    index("idx_generation_feedback_personal_created").on(t.personalOwnerUserId, t.createdAt).where(sql`${t.personalOwnerUserId} IS NOT NULL`),
    index("idx_generation_feedback_organization_created").on(t.organizationId, t.createdAt).where(sql`${t.organizationId} IS NOT NULL`),
    check("generation_feedback_id_chk", sql`length(${t.id}) = 40 AND substr(${t.id}, 1, 4) = 'gfb_'`),
    check("generation_feedback_category_chk", sql`${t.category} IN ('latency', 'incoherence', 'incorrect_response', 'formatting', 'billing', 'api_error', 'other')`),
    check("generation_feedback_comment_chk", sql`${t.comment} IS NULL OR length(${t.comment}) <= 1000`),
    check(
      "generation_feedback_account_owner_chk",
      sql`(
			(${t.accountType} = 'personal' AND ${t.personalOwnerUserId} IS NOT NULL AND ${t.organizationId} IS NULL)
			OR (${t.accountType} = 'organization' AND ${t.personalOwnerUserId} IS NULL AND ${t.organizationId} IS NOT NULL)
			)`
    )
  ]
);
var publicModelDailyStatsTable = sqliteTable(
  "public_model_daily_stats",
  {
    statDate: text2("stat_date").notNull(),
    modelId: text2("model_id").notNull(),
    shard: integer2("shard").notNull(),
    requestCount: integer2("request_count").notNull().default(0),
    successCount: integer2("success_count").notNull().default(0),
    errorCount: integer2("error_count").notNull().default(0),
    outputTokens: integer2("output_tokens").notNull().default(0),
    totalTokens: integer2("total_tokens").notNull().default(0),
    latencyTotalMs: integer2("latency_total_ms").notNull().default(0),
    latencySampleCount: integer2("latency_sample_count").notNull().default(0),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_public_model_daily_stats").on(
      t.statDate,
      t.modelId,
      t.shard
    ),
    check("public_model_daily_stats_shard_chk", sql`shard >= 0 AND shard < 16`)
  ]
);
var systemConfigTable = sqliteTable("system_config", {
  key: text2("key").primaryKey(),
  value: text2("value").notNull(),
  description: text2("description"),
  revision: text2("revision").notNull().default("legacy"),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var configGroupAuditTable = sqliteTable("config_group_audit", {
  id: text2("id").primaryKey(),
  family: text2("family").notNull(),
  provider: text2("provider"),
  action: text2("action").notNull(),
  actorKind: text2("actor_kind").notNull(),
  actorId: text2("actor_id").notNull(),
  reason: text2("reason").notNull(),
  changedFieldsJson: text2("changed_fields_json").notNull(),
  activeBefore: text2("active_before"),
  activeAfter: text2("active_after"),
  credentialsJson: text2("credentials_json").notNull(),
  revisionBeforeJson: text2("revision_before_json").notNull(),
  revisionAfterJson: text2("revision_after_json").notNull(),
  source: text2("source").notNull(),
  createdAt: text2("created_at").notNull()
}, (t) => [
  index("idx_config_group_audit_family_created").on(t.family, sql`${t.createdAt} DESC`, sql`${t.id} DESC`),
  check("config_group_audit_family_chk", sql`family IN ('web-search', 'web-fetch', 'web-deep-search', 'ai-detection')`),
  check("config_group_audit_provider_chk", sql`provider IS NULL OR provider IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
  check("config_group_audit_active_before_chk", sql`active_before IS NULL OR active_before IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
  check("config_group_audit_active_after_chk", sql`active_after IS NULL OR active_after IN ('bocha', 'tavily', 'cleversee', 'tencent_wsa', 'firecrawl', 'jina', 'tencent_tms')`),
  check("config_group_audit_action_chk", sql`action IN ('save', 'save_activate', 'activate', 'legacy_save', 'reveal')`),
  check("config_group_audit_actor_kind_chk", sql`actor_kind IN ('console', 'admin_key')`),
  check("config_group_audit_actor_bounds_chk", sql`length(actor_id) BETWEEN 1 AND CASE WHEN actor_kind = 'console' THEN 617 ELSE 600 END`),
  check("config_group_audit_reason_bounds_chk", sql`length(reason) BETWEEN 1 AND 600`),
  check("config_group_audit_source_chk", sql`source IN ('admin_api', 'legacy_admin')`)
]);
var requestPresetsTable = sqliteTable(
  "request_presets",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    ownerUserId: text2("owner_user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    slug: text2("slug").notNull(),
    name: text2("name").notNull(),
    description: text2("description"),
    visibility: text2("visibility").notNull().default("private"),
    status: text2("status").notNull().default("active"),
    designatedVersion: integer2("designated_version").notNull().default(1),
    latestVersion: integer2("latest_version").notNull().default(1),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_request_presets_workspace_slug").on(t.workspaceId, t.slug),
    check(
      "request_presets_visibility_chk",
      sql`visibility IN ('private', 'public')`
    ),
    check("request_presets_status_chk", sql`status IN ('active', 'archived')`),
    check(
      "request_presets_versions_chk",
      sql`designated_version >= 1 AND latest_version >= designated_version`
    )
  ]
);
var requestPresetVersionsTable = sqliteTable(
  "request_preset_versions",
  {
    id: text2("id").primaryKey(),
    presetId: text2("preset_id").notNull().references(() => requestPresetsTable.id, { onDelete: "cascade" }),
    version: integer2("version").notNull(),
    systemPrompt: text2("system_prompt"),
    configJson: text2("config_json").notNull(),
    createdByUserId: text2("created_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [uniqueIndex("uk_request_preset_versions").on(t.presetId, t.version)]
);
var guardrailsTable = sqliteTable(
  "guardrails",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    ownerUserId: text2("owner_user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    name: text2("name").notNull(),
    description: text2("description"),
    status: text2("status").notNull().default("active"),
    isWorkspaceDefault: integer2("is_workspace_default", { mode: "boolean" }).notNull().default(false),
    isAccountDefault: integer2("is_account_default", { mode: "boolean" }).notNull().default(false),
    accountScopeKey: text2("account_scope_key"),
    designatedVersion: integer2("designated_version").notNull().default(1),
    latestVersion: integer2("latest_version").notNull().default(1),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_guardrails_id_workspace").on(t.id, t.workspaceId),
    uniqueIndex("uk_guardrails_workspace_default").on(t.workspaceId).where(sql`${t.isWorkspaceDefault} = 1`),
    uniqueIndex("uk_guardrails_account_default").on(t.accountScopeKey).where(sql`${t.isAccountDefault} = 1`),
    check(
      "guardrails_default_kind_chk",
      sql`NOT (${t.isWorkspaceDefault} = 1 AND ${t.isAccountDefault} = 1)`
    ),
    check(
      "guardrails_account_scope_key_chk",
      sql`(${t.isAccountDefault} = 1 AND ${t.accountScopeKey} IS NOT NULL) OR (${t.isAccountDefault} = 0 AND ${t.accountScopeKey} IS NULL)`
    ),
    check("guardrails_status_chk", sql`status IN ('active', 'archived')`),
    check(
      "guardrails_versions_chk",
      sql`designated_version >= 1 AND latest_version >= designated_version`
    )
  ]
);
var guardrailVersionsTable = sqliteTable(
  "guardrail_versions",
  {
    id: text2("id").primaryKey(),
    guardrailId: text2("guardrail_id").notNull().references(() => guardrailsTable.id, { onDelete: "cascade" }),
    version: integer2("version").notNull(),
    configJson: text2("config_json").notNull(),
    createdByUserId: text2("created_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [uniqueIndex("uk_guardrail_versions").on(t.guardrailId, t.version)]
);
var guardrailAssignmentsTable = sqliteTable(
  "guardrail_assignments",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    guardrailId: text2("guardrail_id").notNull().references(() => guardrailsTable.id, { onDelete: "cascade" }),
    scopeType: text2("scope_type").notNull(),
    scopeId: text2("scope_id").notNull(),
    createdByUserId: text2("created_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    managementSource: text2("management_source"),
    assignedByUserId: text2("assigned_by_user_id").references(
      () => usersTable.id,
      { onDelete: "set null" }
    ),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_guardrail_assignments_workspace_scope").on(
      t.workspaceId,
      t.scopeType,
      t.scopeId
    ),
    index("idx_guardrail_assignments_assigned_by").on(t.assignedByUserId),
    index("idx_guardrail_assignments_management_list").on(t.workspaceId, t.managementSource, t.createdAt, t.id).where(sql`${t.managementSource} IS NOT NULL`),
    check(
      "guardrail_assignments_scope_chk",
      sql`scope_type IN ('user', 'api_key')`
    )
  ]
);
var guardrailBudgetWindowsTable = sqliteTable(
  "guardrail_budget_windows",
  {
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    scopeType: text2("scope_type").notNull(),
    scopeId: text2("scope_id").notNull(),
    period: text2("period").notNull(),
    periodStart: text2("period_start").notNull(),
    periodEnd: text2("period_end").notNull(),
    unreservedMicros: integer2("unreserved_micros").notNull().default(0),
    settledMicros: integer2("settled_micros").notNull().default(0),
    reservedMicros: integer2("reserved_micros").notNull().default(0),
    seedRequestId: text2("seed_request_id"),
    seededAt: text2("seeded_at").notNull(),
    updatedAt: text2("updated_at").notNull()
  },
  (t) => [
    primaryKey2({
      columns: [t.workspaceId, t.scopeType, t.scopeId, t.period, t.periodStart]
    }),
    check(
      "guardrail_budget_windows_scope_chk",
      sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
    ),
    check(
      "guardrail_budget_windows_period_chk",
      sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
    ),
    check(
      "guardrail_budget_windows_amount_chk",
      sql`${t.unreservedMicros} >= 0 AND ${t.settledMicros} >= 0 AND ${t.reservedMicros} >= 0`
    )
  ]
);
var guardrailBudgetReservationsTable = sqliteTable(
  "guardrail_budget_reservations",
  {
    id: text2("id").primaryKey(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "cascade" }),
    requestId: text2("request_id").notNull(),
    assignmentId: text2("assignment_id").notNull(),
    guardrailId: text2("guardrail_id").notNull(),
    guardrailVersion: integer2("guardrail_version").notNull(),
    scopeType: text2("scope_type").notNull(),
    scopeId: text2("scope_id").notNull(),
    period: text2("period").notNull(),
    periodStart: text2("period_start").notNull(),
    periodEnd: text2("period_end").notNull(),
    limitMicros: integer2("limit_micros").notNull(),
    reservedMicros: integer2("reserved_micros").notNull(),
    settledMicros: integer2("settled_micros").notNull().default(0),
    settlementBasis: text2("settlement_basis").notNull().default("charged"),
    state: text2("state").notNull().default("reserved"),
    expiresAt: text2("expires_at").notNull(),
    dispatchedAt: text2("dispatched_at"),
    terminalAt: text2("terminal_at"),
    terminalReason: text2("terminal_reason"),
    createdAt: text2("created_at").notNull(),
    updatedAt: text2("updated_at").notNull()
  },
  (t) => [
    uniqueIndex("uk_guardrail_budget_reservation_request_assignment").on(
      t.requestId,
      t.assignmentId
    ),
    check(
      "guardrail_budget_reservations_scope_chk",
      sql`${t.scopeType} IN ('user', 'api_key', 'workspace')`
    ),
    check(
      "guardrail_budget_reservations_period_chk",
      sql`${t.period} IN ('daily', 'weekly', 'monthly', 'lifetime')`
    ),
    check(
      "guardrail_budget_reservations_amount_chk",
      sql`${t.limitMicros} >= 0 AND ${t.reservedMicros} > 0 AND ${t.settledMicros} >= 0`
    ),
    check(
      "guardrail_budget_reservations_state_chk",
      sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
    ),
    check(
      "guardrail_budget_reservations_settlement_basis_chk",
      sql`${t.settlementBasis} IN ('charged', 'gateway_key_route')`
    )
  ]
);
var userBudgetReservationsTable = sqliteTable(
  "user_budget_reservations",
  {
    requestId: text2("request_id").primaryKey(),
    userId: text2("user_id").notNull(),
    apiKeyId: text2("api_key_id").notNull(),
    budgetEpoch: integer2("budget_epoch").notNull(),
    limitMicros: integer2("limit_micros").notNull(),
    reservedMicros: integer2("reserved_micros").notNull(),
    settledMicros: integer2("settled_micros").notNull().default(0),
    state: text2("state").notNull().default("reserved"),
    expiresAt: text2("expires_at").notNull(),
    dispatchedAt: text2("dispatched_at"),
    terminalAt: text2("terminal_at"),
    terminalReason: text2("terminal_reason"),
    createdAt: text2("created_at").notNull(),
    updatedAt: text2("updated_at").notNull()
  },
  (t) => [
    check(
      "user_budget_reservations_epoch_chk",
      sql`${t.budgetEpoch} >= 0 AND ${t.budgetEpoch} <= 9007199254740991`
    ),
    check(
      "user_budget_reservations_amount_chk",
      sql`${t.limitMicros} >= 0 AND ${t.limitMicros} <= 9007199254740991 AND ${t.reservedMicros} > 0 AND ${t.reservedMicros} <= 9007199254740991 AND ${t.settledMicros} >= 0 AND ${t.settledMicros} <= 9007199254740991`
    ),
    check(
      "user_budget_reservations_state_chk",
      sql`${t.state} IN ('reserved', 'dispatched', 'settled', 'released', 'expired')`
    ),
    check(
      "user_budget_reservations_range_chk",
      sql`${t.expiresAt} > ${t.createdAt}`
    ),
    check(
      "user_budget_reservations_request_id_chk",
      sql`length(${t.requestId}) BETWEEN 1 AND 128`
    ),
    check(
      "user_budget_reservations_user_id_chk",
      sql`length(${t.userId}) BETWEEN 1 AND 512`
    ),
    check(
      "user_budget_reservations_api_key_id_chk",
      sql`length(${t.apiKeyId}) BETWEEN 1 AND 512`
    )
  ]
);
var routeDataPoliciesTable = sqliteTable(
  "route_data_policies",
  {
    routeTargetId: text2("route_target_id").primaryKey().references(() => modelRoutesTable.id, { onDelete: "cascade" }),
    subjectFingerprint: text2("subject_fingerprint"),
    retentionDays: integer2("retention_days"),
    trainingAllowed: integer2("training_allowed").notNull().default(1),
    zdrSupported: integer2("zdr_supported").notNull().default(0),
    evidenceUrl: text2("evidence_url"),
    verifiedBy: text2("verified_by"),
    verifiedAt: text2("verified_at"),
    expiresAt: text2("expires_at"),
    status: text2("status").notNull().default("unknown"),
    invalidatedAt: text2("invalidated_at"),
    invalidationReason: text2("invalidation_reason"),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    check(
      "route_data_policies_retention_chk",
      sql`retention_days IS NULL OR retention_days >= 0`
    ),
    check(
      "route_data_policies_status_chk",
      sql`status IN ('verified', 'expired', 'unknown')`
    )
  ]
);
var routeDataPolicyAuditTable = sqliteTable(
  "route_data_policy_audit",
  {
    id: text2("id").primaryKey(),
    routeTargetId: text2("route_target_id").references(
      () => modelRoutesTable.id,
      { onDelete: "set null" }
    ),
    snapshotJson: text2("snapshot_json").notNull(),
    actorId: text2("actor_id").notNull(),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  }
);
var userAuditLogsTable = sqliteTable("user_audit_logs", {
  id: text2("id").primaryKey(),
  userId: text2("user_id"),
  apiKeyId: text2("api_key_id"),
  eventType: text2("event_type").notNull(),
  actorType: text2("actor_type").notNull().default("system"),
  requestLogId: text2("request_log_id"),
  changePayload: text2("change_payload"),
  beforeUserSnapshot: text2("before_user_snapshot"),
  afterUserSnapshot: text2("after_user_snapshot"),
  changedFields: text2("changed_fields"),
  correlationId: text2("correlation_id"),
  source: text2("source"),
  actorId: text2("actor_id"),
  reasonCode: text2("reason_code"),
  reasonText: text2("reason_text"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var adminApiKeysTable = sqliteTable("admin_api_keys", {
  id: text2("id").primaryKey(),
  name: text2("name").notNull().unique(),
  description: text2("description"),
  secretKey: text2("secret_key").notNull().unique(),
  secretKeyHash: text2("secret_key_hash"),
  keyPrefix: text2("key_prefix").notNull(),
  permissionsJson: text2("permissions_json").notNull().default("[]"),
  status: text2("status").notNull().default("active"),
  lastUsedAt: text2("last_used_at"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  revokedAt: text2("revoked_at")
});
var adminAccessKeyAuditTable = sqliteTable("admin_access_key_audit", {
  id: text2("id").primaryKey(),
  keyId: text2("key_id").notNull(),
  action: text2("action").notNull(),
  changeMask: integer2("change_mask").notNull(),
  actorKind: text2("actor_kind").notNull(),
  actorId: text2("actor_id").notNull(),
  beforePermissionsJson: text2("before_permissions_json"),
  afterPermissionsJson: text2("after_permissions_json"),
  beforeStatus: text2("before_status"),
  afterStatus: text2("after_status"),
  createdAt: text2("created_at").notNull()
});
var adminSharedKeyAuditTable = sqliteTable("admin_shared_key_audit", {
  id: text2("id").primaryKey(),
  keyId: text2("key_id").notNull(),
  action: text2("action").notNull(),
  changeMask: integer2("change_mask").notNull(),
  actorKind: text2("actor_kind").notNull(),
  actorId: text2("actor_id").notNull(),
  source: text2("source").notNull(),
  reason: text2("reason").notNull(),
  beforeStatus: text2("before_status").notNull(),
  beforeSellerPriority: integer2("before_seller_priority").notNull(),
  beforeWeight: integer2("before_weight").notNull(),
  beforeValidated: integer2("before_validated").notNull(),
  afterStatus: text2("after_status"),
  afterSellerPriority: integer2("after_seller_priority"),
  afterWeight: integer2("after_weight"),
  afterValidated: integer2("after_validated"),
  beforeRevision: text2("before_revision").notNull(),
  afterRevision: text2("after_revision"),
  createdAt: text2("created_at").notNull()
}, (t) => [index("idx_admin_shared_key_audit_key_created").on(t.keyId, t.createdAt, t.id)]);
var adminSessionsTable = sqliteTable("admin_sessions", {
  tokenHash: text2("token_hash").primaryKey(),
  username: text2("username").notNull(),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  expiresAt: text2("expires_at").notNull()
});
var portalSessionsTable = sqliteTable("portal_sessions", {
  tokenHash: text2("token_hash").primaryKey(),
  /** CinaAuth OIDC `sub` */
  subject: text2("subject").notNull(),
  email: text2("email").notNull(),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  expiresAt: text2("expires_at").notNull()
});
var sharedKeysTable = sqliteTable(
  "shared_keys",
  {
    id: text2("id").primaryKey(),
    sellerUserId: text2("seller_user_id").notNull(),
    channelType: text2("channel_type").notNull(),
    apiKey: text2("api_key").notNull(),
    keyFingerprint: text2("key_fingerprint").notNull(),
    label: text2("label"),
    status: text2("status").notNull().default("validating"),
    sellerPriority: integer2("seller_priority").notNull().default(0),
    weight: integer2("weight").notNull().default(1),
    inputPrice: real2("input_price").notNull().default(0),
    outputPrice: real2("output_price").notNull().default(0),
    cacheReadPrice: real2("cache_read_price"),
    cacheWritePrice: real2("cache_write_price"),
    validatedAt: text2("validated_at"),
    lastUsedAt: text2("last_used_at"),
    lastFailureAt: text2("last_failure_at"),
    failureReason: text2("failure_reason"),
    servedInputTokens: integer2("served_input_tokens").notNull().default(0),
    servedOutputTokens: integer2("served_output_tokens").notNull().default(0),
    earnedTotal: real2("earned_total").notNull().default(0),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [
    uniqueIndex("uk_shared_keys_seller_fingerprint").on(
      t.sellerUserId,
      t.keyFingerprint
    )
  ]
);
var sharedKeyEarningsTable = sqliteTable(
  "shared_key_earnings",
  {
    id: text2("id").primaryKey(),
    requestLogId: text2("request_log_id").notNull(),
    sharedKeyId: text2("shared_key_id").notNull(),
    sellerUserId: text2("seller_user_id").notNull(),
    inputTokens: integer2("input_tokens").notNull().default(0),
    outputTokens: integer2("output_tokens").notNull().default(0),
    cacheReadTokens: integer2("cache_read_tokens").notNull().default(0),
    cacheWriteTokens: integer2("cache_write_tokens").notNull().default(0),
    grossAmount: real2("gross_amount").notNull().default(0),
    platformFee: real2("platform_fee").notNull().default(0),
    netAmount: real2("net_amount").notNull().default(0),
    currency: text2("currency").notNull().default("USD"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`)
  },
  (t) => [uniqueIndex("uk_shared_key_earnings_request_log").on(t.requestLogId)]
);
var userEarningsTable = sqliteTable("user_earnings", {
  userId: text2("user_id").primaryKey(),
  balance: real2("balance").notNull().default(0),
  lockedAmount: real2("locked_amount").notNull().default(0),
  lifetimeEarned: real2("lifetime_earned").notNull().default(0),
  lifetimeWithdrawn: real2("lifetime_withdrawn").notNull().default(0),
  contributionValue: real2("contribution_value").notNull().default(0),
  walletAddress: text2("wallet_address"),
  walletVerifiedAt: text2("wallet_verified_at"),
  highestBadgeTier: integer2("highest_badge_tier").notNull().default(0),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`)
});
var withdrawalsTable = sqliteTable("withdrawals", {
  id: text2("id").primaryKey(),
  userId: text2("user_id").notNull(),
  amount: real2("amount").notNull(),
  fee: real2("fee").notNull().default(0),
  netAmount: real2("net_amount").notNull(),
  currency: text2("currency").notNull().default("USD"),
  walletAddress: text2("wallet_address").notNull(),
  status: text2("status").notNull().default("requested"),
  tokenAmount: real2("token_amount"),
  txHash: text2("tx_hash"),
  chainId: integer2("chain_id"),
  failureReason: text2("failure_reason"),
  createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text2("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  confirmedAt: text2("confirmed_at")
});
var nftMintsTable = sqliteTable(
  "nft_mints",
  {
    id: text2("id").primaryKey(),
    userId: text2("user_id").notNull(),
    badgeTokenId: integer2("badge_token_id").notNull(),
    tierName: text2("tier_name").notNull(),
    walletAddress: text2("wallet_address").notNull(),
    status: text2("status").notNull().default("pending"),
    txHash: text2("tx_hash"),
    chainId: integer2("chain_id"),
    valueSnapshot: real2("value_snapshot").notNull().default(0),
    failureReason: text2("failure_reason"),
    createdAt: text2("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    confirmedAt: text2("confirmed_at")
  },
  (t) => [uniqueIndex("uk_nft_mints_user_badge").on(t.userId, t.badgeTokenId)]
);
var batchesTable = sqliteTable(
  "batches",
  {
    id: text2("id").primaryKey(),
    accountId: text2("account_id").notNull(),
    workspaceId: text2("workspace_id").notNull().references(() => workspacesTable.id, { onDelete: "restrict" }),
    userId: text2("user_id").notNull().references(() => usersTable.id, { onDelete: "restrict" }),
    apiKeyHash: text2("api_key_hash").notNull(),
    endpoint: text2("endpoint").notNull(),
    modelId: text2("model_id").notNull(),
    routeGroup: text2("route_group").notNull(),
    status: text2("status").notNull().default("validating"),
    completionWindow: text2("completion_window").notNull().default("24h"),
    idempotencyKeyHash: text2("idempotency_key_hash"),
    inputObjectKey: text2("input_object_key").notNull(),
    inputSha256: text2("input_sha256").notNull(),
    inputBytes: integer2("input_bytes").notNull(),
    resultObjectKey: text2("result_object_key"),
    resultSha256: text2("result_sha256"),
    requestCount: integer2("request_count").notNull(),
    validationNextOrdinal: integer2("validation_next_ordinal").notNull().default(0),
    validationInputOffset: integer2("validation_input_offset").notNull().default(0),
    completedCount: integer2("completed_count").notNull().default(0),
    failedCount: integer2("failed_count").notNull().default(0),
    cancelledCount: integer2("cancelled_count").notNull().default(0),
    promptTokens: integer2("prompt_tokens").notNull().default(0),
    completionTokens: integer2("completion_tokens").notNull().default(0),
    totalTokens: integer2("total_tokens").notNull().default(0),
    chargedCostMicros: integer2("charged_cost_micros").notNull().default(0),
    byokRequestCount: integer2("byok_request_count").notNull().default(0),
    unknownCostCount: integer2("unknown_cost_count").notNull().default(0),
    createdAt: text2("created_at").notNull(),
    inProgressAt: text2("in_progress_at"),
    finalizingAt: text2("finalizing_at"),
    finalizedAt: text2("finalized_at"),
    expiresAt: text2("expires_at").notNull(),
    retentionExpiresAt: text2("retention_expires_at").notNull(),
    leaseOwner: text2("lease_owner"),
    leaseExpiresAt: text2("lease_expires_at"),
    attemptCount: integer2("attempt_count").notNull().default(0),
    revision: integer2("revision").notNull().default(0),
    lastErrorCode: text2("last_error_code"),
    updatedAt: text2("updated_at").notNull()
  },
  (t) => [
    uniqueIndex("uk_batches_idempotency").on(t.workspaceId, t.apiKeyHash, t.idempotencyKeyHash).where(sql`idempotency_key_hash IS NOT NULL`),
    index("idx_batches_workspace_created").on(
      t.workspaceId,
      t.createdAt,
      t.id
    ),
    index("idx_batches_status_lease").on(t.status, t.leaseExpiresAt),
    index("idx_batches_retention").on(t.retentionExpiresAt),
    check(
      "batches_status_chk",
      sql`${t.status} IN ('validating', 'in_progress', 'finalizing', 'completed', 'failed', 'expired', 'cancelling', 'cancelled')`
    ),
    check(
      "batches_counts_chk",
      sql`${t.requestCount} BETWEEN 1 AND 1000000 AND ${t.completedCount} + ${t.failedCount} + ${t.cancelledCount} <= ${t.requestCount}`
    ),
    check(
      "batches_validation_checkpoint_chk",
      sql`${t.inputBytes} BETWEEN 1 AND 52428800 AND ${t.validationNextOrdinal} BETWEEN 0 AND ${t.requestCount} AND ${t.validationInputOffset} BETWEEN 0 AND ${t.inputBytes}`
    )
  ]
);
var batchItemsTable = sqliteTable(
  "batch_items",
  {
    id: text2("id").notNull().unique(),
    batchId: text2("batch_id").notNull().references(() => batchesTable.id, { onDelete: "cascade" }),
    ordinal: integer2("ordinal").notNull(),
    customId: text2("custom_id").notNull(),
    status: text2("status").notNull().default("pending"),
    attemptCount: integer2("attempt_count").notNull().default(0),
    startedAt: text2("started_at"),
    dispatchStartedAt: text2("dispatch_started_at"),
    completedAt: text2("completed_at"),
    generationId: text2("generation_id"),
    reservationId: text2("reservation_id"),
    leaseOwner: text2("lease_owner"),
    leaseExpiresAt: text2("lease_expires_at"),
    requestStartOffset: integer2("request_start_offset").notNull(),
    requestEndOffset: integer2("request_end_offset").notNull(),
    requestSha256: text2("request_sha256").notNull(),
    resultObjectKey: text2("result_object_key"),
    resultSha256: text2("result_sha256"),
    errorCode: text2("error_code"),
    errorSummary: text2("error_summary"),
    revision: integer2("revision").notNull().default(0),
    createdAt: text2("created_at").notNull(),
    updatedAt: text2("updated_at").notNull()
  },
  (t) => [
    primaryKey2({ columns: [t.batchId, t.ordinal] }),
    uniqueIndex("uk_batch_items_custom").on(t.batchId, t.customId),
    index("idx_batch_items_status_ordinal").on(
      t.batchId,
      t.status,
      t.ordinal
    ),
    check(
      "batch_items_status_chk",
      sql`${t.status} IN ('pending', 'in_progress', 'completed', 'failed', 'cancelled')`
    ),
    check(
      "batch_items_request_range_chk",
      sql`${t.requestStartOffset} BETWEEN 0 AND 52428799 AND ${t.requestEndOffset} BETWEEN 1 AND 52428800 AND ${t.requestEndOffset} > ${t.requestStartOffset} AND ${t.requestEndOffset} - ${t.requestStartOffset} <= 1048578`
    ),
    check(
      "batch_items_lease_pair_chk",
      sql`(${t.leaseOwner} IS NULL AND ${t.leaseExpiresAt} IS NULL) OR (${t.leaseOwner} IS NOT NULL AND length(${t.leaseOwner}) BETWEEN 1 AND 128 AND ${t.leaseExpiresAt} IS NOT NULL)`
    ),
    check(
      "batch_items_dispatch_chk",
      sql`(${t.dispatchStartedAt} IS NULL AND ${t.generationId} IS NULL AND ${t.reservationId} IS NULL) OR (${t.dispatchStartedAt} IS NOT NULL AND ${t.startedAt} IS NOT NULL AND ${t.generationId} IS NOT NULL AND length(${t.generationId}) BETWEEN 1 AND 512 AND ${t.reservationId} IS NOT NULL AND length(${t.reservationId}) BETWEEN 1 AND 512)`
    )
  ]
);

// packages/core/src/storage/context.ts
init_repositories_d1();
init_postgres_initialization();

// packages/core/src/index.ts
init_postgres_initialization();

// packages/core/src/storage/repositories.ts
init_repositories_d1();

// packages/core/src/db/d1/critical-writes.impl.ts
init_drizzle_orm();
init_user_audit_catalog();
init_user_audit_logs_impl();
init_api_keys_impl();
init_request_logs_impl();
init_provider_attempt_availability();
init_guardrail_budget_types();
init_user_budget_reservation_types();
init_money_precision();
init_critical_write_paths_utils();

// packages/core/src/db/mysql/critical-writes.impl.ts
init_drizzle_orm();
init_key_hash();
init_request_logs_types();
init_provider_attempt_availability();
init_guardrail_budget_types();
init_user_budget_reservation_types();
init_user_audit_drizzle_insert();
init_money_precision();
init_critical_write_paths_utils();
init_mysql2_compat();
init_schema_mysql();

// packages/core/src/db/postgres/critical-writes.impl.ts
init_drizzle_orm();
init_key_hash();
init_request_logs_types();
init_provider_attempt_availability();

// packages/core/src/db/shared-key-economic-outbox-types.ts
var MAX_OUTCOMES_JSON_BYTES = 4 * 1024 * 1024;
var OUTCOME_KEYS = [
  "attemptId",
  "requestLogId",
  "attemptIndex",
  "sharedKeyId",
  "transitionId",
  "quoteVersionId",
  "usageCertainty",
  "inputTokens",
  "outputTokens",
  "cacheReadTokens",
  "cacheWriteTokens",
  "providerCostCertainty",
  "providerCostMicros",
  "evidenceKind",
  "evidenceSha256",
  "observedAtIso"
].sort();

// packages/core/src/db/postgres/critical-writes.impl.ts
init_guardrail_budget_types();
init_user_budget_reservation_types();
init_user_audit_drizzle_insert();
init_money_precision();

// packages/core/src/db/postgres/legacy-buyer-windowed-transaction-v372.ts
init_drizzle_orm();
init_user_audit_snapshot();

// packages/core/src/db/postgres/critical-writes.impl.ts
init_critical_write_paths_utils();

// packages/core/src/storage/recovery/usage-settlement-transaction-postgres.ts
init_drizzle_orm();

// packages/core/src/storage/recovery/usage-settlement-codec.ts
init_request_logs_types();
init_provider_attempt_availability();
init_guardrail_budget_types();
init_money_precision();
var MAX_SETTLEMENT_BYTES = 256 * 1024;
var encoder2 = new TextEncoder();
var nil = (value) => value === null;
var bool = (value) => typeof value === "boolean";
var amount = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER / 1e6;
var integer3 = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
var optional = (check4) => (value) => value === void 0 || check4(value);
var nullable = (check4) => (value) => value === null || check4(value);
var maybe = (check4) => optional(nullable(check4));
var str = (max) => (value) => typeof value === "string" && value.length <= max && encoder2.encode(value).byteLength <= max;
var jsonText = (max) => (value) => {
  if (typeof value !== "string" || !str(max)(value)) return false;
  try {
    JSON.parse(value);
    return true;
  } catch {
    return false;
  }
};
var text4 = str(512);
var auditText = jsonText(32 * 1024);
var usageText = jsonText(64 * 1024);
var oneOf = (...values) => (value) => values.some((candidate) => candidate === value);
var settlementId = (value) => typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$/.test(value);
var digest = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
var uuid2 = (value) => typeof value === "string" && /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value);
var iso = (value) => typeof value === "string" && value.length === 24 && Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
var protocol = oneOf("openai", "anthropic", "gemini", "dashscope");
function shape(value, fields) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  return Object.keys(value).every((key) => Object.hasOwn(fields, key)) && Object.entries(fields).every(([key, check4]) => check4(Object.getOwnPropertyDescriptor(value, key)?.value));
}
var array = (max, check4) => (value) => Array.isArray(value) && value.length <= max && value.every(check4);
var attemptFields = {
  attemptIndex: (value) => integer3(value) && Number(value) > 0,
  routeTargetId: text4,
  providerId: text4,
  outcome: oneOf("available", "unavailable", "excluded"),
  reason: oneOf("accepted", "provider_http_error", "rate_limited", "network_error", "invalid_response", "client_error", "client_cancelled", "unknown"),
  httpStatus: nullable(integer3),
  observedAtIso: iso
};
var responseFields = {
  status: nullable(integer3),
  endpoint_id: optional(text4),
  id: optional(text4),
  is_byok: optional(bool),
  latency: optional(integer3),
  model_permaslug: optional(text4),
  provider_name: optional(text4),
  routed_service_tier: optional(oneOf("flex", "priority"))
};
var logFields = {
  id: settlementId,
  userId: settlementId,
  apiKeyId: settlementId,
  workspaceId: settlementId,
  userEmail: nullable(text4),
  modelId: text4,
  providerId: text4,
  providerModelName: nullable(text4),
  modelName: nullable(text4),
  providerName: nullable(text4),
  requestBody: nil,
  upstreamRequestBody: nil,
  requestProtocol: protocol,
  upstreamProtocol: protocol,
  requestOperation: oneOf("images.generations", "images.edits"),
  upstreamOperation: maybe(text4),
  modelSurfaceId: maybe(text4),
  routePoolId: maybe(text4),
  routeTargetId: maybe(text4),
  adapter: maybe(text4),
  routeTrace: maybe(auditText),
  inputTokens: integer3,
  outputTokens: integer3,
  cacheReadTokens: integer3,
  cacheWriteTokens: integer3,
  reasoningTokens: integer3,
  totalTokens: integer3,
  nativeTokensPrompt: maybe(integer3),
  nativeTokensCompletion: maybe(integer3),
  nativeTokensCached: maybe(integer3),
  nativeTokensReasoning: maybe(integer3),
  nativeTokensCompletionImages: maybe(integer3),
  meteredCost: amount,
  standardCost: amount,
  chargedCost: amount,
  budgetChargedMicros: maybe(integer3),
  budgetAccountedAt: maybe(iso),
  routeGroup: text4,
  status: oneOf("success", "error", "incomplete", "cancelled"),
  latencyMs: nullable(integer3),
  gatewayOverheadMs: maybe(integer3),
  upstreamResponseMs: maybe(integer3),
  finalUpstreamHeadersMs: maybe(integer3),
  firstReasoningTokenMs: maybe(integer3),
  firstTokenMs: maybe(integer3),
  streamDurationMs: maybe(integer3),
  upstreamAttemptCount: maybe(integer3),
  upstreamFailoverCount: maybe(integer3),
  timingMetadata: maybe(auditText),
  errorMessage: nullable(text4),
  rawUsage: nullable(usageText),
  pricingAudit: maybe(usageText),
  providerKeyId: maybe(text4),
  providerKeyLabel: maybe(text4),
  providerKeyFingerprint: maybe(text4),
  upstreamRequestId: maybe(text4),
  upstreamMessageId: maybe(text4),
  billingKind: maybe(text4),
  inputImageCount: optional(integer3),
  outputImageCount: optional(integer3),
  audioDurationSeconds: maybe(amount),
  audioCharacters: maybe(integer3),
  sessionId: maybe(str(1024)),
  requestOrigin: maybe(text4),
  httpReferer: maybe(text4),
  userAgent: maybe(text4),
  responseStreamed: maybe(bool),
  dataRegion: maybe(oneOf("global", "europe", "us")),
  isByok: maybe(bool),
  chargedCostUsd: maybe(amount),
  upstreamInferenceCostUsd: maybe(amount),
  serviceTier: maybe(oneOf("default", "flex", "priority")),
  finishReason: maybe(oneOf("tool_calls", "stop", "length", "content_filter", "error")),
  nativeFinishReason: maybe(text4),
  providerResponses: maybe(array(32, (value) => shape(value, responseFields))),
  providerAttempts: optional(array(128, (value) => shape(value, attemptFields)))
};
var auditFields = {
  apiKeyId: settlementId,
  eventType: oneOf("usage_charge"),
  actorType: oneOf("system", "service", "user", "admin"),
  actorId: maybe(text4),
  reasonCode: maybe(text4),
  reasonText: maybe(text4),
  beforeSpent: amount,
  beforeBudgetMax: maybe(amount),
  afterBudgetMax: maybe(amount),
  beforeBudgetBase: maybe(amount),
  afterBudgetBase: maybe(amount),
  beforeBudgetPeriod: maybe(text4),
  afterBudgetPeriod: maybe(text4),
  beforeBudgetResetAt: maybe(iso),
  afterBudgetResetAt: maybe(iso),
  requestLogId: settlementId,
  changePayloadMerge: maybe(auditText),
  beforeUserSnapshot: maybe(auditText),
  afterUserSnapshot: maybe(auditText),
  changedFields: maybe(auditText),
  correlationId: maybe(text4),
  source: maybe(text4)
};
var budgetFields = { requestId: settlementId, mode: oneOf("actual", "reserved"), reason: str(128) };
var paramFields = {
  requestLog: (value) => shape(value, logFields),
  shouldChargeBudget: bool,
  userId: settlementId,
  beforeSpent: amount,
  chargedCost: amount,
  audit: (value) => shape(value, auditFields),
  userBudgetSettlement: optional((value) => shape(value, budgetFields)),
  guardrailBudgetSettlement: optional((value) => shape(value, budgetFields))
};
var intentFields = {
  requestId: settlementId,
  attemptIndex: (value) => integer3(value) && Number(value) >= 1 && Number(value) <= 32,
  userId: settlementId,
  apiKeyId: settlementId,
  workspaceId: settlementId,
  operation: oneOf("images.generations", "images.edits"),
  contextSha256: digest
};
var envelopeFields = {
  version: oneOf(1),
  intent: (value) => shape(value, intentFields),
  dispatchClaimId: uuid2,
  recordedAtIso: iso,
  params: (value) => shape(value, paramFields)
};

// packages/core/src/storage/recovery/usage-settlement-facts-postgres.ts
var FACT = "cinatoken_gateway.request_usage_settlements";
var OUTBOX = "cinatoken_gateway.request_usage_settlement_outbox";
var JOIN = `FROM ${FACT} s JOIN ${OUTBOX} o ON o.request_id=s.request_id
	AND o.payload_sha256=s.payload_sha256 AND o.created_at_ms=s.created_at_ms`;

// packages/core/src/db/postgres/critical-writes.impl.ts
init_schema_pg();

// packages/core/src/index.ts
init_critical_write_paths_utils();
init_provider_attempt_availability();

// packages/core/src/storage/workspaces.ts
init_workspaces();

// packages/core/src/storage/workspace-budgets.ts
init_mysql2_compat();
init_management_api_keys_types();
init_workspace_budgets();

// packages/core/src/storage/management-workspaces.ts
init_management_api_keys_types();
init_mysql2_compat();

// packages/core/src/storage/management-workspace-members.ts
init_management_api_keys_types();
init_mysql2_compat();
init_workspaces();

// packages/core/src/index.ts
init_byok_keys();

// packages/core/src/storage/management-guardrails.ts
init_management_api_keys_types();
init_mysql2_compat();

// packages/core/src/storage/management-guardrail-assignments.ts
init_management_api_keys_types();
init_mysql2_compat();

// packages/core/src/index.ts
init_user_audit_catalog();
init_user_audit_snapshot();
init_api_keys_types();
init_providers_types();

// packages/core/src/db/model-route-policy.ts
init_provider_endpoints();
init_route_topology();
init_upstream_protocol();
var CAPABILITIES_BY_PROTOCOL2 = {
  openai: OPENAI_ENDPOINT_CAPABILITIES,
  anthropic: ANTHROPIC_ENDPOINT_CAPABILITIES,
  gemini: [...GEMINI_ENDPOINT_CAPABILITIES, ...GEMINI_LEGACY_ENDPOINT_CAPABILITIES],
  dashscope: DASHSCOPE_ENDPOINT_CAPABILITIES
};

// packages/core/src/index.ts
init_request_logs_types();
init_analytics_query();

// packages/core/src/generation-metadata.ts
init_request_logs_types();

// packages/core/src/index.ts
init_generation_feedback_types();
init_pricing_profile();

// packages/core/src/db/image-token-usage.ts
var SEEDREAM_TYPICAL_OUTPUT_TOKENS = 16384;
var SEEDREAM_ESTIMATED_OUTPUT_TOKENS = {
  "flat:2k": SEEDREAM_TYPICAL_OUTPUT_TOKENS,
  "flat:3k": SEEDREAM_TYPICAL_OUTPUT_TOKENS,
  "flat:4k": SEEDREAM_TYPICAL_OUTPUT_TOKENS * 2,
  "flat:auto": SEEDREAM_TYPICAL_OUTPUT_TOKENS,
  /** 兼容客户端直接传 `size=2K` 且 quality 缺省/auto 的预检 key */
  "auto:2k": SEEDREAM_TYPICAL_OUTPUT_TOKENS,
  "auto:3k": SEEDREAM_TYPICAL_OUTPUT_TOKENS,
  "auto:4k": SEEDREAM_TYPICAL_OUTPUT_TOKENS * 2
};

// packages/core/src/db/user-charged-cost-factors.ts
init_money_precision();

// packages/core/src/index.ts
init_model_modalities();
init_request_log_status_filter();
init_system_config_group();
init_admin_access_audit();
init_shared_keys_types();
init_admin_shared_key_governance();
init_guardrails_types();
init_guardrail_budget_types();
init_user_budget_reservation_types();
init_route_data_policy_types();
init_model_endpoints_types();
init_management_api_keys_types();
init_byok_keys_types();
init_batch_types();

// packages/core/src/model-endpoint-backfill.ts
init_provider_endpoints();
init_upstream_protocol();
init_route_data_policy();
var QUANTIZATIONS3 = new Set(ROUTE_QUANTIZATIONS);

// packages/core/src/lib/business-timezone.ts
var DAY_MS = 24 * 60 * 60 * 1e3;

// packages/core/src/index.ts
init_alert_webhook_system_config();

// packages/core/src/lib/web-search-system-config.ts
init_system_config_group();
init_money_precision();

// packages/core/src/lib/tool-pricing.ts
init_money_precision();

// packages/core/src/lib/web-fetch-system-config.ts
init_system_config_group();
init_money_precision();

// packages/core/src/lib/web-deep-search-system-config.ts
init_system_config_group();
init_money_precision();

// packages/core/src/lib/ai-detection-system-config.ts
init_system_config_group();

// packages/core/src/index.ts
init_money_precision();
init_shared_key_encryption();

// packages/core/src/lib/provider-key-encryption.ts
init_preparation_control();
init_shared_key_encryption();

// packages/core/src/lib/byok-key-encryption.ts
init_preparation_control();
init_shared_key_encryption();

// packages/core/src/index.ts
init_key_hash();

// packages/core/src/services/user-service.ts
init_money_precision();
init_user_audit_snapshot();

// packages/core/src/services/budget-transition-service.ts
init_money_precision();
init_user_audit_snapshot();
init_user_budget_reservation_types();

// packages/core/src/services/key-service.ts
init_user_audit_snapshot();
init_gateway_key_limits();

// packages/core/src/services/management-key-service.ts
init_management_api_keys_types();
init_key_hash();

// packages/core/src/services/shared-key-earnings.ts
init_money_precision();

// packages/proxy/src/services/request-deadline.ts
function markTextStreamCancellation(usage, signal) {
  if (signal?.reason instanceof RequestExecutionStoppedError && signal.reason.reason === "deadline_exceeded") {
    usage.stream_error ??= "Request deadline exceeded";
  } else {
    usage.cancelled = true;
  }
}

// packages/proxy/src/services/route-default-params.ts
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value) && !(value instanceof JsonStringPages);
}
function deepMergeDefaults(defaultValue, userValue) {
  if (userValue !== void 0) {
    if (Array.isArray(userValue)) {
      return userValue;
    }
    if (isPlainObject(defaultValue) && isPlainObject(userValue)) {
      const merged = {};
      const keys = /* @__PURE__ */ new Set([...Object.keys(defaultValue), ...Object.keys(userValue)]);
      for (const key of keys) {
        merged[key] = deepMergeDefaults(defaultValue[key], userValue[key]);
      }
      return merged;
    }
    return userValue;
  }
  return defaultValue;
}
function buildRouteRequestBody(route2, userBody) {
  const finalBody = deepMergeDefaults(route2.customParams ?? {}, userBody);
  const normalized = isPlainObject(finalBody) ? finalBody : { ...userBody };
  const speedControlledBody = route2.gatewayTextSpeedControlled ? { ...normalized } : normalized;
  if (route2.gatewayTextSpeedControlled) delete speedControlledBody.speed;
  const sessionControlledBody = route2.gatewaySessionIdControlled ? { ...speedControlledBody } : speedControlledBody;
  if (route2.gatewaySessionIdControlled) delete sessionControlledBody.session_id;
  const withSpeed = route2.gatewayTextSpeed ? { ...sessionControlledBody, speed: route2.gatewayTextSpeed } : sessionControlledBody;
  const requestedServiceTier = route2.gatewayRequestedServiceTier ?? route2.gatewayServiceTier;
  return requestedServiceTier ? { ...withSpeed, service_tier: requestedServiceTier } : withSpeed;
}

// packages/proxy/src/services/bounded-request-body.ts
var MAX_REQUEST_BODY_BYTES = 50 * 1024 * 1024;

// packages/proxy/src/services/chat-final-quote-input.ts
var FinalChatQuoteInputError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "FinalChatQuoteInputError";
  }
};
function canonical(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new FinalChatQuoteInputError("Final Chat body contains a non-finite number");
    return Object.is(value, -0) ? 0 : value;
  }
  if (Array.isArray(value)) return value.map(canonical);
  if (typeof value === "object") {
    if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new FinalChatQuoteInputError("Final Chat body contains a non-JSON object");
    }
    const out = /* @__PURE__ */ Object.create(null);
    for (const key of Object.keys(value).sort()) {
      const item = value[key];
      if (item === void 0) throw new FinalChatQuoteInputError("Final Chat body contains undefined");
      out[key] = canonical(item);
    }
    return out;
  }
  throw new FinalChatQuoteInputError("Final Chat body contains non-JSON data");
}
function canonicalJson(value) {
  const encoded = JSON.stringify(canonical(value));
  if (typeof encoded !== "string") throw new FinalChatQuoteInputError("Final Chat body is not JSON");
  return encoded;
}
async function sha256Hex(data) {
  const owned = data instanceof ArrayBuffer ? data : new ArrayBuffer(data.byteLength);
  if (data instanceof Uint8Array) new Uint8Array(owned).set(data);
  const bytes = await crypto.subtle.digest("SHA-256", owned);
  return [...new Uint8Array(bytes)].map((value) => value.toString(16).padStart(2, "0")).join("");
}
function canonicalChatJsonSha256(value) {
  return sha256Hex(new TextEncoder().encode(canonicalJson(value)));
}

// packages/proxy/src/services/egress/upstream-request-id.ts
var UPSTREAM_REQUEST_ID_HEADER_NAMES = [
  // —— provider 官方标准头 ——
  "x-request-id",
  // OpenAI 及多数 OpenAI 兼容供应商
  "request-id",
  // Anthropic（直连）
  "anthropic-request-id",
  "x-goog-request-id",
  // Google / Gemini
  "x-amzn-requestid",
  // AWS Bedrock
  "x-amzn-request-id",
  "apim-request-id",
  // Azure API Management（Azure OpenAI）
  "x-ms-request-id",
  // Azure
  // —— Gemini / Google 中转与 CDN 兜底头 ——
  "http_x_reqid",
  // 七牛 APISIX 等代理（上游 x-goog-request-id 的别名）
  "x-cloud-trace-context",
  // GCP（值为 TRACE_ID/SPAN;o=1，取 TRACE_ID 段）
  "eo-log-uuid",
  // EdgeOne CDN
  // —— 其他中转 / CDN 兜底头 ——
  "x-ws-request-id"
  // 网宿（Wangsu）边缘网关
];
var UPSTREAM_ID_MAX_LENGTH = 200;
function normalizeUpstreamId(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > UPSTREAM_ID_MAX_LENGTH) return null;
  return /^[\x21-\x7e]+$/.test(trimmed) ? trimmed : null;
}
function normalizeCloudTraceContextRequestId(value) {
  const trimmed = value.trim();
  if (!trimmed) return null;
  const slash = trimmed.indexOf("/");
  return normalizeUpstreamId(slash >= 0 ? trimmed.slice(0, slash) : trimmed);
}
function extractHeaderRequestId(headers, name) {
  const raw = headers.get(name);
  if (!raw) return null;
  if (name === "x-cloud-trace-context") {
    return normalizeCloudTraceContextRequestId(raw);
  }
  return normalizeUpstreamId(raw);
}
function extractUpstreamRequestId(headers) {
  for (const name of UPSTREAM_REQUEST_ID_HEADER_NAMES) {
    const value = extractHeaderRequestId(headers, name);
    if (value) return value;
  }
  return null;
}

// packages/proxy/src/services/egress/sse-data-line.ts
function fieldName(line2) {
  const separator = line2.indexOf(":");
  return separator < 0 ? line2 : line2.slice(0, separator);
}
function fieldValue(line2) {
  const separator = line2.indexOf(":");
  if (separator < 0) return "";
  const value = line2.slice(separator + 1);
  return value.startsWith(" ") ? value.slice(1) : value;
}
function isDataField(line2) {
  return fieldName(line2) === "data";
}
function parseSseEventData(event) {
  const values = [];
  for (const line2 of event.split(/\r\n|\r|\n/)) {
    if (line2.startsWith(":") || !isDataField(line2)) continue;
    values.push(fieldValue(line2));
  }
  return values.length > 0 ? values.join("\n") : null;
}
function preferredLineEnding(event) {
  if (event.includes("\r\n")) return "\r\n";
  if (event.includes("\r")) return "\r";
  return "\n";
}
function rewriteSseEventData(event, data) {
  const lineEnding = preferredLineEnding(event);
  const lines = event.split(/\r\n|\r|\n/);
  while (lines.at(-1) === "") lines.pop();
  const rewritten = [];
  let inserted = false;
  for (const line2 of lines) {
    if (!isDataField(line2)) {
      rewritten.push(line2);
      continue;
    }
    if (!inserted) {
      rewritten.push(`data: ${data}`);
      inserted = true;
    }
  }
  if (!inserted) rewritten.push(`data: ${data}`);
  return `${rewritten.join(lineEnding)}${lineEnding}${lineEnding}`;
}
function terminateSseEvent(event) {
  const lineEnding = preferredLineEnding(event);
  const lines = event.split(/\r\n|\r|\n/);
  while (lines.at(-1) === "") lines.pop();
  return `${lines.join(lineEnding)}${lineEnding}${lineEnding}`;
}
function lineEndingLengthAt(value, index4) {
  if (value[index4] === "\n") return 1;
  if (value[index4] !== "\r") return 0;
  if (index4 + 1 >= value.length) return -1;
  return value[index4 + 1] === "\n" ? 2 : 1;
}
function findEventBoundaryEnd(value, start) {
  let index4 = start;
  while (index4 < value.length) {
    const firstLength = lineEndingLengthAt(value, index4);
    if (firstLength < 0) return null;
    if (firstLength === 0) {
      index4 += 1;
      continue;
    }
    const secondIndex = index4 + firstLength;
    const secondLength = lineEndingLengthAt(value, secondIndex);
    if (secondLength < 0) return null;
    if (secondLength > 0) return secondIndex + secondLength;
    index4 = secondIndex;
  }
  return null;
}
var BoundedSseEventFramer = class {
  constructor(maxEventChars, limitErrorMessage) {
    this.maxEventChars = maxEventChars;
    this.limitErrorMessage = limitErrorMessage;
  }
  buffer = "";
  async push(chunk, handleEvent) {
    this.buffer += chunk;
    let consumed = 0;
    while (true) {
      const boundaryEnd = findEventBoundaryEnd(this.buffer, consumed);
      if (boundaryEnd === null) break;
      if (boundaryEnd - consumed > this.maxEventChars) {
        this.buffer = "";
        throw new Error(this.limitErrorMessage);
      }
      const event = this.buffer.slice(consumed, boundaryEnd);
      consumed = boundaryEnd;
      if (await handleEvent(event)) {
        this.buffer = "";
        return true;
      }
    }
    if (consumed > 0) this.buffer = this.buffer.slice(consumed);
    if (this.buffer.length > this.maxEventChars) {
      this.buffer = "";
      throw new Error(this.limitErrorMessage);
    }
    return false;
  }
  finish() {
    if (this.buffer.length > this.maxEventChars) {
      this.buffer = "";
      throw new Error(this.limitErrorMessage);
    }
    const remainder = this.buffer;
    this.buffer = "";
    return remainder;
  }
};

// packages/proxy/src/services/egress/audio-transcription-upload.ts
var PAGE_BYTES = 64 * 1024;
var TEXT_UNITS = 8 * 1024;
var encoder3 = new TextEncoder();

// packages/proxy/src/services/egress/bounded-response-body.ts
var UpstreamResponseBodyTooLargeError = class extends Error {
  constructor(upstreamStatus) {
    super("Upstream response body exceeds the configured limit");
    this.upstreamStatus = upstreamStatus;
    this.name = "UpstreamResponseBodyTooLargeError";
  }
};
async function consumeResponseTextWithinLimit(response, maxBytes, consumeText, signal, trackResourceCompletion) {
  let cancellation;
  const cancel = (source, reason) => {
    if (!source || cancellation) return;
    cancellation = observeResourceCleanup(() => source.cancel(reason));
    trackResourceCompletion?.(cancellation);
  };
  if (signal?.aborted) {
    cancel(response.body, signal.reason);
    signal.throwIfAborted();
  }
  const declaredLength = Number(response.headers.get("content-length"));
  if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
    cancel(response.body, "upstream_response_too_large");
    throw new UpstreamResponseBodyTooLargeError(response.status);
  }
  if (!response.body) return;
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let byteLength = 0;
  let rejectPendingRead;
  const onAbort = () => {
    rejectPendingRead?.(signal?.reason);
    cancel(reader, signal?.reason);
  };
  signal?.addEventListener("abort", onAbort, { once: true });
  try {
    while (true) {
      signal?.throwIfAborted();
      const { done, value } = await new Promise((resolve, reject) => {
        rejectPendingRead = reject;
        void reader.read().then(resolve, reject);
      });
      rejectPendingRead = void 0;
      signal?.throwIfAborted();
      if (done) break;
      byteLength += value.byteLength;
      if (byteLength > maxBytes) {
        cancel(reader, "upstream_response_too_large");
        throw new UpstreamResponseBodyTooLargeError(response.status);
      }
      try {
        for (let offset = 0; offset < value.byteLength; offset += 64 * 1024) {
          signal?.throwIfAborted();
          consumeText(decoder.decode(value.subarray(offset, offset + 64 * 1024), { stream: true }));
        }
      } catch (error) {
        cancel(reader, "upstream_response_inspection_failed");
        throw error;
      }
    }
    consumeText(decoder.decode());
  } catch (error) {
    cancel(reader, "upstream_response_read_failed");
    throw error;
  } finally {
    rejectPendingRead = void 0;
    signal?.removeEventListener("abort", onAbort);
    reader.releaseLock();
  }
}
async function responseTextWithinLimit(response, maxBytes, signal, inspectText, trackResourceCompletion) {
  const parts = [];
  let page = "";
  await consumeResponseTextWithinLimit(response, maxBytes, (text5) => {
    inspectText?.(text5);
    page += text5;
    if (page.length >= 64 * 1024) {
      parts.push(page);
      page = "";
    }
  }, signal, trackResourceCompletion);
  if (page) parts.push(page);
  return parts.join("");
}

// packages/proxy/src/services/gateway-error-codes.ts
var GATEWAY_ERROR_CODE_HEADER = "X-OctaFuse-Error-Code";
var GatewayErrorCode = {
  // gateway.*
  invalidJson: "gateway.invalid_json",
  missingModel: "gateway.missing_model",
  modelNotFound: "gateway.model_not_found",
  budgetExceeded: "gateway.budget_exceeded",
  authFailed: "gateway.auth_failed",
  permissionDenied: "gateway.permission_denied",
  authRateLimited: "gateway.auth_rate_limited",
  publicCatalogRateLimited: "gateway.public_catalog_rate_limited",
  analyticsRateLimited: "gateway.analytics_rate_limited",
  publicCatalogUnavailable: "gateway.public_catalog_unavailable",
  internalError: "gateway.internal_error",
  imageSettlementUnconfirmed: "gateway.image_settlement_unconfirmed",
  capacityUnavailable: "gateway.capacity_unavailable",
  routeNotFound: "gateway.route_not_found",
  payloadTooLarge: "gateway.payload_too_large",
  noRoute: "gateway.no_route",
  routeResolutionFailed: "gateway.route_resolution_failed",
  invalidRequest: "gateway.invalid_request",
  resourceConflict: "gateway.resource_conflict",
  invalidPresetReference: "gateway.invalid_preset_reference",
  presetNotFound: "gateway.preset_not_found",
  presetInvalid: "gateway.preset_invalid",
  guardrailBlocked: "gateway.guardrail_blocked",
  guardrailInvalid: "gateway.guardrail_invalid",
  zdrNoRoute: "gateway.zdr_no_route",
  dataCollectionNoRoute: "gateway.data_collection_no_route",
  zdrToolsUnsupported: "gateway.zdr_tools_unsupported",
  upstreamRequestFailed: "gateway.upstream_request_failed",
  dispatchLimitExceeded: "gateway.dispatch_limit_exceeded",
  auxiliaryAuthLimitExceeded: "gateway.auxiliary_auth_limit_exceeded",
  requestDeadlineExceeded: "gateway.request_deadline_exceeded",
  requestCancelled: "gateway.request_cancelled",
  upstreamResponseTooLarge: "gateway.upstream_response_too_large",
  responsesStateRouteUnavailable: "responses.state_route_unavailable",
  responsesUnsupportedStateOperation: "responses.unsupported_state_operation",
  // circuit.*
  circuitSensitiveContent: "circuit.sensitive_content",
  circuitClientError: "circuit.client_error",
  circuitUpstreamCapacityExhausted: "circuit.upstream_capacity_exhausted",
  // upstream.*
  upstreamContentFilter: "upstream.content_filter",
  upstreamInvalidRequest: "upstream.invalid_request",
  upstreamRateLimited: "upstream.rate_limited",
  upstreamAuthFailed: "upstream.auth_failed",
  upstreamNotFound: "upstream.not_found",
  upstreamServerError: "upstream.server_error",
  upstreamTimeout: "upstream.timeout"
};

// packages/proxy/src/services/openrouter-error-protocol.ts
var MAX_PUBLIC_ERROR_MESSAGE_CHARS = 512;
var MAX_PROVIDER_CODE_CHARS = 96;
var MAX_METADATA_KEYS = 32;
var MAX_METADATA_ARRAY_ITEMS = 32;
var MAX_METADATA_DEPTH = 3;
var ERROR_TYPE_BY_GATEWAY_CODE = {
  [GatewayErrorCode.invalidJson]: "invalid_request",
  [GatewayErrorCode.missingModel]: "invalid_request",
  [GatewayErrorCode.modelNotFound]: "not_found",
  [GatewayErrorCode.budgetExceeded]: "payment_required",
  [GatewayErrorCode.authFailed]: "authentication",
  [GatewayErrorCode.permissionDenied]: "permission_denied",
  [GatewayErrorCode.authRateLimited]: "rate_limit_exceeded",
  [GatewayErrorCode.publicCatalogRateLimited]: "rate_limit_exceeded",
  [GatewayErrorCode.analyticsRateLimited]: "rate_limit_exceeded",
  [GatewayErrorCode.publicCatalogUnavailable]: "server",
  [GatewayErrorCode.internalError]: "server",
  [GatewayErrorCode.imageSettlementUnconfirmed]: "server",
  [GatewayErrorCode.capacityUnavailable]: "server",
  [GatewayErrorCode.routeNotFound]: "not_found",
  [GatewayErrorCode.payloadTooLarge]: "payload_too_large",
  [GatewayErrorCode.noRoute]: "not_found",
  [GatewayErrorCode.routeResolutionFailed]: "provider_unavailable",
  [GatewayErrorCode.invalidRequest]: "invalid_request",
  [GatewayErrorCode.resourceConflict]: "conflict",
  [GatewayErrorCode.invalidPresetReference]: "invalid_request",
  [GatewayErrorCode.presetNotFound]: "not_found",
  [GatewayErrorCode.presetInvalid]: "invalid_request",
  [GatewayErrorCode.guardrailBlocked]: "permission_denied",
  [GatewayErrorCode.guardrailInvalid]: "invalid_request",
  [GatewayErrorCode.zdrNoRoute]: "not_found",
  [GatewayErrorCode.dataCollectionNoRoute]: "not_found",
  [GatewayErrorCode.zdrToolsUnsupported]: "invalid_request",
  [GatewayErrorCode.upstreamRequestFailed]: "provider_unavailable",
  [GatewayErrorCode.dispatchLimitExceeded]: "provider_unavailable",
  [GatewayErrorCode.auxiliaryAuthLimitExceeded]: "provider_unavailable",
  [GatewayErrorCode.requestDeadlineExceeded]: "timeout",
  [GatewayErrorCode.requestCancelled]: "provider_unavailable",
  [GatewayErrorCode.upstreamResponseTooLarge]: "provider_unavailable",
  [GatewayErrorCode.responsesStateRouteUnavailable]: "invalid_request",
  [GatewayErrorCode.responsesUnsupportedStateOperation]: "invalid_request",
  [GatewayErrorCode.circuitSensitiveContent]: "rate_limit_exceeded",
  [GatewayErrorCode.circuitClientError]: "invalid_request",
  [GatewayErrorCode.circuitUpstreamCapacityExhausted]: "rate_limit_exceeded",
  [GatewayErrorCode.upstreamContentFilter]: "content_policy_violation",
  [GatewayErrorCode.upstreamInvalidRequest]: "invalid_request",
  [GatewayErrorCode.upstreamRateLimited]: "rate_limit_exceeded",
  [GatewayErrorCode.upstreamAuthFailed]: "provider_unavailable",
  [GatewayErrorCode.upstreamNotFound]: "provider_unavailable",
  [GatewayErrorCode.upstreamServerError]: "provider_unavailable",
  [GatewayErrorCode.upstreamTimeout]: "timeout"
};
var STATUS_BY_ERROR_TYPE = {
  authentication: 401,
  permission_denied: 403,
  payment_required: 402,
  rate_limit_exceeded: 429,
  provider_overloaded: 529,
  provider_unavailable: 502,
  invalid_request: 400,
  conflict: 409,
  invalid_prompt: 400,
  not_found: 404,
  precondition_failed: 412,
  payload_too_large: 413,
  unprocessable: 422,
  content_policy_violation: 400,
  context_length_exceeded: 400,
  max_tokens_exceeded: 400,
  token_limit_exceeded: 400,
  string_too_long: 400,
  timeout: 504,
  server: 500,
  unmapped: 500
};
var RESPONSE_CODE_BY_ERROR_TYPE = {
  rate_limit_exceeded: "rate_limit_exceeded",
  context_length_exceeded: "invalid_prompt",
  invalid_request: "invalid_prompt",
  conflict: "server_error",
  content_policy_violation: "image_content_policy_violation",
  authentication: "server_error",
  provider_overloaded: "server_error",
  provider_unavailable: "server_error",
  timeout: "server_error",
  server: "server_error",
  payment_required: "server_error",
  permission_denied: "server_error",
  invalid_prompt: "server_error",
  not_found: "server_error",
  precondition_failed: "server_error",
  payload_too_large: "server_error",
  unprocessable: "server_error",
  max_tokens_exceeded: "server_error",
  token_limit_exceeded: "server_error",
  string_too_long: "server_error",
  unmapped: "server_error"
};
var ANTHROPIC_TYPE_BY_ERROR_TYPE = {
  authentication: "authentication_error",
  permission_denied: "permission_error",
  payment_required: "billing_error",
  not_found: "not_found_error",
  rate_limit_exceeded: "rate_limit_error",
  provider_overloaded: "overloaded_error",
  timeout: "timeout_error",
  context_length_exceeded: "invalid_request_error",
  content_policy_violation: "invalid_request_error",
  invalid_request: "invalid_request_error",
  conflict: "invalid_request_error",
  invalid_prompt: "invalid_request_error",
  precondition_failed: "invalid_request_error",
  payload_too_large: "invalid_request_error",
  unprocessable: "invalid_request_error",
  max_tokens_exceeded: "invalid_request_error",
  token_limit_exceeded: "invalid_request_error",
  string_too_long: "invalid_request_error",
  provider_unavailable: "api_error",
  server: "api_error",
  unmapped: "api_error"
};
function collapseWhitespace(value) {
  return value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim();
}
function sanitizePublicErrorMessage(value, fallback = "Request failed") {
  let message = collapseWhitespace(value);
  message = message.replace(/\bBearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [redacted]").replace(/\bsk-[A-Za-z0-9_-]{8,}\b/g, "[redacted]").replace(
    /\b(api[_ -]?key|access[_ -]?token|authorization)(\s*[:=]\s*)[^\s,;]+/gi,
    "$1$2[redacted]"
  ).replace(/(https?:\/\/[^\s/:@]+:)[^\s/@]+@/gi, "$1[redacted]@");
  if (!message) message = fallback;
  return message.length <= MAX_PUBLIC_ERROR_MESSAGE_CHARS ? message : `${message.slice(0, MAX_PUBLIC_ERROR_MESSAGE_CHARS - 1)}\u2026`;
}
function sanitizeProviderCode(value) {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const normalized = String(value).trim();
  if (!normalized || !/^[A-Za-z0-9_.:/-]+$/.test(normalized)) return null;
  return normalized.slice(0, MAX_PROVIDER_CODE_CHARS);
}
function sanitizeMetadataValue(value, depth) {
  if (value == null || typeof value === "boolean") return value;
  if (typeof value === "number")
    return Number.isFinite(value) ? value : void 0;
  if (typeof value === "string") return sanitizePublicErrorMessage(value, "");
  if (depth >= MAX_METADATA_DEPTH) return void 0;
  if (Array.isArray(value)) {
    return value.slice(0, MAX_METADATA_ARRAY_ITEMS).map((item) => sanitizeMetadataValue(item, depth + 1)).filter((item) => item !== void 0);
  }
  if (typeof value !== "object") return void 0;
  const sanitized = {};
  for (const [key, item] of Object.entries(value).slice(0, MAX_METADATA_KEYS)) {
    if (!/^[A-Za-z0-9_.-]{1,64}$/.test(key)) continue;
    const next = sanitizeMetadataValue(item, depth + 1);
    if (next !== void 0) sanitized[key] = next;
  }
  return sanitized;
}
function sanitizeMetadata(metadata) {
  const sanitized = sanitizeMetadataValue(metadata ?? {}, 0);
  return sanitized && typeof sanitized === "object" && !Array.isArray(sanitized) ? sanitized : {};
}
function openRouterErrorTypeForGatewayCode(code) {
  return ERROR_TYPE_BY_GATEWAY_CODE[code];
}
function openRouterStatusForErrorType(errorType) {
  return STATUS_BY_ERROR_TYPE[errorType];
}
function openRouterStatusForGatewayCode(code) {
  if (code === GatewayErrorCode.capacityUnavailable) return 503;
  if (code === GatewayErrorCode.imageSettlementUnconfirmed) return 503;
  return openRouterStatusForErrorType(openRouterErrorTypeForGatewayCode(code));
}
function buildOpenRouterErrorBody(options) {
  const message = sanitizePublicErrorMessage(options.message);
  const metadata = sanitizeMetadata(options.metadata);
  const providerCode = sanitizeProviderCode(options.providerCode);
  if (options.skin === "anthropic") {
    return {
      type: "error",
      error: {
        type: ANTHROPIC_TYPE_BY_ERROR_TYPE[options.errorType],
        message,
        error_type: options.errorType
      },
      request_id: options.requestId ?? null,
      ...options.legacyCode ? { code: options.legacyCode } : {}
    };
  }
  if (options.skin === "responses") {
    return {
      status: "failed",
      error: {
        code: RESPONSE_CODE_BY_ERROR_TYPE[options.errorType],
        message
      },
      error_type: options.errorType,
      ...options.requestId ? { id: options.requestId } : {},
      ...options.legacyCode ? { code: options.legacyCode } : {}
    };
  }
  return {
    error: {
      code: options.status,
      message,
      metadata: {
        ...metadata,
        error_type: options.errorType,
        ...providerCode ? { provider_code: providerCode } : {}
      }
    },
    ...options.legacyCode ? { code: options.legacyCode } : {}
  };
}
function publicMessageForGatewayError(code, message) {
  switch (code) {
    case GatewayErrorCode.capacityUnavailable:
      return "Gateway capacity is unavailable";
    case GatewayErrorCode.internalError:
      return "Internal server error";
    case GatewayErrorCode.imageSettlementUnconfirmed:
      return "Image settlement persistence is unconfirmed. Upstream may have completed; do not automatically retry.";
    case GatewayErrorCode.noRoute:
    case GatewayErrorCode.zdrNoRoute:
    case GatewayErrorCode.dataCollectionNoRoute:
      return "No available model provider meets the routing requirements";
    case GatewayErrorCode.routeResolutionFailed:
    case GatewayErrorCode.upstreamRequestFailed:
    case GatewayErrorCode.upstreamAuthFailed:
    case GatewayErrorCode.upstreamNotFound:
    case GatewayErrorCode.upstreamServerError:
      return "Upstream provider is unavailable";
    case GatewayErrorCode.upstreamTimeout:
      return "Upstream provider timed out";
    default:
      return sanitizePublicErrorMessage(message);
  }
}
function buildChatMidstreamErrorEvent(params) {
  const status = openRouterStatusForErrorType("provider_unavailable");
  return `data: ${JSON.stringify({
    ...params.id ? { id: params.id } : {},
    object: "chat.completion.chunk",
    created: Math.floor(Date.now() / 1e3),
    model: params.model,
    provider: params.provider,
    error: {
      code: status,
      message: sanitizePublicErrorMessage(
        params.message ?? "Upstream provider stream interrupted"
      ),
      metadata: { error_type: "provider_unavailable" }
    },
    choices: [{ index: 0, delta: { content: "" }, finish_reason: "error" }]
  })}

`;
}

// packages/proxy/src/services/gateway-error-response.ts
function publicErrorHeaders(code, status, extra) {
  const headers = new Headers(extra);
  headers.set("Content-Type", "application/json; charset=UTF-8");
  headers.set("Cache-Control", "no-store");
  headers.set(GATEWAY_ERROR_CODE_HEADER, code);
  headers.delete("Content-Length");
  if (status !== 429 && status !== 503 && status !== 529) headers.delete("Retry-After");
  return headers;
}
function buildGatewayErrorResponse(opts, skin) {
  const status = openRouterStatusForGatewayCode(opts.code);
  const errorType = openRouterErrorTypeForGatewayCode(opts.code);
  const message = publicMessageForGatewayError(opts.code, opts.message);
  const body = buildOpenRouterErrorBody({
    skin,
    status,
    message,
    errorType,
    legacyCode: opts.code,
    metadata: opts.metadata,
    requestId: opts.requestId
  });
  return new Response(JSON.stringify(body), {
    status,
    headers: publicErrorHeaders(opts.code, status, opts.headers)
  });
}
function gatewayErrorResponse(opts) {
  return buildGatewayErrorResponse(opts, opts.skin ?? "chat");
}

// packages/proxy/src/services/egress/openai-audio-driver.ts
var AUDIO_TRANSCRIPTION_MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
var AUDIO_MAX_BYTES_PER_FILE = 25 * 1024 * 1024;

// packages/proxy/src/services/egress/audio-duration.ts
var MAX_AUDIO_DURATION_SECONDS = 25 * 60;

// packages/proxy/src/services/endpoint-audio-billing-pricing.ts
var MAX_SAFE_COST = Number.MAX_SAFE_INTEGER;
var AUDIO_OPERATION_SET = new Set(AUDIO_ENDPOINT_PRICING_OPERATIONS);

// packages/proxy/src/services/dashscope-realtime-guardrails.ts
var DASHSCOPE_REALTIME_MAX_SESSION_MS = 10 * 60 * 1e3;
var DASHSCOPE_REALTIME_CONNECT_TIMEOUT_MS = 30 * 1e3;
var DASHSCOPE_REALTIME_MAX_AUDIO_SECONDS = 10 * 60;
var DASHSCOPE_REALTIME_BILLING_DURATION_CEILING_SECONDS = DASHSCOPE_REALTIME_MAX_AUDIO_SECONDS + 1;
var DASHSCOPE_REALTIME_MAX_CLIENT_MESSAGE_BYTES = 4 * 1024 * 1024;
var DASHSCOPE_REALTIME_MAX_CLIENT_BYTES = 32 * 1024 * 1024;
var DASHSCOPE_REALTIME_GUARDRAIL_LEASE_MS = 15 * 60 * 1e3;

// packages/proxy/src/services/egress/text-upstream-url.ts
function assertTextUpstreamHttpUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error("Text upstream endpoint is not a valid URL");
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Text upstream endpoint must use http(s)");
  }
}

// packages/proxy/src/services/egress/ambiguous-upstream-status.ts
function ambiguousDispatchedStatusMeta(status) {
  const mayHideAcceptedWork = status >= 300 && status < 400 || status === 408 || status === 499 || status >= 500;
  return mayHideAcceptedWork ? { upstreamOutcomeUnknown: true, failoverForbidden: true } : void 0;
}

// packages/proxy/src/services/egress/text-json-response.ts
var TEXT_JSON_RESPONSE_MAX_BYTES = 8 * 1024 * 1024;
var TEXT_SUCCESS_RESPONSE_MAX_COLLECTION_ITEMS = 4096;
function invalidTextSuccessResponse(params) {
  return {
    response: gatewayErrorResponse({
      status: 502,
      code: GatewayErrorCode.upstreamRequestFailed,
      message: `Upstream provider returned an invalid ${params.protocol} response`,
      skin: params.skin,
      requestId: params.requestId
    }),
    meta: {
      upstreamOutcomeUnknown: true,
      failoverForbidden: true,
      gatewayGeneratedError: true
    }
  };
}
async function cancelInvalidTextSuccessResponse(response, params) {
  void response.body?.cancel("invalid_text_success_response").catch(() => void 0);
  return invalidTextSuccessResponse(params);
}
function unreadableTextJsonResponse(params) {
  return {
    response: gatewayErrorResponse({
      status: 502,
      code: params.tooLarge ? GatewayErrorCode.upstreamResponseTooLarge : GatewayErrorCode.upstreamRequestFailed,
      message: params.tooLarge ? "Upstream response exceeded the gateway size limit" : "Upstream provider returned an invalid JSON response",
      skin: params.skin,
      requestId: params.requestId
    }),
    meta: {
      upstreamOutcomeUnknown: true,
      failoverForbidden: true,
      gatewayGeneratedError: true,
      ...params.tooLarge ? { responseBodyTooLarge: true } : {}
    }
  };
}
async function readBoundedTextJsonObject(response, options) {
  let text5;
  try {
    text5 = await responseTextWithinLimit(
      response,
      options.maxBytes ?? TEXT_JSON_RESPONSE_MAX_BYTES,
      options.signal
    );
  } catch (error) {
    return {
      ok: false,
      ...unreadableTextJsonResponse({
        ...options,
        tooLarge: error instanceof UpstreamResponseBodyTooLargeError
      })
    };
  }
  let parsed;
  try {
    parsed = JSON.parse(text5);
  } catch {
    return {
      ok: false,
      ...unreadableTextJsonResponse({ ...options, tooLarge: false })
    };
  }
  if (parsed == null || typeof parsed !== "object" || Array.isArray(parsed)) {
    return {
      ok: false,
      ...unreadableTextJsonResponse({ ...options, tooLarge: false })
    };
  }
  return { ok: true, value: parsed };
}
function rebuildTextJsonResponse(response, value) {
  const headers = new Headers(response.headers);
  headers.delete("Content-Length");
  headers.delete("Content-Encoding");
  headers.delete("Transfer-Encoding");
  return new Response(JSON.stringify(value), {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}
function preDispatchCancelledTextResponse(skin, requestId) {
  const status = 499;
  return new Response(JSON.stringify(buildOpenRouterErrorBody({
    skin,
    status,
    message: "Request was cancelled before upstream dispatch",
    errorType: "provider_unavailable",
    legacyCode: GatewayErrorCode.upstreamRequestFailed,
    requestId
  })), {
    status,
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
      "Cache-Control": "no-store",
      [GATEWAY_ERROR_CODE_HEADER]: GatewayErrorCode.upstreamRequestFailed
    }
  });
}

// packages/proxy/src/services/egress/service-tier-contract.ts
function normalizeResponseTextSpeed(value) {
  return value === "fast" || value === "standard" ? value : null;
}
function normalizeOpenAiResponseServiceTier(value) {
  if (value === "flex") return "flex";
  if (value === "priority" || value === "fast") return "priority";
  if (value === "default" || value === "standard" || value === "auto") return "default";
  return null;
}

// packages/proxy/src/services/egress/openai-responses-driver.ts
var MAX_RESPONSES_SSE_EVENT_CHARS = 256 * 1024;
var encoder4 = new TextEncoder();

// packages/proxy/src/services/egress/openai-embeddings-driver.ts
var OPENAI_EMBEDDINGS_RESPONSE_MAX_BYTES = 32 * 1024 * 1024;

// packages/proxy/src/services/egress/openai-rerank-driver.ts
var OPENAI_RERANK_RESPONSE_MAX_BYTES = 16 * 1024 * 1024;

// packages/proxy/src/services/image-attempt-context.ts
import { createHash as createHash3 } from "node:crypto";

// packages/proxy/src/services/json-structure-budget.ts
var IMAGE_JSON_STRUCTURE_LIMITS = Object.freeze({
  maxDepth: 64,
  maxNodes: 65536
});
var IMAGE_JSON_MAX_PROPERTY_NAME_CHARS = 256;
var IMAGE_JSON_ADMISSION_LIMITS = Object.freeze({
  ...IMAGE_JSON_STRUCTURE_LIMITS,
  maxPropertyNameChars: IMAGE_JSON_MAX_PROPERTY_NAME_CHARS
});

// packages/proxy/src/services/multipart-body-inspector.ts
var MULTIPART_MAX_HEADER_BYTES = 16 * 1024;
var MULTIPART_MAX_FIELD_BYTES = 64 * 1024;
var MULTIPART_MAX_FIELDS_BYTES = 128 * 1024;
var MAX_FRAMING_BYTES = 16 * 1024;

// packages/proxy/src/services/streaming-multipart-body.ts
var MULTIPART_FILE_PAGE_BYTES = 64 * 1024;

// packages/proxy/src/services/image-attempt-context.ts
var MAX_DIGEST_JSON_BYTES = 4 * MAX_REQUEST_BODY_BYTES;
var MAX_FILE_BYTES = 20 * 1024 * 1024;
var JSON_LIMITS = Object.freeze({
  maxDepth: IMAGE_JSON_STRUCTURE_LIMITS.maxDepth + 4,
  maxNodes: IMAGE_JSON_STRUCTURE_LIMITS.maxNodes + 128
});

// packages/proxy/src/services/egress/multipart-upload-body.ts
var encoder5 = new TextEncoder();

// packages/proxy/src/services/egress/image-response-usage.ts
var IMAGE_MAX_USAGE_JSON_BYTES = 64 * 1024;
var USAGE_LIMITS = Object.freeze({ maxDepth: IMAGE_JSON_STRUCTURE_LIMITS.maxDepth, maxNodes: 3 * IMAGE_JSON_STRUCTURE_LIMITS.maxNodes + 16 });

// packages/proxy/src/services/egress/openai-images-driver.ts
var IMAGE_MAX_REFERENCE_COUNT = 5;
var IMAGE_MAX_BYTES_PER_FILE = 20 * 1024 * 1024;
var IMAGE_MAX_TOTAL_UPLOAD_BYTES = IMAGE_MAX_REFERENCE_COUNT * IMAGE_MAX_BYTES_PER_FILE;
var IMAGE_MAX_RESPONSE_BYTES = 32 * 1024 * 1024;
var NORMALIZED_IMAGE_JSON_LIMITS = Object.freeze({
  maxDepth: IMAGE_JSON_STRUCTURE_LIMITS.maxDepth,
  maxNodes: 3 * IMAGE_JSON_STRUCTURE_LIMITS.maxNodes + 16
});
var IMAGE_MAX_SSE_EVENT_BYTES = 8 * 1024 * 1024;
var SSE_DONE_FRAME = new TextEncoder().encode("data: [DONE]\n\n");
var SSE_KEEPALIVE_FRAME = new TextEncoder().encode(": keep-alive\n\n");

// packages/tool-engines/src/http/bounded-response.ts
var TOOL_PROVIDER_RESPONSE_MAX_BYTES = 2 * 1024 * 1024;
var TOOL_PROVIDER_OUTPUT_MAX_BYTES = TOOL_PROVIDER_RESPONSE_MAX_BYTES - 16 * 1024;

// packages/proxy/src/services/egress/dashscope-audio-driver.ts
var DASHSCOPE_SYNC_ASR_MAX_DATA_URL_BYTES = 10 * 1024 * 1024;
var DASHSCOPE_MULTIMODAL_MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

// packages/proxy/src/services/egress/audio-speech-driver.ts
var AUDIO_SPEECH_MAX_ERROR_RESPONSE_BYTES = 64 * 1024;
var SPEECH_SSE_MAX_EVENT_CHARS = 8 * 1024 * 1024;

// packages/proxy/src/services/egress/dashscope-realtime-driver.ts
init_provider_endpoints();
var DASHSCOPE_REALTIME_MAX_PROVIDER_MESSAGE_BYTES = 4 * 1024 * 1024;
var DASHSCOPE_REALTIME_MAX_PROVIDER_BYTES = 32 * 1024 * 1024;

// packages/proxy/src/services/egress/finish-reason-contract.ts
var CONTROL_CHAR_PATTERN = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/u;
var MAX_NATIVE_FINISH_REASON_LENGTH = 128;
function normalizeNativeFinishReason(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed && trimmed.length <= MAX_NATIVE_FINISH_REASON_LENGTH && !CONTROL_CHAR_PATTERN.test(trimmed) ? trimmed : null;
}
function normalizeCanonicalFinishReason(value) {
  switch (value) {
    case "tool_calls":
    case "stop":
    case "length":
    case "content_filter":
    case "error":
      return value;
    default:
      return null;
  }
}

// packages/proxy/src/services/egress/anthropic-driver.ts
var MAX_ANTHROPIC_SSE_EVENT_CHARS = 256 * 1024;
var encoder6 = new TextEncoder();

// packages/proxy/src/services/egress/gemini-driver.ts
var GEMINI_SSE_MAX_LINE_CHARS = 256 * 1024;

// packages/proxy/src/services/ordinary-budget-lifecycle.ts
var ORDINARY_BUDGET_ADMISSION_LEASE_MS = 2 * 60 * 1e3;
var ORDINARY_BUDGET_DISPATCH_LEASE_MS = 15 * 60 * 1e3;

// packages/proxy/src/services/request-guardrails.ts
var GUARDRAIL_BUDGET_ADMISSION_LEASE_MS = 2 * 60 * 1e3;
var GUARDRAIL_BUDGET_DISPATCH_LEASE_MS = 15 * 60 * 1e3;
var GUARDRAIL_MAX_RESPONSE_BYTES = 2 * 1024 * 1024;

// packages/proxy/src/services/request-log-record-status.ts
var MAX_MATERIALIZED_ERROR_BODY_BYTES = 64 * 1024;

// packages/proxy/src/services/failover-dispatch.ts
var STICKY_STALE_GC_PROBABILITY = 1 / 500;
var STICKY_STALE_GC_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
var MAX_DISPATCH_TRACE_ERROR_BODY_BYTES = 8 * 1024;
function markUpstreamOutcomeUnknown(error) {
  const normalized = error instanceof Error ? error : new Error(String(error));
  return Object.assign(normalized, { upstreamOutcomeUnknown: true });
}

// packages/proxy/src/services/egress/openai-stream-usage-request.ts
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function ensureOpenAiStreamIncludesUsage(body) {
  if (body.stream !== true) return body;
  const current = isRecord(body.stream_options) ? body.stream_options : {};
  return {
    ...body,
    stream_options: {
      ...current,
      include_usage: true
    }
  };
}

// packages/proxy/src/services/egress/openai-driver.ts
var EMPTY_USAGE_LOCAL = {
  input_tokens: 0,
  output_tokens: 0,
  cache_read_tokens: 0,
  cache_write_tokens: 0,
  reasoning_tokens: 0,
  total_tokens: 0,
  raw_usage: null
};
var MAX_OPENAI_SSE_EVENT_CHARS = 256 * 1024;
function isPlainObject2(value) {
  return value != null && typeof value === "object" && !Array.isArray(value);
}
function nonNegativeSafeInteger(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function optionalSafeCount(value) {
  return value === void 0 || nonNegativeSafeInteger(value);
}
function effectiveSafeCount(primary, fallback) {
  if (nonNegativeSafeInteger(primary)) return primary;
  return nonNegativeSafeInteger(fallback) ? fallback : null;
}
function validProviderUsage(value) {
  if (!isPlainObject2(value)) return false;
  const prompt = value.prompt_tokens;
  const input = value.input_tokens;
  const completion = value.completion_tokens;
  const output = value.output_tokens;
  if (!nonNegativeSafeInteger(prompt) && !nonNegativeSafeInteger(input) || !nonNegativeSafeInteger(completion) && !nonNegativeSafeInteger(output) || !nonNegativeSafeInteger(value.total_tokens) || prompt !== void 0 && input !== void 0 && prompt !== input || completion !== void 0 && output !== void 0 && completion !== output) return false;
  const promptDetails = value.prompt_tokens_details;
  const completionDetails = value.completion_tokens_details;
  if (promptDetails !== void 0 && !isPlainObject2(promptDetails)) return false;
  if (completionDetails !== void 0 && !isPlainObject2(completionDetails)) return false;
  if (!optionalSafeCount(promptDetails?.cached_tokens) || !optionalSafeCount(promptDetails?.cache_creation_tokens) || !optionalSafeCount(completionDetails?.reasoning_tokens) || !optionalSafeCount(completionDetails?.text_tokens) || !optionalSafeCount(completionDetails?.image_tokens)) return false;
  const inputCount = effectiveSafeCount(prompt, input);
  const outputCount = effectiveSafeCount(completion, output);
  if (inputCount == null || outputCount == null) return false;
  const cacheRead = nonNegativeSafeInteger(promptDetails?.cached_tokens) ? promptDetails.cached_tokens : 0;
  const cacheWrite = nonNegativeSafeInteger(promptDetails?.cache_creation_tokens) ? promptDetails.cache_creation_tokens : 0;
  const cacheCount = cacheRead + cacheWrite;
  const totalCount = value.total_tokens;
  if ((!Number.isSafeInteger(inputCount + outputCount) || totalCount !== inputCount + outputCount) && (!Number.isSafeInteger(inputCount + cacheCount + outputCount) || totalCount !== inputCount + cacheCount + outputCount)) return false;
  const reasoning = completionDetails?.reasoning_tokens;
  return reasoning === void 0 || nonNegativeSafeInteger(reasoning) && reasoning <= outputCount;
}
function validChatMessage(value) {
  if (!isPlainObject2(value) || value.role !== "assistant") return false;
  const hasContent = Object.prototype.hasOwnProperty.call(value, "content");
  const content = value.content;
  const validContent = content === null || typeof content === "string" || Array.isArray(content);
  return hasContent && validContent || Array.isArray(value.tool_calls) || isPlainObject2(value.function_call) || typeof value.refusal === "string";
}
function validChatSuccessResponse(value) {
  if (value.object !== "chat.completion" || normalizeUpstreamId(value.id) == null || typeof value.model !== "string" || !value.model.trim() || !nonNegativeSafeInteger(value.created) || !Array.isArray(value.choices) || value.choices.length === 0 || value.choices.length > TEXT_SUCCESS_RESPONSE_MAX_COLLECTION_ITEMS || value.usage !== void 0 && !validProviderUsage(value.usage)) return false;
  const indexes = /* @__PURE__ */ new Set();
  for (const choice of value.choices) {
    if (!isPlainObject2(choice) || !nonNegativeSafeInteger(choice.index) || indexes.has(choice.index) || !Object.prototype.hasOwnProperty.call(choice, "finish_reason") || choice.finish_reason !== null && typeof choice.finish_reason !== "string" || !validChatMessage(choice.message)) return false;
    indexes.add(choice.index);
  }
  return true;
}
var encoder7 = new TextEncoder();
function normalizeInputTokensFromPrompt(args) {
  const { promptTokens, completionTokens, cacheRead, cacheWrite, totalTokens } = args;
  const cacheTotal = cacheRead + cacheWrite;
  if (cacheTotal <= 0) return promptTokens;
  if (promptTokens < cacheTotal) {
    return promptTokens + cacheTotal;
  }
  if (typeof totalTokens === "number" && Number.isFinite(totalTokens) && totalTokens >= 0) {
    const expectedWithIncludedCache = promptTokens + completionTokens;
    const expectedWithPureInputPrompt = promptTokens + cacheTotal + completionTokens;
    const diffIncluded = Math.abs(totalTokens - expectedWithIncludedCache);
    const diffPureInput = Math.abs(totalTokens - expectedWithPureInputPrompt);
    if (diffPureInput < diffIncluded) {
      return promptTokens + cacheTotal;
    }
  }
  return promptTokens;
}
function usageFromProvider(u) {
  const promptTokensRaw = u.prompt_tokens ?? u.input_tokens ?? 0;
  const completionTokens = u.completion_tokens ?? u.output_tokens ?? 0;
  const cacheRead = u.prompt_tokens_details?.cached_tokens ?? 0;
  const cacheWrite = u.prompt_tokens_details?.cache_creation_tokens ?? 0;
  const reasoning = u.completion_tokens_details?.reasoning_tokens ?? 0;
  const promptTokens = normalizeInputTokensFromPrompt({
    promptTokens: promptTokensRaw,
    completionTokens,
    cacheRead,
    cacheWrite,
    totalTokens: u.total_tokens
  });
  const rawJson = JSON.stringify(u);
  const nativePrompt = effectiveSafeCount(u.prompt_tokens, u.input_tokens);
  const nativeCompletion = effectiveSafeCount(u.completion_tokens, u.output_tokens);
  const nativeCached = nonNegativeSafeInteger(u.prompt_tokens_details?.cached_tokens) ? u.prompt_tokens_details.cached_tokens : null;
  const nativeReasoning = nonNegativeSafeInteger(u.completion_tokens_details?.reasoning_tokens) ? u.completion_tokens_details.reasoning_tokens : null;
  const nativeCompletionImages = nonNegativeSafeInteger(u.completion_tokens_details?.image_tokens) ? u.completion_tokens_details.image_tokens : null;
  const usage = {
    input_tokens: promptTokens,
    output_tokens: completionTokens,
    cache_read_tokens: cacheRead,
    cache_write_tokens: cacheWrite,
    reasoning_tokens: reasoning,
    total_tokens: u.total_tokens ?? promptTokens + completionTokens,
    raw_usage: rawJson,
    native_tokens_prompt: nativePrompt,
    native_tokens_completion: nativeCompletion,
    native_tokens_cached: nativeCached,
    native_tokens_reasoning: nativeReasoning,
    native_tokens_completion_images: nativeCompletionImages
  };
  if (Object.prototype.hasOwnProperty.call(u, "speed")) {
    usage.speed = normalizeResponseTextSpeed(u.speed);
  }
  return usage;
}
function hasOpenAiReasoningDelta(parsed) {
  for (const choice of parsed.choices ?? []) {
    const delta = choice?.delta;
    if (!delta) continue;
    const rc = delta.reasoning_content;
    if (typeof rc === "string" && rc.length > 0) return true;
    const th = delta.thinking;
    if (typeof th === "string" && th.length > 0) return true;
    const r = delta.reasoning;
    if (typeof r === "string" && r.length > 0) return true;
  }
  return false;
}
function hasOpenAiContentDelta(parsed) {
  for (const choice of parsed.choices ?? []) {
    const delta = choice?.delta;
    if (!delta) continue;
    if (typeof delta.content === "string" && delta.content.length > 0) return true;
    if (Array.isArray(delta.tool_calls) && delta.tool_calls.length > 0) return true;
    if (delta.function_call != null) return true;
  }
  return false;
}
function nonEmptyString(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function applyProviderUsage(target, providerUsage) {
  const next = usageFromProvider(providerUsage);
  target.input_tokens = next.input_tokens;
  target.output_tokens = next.output_tokens;
  target.cache_read_tokens = next.cache_read_tokens;
  target.cache_write_tokens = next.cache_write_tokens;
  target.reasoning_tokens = next.reasoning_tokens;
  target.total_tokens = next.total_tokens;
  target.raw_usage = next.raw_usage;
  target.native_tokens_prompt = next.native_tokens_prompt;
  target.native_tokens_completion = next.native_tokens_completion;
  target.native_tokens_cached = next.native_tokens_cached;
  target.native_tokens_reasoning = next.native_tokens_reasoning;
  target.native_tokens_completion_images = next.native_tokens_completion_images;
  if (Object.prototype.hasOwnProperty.call(next, "speed")) target.speed = next.speed;
}
function processChatSseEvent(params) {
  const parsedData = parseSseEventData(params.event);
  if (parsedData === null) return { wire: params.event, stop: false };
  const data = parsedData.trim();
  if (!data) return { wire: params.event, stop: false };
  if (data === "[DONE]") {
    params.state.sawDone = true;
    return { wire: params.event, stop: true };
  }
  let parsed;
  try {
    const candidate = JSON.parse(data);
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) throw new Error("invalid event");
    parsed = candidate;
  } catch {
    params.usage.stream_error = params.usage.stream_error ?? "Malformed OpenAI SSE data event";
    params.state.sawFailure = true;
    return {
      wire: buildChatMidstreamErrorEvent({
        id: params.state.associationId,
        model: params.publicModelId ?? "",
        provider: params.publicProviderName ?? ""
      }),
      stop: true
    };
  }
  params.timing?.markFirstEvent();
  if (hasOpenAiReasoningDelta(parsed)) params.timing?.markFirstReasoningToken();
  if (hasOpenAiContentDelta(parsed)) params.timing?.markFirstToken();
  const eventId = normalizeUpstreamId(parsed.id);
  if (eventId) {
    params.state.associationId ??= eventId;
    params.usage.upstreamMessageId ??= eventId;
  }
  if (parsed.usage) {
    if (Object.prototype.hasOwnProperty.call(parsed.usage, "speed")) {
      parsed.usage.speed = normalizeResponseTextSpeed(parsed.usage.speed);
    }
    applyProviderUsage(params.usage, parsed.usage);
  }
  if (parsed.error && typeof parsed.error === "object") {
    params.usage.stream_error = sanitizePublicErrorMessage(
      nonEmptyString(parsed.error.message) ?? "Upstream Chat Completions stream failed",
      "Upstream Chat Completions stream failed"
    );
    params.state.sawFailure = true;
    return {
      wire: buildChatMidstreamErrorEvent({
        id: params.state.associationId,
        model: params.publicModelId ?? "",
        provider: params.publicProviderName ?? ""
      }),
      stop: true
    };
  }
  let changed = false;
  if (Object.prototype.hasOwnProperty.call(parsed, "service_tier")) {
    params.state.serviceTier = normalizeOpenAiResponseServiceTier(parsed.service_tier);
  }
  parsed.service_tier = params.state.serviceTier;
  params.usage.service_tier = params.state.serviceTier;
  changed = true;
  if (params.state.associationId && parsed.id !== params.state.associationId) {
    parsed.id = params.state.associationId;
    changed = true;
  }
  if (params.publicModelId && Object.prototype.hasOwnProperty.call(parsed, "model")) {
    parsed.model = params.publicModelId;
    changed = true;
  }
  const choices = Array.isArray(parsed.choices) ? parsed.choices : [];
  let hasTerminalFinish = false;
  for (const choice of choices) {
    if (!choice || typeof choice !== "object") continue;
    const finishReason = nonEmptyString(choice.finish_reason);
    const nativeFinishReason = nonEmptyString(choice.native_finish_reason);
    if (finishReason) {
      hasTerminalFinish = true;
      params.state.lastFinishReason = finishReason;
      params.state.lastNativeFinishReason = nativeFinishReason ?? finishReason;
      if (!nativeFinishReason) {
        choice.native_finish_reason = finishReason;
        changed = true;
      }
    } else if (nativeFinishReason) {
      params.state.lastNativeFinishReason = nativeFinishReason;
    }
    if (choice.index === 0) {
      params.usage.finish_reason = normalizeCanonicalFinishReason(choice.finish_reason);
      params.usage.native_finish_reason = normalizeNativeFinishReason(
        choice.native_finish_reason ?? choice.finish_reason
      );
    }
  }
  if (parsed.usage != null && choices.length === 0) {
    const finishReason = params.state.lastFinishReason ?? params.state.lastNativeFinishReason ?? "stop";
    const nativeFinishReason = params.state.lastNativeFinishReason ?? finishReason;
    parsed.choices = [{
      index: 0,
      delta: { content: "", role: "assistant" },
      finish_reason: finishReason,
      native_finish_reason: nativeFinishReason
    }];
    if (!eventId && params.state.associationId) parsed.id = params.state.associationId;
    changed = true;
  } else if (parsed.usage != null && choices.length > 0 && !hasTerminalFinish) {
    delete parsed.usage;
    changed = true;
  }
  return {
    wire: changed ? rewriteSseEventData(params.event, JSON.stringify(parsed)) : params.event,
    stop: false
  };
}
async function pumpWithUsageTracking(upstream, downstream, usage, resolveUsage, stopDownstream, requestSignal, timing, publicModelId, publicProviderName, publicCorrelationId) {
  const decoder = new TextDecoder();
  const reader = upstream.getReader();
  const writer = downstream.getWriter();
  const state = {
    sawDone: false,
    sawFailure: false,
    associationId: normalizeUpstreamId(publicCorrelationId),
    lastFinishReason: null,
    lastNativeFinishReason: null,
    serviceTier: null
  };
  const framer = new BoundedSseEventFramer(
    MAX_OPENAI_SSE_EVENT_CHARS,
    "OpenAI SSE event exceeded the gateway framing limit"
  );
  let clientDisconnected = false;
  let finished = false;
  let cleanupConfirmed = true;
  let cancellation;
  const cancelUpstream = (reason) => {
    cancellation ??= reader.cancel(reason).catch(() => {
      cleanupConfirmed = false;
    });
  };
  const markClientDisconnected = () => {
    if (finished || clientDisconnected) return;
    markTextStreamCancellation(usage, requestSignal);
    clientDisconnected = true;
    cancelUpstream(requestSignal?.reason);
    stopDownstream(requestSignal?.reason ?? new Error("Text response delivery stopped"));
  };
  const onAbort = () => {
    markClientDisconnected();
  };
  if (requestSignal?.aborted) markClientDisconnected();
  else {
    requestSignal?.addEventListener("abort", onAbort, { once: true });
  }
  void writer.closed.catch(markClientDisconnected);
  const writeWire = async (wire) => {
    if (!wire || clientDisconnected) return !clientDisconnected;
    try {
      await writer.write(encoder7.encode(wire));
      return true;
    } catch {
      markClientDisconnected();
      return false;
    }
  };
  const processEvent = (event) => processChatSseEvent({
    event,
    state,
    usage,
    timing,
    publicModelId,
    publicProviderName
  });
  const handleEvent = async (event) => {
    if (clientDisconnected) return true;
    const processed = processEvent(event);
    const written = await writeWire(processed.wire);
    return processed.stop || !written || clientDisconnected;
  };
  try {
    while (true) {
      if (clientDisconnected) break;
      const { done, value } = await reader.read();
      if (clientDisconnected) break;
      if (done) {
        const stopped = await framer.push(decoder.decode(), handleEvent);
        const remainder = stopped ? "" : framer.finish();
        if (remainder.trim() && !clientDisconnected) {
          await handleEvent(terminateSseEvent(remainder));
        }
        if (!state.sawDone && !state.sawFailure && !clientDisconnected) {
          usage.stream_error = usage.stream_error ?? "Upstream Chat stream ended before data: [DONE]";
          state.sawFailure = true;
          await writeWire(buildChatMidstreamErrorEvent({
            id: state.associationId,
            model: publicModelId ?? "",
            provider: publicProviderName ?? ""
          }));
        }
        break;
      }
      if (value.byteLength > 0) timing?.markFirstByte();
      const stop = await framer.push(decoder.decode(value, { stream: true }), handleEvent);
      if (stop || clientDisconnected) {
        cancelUpstream(stop ? "Chat SSE terminal event received" : requestSignal?.reason);
        break;
      }
    }
  } catch (err) {
    if (!clientDisconnected) {
      cancelUpstream("Chat SSE processing failed");
      usage.stream_error = usage.stream_error ?? sanitizePublicErrorMessage(
        err instanceof Error ? err.message : String(err),
        "Upstream Chat Completions stream failed"
      );
      console.warn("[Gateway Proxy] pump error", err instanceof Error ? err.message : String(err));
      if (!state.sawFailure) {
        state.sawFailure = true;
        await writeWire(buildChatMidstreamErrorEvent({
          id: state.associationId,
          model: publicModelId ?? "",
          provider: publicProviderName ?? ""
        }));
      }
    }
  } finally {
    finished = true;
    requestSignal?.removeEventListener("abort", onAbort);
    if (!clientDisconnected) reader.releaseLock();
    timing?.markStreamComplete();
    resolveUsage(usage);
    try {
      await writer.close();
    } catch (err) {
      console.warn(
        "[Gateway Proxy] pump writer.close (non-fatal)",
        err instanceof Error ? err.message : String(err),
        { clientDisconnected, usageCancelled: usage.cancelled }
      );
    }
    await cancellation;
    if (clientDisconnected) reader.releaseLock();
  }
  return cleanupConfirmed ? "confirmed" : "unconfirmed";
}
function streamResponseWithUsage(response, requestSignal, timing, publicModelId, publicProviderName, publicCorrelationId) {
  let resolveUsage;
  const usagePromise = new Promise((resolve) => {
    resolveUsage = resolve;
  });
  const usage = { ...EMPTY_USAGE_LOCAL };
  let stopDownstream;
  const { readable, writable } = new TransformStream({
    // Preserve graceful read-side cancellation while rejecting blocked writes.
    start(controller) {
      stopDownstream = () => controller.terminate();
    }
  });
  const resourceCompletion = pumpWithUsageTracking(
    response.body,
    writable,
    usage,
    resolveUsage,
    stopDownstream,
    requestSignal,
    timing,
    publicModelId,
    publicProviderName,
    publicCorrelationId
  ).catch(() => "unconfirmed");
  return {
    response: new Response(readable, {
      status: response.status,
      headers: {
        "Content-Type": response.headers.get("Content-Type") ?? "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive"
      }
    }),
    usagePromise,
    resourceCompletion
  };
}
async function nonStreamResponseWithUsage(response, timing, publicModelId, publicCorrelationId, requestSignal) {
  const materialized = await readBoundedTextJsonObject(response, {
    skin: "chat",
    requestId: publicCorrelationId,
    signal: requestSignal
  });
  timing?.markStreamComplete();
  if (!materialized.ok) {
    return {
      response: materialized.response,
      usagePromise: Promise.resolve({ ...EMPTY_USAGE_LOCAL }),
      meta: materialized.meta
    };
  }
  const parsed = materialized.value;
  if (!validChatSuccessResponse(parsed)) {
    const invalid = invalidTextSuccessResponse({
      skin: "chat",
      protocol: "Chat Completions",
      requestId: publicCorrelationId
    });
    return {
      ...invalid,
      usagePromise: Promise.resolve({ ...EMPTY_USAGE_LOCAL })
    };
  }
  const providerUsage = parsed.usage;
  if (providerUsage && Object.prototype.hasOwnProperty.call(providerUsage, "speed")) {
    providerUsage.speed = normalizeResponseTextSpeed(
      providerUsage.speed
    );
  }
  let usage = providerUsage != null ? usageFromProvider(providerUsage) : { ...EMPTY_USAGE_LOCAL };
  const msgId = normalizeUpstreamId(parsed.id);
  if (msgId) usage = { ...usage, upstreamMessageId: msgId };
  const primaryChoice = parsed.choices.find((choice) => choice.index === 0) ?? parsed.choices[0];
  if (primaryChoice) {
    usage.finish_reason = normalizeCanonicalFinishReason(primaryChoice.finish_reason);
    usage.native_finish_reason = normalizeNativeFinishReason(
      primaryChoice.native_finish_reason ?? primaryChoice.finish_reason
    );
  }
  const generationId = normalizeUpstreamId(publicCorrelationId);
  if (generationId) parsed.id = generationId;
  if (publicModelId) parsed.model = publicModelId;
  const serviceTier = normalizeOpenAiResponseServiceTier(parsed.service_tier);
  parsed.service_tier = serviceTier;
  usage.service_tier = serviceTier;
  return {
    response: rebuildTextJsonResponse(response, parsed),
    usagePromise: Promise.resolve(usage)
  };
}
async function dispatchOpenAiRoute(route2, body, requestSignal, timing, attempt, beforeFetch, publicCorrelationId, auxiliaryAuth, upstreamHeadersObserved) {
  const url = resolveUpstreamEndpoint("openai", "chat", route2.providerEndpoints, {
    providerId: route2.providerId
  });
  assertTextUpstreamHttpUrl(url);
  const routeIdentity = beforeFetch ? captureTextRouteIdentity(route2) : null;
  const cancelledBeforeDispatch = () => ({
    response: preDispatchCancelledTextResponse("chat", publicCorrelationId),
    usagePromise: Promise.resolve({ ...EMPTY_USAGE_LOCAL, cancelled: true }),
    upstreamRequestId: null,
    meta: {
      failoverForbidden: true,
      gatewayGeneratedError: true
    }
  });
  if (requestSignal?.aborted) return cancelledBeforeDispatch();
  const requestBody = ensureOpenAiStreamIncludesUsage({
    ...buildRouteRequestBody(route2, body),
    model: applyVertexOpenAiModelPrefix(url, route2.providerModelName)
  });
  return withOwnedJsonUpload(requestBody, requestSignal, async (upload) => {
    const { secret } = await resolveProviderUpstreamSecret(route2.providerApiKey, { signal: requestSignal, auxiliaryAuth });
    const headers = {
      "Content-Type": "application/json",
      "Content-Length": String(upload.contentLength),
      Authorization: `Bearer ${secret}`
    };
    new Headers(headers);
    if (requestSignal?.aborted) return cancelledBeforeDispatch();
    if (beforeFetch) {
      let outboundBodyCanonicalSha256;
      try {
        outboundBodyCanonicalSha256 = await canonicalChatJsonSha256(upload.preparedSnapshot);
      } catch {
      }
      const prepared = createPreparedTextAttempt({
        routeIdentity,
        url,
        method: "POST",
        headers,
        outboundBodySha256: await upload.digestSha256(),
        outboundBodyBytes: upload.contentLength,
        outboundBodyCanonicalSha256
      });
      await beforeFetch(prepared);
    }
    if (requestSignal?.aborted) return cancelledBeforeDispatch();
    let response;
    try {
      const init = {
        method: "POST",
        // A redirect is another unbudgeted dispatch and may forward credentials.
        redirect: "manual",
        headers,
        body: upload.body,
        duplex: "half",
        signal: requestSignal
      };
      response = await fetch(url, init);
    } catch (error) {
      throw markUpstreamOutcomeUnknown(error);
    }
    upstreamHeadersObserved?.(response.status);
    timing?.markAttemptHeaders(attempt, response.status);
    const upstreamRequestId = extractUpstreamRequestId(response.headers);
    const normalizedContentType = (response.headers.get("Content-Type") ?? "").toLowerCase();
    const streamRequested = requestBody.stream === true;
    if (response.ok && streamRequested && response.body && normalizedContentType.includes("text/event-stream")) {
      const result = streamResponseWithUsage(
        response,
        requestSignal,
        timing,
        route2.gatewayModelId,
        route2.providerName,
        publicCorrelationId
      );
      return { ...result, upstreamRequestId };
    }
    const owned = ownUpstreamResponse(response, requestSignal);
    response = owned.response;
    if (response.ok) {
      if (!streamRequested && normalizedContentType.includes("application/json")) {
        const result = await nonStreamResponseWithUsage(
          response,
          timing,
          route2.gatewayModelId,
          publicCorrelationId,
          requestSignal
        );
        return { ...result, upstreamRequestId, resourceCompletion: owned.resourceCompletion };
      }
      const invalid = await cancelInvalidTextSuccessResponse(response, {
        skin: "chat",
        protocol: "Chat Completions",
        requestId: publicCorrelationId
      });
      timing?.markStreamComplete();
      return {
        ...invalid,
        usagePromise: Promise.resolve({ ...EMPTY_USAGE_LOCAL }),
        upstreamRequestId,
        resourceCompletion: owned.resourceCompletion
      };
    }
    return {
      response,
      usagePromise: Promise.resolve(EMPTY_USAGE_LOCAL),
      upstreamRequestId,
      resourceCompletion: owned.resourceCompletion,
      meta: ambiguousDispatchedStatusMeta(response.status)
    };
  });
}

// packages/proxy/src/services/text-usage-settlement.ts
function hasAuthoritativeTextUsage(usage) {
  return typeof usage.raw_usage === "string" && usage.raw_usage.length > 0 || usage.total_tokens > 0 || usage.input_tokens > 0 || usage.output_tokens > 0 || usage.reasoning_tokens > 0;
}
function textUsageCostIsUnknown(input) {
  if (input.upstreamOutcomeUnknown) return true;
  if (!input.upstreamResponseOk) return false;
  return !input.usageAvailable || input.cancelled === true || input.streamError === true || input.responseBodyTooLarge === true || input.serviceTierPricingUnknown === true;
}

// product-sse-cancel-worker.mjs
var streamPath = "/fixture/product-sse";
var minimalPath = "/fixture/minimal-readable";
function localURL(raw) {
  const url = new URL(raw);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port) throw Error("owned loopback only");
  return url;
}
async function observe(env, caseId, kind, value) {
  const target = localURL(env.OBSERVATION_URL);
  const response = await fetch(target, { method: "POST", redirect: "manual", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ caseId, kind, value, workerWallTime: Date.now() }) });
  if (response.status !== 204) throw Error("observation was not recorded");
  await response.body?.cancel();
}
function route(base) {
  return { targetId: "synthetic", providerId: "synthetic", providerName: "synthetic", providerModelName: "synthetic", gatewayModelId: "public/synthetic", upstreamProtocol: "openai", upstreamOperation: "chat", adapter: "passthrough", providerEndpoints: { openai: { base } }, providerApiKey: "synthetic-only", customParams: null, routeGroup: "default", routePriority: 0, routeWeight: 1 };
}
var product_sse_cancel_worker_default = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname === "/fixture/warmup" && request.method === "GET") return new Response("owned-worker-ready");
    if (request.method !== "POST" || ![streamPath, minimalPath].includes(url.pathname)) return new Response(null, { status: 404 });
    const caseId = url.pathname === streamPath ? "product" : "minimal";
    console.log(JSON.stringify({ fixture: "product-sse-cancel", kind: "worker-entry", caseId, path: url.pathname, method: request.method, signalAvailable: Boolean(request.signal), upstreamBindingPresent: typeof env.UPSTREAM_BASE === "string", observationBindingPresent: typeof env.OBSERVATION_URL === "string" }));
    request.signal.addEventListener("abort", () => {
      ctx.waitUntil(observe(env, caseId, "request-signal-aborted", { aborted: request.signal.aborted }));
    }, { once: true });
    await observe(env, caseId, "request-start", { signalInitiallyAborted: request.signal.aborted });
    if (caseId === "minimal") {
      let timer;
      let chunks = 0;
      let stopped = false;
      const body = new ReadableStream({
        start(controller) {
          timer = setInterval(() => {
            if (stopped) return;
            if (++chunks > 400) {
              stopped = true;
              clearInterval(timer);
              controller.error(Error("minimal stream ceiling"));
              return;
            }
            try {
              controller.enqueue(new TextEncoder().encode("data: " + JSON.stringify({ minimal: true, sequence: chunks }) + "\n\n"));
            } catch (error) {
              stopped = true;
              clearInterval(timer);
              ctx.waitUntil(observe(env, caseId, "minimal-enqueue-error", { chunks, message: String(error.message) }));
            }
          }, 40);
        },
        cancel() {
          stopped = true;
          clearInterval(timer);
          return observe(env, caseId, "minimal-source-cancel", { chunks, stopped: true });
        }
      });
      return new Response(body, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-store" } });
    }
    const upstream = localURL(env.UPSTREAM_BASE);
    const result = await dispatchOpenAiRoute(route(upstream.href), { stream: true }, request.signal);
    if (!result.resourceCompletion || typeof result.resourceCompletion.then !== "function") throw Error("real driver resourceCompletion missing");
    const usageTask = result.usagePromise.then((usage) => observe(env, caseId, "usage-settled", {
      usage,
      costUnknown: textUsageCostIsUnknown({ upstreamResponseOk: result.response.ok, usageAvailable: hasAuthoritativeTextUsage(usage), cancelled: usage.cancelled === true, streamError: Boolean(usage.stream_error), upstreamOutcomeUnknown: result.meta?.upstreamOutcomeUnknown === true, responseBodyTooLarge: result.meta?.responseBodyTooLarge === true })
    }));
    const resourceTask = result.resourceCompletion.then((outcome) => observe(env, caseId, "resource-completion-settled", { outcome }));
    ctx.waitUntil(Promise.all([usageTask, resourceTask]).catch((error) => {
      console.error(JSON.stringify({ fixture: "product-sse-cancel", kind: "observer-failed", caseId, message: String(error.message) }));
      throw error;
    }));
    return result.response;
  }
};
export {
  product_sse_cancel_worker_default as default
};
